# Micah

## Chapter 1

**<sup>1</sup>** The word of the LORD that came to Micah of Moresheth in the days of Jotham, Ahaz, and Hezekiah, kings of Judah, which he saw concerning Samaria and Jerusalem. **<sup>2</sup>** Hear, O you nations, all of you; listen, O earth and all that is in it. And let the Lord GOD be a witness against you, the Lord from His holy temple. **<sup>3</sup>** For behold, the LORD is coming out of His place, and He will come down and tread upon the high places of the earth.

**<sup>4</sup>** The mountains shall melt beneath Him, and the valleys will split apart like wax before the fire, like waters poured down a steep place. **<sup>5</sup>** All this is because of the transgression of Jacob and because of the sins of the house of Israel. What is the transgression of Jacob? Is it not Samaria? And what are the high places of Judah? Are they not Jerusalem?

**<sup>6</sup>** Therefore I will make Samaria a heap in the open country, a place for planting vineyards; and I will pour down her stones into the valley and lay bare her foundations. **<sup>7</sup>** All her carved images shall be broken in pieces, and all her earnings shall be burned with fire, and all her idols I will destroy. For from the wages of a harlot she gathered them, and to the wages of a harlot they shall return.

**<sup>8</sup>** Because of this I will lament and wail; I will go barefoot and naked; I will make a wailing like jackals and a mourning like ostriches. **<sup>9</sup>** For her wound is incurable, and it has come to Judah; it has reached the gate of my people, to Jerusalem.

**<sup>10</sup>** Do not tell it in Gath; do not weep at all. In Beth-leaphrah, roll yourself in the dust. **<sup>11</sup>** Pass on, O inhabitant of Shaphir, in nakedness and shame; the inhabitant of Zaanan has not come out. The lamentation of Beth-ezel will take away its support from you. **<sup>12</sup>** For the inhabitant of Maroth trembled for good, because disaster has come down from the LORD to the gate of Jerusalem. **<sup>13</sup>** Harness the chariot to the steeds, O inhabitant of Lachish. She was the beginning of sin for the daughter of Zion, for in you were found the transgressions of Israel. **<sup>14</sup>** Therefore you shall give parting gifts to Moresheth-gath. The houses of Achzib shall be a deception to the kings of Israel. **<sup>15</sup>** I will again bring a conqueror to you, O inhabitant of Mareshah. The glory of Israel shall come to Adullam.

**<sup>16</sup>** Shave yourself bald and cut off your hair for the sons of your delight; enlarge your baldness like the eagle, for they have gone from you into exile. 

## Chapter 2

**<sup>1</sup>** Woe to those who devise wickedness and plan evil on their beds! At morning light they do it, because it is in the power of their hand. **<sup>2</sup>** They covet fields and seize them, and houses, and take them away; they oppress a man and his house, a man and his inheritance.

**<sup>3</sup>** Therefore thus says the LORD: Behold, I am planning evil against this clan, from which you shall not remove your necks; and you shall not walk haughtily, for it will be an evil time. **<sup>4</sup>** In that day one shall take up a taunt against you and lament with bitter lamentation, saying, “We are utterly ruined! He changes the portion of my people; how He removes it from me! To the unfaithful He allots our fields.” **<sup>5</sup>** Therefore you shall have none who casts the measuring line by lot in the assembly of the LORD.

**<sup>6</sup>** “Do not preach”—thus they preach—“one should not preach of such things; disgrace will not overtake us.” **<sup>7</sup>** Shall it be said, O house of Jacob, “Is the Spirit of the LORD impatient? Are these His deeds?” Do not My words do good to him who walks uprightly? **<sup>8</sup>** But lately My people has risen up as an enemy; you strip the robe from off the garment from those who pass by securely, as men averse to war. **<sup>9</sup>** The women of My people you drive out from their pleasant houses; from their young children you take away My splendor forever.

**<sup>10</sup>** Arise and go, for this is no resting place, because of uncleanness that destroys, even with a grievous destruction. **<sup>11</sup>** If a man walking in wind and falsehood lies, saying, “I will preach to you of wine and strong drink,” he would be the preacher for this people.

**<sup>12</sup>** I will surely gather all of you, O Jacob; I will surely assemble the remnant of Israel; I will put them together like sheep in a fold, like a flock in the midst of its pasture—a noisy multitude of men. **<sup>13</sup>** He who breaks through has gone up before them; they have broken through and passed the gate and gone out by it. And their king passes on before them, the LORD at their head. 

## Chapter 3

**<sup>1</sup>** And I said, “Hear now, heads of Jacob and rulers of the house of Israel: Is it not for you to know justice? **<sup>2</sup>** You who hate good and love evil, who tear off their skin from them and their flesh from off their bones, **<sup>3</sup>** who eat the flesh of my people, and flay their skin from off them, and break their bones, and chop them up like meat for the pot, like flesh in the midst of a caldron.”

**<sup>4</sup>** Then they will cry to the LORD, but He will not answer them; He will hide His face from them at that time, because they have practiced evil deeds.

**<sup>5</sup>** Thus says the LORD concerning the prophets who lead my people astray, who bite with their teeth and cry, “Peace,” but whoever does not put something in their mouths, they sanctify war against him: **<sup>6</sup>** "Therefore it shall be night to you, without vision, and darkness to you, without divination. And the sun shall go down on the prophets, and the day shall grow dark over them. **<sup>7</sup>** The seers shall be ashamed, and the diviners confounded; they shall all cover their lips, for there is no answer from God."

**<sup>8</sup>** But as for me, I am filled with power—by the Spirit of the LORD—and with justice and might, to declare to Jacob his transgression and to Israel his sin.

**<sup>9</sup>** Hear this, now, heads of the house of Jacob and rulers of the house of Israel, who abhor justice and twist everything that is straight, **<sup>10</sup>** who build Zion with bloodshed and Jerusalem with injustice: **<sup>11</sup>** "Her heads render judgment for a bribe, her priests teach for a price, and her prophets divine for silver—yet they lean on the LORD, saying, 'Is not the LORD in our midst? No evil shall come upon us.'"

**<sup>12</sup>** Therefore because of you, Zion shall be plowed as a field, and Jerusalem shall become a heap of ruins, and the mountain of the house a wooded height. 

## Chapter 4

**<sup>1</sup>** But it shall come to pass in the latter days that the mountain of the house of the LORD shall be established as the highest of the mountains, and it shall be lifted up above the hills, and peoples shall stream to it. **<sup>2</sup>** And many nations shall come and say, “Come, let us go up to the mountain of the LORD, and to the house of the God of Jacob, that He may teach us His ways, and we may walk in His paths.” For out of Zion shall go forth the law, and the word of the LORD from Jerusalem. **<sup>3</sup>** And He shall judge between many peoples, and shall decide for strong nations far away; and they shall beat their swords into plowshares, and their spears into pruning hooks; nation shall not lift up sword against nation, nor shall they learn war anymore. **<sup>4</sup>** But every man shall sit under his vine and under his fig tree, and none shall make them afraid, for the mouth of the LORD of hosts has spoken. **<sup>5</sup>** For all the peoples walk, each in the name of his god, but we will walk in the name of the LORD our God forever and ever.

**<sup>6</sup>** “In that day,” declares the LORD, “I will gather the lame and assemble the outcast and those whom I have afflicted. **<sup>7</sup>** And I will make the lame a remnant, and the outcast a strong nation; and the LORD shall reign over them on Mount Zion from now on and forever. **<sup>8</sup>** And you, O tower of the flock, hill of the daughter of Zion, to you it shall come—yes, the former dominion shall come, the kingdom to the daughter of Jerusalem.”

**<sup>9</sup>** Now why do you cry aloud? Is there no king in you? Has your counselor perished, that pangs have seized you like a woman in labor? **<sup>10</sup>** Writhe and groan, O daughter of Zion, like a woman in labor, for now you shall go out from the city and dwell in the field and go to Babylon. There you shall be rescued; there the LORD will redeem you from the hand of your enemies.

**<sup>11</sup>** Now many nations have gathered against you, saying, “Let her be defiled, and let our eyes gaze upon Zion.” **<sup>12</sup>** But they do not know the thoughts of the LORD, and they do not understand His counsel, for He has gathered them like sheaves to the threshing floor. **<sup>13</sup>** Arise and thresh, O daughter of Zion, for I will make your horn iron, and I will make your hooves bronze; and you shall crush many peoples, and you shall devote their unjust gain to the LORD, and their wealth to the Lord of all the earth. 

## Chapter 5

**<sup>1</sup>** Now muster your troops, O daughter of troops; a siege has been laid against us. With a rod they strike the judge of Israel on the cheek. **<sup>2</sup>** But you, Bethlehem Ephrathah, too little to be among the clans of Judah, from you shall come forth for Me one who is to be ruler in Israel, whose origin is from of old, from ancient days. **<sup>3</sup>** Therefore He shall give them up until the time when she who is in labor has given birth; then the remnant of His brothers shall return to the children of Israel. **<sup>4</sup>** And He shall stand and shepherd His flock in the strength of the LORD, in the majesty of the name of the LORD His God. And they shall dwell secure, for now He shall be great to the ends of the earth.

**<sup>5</sup>** And He shall be their peace. When the Assyrian comes into our land and treads in our palaces, then we will raise against him seven shepherds and eight princes of men. **<sup>6</sup>** And they shall shepherd the land of Assyria with the sword, and the land of Nimrod at its entrances. And He shall deliver us from the Assyrian when he comes into our land and treads within our borders.

**<sup>7</sup>** Then the remnant of Jacob shall be in the midst of many peoples like dew from the LORD, like showers on the grass, which do not wait for man nor delay for the sons of men. **<sup>8</sup>** And the remnant of Jacob shall be among the nations, in the midst of many peoples, like a lion among the beasts of the forest, like a young lion among flocks of sheep, who, when he passes through, tramples and tears in pieces, and there is none to deliver.

**<sup>9</sup>** Your hand shall be lifted up over your adversaries, and all your enemies shall be cut off. **<sup>10</sup>** "And in that day," declares the LORD, "I will cut off your horses from among you and will destroy your chariots. **<sup>11</sup>** And I will cut off the cities of your land and throw down all your strongholds. **<sup>12</sup>** And I will cut off sorceries from your hand, and you shall have no more soothsayers. **<sup>13</sup>** And I will cut off your carved images and your pillars from among you, and you shall bow down no more to the work of your hands. **<sup>14</sup>** And I will root out your Asherim from among you and destroy your cities. **<sup>15</sup>** And I will execute vengeance in anger and wrath on the nations that did not obey." 

## Chapter 6

**<sup>1</sup>** Hear now what the LORD says: "Arise, plead your case before the mountains, and let the hills hear your voice. **<sup>2</sup>** Hear, O mountains, the indictment of the LORD, and you enduring foundations of the earth, for the LORD has a case against His people, and with Israel He will contend."

**<sup>3</sup>** O My people, what have I done to you? And how have I wearied you? Answer Me. **<sup>4</sup>** For I brought you up from the land of Egypt and redeemed you from the house of bondage, and I sent before you Moses, Aaron, and Miriam. **<sup>5</sup>** O My people, remember now what Balak king of Moab devised, and what Balaam son of Beor answered him, and what happened from Shittim to Gilgal, that you may know the righteous acts of the LORD.

**<sup>6</sup>** With what shall I come before the LORD and bow down to God on high? Shall I come before Him with burnt offerings, with calves a year old? **<sup>7</sup>** Will the LORD be pleased with thousands of rams, with ten thousand rivers of oil? Shall I give my firstborn for my transgression, the fruit of my body for the sin of my soul?

**<sup>8</sup>** He has told you, O man, what is good; and what does the LORD require of you but to do justice, to love mercy, and to walk humbly with your God?

**<sup>9</sup>** The voice of the LORD calls to the city— wisdom fears Your name— hear the rod and Him who appointed it. **<sup>10</sup>** Are there still treasures of wickedness in the house of the wicked, and the scant measure that is accursed? **<sup>11</sup>** Shall I acquit a man with dishonest scales, with a bag of false weights? **<sup>12</sup>** Her rich men are full of violence, her inhabitants speak lies, and their tongue is deceitful in their mouth.

**<sup>13</sup>** Therefore I will also strike you with a grievous blow, making you desolate because of your sins. **<sup>14</sup>** You shall eat, but not be satisfied, and your emptiness shall remain within you; you shall store up, but not preserve, and what you preserve I will give to the sword. **<sup>15</sup>** You shall sow, but not reap; you shall tread olives, but not anoint yourself with oil; and grapes, but not drink wine. **<sup>16</sup>** For the statutes of Omri are kept, and all the works of the house of Ahab, and you walk in their counsels, that I may make you a desolation and your inhabitants a hissing. Therefore you shall bear the reproach of My people. 

## Chapter 7

**<sup>1</sup>** Woe is me! For I have become like one who gathers summer fruit, like gleanings of the grape harvest— there is no cluster to eat, no first-ripe fig that my soul desires. **<sup>2</sup>** The godly has perished from the land, and there is no upright among men; all of them lie in wait for blood; each hunts his brother with a net. **<sup>3</sup>** Both hands are skilled to do evil; the prince demands, and the judge is ready for a bribe, and the great man utters the evil desire of his soul— thus they weave it together.

**<sup>4</sup>** The best of them is like a brier; the most upright is worse than a thorn hedge. The day of your watchmen— your punishment— has come; now shall be their confusion. **<sup>5</sup>** Do not trust in a companion, do not rely on a close friend; guard the doors of your mouth from her who lies in your bosom. **<sup>6</sup>** For son dishonors father, daughter rises up against her mother, daughter-in-law against her mother-in-law; a man’s enemies are the men of his own household.

**<sup>7</sup>** But as for me, I will look to the LORD; I will wait for the God of my salvation; my God will hear me. **<sup>8</sup>** Rejoice not over me, O my enemy! When I fall, I shall arise; when I sit in darkness, the LORD will be a light to me. **<sup>9</sup>** I will bear the indignation of the LORD because I have sinned against Him, until He pleads my cause and executes judgment for me. He will bring me out to the light; I shall behold His righteousness. **<sup>10</sup>** Then my enemy will see, and shame will cover her who said to me, “Where is the LORD your God?” My eyes will look upon her; now she will be trampled like mud in the streets.

**<sup>11</sup>** A day for building your walls— on that day the boundary shall be extended. **<sup>12</sup>** In that day they will come to you, from Assyria and the cities of Egypt, and from Egypt to the River, from sea to sea, and from mountain to mountain. **<sup>13</sup>** But the earth shall be desolate because of its inhabitants, for the fruit of their deeds.

**<sup>14</sup>** Shepherd Your people with Your staff, the flock of Your inheritance, who dwell alone in a forest in the midst of a garden land. Let them graze in Bashan and Gilead as in the days of old. **<sup>15</sup>** As in the days when you came out of the land of Egypt, I will show them wondrous things. **<sup>16</sup>** Nations shall see and be ashamed of all their might; they shall lay their hands on their mouths; their ears shall be deaf. **<sup>17</sup>** They shall lick the dust like a serpent, like crawling things of the earth; they shall come trembling out of their strongholds; to the LORD our God they shall turn in dread, and they shall be afraid before You.

**<sup>18</sup>** Who is a God like You, pardoning iniquity and passing over the transgression of the remnant of His heritage? He does not retain His anger forever, because He delights in steadfast love. **<sup>19</sup>** He will again have compassion on us; He will tread our iniquities underfoot. You will cast all their sins into the depths of the sea. **<sup>20</sup>** You will show faithfulness to Jacob and steadfast love to Abraham, as You swore to our fathers from days of old. 