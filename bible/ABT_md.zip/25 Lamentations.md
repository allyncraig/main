# The Lamentations of Jeremiah

## Chapter 1

**<sup>1</sup>** How lonely sits the city that was full of people!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;She has become like a widow, she who was great among the nations!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;She who was a princess among the provinces has become a slave.

**<sup>2</sup>** She weeps bitterly in the night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her tears are on her cheeks;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;among all her lovers there is none to comfort her.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All her friends have dealt treacherously with her;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have become her enemies.

**<sup>3</sup>** Judah has gone into exile under affliction<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and under harsh servitude;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she dwells among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but finds no rest.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All her pursuers have overtaken her<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the midst of distress.

**<sup>4</sup>** The roads of Zion mourn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because none come to the appointed feasts;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all her gates are desolate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her priests groan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her virgins grieve,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and she herself is bitter.

**<sup>5</sup>** Her adversaries have become her masters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her enemies prosper,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the LORD has afflicted her<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the multitude of her transgressions;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her little ones have gone away captive<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the foe.

**<sup>6</sup>** From the daughter of Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all her splendor has departed.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Her princes have become like deer<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that find no pasture;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they fled without strength<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the pursuer.

**<sup>7</sup>** In the days of her affliction and wandering,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jerusalem remembers all her precious things<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that were from the days of old.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;When her people fell into the hand of the enemy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no one helped her,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the adversaries saw her and mocked<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at her downfall.

**<sup>8</sup>** Jerusalem has grievously sinned;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore she has become unclean.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All who honored her despise her,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they have seen her nakedness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she herself groans<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and turns away.

**<sup>9</sup>** Her uncleanness was in her skirts;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she did not consider her latter end.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Therefore she has fallen astonishingly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she has no comforter.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“See, O LORD, my affliction,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the enemy has magnified himself.”

**<sup>10</sup>** The adversary has stretched out his hand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;over all her precious things;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for she has seen the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;enter her sanctuary,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those whom You commanded<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they should not enter Your assembly.

**<sup>11</sup>** All her people groan<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as they search for bread;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have given their precious things for food<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to restore their lives.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“See, O LORD, and look,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am despised.”

**<sup>12</sup>** “Is it nothing to you, all who pass by?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Look and see if there is any sorrow like my sorrow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which has been brought upon me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which the LORD inflicted<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day of His fierce anger.

**<sup>13</sup>** From on high He sent fire into my bones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it prevailed against them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has spread a net for my feet,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has turned me back;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has made me desolate<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and faint all the day long.

**<sup>14</sup>** The yoke of my transgressions is bound by His hand;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are knit together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have come up upon my neck;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has made my strength fail.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The Lord has given me into the hands<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of those whom I cannot withstand.

**<sup>15</sup>** The Lord has rejected<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all my mighty men in my midst;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has called an assembly against me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to crush my young men.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The Lord has trodden as in a winepress<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the virgin daughter of Judah.

**<sup>16</sup>** For these things I weep;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my eyes flow with tears,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for a comforter is far from me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;one to restore my life.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My children are desolate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the enemy has prevailed.”

**<sup>17</sup>** Zion stretches out her hands,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but there is no one to comfort her;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD has commanded against Jacob<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that his neighbors should be his adversaries;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jerusalem has become<br/>
&nbsp;&nbsp;&nbsp;&nbsp;an unclean thing among them.

**<sup>18</sup>** “The LORD is righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have rebelled against His commandment.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hear, all peoples, and see my sorrow;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my virgins and my young men<br/>
&nbsp;&nbsp;&nbsp;&nbsp;have gone into captivity.

**<sup>19</sup>** I called to my lovers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but they deceived me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my priests and my elders perished in the city<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while they sought food for themselves<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to restore their lives.

**<sup>20</sup>** See, O LORD, for I am in distress;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my spirit is greatly troubled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my heart is overturned within me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have been very rebellious.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In the street the sword bereaves;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the house it is like death.

**<sup>21</sup>** They have heard that I sigh;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is none to comfort me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All my enemies have heard of my trouble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are glad that You have done it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Bring the day that You have proclaimed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they may become like me.

**<sup>22</sup>** Let all their wickedness come before You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and deal with them as You have dealt with me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of all my transgressions;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for my sighs are many,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my heart is faint.”<br/>


## Chapter 2

**<sup>1</sup>** How the Lord in His anger<br/>
&nbsp;&nbsp;&nbsp;&nbsp;has covered the daughter of Zion with a cloud!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has cast down from heaven to earth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the splendor of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and has not remembered His footstool<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day of His anger.

**<sup>2</sup>** The Lord has swallowed up without mercy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the habitations of Jacob;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has torn down in His wrath the strongholds<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of the daughter of Judah;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has brought them down to the ground;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has profaned the kingdom and its princes.

**<sup>3</sup>** In fierce anger He has cut off<br/>
&nbsp;&nbsp;&nbsp;&nbsp;every horn of Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has withdrawn His right hand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from before the enemy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has burned against Jacob like a flaming fire<br/>
&nbsp;&nbsp;&nbsp;&nbsp;consuming all around.

**<sup>4</sup>** He has bent His bow like an enemy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has set His right hand like an adversary<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and slain all that were pleasant to the eye;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the tent of the daughter of Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has poured out His fury like fire.

**<sup>5</sup>** The Lord has become like an enemy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has swallowed up Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has swallowed up all her palaces;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has destroyed her strongholds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and multiplied in the daughter of Judah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;mourning and lamentation.

**<sup>6</sup>** He has violently treated His tabernacle like a garden hut;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has destroyed His appointed meeting place.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD has caused the appointed feast and Sabbath to be forgotten in Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in the indignation of His anger has despised king and priest.

**<sup>7</sup>** The Lord has rejected His altar;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has abandoned His sanctuary;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has delivered into the hand of the enemy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the walls of her palaces.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They have raised a cry in the house of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as on the day of an appointed feast.

**<sup>8</sup>** The LORD determined to destroy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the wall of the daughter of Zion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He stretched out the measuring line;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He did not withdraw His hand from destroying;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He made rampart and wall lament;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they languish together.

**<sup>9</sup>** Her gates have sunk into the ground;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has destroyed and broken her bars;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her king and her princes are among the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the law is no more,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her prophets find no vision from the LORD.

**<sup>10</sup>** The elders of the daughter of Zion sit on the ground and keep silence;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have thrown dust on their heads;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have girded themselves with sackcloth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the virgins of Jerusalem hang down their heads to the ground.

**<sup>11</sup>** My eyes fail because of tears,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my spirit is troubled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my heart is poured out on the ground<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the destruction of the daughter of my people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when the little ones and infants faint<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the streets of the city.

**<sup>12</sup>** They say to their mothers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Where is grain and wine?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as they faint like wounded men<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the streets of the city,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as their life is poured out<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on their mothers’ bosom.

**<sup>13</sup>** What can I say for you?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What can I compare to you, O daughter of Jerusalem?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What can I liken to you that I may comfort you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O virgin daughter of Zion?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For your ruin is vast as the sea;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who can heal you?

**<sup>14</sup>** Your prophets have seen for you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;vain and foolish things;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have not exposed your iniquity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to restore your fortunes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but have seen for you oracles<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of falsehood and delusion.

**<sup>15</sup>** All who pass along the way clap their hands at you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they hiss and shake their heads<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the daughter of Jerusalem, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Is this the city that was called<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the perfection of beauty,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the joy of the whole earth?”

**<sup>16</sup>** All your enemies open their mouths wide against you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they hiss and gnash their teeth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“We have swallowed her up!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Surely this is the day we have waited for;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we have found it, we have seen it.”

**<sup>17</sup>** The LORD has done what He purposed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has carried out His word<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which He commanded from days of old;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has thrown down without pity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and has caused the enemy to rejoice over you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has exalted the horn of your adversaries.

**<sup>18</sup>** Their heart cried out to the Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“O wall of the daughter of Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let tears run down like a river day and night;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give yourself no relief;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let not the apple of your eye cease.”

**<sup>19</sup>** “Arise, cry out in the night<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the beginning of the watches;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;pour out your heart like water<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the face of the Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lift up your hands toward Him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the life of your little ones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who faint for hunger<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the head of every street.”

**<sup>20</sup>** “Look, O LORD, and consider<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to whom You have done this!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Should women eat the fruit of their womb,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the children they have cared for?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Should priest and prophet be slain<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the sanctuary of the Lord?”

**<sup>21</sup>** The young and the old<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lie on the ground in the streets;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my virgins and my young men<br/>
&nbsp;&nbsp;&nbsp;&nbsp;have fallen by the sword;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have slain them in the day of Your anger;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have slaughtered without pity.

**<sup>22</sup>** You have summoned as on an appointed day<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my terrors on every side,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there was no one who escaped or survived<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day of the LORD’s anger;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those whom I have cared for and raised,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my enemy has destroyed.<br/>


## Chapter 3

**<sup>1</sup>** I am the man who has seen affliction<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by the rod of His wrath.<br/>
**<sup>2</sup>** He has driven me and brought me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;into darkness and not light.<br/>
**<sup>3</sup>** Surely against me He turns His hand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;again and again all the day.

**<sup>4</sup>** He has worn away my flesh and my skin;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has broken my bones.<br/>
**<sup>5</sup>** He has besieged me and surrounded me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with bitterness and hardship.<br/>
**<sup>6</sup>** He has made me dwell in dark places<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like those long dead.

**<sup>7</sup>** He has walled me in so I cannot escape;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has made my chains heavy.<br/>
**<sup>8</sup>** Even when I cry out and call for help,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He shuts out my prayer.<br/>
**<sup>9</sup>** He has blocked my ways with hewn stone;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has made my paths crooked.

**<sup>10</sup>** He is to me like a bear lying in wait,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a lion in hiding.<br/>
**<sup>11</sup>** He has turned aside my ways and torn me in pieces;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has made me desolate.<br/>
**<sup>12</sup>** He has bent His bow and set me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as the target for His arrow.

**<sup>13</sup>** He has caused the arrows of His quiver<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to pierce my inward parts.<br/>
**<sup>14</sup>** I have become the laughingstock of all my people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their song all the day.<br/>
**<sup>15</sup>** He has filled me with bitterness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has made me drunk with wormwood.

**<sup>16</sup>** He has broken my teeth with gravel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has covered me with ashes.<br/>
**<sup>17</sup>** My soul has been removed from peace;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have forgotten what prosperity is.<br/>
**<sup>18</sup>** So I said, “My strength is gone,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my hope from the LORD.”

**<sup>19</sup>** Remember my affliction and my wandering,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the wormwood and the gall.<br/>
**<sup>20</sup>** My soul continually remembers<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and is bowed down within me.<br/>
**<sup>21</sup>** Yet this I call to mind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and therefore I have hope:

**<sup>22</sup>** The LORD’s loyal love never ceases;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His compassions never fail.<br/>
**<sup>23</sup>** They are new every morning;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;great is Your faithfulness.<br/>
**<sup>24</sup>** “The LORD is my portion,” says my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“therefore I will hope in Him.”

**<sup>25</sup>** The LORD is good to those who wait for Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the soul who seeks Him.<br/>
**<sup>26</sup>** It is good that one should wait quietly<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the salvation of the LORD.<br/>
**<sup>27</sup>** It is good for a man<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to bear the yoke in his youth.

**<sup>28</sup>** Let him sit alone and be silent,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because He has laid it on him.<br/>
**<sup>29</sup>** Let him put his mouth in the dust—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;perhaps there is hope.<br/>
**<sup>30</sup>** Let him give his cheek to the one who strikes him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let him be filled with reproach.

**<sup>31</sup>** For the Lord will not<br/>
&nbsp;&nbsp;&nbsp;&nbsp;reject forever.<br/>
**<sup>32</sup>** Though He causes grief, He will have compassion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to the abundance of His steadfast love.<br/>
**<sup>33</sup>** For He does not willingly afflict<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or grieve the sons of man.

**<sup>34</sup>** To crush underfoot<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the prisoners of the earth,<br/>
**<sup>35</sup>** to deny a man justice<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the presence of the Most High,<br/>
**<sup>36</sup>** to subvert a man in his cause—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord does not approve.

**<sup>37</sup>** Who is there who speaks and it happens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;unless the Lord has commanded it?<br/>
**<sup>38</sup>** Is it not from the mouth of the Most High<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that both calamities and blessings come?<br/>
**<sup>39</sup>** Why should any living man comlain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a man for the punishment of his sins?

**<sup>40</sup>** Let us test and examine our ways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and return to the LORD.<br/>
**<sup>41</sup>** Let us lift up our hearts and hands<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to God in heaven:<br/>
**<sup>42</sup>** “We have transgressed and rebelled,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and You have not pardoned.

**<sup>43</sup>** You have wrapped Yourself in anger and pursued us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have slain without pity.<br/>
**<sup>44</sup>** You have covered Yourself with a cloud<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that no prayer can pass through.<br/>
**<sup>45</sup>** You have made us scum and refuse<br/>
&nbsp;&nbsp;&nbsp;&nbsp;among the nations.

**<sup>46</sup>** All our enemies have opened their mouths<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against us.<br/>
**<sup>47</sup>** Terror and pitfall have come upon us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;devastation and destruction.<br/>
**<sup>48</sup>** My eyes flow with streams of tears<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the destruction of the daughter of my people.

**<sup>49</sup>** My eyes flow unceasingly,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;without relief,<br/>
**<sup>50</sup>** until the LORD looks down<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and sees from heaven.<br/>
**<sup>51</sup>** My eyes bring pain to my soul<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of all the daughters of my city.”

**<sup>52</sup>** My enemies without cause<br/>
&nbsp;&nbsp;&nbsp;&nbsp;hunted me down like a bird.<br/>
**<sup>53</sup>** They silenced my life in the pit<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cast stones on me.<br/>
**<sup>54</sup>** Waters flowed over my head;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I said, “I am cut off.”

**<sup>55</sup>** I called on Your name, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the lowest pit.<br/>
**<sup>56</sup>** You heard my voice:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Do not close Your ear to my cry for relief,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to my cry for help.”<br/>
**<sup>57</sup>** You drew near when I called on You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You said, “Do not fear.”

**<sup>58</sup>** You have pleaded the causes of my soul, O Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have redeemed my life.<br/>
**<sup>59</sup>** You have seen, O LORD, the wrong done to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;judge my cause.<br/>
**<sup>60</sup>** You have seen all their vengeance,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all their plots against me.

**<sup>61</sup>** You have heard their reproach, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all their schemes against me,<br/>
**<sup>62</sup>** the lips of my enemies and their whispering<br/>
&nbsp;&nbsp;&nbsp;&nbsp;are against me all day long.<br/>
**<sup>63</sup>** Look at their sitting down and their rising up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am their song.

**<sup>64</sup>** You will repay them, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to the work of their hands.<br/>
**<sup>65</sup>** You will give them hardness of heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your curse will be on them.<br/>
**<sup>66</sup>** You will pursue them in anger and destroy them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from under the heavens of the LORD.<br/>


## Chapter 4

**<sup>1</sup>** How the gold has grown dim,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the fine gold changed!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The sacred stones lie scattered<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at every street corner.

**<sup>2</sup>** The precious sons of Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;worth their weight in pure gold—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how they are reckoned as clay jars,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the work of a potter’s hands!

**<sup>3</sup>** Even jackals offer the breast<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to nurse their young,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the daughter of my people has become cruel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like ostriches in the wilderness.

**<sup>4</sup>** The tongue of the nursing infant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sticks to its palate for thirst;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the children beg for bread,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but no one breaks it for them.

**<sup>5</sup>** Those who once feasted on delicacies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lie dying in the streets;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who were brought up in scarlet<br/>
&nbsp;&nbsp;&nbsp;&nbsp;now embrace ash heaps.

**<sup>6</sup>** The guilt of the daughter of my people<br/>
&nbsp;&nbsp;&nbsp;&nbsp;is greater than the sin of Sodom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which was overthrown in a moment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no hands were laid on her.

**<sup>7</sup>** Her princes were purer than snow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whiter than milk;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their bodies were more ruddy than coral,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their form like sapphire.

**<sup>8</sup>** Now their appearance is darker than soot;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are not recognized in the streets.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their skin has shriveled on their bones;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it has become dry as wood.

**<sup>9</sup>** Those slain by the sword<br/>
&nbsp;&nbsp;&nbsp;&nbsp;were better off than those slain by hunger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who waste away,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;pierced through for lack of the fruits of the field.

**<sup>10</sup>** The hands of compassionate women<br/>
&nbsp;&nbsp;&nbsp;&nbsp;have boiled their own children;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they became their food<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the destruction of the daughter of my people.

**<sup>11</sup>** The LORD has spent His fury;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has poured out His fierce anger.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He kindled a fire in Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it consumed her foundations.

**<sup>12</sup>** The kings of the earth did not believe,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor any of the inhabitants of the world,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that foe or enemy could enter<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the gates of Jerusalem.

**<sup>13</sup>** It was because of the sins of her prophets<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the iniquities of her priests,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who shed in her midst<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the blood of the righteous.

**<sup>14</sup>** They wandered, blind, through the streets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;defiled with blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that none could touch<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their garments.

**<sup>15</sup>** “Away! Unclean!” they cried to them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Away! Away! Do not touch!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So they fled and wandered;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it was said among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“They shall dwell here no longer.”

**<sup>16</sup>** The LORD Himself has scattered them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He no longer regards them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They did not honor the priests;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they showed no favor to the elders.

**<sup>17</sup>** Still our eyes failed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;watching vainly for help.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;We watched and watched<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for a nation that could not save.

**<sup>18</sup>** They hunted our steps<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that we could not walk in our streets.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Our end drew near; our days were finished,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for our end had come.

**<sup>19</sup>** Our pursuers were swifter<br/>
&nbsp;&nbsp;&nbsp;&nbsp;than the eagles of the sky.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They chased us on the mountains;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they lay in wait for us in the wilderness.

**<sup>20</sup>** The breath of our nostrils,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD’s anointed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;was captured in their pits—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he of whom we said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Under his shadow we shall live among the nations.”

**<sup>21</sup>** Rejoice and be glad,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O daughter of Edom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who dwell in the land of Uz!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But to you also the cup shall pass;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you shall become drunk and strip yourself bare.

**<sup>22</sup>** The punishment of your iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O daughter of Zion, is accomplished;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will no longer exile you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But He will punish your iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O daughter of Edom;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will expose your sins.<br/>


## Chapter 5

**<sup>1</sup>** Remember, O LORD, what has come upon us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;look and see our disgrace.<br/>
**<sup>2</sup>** Our inheritance has been turned over to strangers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our houses to foreigners.<br/>
**<sup>3</sup>** We have become orphans, fatherless;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our mothers are like widows.<br/>
**<sup>4</sup>** We must pay for the water we drink;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our wood comes at a price.<br/>
**<sup>5</sup>** We are pursued with a yoke on our necks;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we are weary, we find no rest.<br/>
**<sup>6</sup>** We have given our hand to Egypt<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to Assyria, to get enough bread.<br/>
**<sup>7</sup>** Our fathers sinned and are no more,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but we bear their iniquities.<br/>
**<sup>8</sup>** Servants rule over us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is none to deliver us from their hand.<br/>
**<sup>9</sup>** We get our bread at the peril of our lives<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the sword in the wilderness.<br/>
**<sup>10</sup>** Our skin burns like an oven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the scorching heat of famine.<br/>
**<sup>11</sup>** They ravished the women in Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the virgins in the towns of Judah.<br/>
**<sup>12</sup>** Princes were hung up by their hands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no respect was shown to the elders.<br/>
**<sup>13</sup>** Young men were made to grind at the mill,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and boys staggered under loads of wood.<br/>
**<sup>14</sup>** The elders have left the gate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the young men their music.<br/>
**<sup>15</sup>** The joy of our hearts has ceased;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our dance has turned into mourning.<br/>
**<sup>16</sup>** The crown has fallen from our head;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;woe to us, for we have sinned!<br/>
**<sup>17</sup>** Because of this our heart is faint;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of these things our eyes grow dim,<br/>
**<sup>18</sup>** because Mount Zion lies desolate;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;foxes prowl over it.<br/>
**<sup>19</sup>** You, O LORD, reign forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your throne endures from generation to generation.<br/>
**<sup>20</sup>** Why do You forget us forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;why do You forsake us so long?<br/>
**<sup>21</sup>** Restore us to Yourself, O LORD, that we may return;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;renew our days as of old—<br/>
**<sup>22</sup>** unless You have utterly rejected us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and are exceedingly angry with us.<br/>
