# Obadiah

## Chapter 1

**<sup>1</sup>** The vision of Obadiah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus says the Lord GOD concerning Edom:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;We have heard a report from the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and an envoy has been sent among the nations:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Rise up, and let us rise against her for battle!”<br/>
**<sup>2</sup>** Behold, I will make you small among the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you shall be utterly despised.<br/>
**<sup>3</sup>** The pride of your heart has deceived you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who dwell in the clefts of the rock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose habitation is lofty.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who can say in his heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Who will bring me down to the ground?”<br/>
**<sup>4</sup>** Though you soar aloft like the eagle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and though your nest is set among the stars,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from there I will bring you down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>5</sup>** If thieves came to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if plunderers came by night—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how you have been destroyed!—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;would they not steal only what they wanted?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If grape gatherers came to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;would they not leave gleanings?<br/>
**<sup>6</sup>** How Esau has been pillaged,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his hidden treasures sought out!<br/>
**<sup>7</sup>** All your allies have driven you to the border;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your confederates have deceived you and prevailed against you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who eat your bread have set a trap beneath you—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have no understanding.<br/>
**<sup>8</sup>** Will I not on that day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;destroy the wise men out of Edom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and understanding out of Mount Esau?<br/>
**<sup>9</sup>** And your mighty men shall be dismayed, O Teman,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that every man from Mount Esau<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be cut off by slaughter.<br/>
**<sup>10</sup>** Because of the violence against your brother Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shame shall cover you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you shall be cut off forever.

**<sup>11</sup>** On the day that you stood aloof,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day that strangers carried off his wealth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and foreigners entered his gates<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cast lots for Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you were like one of them.<br/>
**<sup>12</sup>** But you should not have gloated over your brother<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of his misfortune,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you should not have rejoiced over the sons of Judah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of their destruction,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you should not have spoken arrogantly<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of distress.<br/>
**<sup>13</sup>** You should not have entered the gate of my people<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of their disaster;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you should not have looked with gloating on his calamity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of his disaster,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor laid hands on his wealth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of his disaster.<br/>
**<sup>14</sup>** You should not have stood at the crossroads<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to cut down his fugitives;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you should not have handed over his survivors<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day of distress.

**<sup>15</sup>** For the day of the LORD is near all the nations.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;As you have done, it shall be done to you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your deeds shall return upon your own head.<br/>
**<sup>16</sup>** For just as you have drunk on my holy mountain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so shall all the nations drink continually;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall drink and gulp down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall be as though they had never been.<br/>
**<sup>17</sup>** But on Mount Zion there shall be those who escape,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall be holy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the house of Jacob shall possess their possessions.<br/>
**<sup>18</sup>** The house of Jacob shall be a fire,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the house of Joseph a flame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the house of Esau stubble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall burn them and consume them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there shall be no survivor for the house of Esau,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the LORD has spoken.

**<sup>19</sup>** Those of the Negev shall possess Mount Esau,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those of the Shephelah the land of the Philistines;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall possess the territory of Ephraim and the territory of Samaria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Benjamin shall possess Gilead.<br/>
**<sup>20</sup>** And the exiles of this host of the sons of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall possess the land of the Canaanites as far as Zarephath,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the exiles of Jerusalem who are in Sepharad<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall possess the cities of the Negev.<br/>
**<sup>21</sup>** Deliverers shall go up to Mount Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to judge the mountain of Esau,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the kingdom shall be the LORD’s.<br/>
