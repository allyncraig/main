# The Psalms

## Chapter 1

**<sup>1</sup>** Blessed is the man<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who does not walk in the counsel of the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor stand in the way of sinners,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor sit in the seat of scoffers.<br/>
**<sup>2</sup>** But his delight is in the law of the Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on His law he meditates day and night.<br/>
**<sup>3</sup>** He is like a tree planted by streams of water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which produces fruit in due season,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;its leaf does not wither;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he prospers in all that he does.

**<sup>4</sup>** The wicked are not so.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Rather, they are like chaff driven away by the wind.<br/>
**<sup>5</sup>** Therefore the wicked will not stand on the day of judgment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor sinners in the congregation of the righteous.<br/>
**<sup>6</sup>** For the Lord knows the way of the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the path of the wicked will fail.<br/>


## Chapter 2

**<sup>1</sup>** Why do the nations conspire<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the peoples plot in vain?<br/>
**<sup>2</sup>** The kings of the earth take their stand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the rulers gather together<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against the Lord and against His Messiah, saying,<br/>
**<sup>3</sup>** "Let us tear off their shackles<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and throw off their cords from us."<br/>
**<sup>4</sup>** The one sitting in heaven laughs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord mocks them.<br/>
**<sup>5</sup>** Then He speaks to them in His anger<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and terrifies them in His wrath:<br/>
**<sup>6</sup>** "I have installed My king<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on Zion, My holy mountain."

**<sup>7</sup>** I will proclaim this decree, the Lord said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"You are My son; today I have begotten you.<br/>
**<sup>8</sup>** Ask of Me, and I will give the nations as your inheritance<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the ends of the earth as your possession.<br/>
**<sup>9</sup>** You will break them with a rod of iron;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you will shatter them like pottery."

**<sup>10</sup>** Now therefore, O kings, be wise;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;be warned, O rulers of the earth.<br/>
**<sup>11</sup>** Serve the Lord with fear<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and rejoice with trembling.<br/>
**<sup>12</sup>** Kiss the son,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lest in His anger, you perish in the way,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for his wrath is quickly kindled.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Blessed are all who take refuge in him.<br/>


## Chapter 3

**<sup>1</sup>** Lord, how many are my foes!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Many rise up against me;<br/>
**<sup>2</sup>** many say about me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“There is no salvation for him in God.” Selah

**<sup>3</sup>** But You, O Lord, are a shield around me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my glory, and the One who lifts my head.<br/>
**<sup>4</sup>** I cry aloud to the Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He answers me from His holy mountain. Selah

**<sup>5</sup>** I lay down and slept;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I awoke, for the Lord sustains me.<br/>
**<sup>6</sup>** I will not fear the multitudes of people<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who have set themselves against me all around.<br/>
**<sup>7</sup>** Arise, O Lord! Save me, O my God!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For You strike all my enemies on the cheek;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You break the teeth of the wicked.<br/>
**<sup>8</sup>** Salvation belongs to the Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may Your blessing be upon Your people. Selah<br/>


## Chapter 4

**<sup>1</sup>** Answer me when I call, O God of my righteousness! You have given me relief when I was in distress; be gracious to me and hear my prayer. **<sup>2</sup>** O sons of men, how long will you turn my glory into shame? How long will you love vanity and seek after lies? **<sup>3</sup>** But know that the Lord has set apart the godly man for Himself; the Lord hears when I call to Him. **<sup>4</sup>** Tremble, and do not sin; meditate in your heart upon your bed and be still.

**<sup>5</sup>** Offer the sacrifices of righteousness and trust in the Lord. **<sup>6</sup>** Many say, “Who will show us any good?” Lift up the light of Your face upon us, O Lord! **<sup>7</sup>** You have put joy in my heart, more than when their grain and new wine abound. **<sup>8</sup>** In peace I will both lie down and sleep, for You alone, O Lord, make me dwell in safety. 

## Chapter 5

**<sup>1</sup>** Give ear to my words, O Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;consider my groaning.

**<sup>2</sup>** Listen to the sound of my cry,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my King and my God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for to You I pray.

**<sup>3</sup>** In the morning, O Lord, You hear my voice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the morning I lay my request before You and watch expectantly.

**<sup>4</sup>** For You are not a God who delights in wickedness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;evil does not dwell with You.

**<sup>5</sup>** The boastful will not stand before Your eyes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You hate all who do iniquity.

**<sup>6</sup>** You destroy those who speak lies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord abhors the man of bloodshed and deceit.

**<sup>7</sup>** But as for me, by Your great mercy I will enter Your house;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in fear of You, I will bow down toward Your holy temple.

**<sup>8</sup>** Lead me, O Lord, in Your righteousness because of my enemies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make Your way straight before me.

**<sup>9</sup>** For there is no truth in their mouth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their heart is destruction itself;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their throat is an open grave;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with their tongue they speak deceit.

**<sup>10</sup>** Make them bear their guilt, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them fall by their own schemes.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Cast them out for their many transgressions,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they have rebelled against You.

**<sup>11</sup>** But let all who take refuge in You rejoice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them sing for joy forever.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Spread Your protection over them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that those who love Your name may exult in You.

**<sup>12</sup>** For You bless the righteous, O Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You surround him with favor as with a shield.<br/>


## Chapter 6

**<sup>1</sup>** O Lord, do not rebuke me in Your anger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor discipline me in Your wrath.

**<sup>2</sup>** Be gracious to me, O Lord, for I am weak;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;heal me, O Lord, for my bones are troubled.

**<sup>3</sup>** My soul also is greatly troubled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but You, O Lord—how long?

**<sup>4</sup>** Turn, O Lord, deliver my soul;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;save me because of Your steadfast love.

**<sup>5</sup>** For in death there is no remembrance of You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the grave, who will give You praise?

**<sup>6</sup>** I am weary with my groaning;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;every night I flood my bed with tears;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I drench my couch with my weeping.

**<sup>7</sup>** My eye wastes away because of grief;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it grows weak because of all my foes.

**<sup>8</sup>** Depart from me, all you workers of iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the Lord has heard the sound of my weeping.

**<sup>9</sup>** The Lord has heard my plea;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord accepts my prayer.

**<sup>10</sup>** All my enemies shall be ashamed and greatly troubled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall turn back and be put to shame in a moment.<br/>


## Chapter 7

**<sup>1</sup>** O LORD my God, in You I take refuge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;save me from all who pursue me, and deliver me,<br/>
**<sup>2</sup>** lest he tear my soul like a lion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rending it in pieces with no one to rescue.

**<sup>3</sup>** O LORD my God, if I have done this,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if there is injustice in my hands,<br/>
**<sup>4</sup>** if I have repaid evil to him who was at peace with me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or plundered my enemy without cause—<br/>
**<sup>5</sup>** let the enemy pursue my soul and overtake it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let him trample my life to the ground<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lay my glory in the dust. Selah

**<sup>6</sup>** Arise, O LORD, in Your anger;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lift Yourself up against the fury of my adversaries;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;awake for me—You have commanded judgment.<br/>
**<sup>7</sup>** Let the assembly of the peoples gather around You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and over it return on high.

**<sup>8</sup>** The LORD judges the peoples;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;judge me, O LORD, according to my righteousness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and according to my integrity within me.<br/>
**<sup>9</sup>** Let the evil of the wicked come to an end, but establish the righteous—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the righteous God tests the hearts and minds.

**<sup>10</sup>** My shield is with God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who saves the upright in heart.<br/>
**<sup>11</sup>** God is a righteous judge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a God who has indignation every day.

**<sup>12</sup>** If a man does not repent, He sharpens His sword;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has bent His bow and made it ready.<br/>
**<sup>13</sup>** He has prepared His deadly weapons;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He makes His arrows fiery shafts.

**<sup>14</sup>** Behold, he is pregnant with wickedness:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he conceives trouble and gives birth to falsehood.<br/>
**<sup>15</sup>** He dug a pit and hollowed it out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and has fallen into the hole he made.<br/>
**<sup>16</sup>** His trouble returns upon his own head,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his violence comes down upon his own skull.

**<sup>17</sup>** I will give thanks to the LORD according to His righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will sing praise to the name of the LORD Most High.<br/>


## Chapter 8

**<sup>1</sup>** O LORD, our Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how majestic is Your name in all the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You who have set Your splendor above the heavens!

**<sup>2</sup>** Out of the mouth of infants and nursing babies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have established strength<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of Your adversaries,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to silence the enemy and the avenger.

**<sup>3</sup>** When I look at Your heavens, the work of Your fingers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the moon and the stars, which You have set in place—

**<sup>4</sup>** what is man that You take thought of him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the son of man that You care for him?

**<sup>5</sup>** Yet You have made him a little lower than the heavenly beings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and crowned him with glory and honor.

**<sup>6</sup>** You have given him dominion over the works of Your hands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have put all things under his feet:

**<sup>7</sup>** all sheep and oxen,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and also the beasts of the field,

**<sup>8</sup>** the birds of the heavens, and the fish of the sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whatever passes through the paths of the seas.

**<sup>9</sup>** O LORD, our Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how majestic is Your name in all the earth!<br/>


## Chapter 9

**<sup>1</sup>** I will give thanks to the LORD with my whole heart; I will recount all Your wondrous deeds. **<sup>2</sup>** I will be glad and rejoice in You; I will sing praise to Your name, O Most High.

**<sup>3</sup>** When my enemies turn back, they stumble and perish before You. **<sup>4</sup>** For You have upheld my right and my cause; You sat on the throne judging justly. **<sup>5</sup>** You rebuked the nations; You destroyed the wicked; You blotted out their name forever and ever. **<sup>6</sup>** The enemy came to an end in everlasting ruins; their cities You uprooted— even the memory of them has perished.

**<sup>7</sup>** But the LORD sits enthroned forever; He has established His throne for judgment. **<sup>8</sup>** He will judge the world with righteousness; He will execute judgment on the peoples with equity.

**<sup>9</sup>** The LORD is a stronghold for the oppressed, a refuge in times of trouble. **<sup>10</sup>** Those who know Your name trust in You, for You have not forsaken those who seek You, O LORD.

**<sup>11</sup>** Sing praises to the LORD, who dwells in Zion! Proclaim His deeds among the nations. **<sup>12</sup>** For He who avenges blood remembers them; He does not forget the cry of the afflicted.

**<sup>13</sup>** Be gracious to me, O LORD! See my affliction from those who hate me, You who lift me up from the gates of death, **<sup>14</sup>** that I may recount all Your praises, in the gates of the daughter of Zion, that I may rejoice in Your salvation.

**<sup>15</sup>** The nations have sunk into the pit they made; their foot is caught in the net they hid. **<sup>16</sup>** The LORD is known by the judgment He carries out; the wicked is snared in the work of his own hands. Higgaion. Selah.

**<sup>17</sup>** The wicked will return to the grave, all the nations that forget God. **<sup>18</sup>** For the needy shall not always be forgotten, and the hope of the poor shall never perish.

**<sup>19</sup>** Arise, O LORD! Let not man prevail; let the nations be judged before You! **<sup>20</sup>** Put them in fear, O LORD; let the nations know they are but men. Selah. 

## Chapter 10

**<sup>1</sup>** Why, O LORD, do You stand far off? Why do You hide Yourself in times of trouble? **<sup>2</sup>** In his pride the wicked hunts down the afflicted; let them be caught in the schemes they have devised.

**<sup>3</sup>** For the wicked boasts of the desires of his soul; the greedy man curses and despises the LORD. **<sup>4</sup>** In the arrogance of his face the wicked does not seek Him; all his thoughts are, “There is no God.”

**<sup>5</sup>** His ways always prosper; Your judgments are far above, out of his sight; as for all his foes, he snorts at them. **<sup>6</sup>** He says in his heart, “I shall not be moved; through all generations I shall not meet adversity.”

**<sup>7</sup>** His mouth is full of cursing and deceit and oppression; under his tongue are mischief and iniquity. **<sup>8</sup>** He sits in ambush near the villages; in hidden places he murders the innocent. His eyes watch closely for the helpless.

**<sup>9</sup>** He lies in wait in secret like a lion in his thicket; he lies in ambush to seize the afflicted; he seizes the afflicted when he draws them into his net. **<sup>10</sup>** He crouches, he bows down, and the helpless fall by his might.

**<sup>11</sup>** He says in his heart, “God has forgotten, He hides His face, He will never see.” **<sup>12</sup>** Arise, O LORD! O God, lift up Your hand; do not forget the afflicted.

**<sup>13</sup>** Why does the wicked despise God and say in his heart, “You will not call to account”? **<sup>14</sup>** But You do see, for You behold trouble and vexation to take it into Your hand. To You the helpless commits himself; You are the helper of the fatherless.

**<sup>15</sup>** Break the arm of the wicked and the evildoer; call his wickedness to account until You find none. **<sup>16</sup>** The LORD is King forever and ever; the nations perish from His land.

**<sup>17</sup>** O LORD, You hear the desire of the humble; You will strengthen their heart; You will incline Your ear **<sup>18</sup>** to give justice to the fatherless and the oppressed, so that man who is of the earth may terrify no more. 

## Chapter 11

**<sup>1</sup>** In the Lord I have taken refuge; how can you say to my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Flee to your mountain like a bird”?<br/>
**<sup>2</sup>** For behold, the wicked bend the bow;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have set their arrow on the string<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to shoot in the dark at the upright in heart.<br/>
**<sup>3</sup>** If the foundations are torn down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;what can the righteous do?<br/>
**<sup>4</sup>** The Lord is in His holy temple;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord—His throne is in heaven.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His eyes behold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His eyelids test the sons of man.<br/>
**<sup>5</sup>** The Lord tests the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in His inmost being he hates the wicked and the one who loves violence.<br/>
**<sup>6</sup>** He will rain down snares on the wicked:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;fire and brimstone and a scorching wind<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be the portion of their cup.<br/>
**<sup>7</sup>** For the Lord is righteous; He loves righteous deeds;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the upright shall behold His face.<br/>


## Chapter 12

**<sup>1</sup>** Save, O LORD, for the godly man has come to an end;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the faithful have vanished from among the sons of man.<br/>
**<sup>2</sup>** Everyone speaks falsehood with his neighbor;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with flattering lips and a double heart they speak.

**<sup>3</sup>** May the LORD cut off all flattering lips,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the tongue that boasts great things—<br/>
**<sup>4</sup>** those who have said, “By our tongue we will prevail;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our lips are with us—who is master over us?”

**<sup>5</sup>** “Because of the oppression of the poor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the groaning of the needy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;now I will arise,” says the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I will set him in safety, the one who longs for it.”

**<sup>6</sup>** The words of the LORD are pure words,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like silver refined in a crucible on the ground,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;purified seven times.

**<sup>7</sup>** You, O LORD, will keep them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You will guard him from this generation forever.<br/>
**<sup>8</sup>** The wicked strut about on every side,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when vileness is exalted among the sons of man.<br/>


## Chapter 13

**<sup>1</sup>** How long, O LORD? Will You forget me forever?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How long will You hide Your face from me?<br/>
**<sup>2</sup>** How long must I take counsel in my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have sorrow in my heart all day long?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How long shall my enemy be exalted over me?

**<sup>3</sup>** Look upon me and answer, O LORD my God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Give light to my eyes, lest I sleep in death,<br/>
**<sup>4</sup>** lest my enemy say, “I have prevailed over him,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my foes rejoice because I am shaken.

**<sup>5</sup>** But I have trusted in Your steadfast love;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my heart shall rejoice in Your salvation.<br/>
**<sup>6</sup>** I will sing to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He has dealt bountifully with me.<br/>


## Chapter 14

**<sup>1</sup>** The fool says in his heart, “There is no God.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They are corrupt; they do vile deeds.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;There is no one who does good.<br/>
**<sup>2</sup>** The Lord looks down from heaven upon the sons of man<br/>
&nbsp;&nbsp;&nbsp;&nbsp;To see if there is anyone who understands, anyone who seeks after God.

**<sup>3</sup>** All have turned aside; together they have become corrupt.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;There is no one who does good—no, not even one.<br/>
**<sup>4</sup>** Do all the workers of iniquity not know, who eat up my people as they eat bread and do not call upon the Lord?

**<sup>5</sup>** There they are in great dread, for God is with the righteous generation. **<sup>6</sup>** You would put to shame the counsel of the poor, but the Lord is his refuge. **<sup>7</sup>** Oh that the salvation of Israel would come out of Zion!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;When the Lord restores the fortunes of His people, Jacob shall rejoice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel shall be glad.<br/>


## Chapter 15

**<sup>1</sup>** O Lord, who may dwell in your tent?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who may live on your holy mountain?<br/>
**<sup>2</sup>** He who walks blamelessly and does what is right,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who speaks the truth from his heart,<br/>
**<sup>3</sup>** who does not slander with his tongue,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;does no harm to his neighbor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and does not cast reproach on his friend;<br/>
**<sup>4</sup>** in whose eyes a vile man is despised,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but who honors those who fear the Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who swears to his own hurt and does not change;<br/>
**<sup>5</sup>** who does not lend his money at interest<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and does not accept a bribe against the innocent.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He who does these things shall never be shaken.<br/>


## Chapter 16

**<sup>1</sup>** Preserve me, O God, for I take refuge in You. **<sup>2</sup>** I said to the LORD, “You are my Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have no good apart from You.”<br/>
**<sup>3</sup>** As for the holy ones who are in the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are the noble ones in whom is all my delight.<br/>
**<sup>4</sup>** The sorrows of those who chase after another god will multiply;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not pour out their drink offerings of blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor will I take their names upon my lips.

**<sup>5</sup>** The LORD is my chosen portion and my cup;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You hold my lot.<br/>
**<sup>6</sup>** The lines have fallen for me in pleasant places;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;indeed, I have a beautiful inheritance.

**<sup>7</sup>** I will bless the LORD who gives me counsel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the night also my conscience instructs me.<br/>
**<sup>8</sup>** I have set the LORD always before me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because He is at my right hand, I will not be shaken.

**<sup>9</sup>** Therefore my heart is glad and my glory rejoices;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my flesh also dwells secure.<br/>
**<sup>10</sup>** For You will not abandon my soul to the grave,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor will You let Your holy one see decay.<br/>
**<sup>11</sup>** You make known to me the path of life;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in Your presence is fullness of joy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at Your right hand are pleasures forevermore.<br/>


## Chapter 17

**<sup>1</sup>** Hear, O LORD, my just cause; attend to my cry;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give ear to my prayer from lips without deceit.<br/>
**<sup>2</sup>** Let my vindication come from your presence;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your eyes behold what is right.

**<sup>3</sup>** You have tested my heart, you have visited me by night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have tried me and found nothing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have purposed that my mouth will not transgress.<br/>
**<sup>4</sup>** As for the deeds of men, by the word of your lips<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have avoided the paths of the violent.<br/>
**<sup>5</sup>** My steps have held fast to your paths;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my feet have not slipped.

**<sup>6</sup>** I call upon you, for you will answer me, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;incline your ear to me; hear my words.<br/>
**<sup>7</sup>** Show the wonder of your steadfast love, O Savior<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to those who seek refuge from their adversaries at your right hand.<br/>
**<sup>8</sup>** Keep me as the apple of the eye;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;hide me in the shadow of your wings,<br/>
**<sup>9</sup>** from the wicked who do me violence,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my deadly enemies who surround me.

**<sup>10</sup>** They close their hearts to pity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with their mouths they speak arrogantly.<br/>
**<sup>11</sup>** They have now surrounded our steps;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they set their eyes to cast us down to the ground.<br/>
**<sup>12</sup>** He is like a lion eager to tear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a young lion lurking in hiding places.

**<sup>13</sup>** Arise, O LORD, confront him, bring him low;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;deliver my soul from the wicked by your sword,<br/>
**<sup>14</sup>** from men, by your hand, O LORD, from men of the world whose portion is in this life.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You fill their belly with your treasure;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are satisfied with children and leave their abundance to their infants.

**<sup>15</sup>** As for me, I shall behold your face in righteousness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I awake, I shall be satisfied with your likeness.<br/>


## Chapter 18

**<sup>1</sup>** I love you, O LORD, my strength. **<sup>2</sup>** The LORD is my rock, my fortress, and my deliverer,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my God, my rock in whom I take refuge, my shield,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the horn of my salvation, my stronghold.<br/>
**<sup>3</sup>** I call upon the LORD, who is worthy of praise,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I am saved from my enemies.

**<sup>4</sup>** The cords of death encompassed me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the torrents of destruction overwhelmed me.<br/>
**<sup>5</sup>** The cords of the grave entangled me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the snares of death confronted me.<br/>
**<sup>6</sup>** In my distress I called upon the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to my God I cried for help.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;From His temple He heard my voice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my cry before Him came into His ears.

**<sup>7</sup>** Then the earth shook and quaked;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the foundations of the mountains trembled<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and were shaken, because He was angry.<br/>
**<sup>8</sup>** Smoke went up from His nostrils, and devouring fire from His mouth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;glowing coals blazed forth from Him.<br/>
**<sup>9</sup>** He bowed the heavens and came down;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;thick darkness was under His feet.<br/>
**<sup>10</sup>** He rode on a cherub and flew;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He came swiftly on the wings of the wind.<br/>
**<sup>11</sup>** He made darkness His covering, His canopy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;around Him, thick clouds, dark with water.<br/>
**<sup>12</sup>** From the brightness before Him, hailstones and coals of fire passed through His clouds. **<sup>13</sup>** The LORD thundered from the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the Most High uttered His voice, hailstones and coals of fire.<br/>
**<sup>14</sup>** He sent out His arrows and scattered them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He flashed forth lightning and routed them.<br/>
**<sup>15</sup>** Then the channels of the sea were exposed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the foundations of the world were laid bare<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at Your rebuke, O LORD, at the blast of the breath of Your nostrils.

**<sup>16</sup>** He reached down from on high and took hold of me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He drew me out of many waters.<br/>
**<sup>17</sup>** He rescued me from my powerful enemy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from those who hated me, for they were too strong for me.<br/>
**<sup>18</sup>** They confronted me in the day of my calamity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the LORD was my support.<br/>
**<sup>19</sup>** He brought me out into a spacious place;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He rescued me because He delighted in me.

**<sup>20</sup>** The LORD rewarded me according to my righteousness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to the cleanness of my hands He repaid me.<br/>
**<sup>21</sup>** For I have kept the ways of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have not wickedly departed from my God.<br/>
**<sup>22</sup>** For all His judgments were before me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I did not put away His statutes from me.<br/>
**<sup>23</sup>** I was blameless before Him, and I kept myself from guilt. **<sup>24</sup>** So the LORD has repaid me according to my righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to the cleanness of my hands in His sight.

**<sup>25</sup>** With the merciful You show Yourself merciful;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the blameless man You show Yourself blameless;<br/>
**<sup>26</sup>** with the pure You show Yourself pure,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with the crooked You make Yourself seem shrewd.<br/>
**<sup>27</sup>** For You save a humble people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the haughty eyes You bring down.<br/>
**<sup>28</sup>** For it is You who light my lamp;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD my God illumines my darkness.

**<sup>29</sup>** For by You I can run against a troop,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by my God I can leap over a wall.<br/>
**<sup>30</sup>** This God—His way is perfect; the word of the LORD proves true;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is a shield for all who take refuge in Him.<br/>
**<sup>31</sup>** For who is God but the LORD?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And who is a rock except our God?

**<sup>32</sup>** The God who girds me with strength and makes my way blameless, **<sup>33</sup>** He makes my feet like the feet of a deer and sets me secure on the heights. **<sup>34</sup>** He trains my hands for war, so that my arms can bend a bow of bronze. **<sup>35</sup>** You have given me the shield of Your salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Your right hand upheld me, and Your gentleness made me great.<br/>
**<sup>36</sup>** You gave a wide place beneath my steps, and my feet did not slip.

**<sup>37</sup>** I pursued my enemies and overtook them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I did not turn back until they were consumed.<br/>
**<sup>38</sup>** I struck them down so that they were not able to rise;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they fell under my feet.<br/>
**<sup>39</sup>** For You girded me with strength for the battle;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You made those who rose against me sink under me.<br/>
**<sup>40</sup>** You made my enemies turn their backs to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those who hated me I destroyed.<br/>
**<sup>41</sup>** They cried for help, but there was none to save;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they cried to the LORD, but He did not answer them.<br/>
**<sup>42</sup>** I beat them fine as dust before the wind;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I cast them out like the mire of the streets.

**<sup>43</sup>** You delivered me from the strife of the people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You made me the head of the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a people I had not known served me.<br/>
**<sup>44</sup>** As soon as they heard of me, they obeyed me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;foreigners came cringing to me.<br/>
**<sup>45</sup>** Foreigners lost heart and came trembling from their strongholds.

**<sup>46</sup>** The LORD lives, and blessed be my rock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and exalted be the God of my salvation—<br/>
**<sup>47</sup>** the God who gave me vengeance and subdued nations under me, **<sup>48</sup>** who delivered me from my enemies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;indeed, You exalted me above those who rose against me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You rescued me from the man of violence.

**<sup>49</sup>** Therefore I will give thanks to You, O LORD, among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and sing praises to Your name.<br/>
**<sup>50</sup>** He gives great salvation to His king, and shows steadfast love to His anointed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to David and his offspring forever.<br/>


## Chapter 19

**<sup>1</sup>** The heavens declare the glory of God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the sky above proclaims the work of his hands.<br/>
**<sup>2</sup>** Day to day pours forth speech,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and night to night reveals knowledge.<br/>
**<sup>3</sup>** There is no speech, nor are there words;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their voice is not heard.<br/>
**<sup>4</sup>** Yet their line goes out through all the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their words to the end of the world.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In them he has set a tent for the sun,<br/>
**<sup>5</sup>** which comes out like a bridegroom leaving his chamber,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and, like a strong man, runs its course with joy.<br/>
**<sup>6</sup>** Its rising is from the end of the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its circuit to the end of them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there is nothing hidden from its heat.

**<sup>7</sup>** The law of the LORD is perfect, restoring the soul;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the testimony of the LORD is trustworthy, making the simple wise.<br/>
**<sup>8</sup>** The precepts of the LORD are right, rejoicing the heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the commandment of the LORD is pure, enlightening the eyes.<br/>
**<sup>9</sup>** The fear of the LORD is clean, enduring forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the judgments of the LORD are true and altogether righteous.<br/>
**<sup>10</sup>** More to be desired are they than gold, even much fine gold;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sweeter also than honey and drippings from the honeycomb.<br/>
**<sup>11</sup>** Moreover, by them your servant is warned;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in keeping them there is great reward.

**<sup>12</sup>** Who can discern his errors?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Cleanse me from hidden faults.<br/>
**<sup>13</sup>** Keep back your servant also from presumptuous sins;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them not have dominion over me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then I shall be blameless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and innocent of great transgression.

**<sup>14</sup>** Let the words of my mouth and the meditation of my heart<br/>
&nbsp;&nbsp;&nbsp;&nbsp;be acceptable in your sight,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD, my rock and my redeemer.<br/>


## Chapter 20

**<sup>1</sup>** May the LORD answer you in the day of trouble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may the name of the God of Jacob protect you.<br/>
**<sup>2</sup>** May He send you help from the sanctuary and support you from Zion. **<sup>3</sup>** May He remember all your offerings and regard with favor your burnt sacrifices. Selah.

**<sup>4</sup>** May He grant you your heart’s desire and fulfill all your plans. **<sup>5</sup>** We will shout for joy over your salvation, and in the name of our God we will set up our banners.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;May the LORD fulfill all your petitions.<br/>
**<sup>6</sup>** Now I know that the LORD saves His anointed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will answer him from His holy heaven with the saving might of His right hand.

**<sup>7</sup>** Some trust in chariots and some in horses, but we trust in the name of the LORD our God. **<sup>8</sup>** They collapse and fall, but we rise and stand upright. **<sup>9</sup>** O LORD, save the king! May He answer us when we call. 

## Chapter 21

**<sup>1</sup>** O LORD, the king rejoices in Your strength, and how greatly he exults in Your salvation! **<sup>2</sup>** You have granted him the desire of his heart and have not withheld the request of his lips. **<sup>3</sup>** For You come to meet him with blessings of good things; You set a crown of pure gold upon his head.

**<sup>4</sup>** He asked You for life, and You gave it to him—length of days, forever and ever. **<sup>5</sup>** His glory is great through Your salvation; You bestow majesty and splendor upon him. **<sup>6</sup>** For You make him most blessed forever; You make him glad with the joy of Your presence.

**<sup>7</sup>** For the king trusts in the LORD, and through the steadfast love of the Most High he shall not be shaken.

**<sup>8</sup>** Your hand will find out all Your enemies; Your right hand will seize those who hate You. **<sup>9</sup>** You will make them like a fiery furnace at the time of Your appearing. The LORD will swallow them up in His wrath, and fire will consume them. **<sup>10</sup>** You will destroy their offspring from the earth, and their descendants from among the sons of man. **<sup>11</sup>** Though they plan evil against You, though they devise schemes, they will not succeed. **<sup>12</sup>** For You will put them to flight; You will aim Your bow at their faces.

**<sup>13</sup>** Be exalted, O LORD, in Your strength! We will sing and praise Your power. 

## Chapter 22

**<sup>1</sup>** My God, my God, why have You forsaken me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why are You so far from saving me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the words of my groaning?<br/>
**<sup>2</sup>** My God, I call out by day, but You do not answer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by night—but I find no rest.

**<sup>3</sup>** Yet You are holy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;enthroned upon the praises of Israel.<br/>
**<sup>4</sup>** In You our fathers trusted;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they trusted, and You delivered them.

**<sup>5</sup>** To You they cried and were rescued;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in You they trusted and were not put to shame.<br/>
**<sup>6</sup>** But I am a worm and not a man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;scorned by men and despised by the people.

**<sup>7</sup>** All who see me mock me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they open wide their mouths; they wag their heads:<br/>
**<sup>8</sup>** “He trusts in the LORD; let Him deliver him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let Him rescue him, for He delights in him.”

**<sup>9</sup>** Yet You are the one who brought me out of the womb;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You made me trust You from my mother's breasts.<br/>
**<sup>10</sup>** On You I was cast from birth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from my mother’s womb You have been my God.

**<sup>11</sup>** Do not be far from me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for trouble is near,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there is no one to help.<br/>
**<sup>12</sup>** Many bulls surround me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;strong bulls of Bashan encircle me.

**<sup>13</sup>** They open wide their mouths at me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a ravenous and roaring lion.<br/>
**<sup>14</sup>** I am poured out like water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all my bones are disjointed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my heart is like wax—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it melts within me.

**<sup>15</sup>** My strength is dried up like a potsherd,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my tongue clings to my jaws;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You lay me in the dust of death.<br/>
**<sup>16</sup>** For dogs have surrounded me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a gang of evildoers has encircled me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have pierced my hands and feet.

**<sup>17</sup>** I can count all my bones—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they look, they stare at me.<br/>
**<sup>18</sup>** They divide my garments among themselves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and for my clothing they cast lots.

**<sup>19</sup>** But You, O LORD, do not be far off!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O my strength, come quickly to help me!<br/>
**<sup>20</sup>** Deliver my soul from the sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my precious life from the power of the dog.

**<sup>21</sup>** Save me from the lion’s mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the horns of wild oxen—You have answered me.<br/>
**<sup>22</sup>** I will declare Your name to my brothers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the midst of the congregation I will praise You.

**<sup>23</sup>** You who fear the LORD, praise Him!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All you descendants of Jacob, glorify Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and stand in awe of Him, all you descendants of Israel!<br/>
**<sup>24</sup>** For He has not despised nor abhorred<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the affliction of the afflicted,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He has not hidden His face from him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but when he cried to Him, He heard.

**<sup>25</sup>** From You comes my praise in the great congregation;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my vows I will fulfill before those who fear Him.<br/>
**<sup>26</sup>** The afflicted shall eat and be satisfied;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who seek Him shall praise the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;May your heart live forever!

**<sup>27</sup>** All the ends of the earth shall remember and turn to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the families of the nations shall bow down before You.<br/>
**<sup>28</sup>** For the kingdom is the LORD’s,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He rules over the nations.

**<sup>29</sup>** All the prosperous of the earth shall eat and bow down;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all who go down to the dust shall bow before Him—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even he who could not keep his soul alive.<br/>
**<sup>30</sup>** Posterity shall serve Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it shall be told of the Lord to the coming generation.<br/>
**<sup>31</sup>** They shall come and proclaim His righteousness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to a people yet to be born,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that He has done it.<br/>


## Chapter 23

**<sup>1</sup>** The Lord is my shepherd; I shall lack nothing. **<sup>2</sup>** He makes me lie down in green pastures; He leads me beside still waters. **<sup>3</sup>** He restores my soul; He guides me in paths of righteousness for His name’s sake. **<sup>4</sup>** Even though I walk through the valley of deep darkness, I will fear no evil, for You are with me; Your rod and Your staff, they comfort me. **<sup>5</sup>** You prepare a table before me in the presence of my enemies; You anoint my head with oil; my cup overflows. **<sup>6</sup>** Surely goodness and lovingkindness shall pursue me all the days of my life, and I shall dwell in the house of the Lord forever. 

## Chapter 24

**<sup>1</sup>** The earth is the Lord’s, and all that fills it, the world and those who dwell in it. **<sup>2</sup>** For He founded it upon the seas and established it upon the rivers.

**<sup>3</sup>** Who may ascend the mountain of the Lord? And who may stand in His holy place? **<sup>4</sup>** He who has clean hands and a pure heart, who has not lifted up his soul to falsehood and has not sworn deceitfully. **<sup>5</sup>** He shall receive blessing from the Lord and righteousness from the God of his salvation. **<sup>6</sup>** This is the generation of those who seek Him, who seek Your face—O God of Jacob.

**<sup>7</sup>** Lift up your heads, O gates, and be lifted up, O ancient doors, that the King of Glory may enter! **<sup>8</sup>** Who is this King of Glory? The Lord strong and mighty, the Lord mighty in battle. **<sup>9</sup>** Lift up your heads, O gates, and lift them up, O ancient doors, that the King of Glory may enter! **<sup>10</sup>** Who is this King of Glory? The Lord of hosts—He is the King of Glory. 

## Chapter 25

**<sup>1</sup>** To You, O LORD, I lift up my soul. **<sup>2</sup>** My God, in You I trust; do not let me be put to shame; do not let my enemies exult over me. **<sup>3</sup>** Indeed, none who wait for You will be put to shame; they shall be put to shame who act treacherously without cause.

**<sup>4</sup>** Make me know Your ways, O LORD; teach me Your paths. **<sup>5</sup>** Lead me in Your truth and teach me, for You are the God of my salvation; for You I wait all the day. **<sup>6</sup>** Remember Your mercies, O LORD, and Your steadfast love, for they are from of old. **<sup>7</sup>** Do not remember the sins of my youth or my transgressions; according to Your steadfast love remember me, for the sake of Your goodness, O LORD.

**<sup>8</sup>** Good and upright is the LORD; therefore He instructs sinners in the way. **<sup>9</sup>** He leads the humble in justice and teaches the humble His way. **<sup>10</sup>** All the paths of the LORD are steadfast love and faithfulness to those who keep His covenant and His testimonies. **<sup>11</sup>** For the sake of Your name, O LORD, pardon my guilt, for it is great.

**<sup>12</sup>** Who is the man who fears the LORD? This man will be instructed in the way he should choose. **<sup>13</sup>** His soul shall abide in prosperity, and his descendants shall inherit the land. **<sup>14</sup>** The secret of the LORD is with those who fear Him, and He makes them know His covenant.

**<sup>15</sup>** My eyes are ever toward the LORD, for He will free my feet from the net. **<sup>16</sup>** Turn to me and be gracious to me, for I am lonely and afflicted. **<sup>17</sup>** The troubles of my heart are enlarged; bring me out of my distresses. **<sup>18</sup>** Look upon my affliction and my trouble, and forgive all my sins. **<sup>19</sup>** Consider my enemies, for they are many, as are those who hate me with violent hatred. **<sup>20</sup>** Guard my soul and deliver me; let me not be put to shame, for I take refuge in You. **<sup>21</sup>** Let integrity and uprightness preserve me, for I wait for You.

**<sup>22</sup>** Redeem Israel, O God, out of all his troubles. 

## Chapter 26

**<sup>1</sup>** Vindicate me, O LORD, for I have walked in my integrity; I have trusted in the LORD without wavering. **<sup>2</sup>** Examine me, O LORD, and try me; test my kidneys and my heart. **<sup>3</sup>** For Your steadfast love is before my eyes, and I have walked in Your truth.

**<sup>4</sup>** I do not sit with deceitful men, nor do I go with hypocrites. **<sup>5</sup>** I hate the assembly of evildoers, and I do not sit with the wicked.

**<sup>6</sup>** I wash my hands in innocence and go around Your altar, O LORD, **<sup>7</sup>** to proclaim thanksgiving aloud and to recount all Your wondrous deeds.

**<sup>8</sup>** O LORD, I love the habitation of Your house and the place where Your glory dwells.

**<sup>9</sup>** Do not sweep away my soul with sinners, nor my life with men of blood, **<sup>10</sup>** in whose hands are evil plots and whose right hand is full of bribes.

**<sup>11</sup>** But as for me, I shall walk in my integrity; redeem me and be gracious to me. **<sup>12</sup>** My foot stands on level ground; in the great assembly I will bless the LORD. 

## Chapter 27

**<sup>1</sup>** The LORD is my light and my salvation; whom shall I fear?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD is the stronghold of my life; of whom shall I be afraid?<br/>
**<sup>2</sup>** When evildoers draw near against me to devour my flesh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my adversaries and my enemies, they stumbled and fell.<br/>
**<sup>3</sup>** Though an army encamp against me, my heart will not fear;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;though war arise against me, even then I will trust.

**<sup>4</sup>** One thing I have asked from the LORD, that I will seek:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to dwell in the house of the LORD all the days of my life,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to behold the beauty of the LORD and to inquire in His temple.

**<sup>5</sup>** For He will hide me in His shelter in the day of trouble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will conceal me in the hiding place of His tent;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will lift me high upon a rock.

**<sup>6</sup>** And now my head shall be lifted up above my enemies all around me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will offer in His tent sacrifices with shouts of joy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing and make melody to the LORD.<br/>
**<sup>7</sup>** Hear, O LORD, my voice when I cry out;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;be gracious to me and answer me.

**<sup>8</sup>** On Your behalf my heart has said, “Seek My face.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your face, O LORD, I will seek.<br/>
**<sup>9</sup>** Do not hide Your face from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not turn Your servant away in anger.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have been my help; do not forsake me or abandon me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O God of my salvation.<br/>
**<sup>10</sup>** Though my father and my mother have forsaken me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD will take me in.

**<sup>11</sup>** Teach me Your way, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lead me on a level path because of my foes.<br/>
**<sup>12</sup>** Do not give me up to the will of my adversaries,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for false witnesses have risen against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they breathe out violence.<br/>
**<sup>13</sup>** I believe that I shall see the goodness of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the land of the living.<br/>
**<sup>14</sup>** Wait for the LORD; be strong,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let your heart be courageous;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;wait for the LORD.<br/>


## Chapter 28

**<sup>1</sup>** To You, O LORD, I call;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my rock, do not be deaf to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lest, if You be silent to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I become like those who go down to the pit.<br/>
**<sup>2</sup>** Hear the voice of my supplications when I cry to You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I lift up my hands toward Your holy sanctuary.

**<sup>3</sup>** Do not drag me away with the wicked<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with the workers of iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who speak peace with their neighbors<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while evil is in their hearts.<br/>
**<sup>4</sup>** Give to them according to their work<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and according to the evil of their deeds.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Give to them according to the work of their hands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;render their recompense to them.<br/>
**<sup>5</sup>** Because they do not regard the deeds of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor the work of His hands,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will tear them down and not build them up.

**<sup>6</sup>** Blessed be the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He has heard the voice of my supplications.<br/>
**<sup>7</sup>** The LORD is my strength and my shield;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in Him my heart trusts, and I am helped.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My heart exults,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with my song I will give thanks to Him.<br/>
**<sup>8</sup>** The LORD is the strength of His people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is a refuge of salvation for His anointed.<br/>
**<sup>9</sup>** Save Your people and bless Your heritage;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shepherd them also and carry them forever.<br/>


## Chapter 29

**<sup>1</sup>** Ascribe to the LORD, O sons of the mighty,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;ascribe to the LORD glory and strength.<br/>
**<sup>2</sup>** Ascribe to the LORD the glory due His name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;worship the LORD in the beauty of holiness.

**<sup>3</sup>** The voice of the LORD is over the waters;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the God of glory thunders,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD is over many waters.<br/>
**<sup>4</sup>** The voice of the LORD is powerful;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the voice of the LORD is full of majesty.

**<sup>5</sup>** The voice of the LORD breaks the cedars;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD shatters the cedars of Lebanon.<br/>
**<sup>6</sup>** He makes Lebanon skip like a calf,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Sirion like a young wild ox.

**<sup>7</sup>** The voice of the LORD hews out flames of fire. **<sup>8</sup>** The voice of the LORD shakes the wilderness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD shakes the wilderness of Kadesh.<br/>
**<sup>9</sup>** The voice of the LORD makes the deer give birth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and strips the forests bare,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in His temple all cry, “Glory!”

**<sup>10</sup>** The LORD sits enthroned over the flood;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD sits enthroned as king forever.<br/>
**<sup>11</sup>** The LORD gives strength to His people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD blesses His people with peace.<br/>


## Chapter 30

**<sup>1</sup>** I will exalt You, O LORD, for You have drawn me up<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have not let my enemies rejoice over me.<br/>
**<sup>2</sup>** O LORD my God, I cried to You for help,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and You have healed me.<br/>
**<sup>3</sup>** O LORD, You have brought me up alive from the grave;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You restored me to life from among those who go down to the pit.

**<sup>4</sup>** Sing praise to the LORD, O you His faithful ones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and give thanks to His holy name.<br/>
**<sup>5</sup>** For His anger is but for a moment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but His favor is for a lifetime.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Weeping may remain for the night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but joy comes in the morning.

**<sup>6</sup>** As for me, I said in my prosperity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I shall never be moved.”<br/>
**<sup>7</sup>** O LORD, by Your favor You made my mountain stand strong;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You hid Your face—I was dismayed.

**<sup>8</sup>** To You, O LORD, I called,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to the Lord I made supplication:<br/>
**<sup>9</sup>** “What gain is there in my death, in my going down to the pit?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Will the dust praise You? Will it declare Your truth?<br/>
**<sup>10</sup>** Hear, O LORD, and be gracious to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD, be my helper.”

**<sup>11</sup>** You turned my mourning into dancing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You removed my sackcloth and girded me with gladness,<br/>
**<sup>12</sup>** so that my soul may sing praise to You and not be silent.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD my God, I will give thanks to You forever.<br/>


## Chapter 31

**<sup>1</sup>** In You, O LORD, I have taken refuge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me never be put to shame;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in Your righteousness deliver me.<br/>
**<sup>2</sup>** Incline Your ear to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rescue me speedily.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Be to me a rock of refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a strong fortress to save me.

**<sup>3</sup>** For You are my rock and my fortress;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and for Your name’s sake You will lead me and guide me.<br/>
**<sup>4</sup>** You will pull me out of the net that they have hidden for me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for You are my refuge.<br/>
**<sup>5</sup>** Into Your hand I commit my spirit;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have redeemed me, O LORD, God of truth.

**<sup>6</sup>** I hate those who regard worthless idols,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but I trust in the LORD.<br/>
**<sup>7</sup>** I will rejoice and be glad in Your lovingkindness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because You have seen my affliction;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have known the distress of my soul,<br/>
**<sup>8</sup>** and You have not delivered me into the hand of the enemy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have set my feet in a broad place.

**<sup>9</sup>** Be gracious to me, O LORD, for I am in distress;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my eye is wasted from grief,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my soul and my body also.<br/>
**<sup>10</sup>** For my life is spent with sorrow<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my years with sighing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my strength fails because of my iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my bones waste away.

**<sup>11</sup>** I am a reproach among all my adversaries,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;especially to my neighbors,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a dread to my acquaintances;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who see me in the street flee from me.<br/>
**<sup>12</sup>** I am forgotten as a dead man out of mind;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am like a broken vessel.<br/>
**<sup>13</sup>** For I have heard the slander of many—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;terror on every side!—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as they take counsel together against me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they scheme to take my life.

**<sup>14</sup>** But I trust in You, O LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I say, “You are my God.”<br/>
**<sup>15</sup>** My times are in Your hand;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;deliver me from the hand of my enemies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from those who pursue me.<br/>
**<sup>16</sup>** Make Your face shine upon Your servant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;save me in Your lovingkindness.<br/>
**<sup>17</sup>** O LORD, let me not be put to shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I call upon You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the wicked be put to shame;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them lie down in the grave.

**<sup>18</sup>** Let the lying lips be mute,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which speak arrogantly against the righteous<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with pride and contempt.

**<sup>19</sup>** How great is Your goodness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which You have stored up for those who fear You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which You perform for those who take refuge in You<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the sons of men!<br/>
**<sup>20</sup>** In the shelter of Your presence You hide them from the schemes of men;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You conceal them in Your pavilion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the strife of tongues.

**<sup>21</sup>** Blessed be the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He has shown me His lovingkindness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in a fortified city.<br/>
**<sup>22</sup>** As for me, I said in my alarm,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I am cut off from before Your eyes.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Nevertheless, You heard the voice of my supplications<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I cried to You.

**<sup>23</sup>** Love the LORD, all you His saints!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD preserves the faithful<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but abundantly repays the one who acts with pride.<br/>
**<sup>24</sup>** Be strong, and let your heart take courage,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all you who wait for the LORD.<br/>


## Chapter 32

**<sup>1</sup>** Blessed is the man whose transgression is forgiven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose sin is covered.<br/>
**<sup>2</sup>** Blessed is the man to whom the LORD does not count iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in whose spirit there is no deceit.

**<sup>3</sup>** When I kept silent, my bones wasted away<br/>
&nbsp;&nbsp;&nbsp;&nbsp;through my groaning all day long.<br/>
**<sup>4</sup>** For day and night Your hand was heavy upon me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my strength was dried up as if by the heat of summer. Selah

**<sup>5</sup>** I acknowledged my sin to You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I did not cover my iniquity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I said, “I will confess my transgressions to the LORD,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and You forgave the iniquity of my sin. Selah

**<sup>6</sup>** Therefore let everyone who is godly<br/>
&nbsp;&nbsp;&nbsp;&nbsp;offer prayer to You at a time when You may be found;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;surely in the rush of great waters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall not reach him.<br/>
**<sup>7</sup>** You are a hiding place for me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You preserve me from trouble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You surround me with shouts of deliverance. Selah

**<sup>8</sup>** I will instruct you and teach you in the way you should go;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will counsel you with My eye upon you.<br/>
**<sup>9</sup>** Do not be like a horse or a mule, without understanding,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which must be curbed with bit and bridle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or it will not stay near you.

**<sup>10</sup>** Many are the sorrows of the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but steadfast love surrounds the one who trusts in the LORD.<br/>
**<sup>11</sup>** Be glad in the LORD, and rejoice, O righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shout for joy, all you upright in heart!<br/>


## Chapter 33

**<sup>1</sup>** Rejoice in the LORD, O righteous!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise befits the upright.<br/>
**<sup>2</sup>** Give thanks to the LORD with the lyre;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make melody to Him with the harp of ten strings.<br/>
**<sup>3</sup>** Sing to Him a new song;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;play skillfully with a shout of joy.

**<sup>4</sup>** For the word of the LORD is upright,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all His work is done in faithfulness.<br/>
**<sup>5</sup>** He loves righteousness and justice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the earth is full of the lovingkindness of the LORD.

**<sup>6</sup>** By the word of the LORD the heavens were made,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by the breath of His mouth all their host.<br/>
**<sup>7</sup>** He gathers the waters of the sea as a heap;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He puts the deeps in storehouses.<br/>
**<sup>8</sup>** Let all the earth fear the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let all the inhabitants of the world stand in awe of Him.<br/>
**<sup>9</sup>** For He spoke, and it came to be;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He commanded, and it stood firm.

**<sup>10</sup>** The LORD brings the counsel of the nations to nothing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He frustrates the plans of the peoples.<br/>
**<sup>11</sup>** The counsel of the LORD stands forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the plans of His heart to all generations.<br/>
**<sup>12</sup>** Blessed is the nation whose God is the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the people He has chosen as His inheritance.

**<sup>13</sup>** The LORD looks down from heaven;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He sees all the sons of man;<br/>
**<sup>14</sup>** from where He dwells He looks<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on all the inhabitants of the earth—<br/>
**<sup>15</sup>** He who fashions the hearts of them all,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who considers all their deeds.

**<sup>16</sup>** The king is not saved by the size of his army;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a warrior is not delivered by great strength.<br/>
**<sup>17</sup>** The horse is a false hope for salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor does it deliver by its great might.

**<sup>18</sup>** Behold, the eye of the LORD is on those who fear Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on those who hope in His lovingkindness,<br/>
**<sup>19</sup>** to deliver their soul from death<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to keep them alive in famine.

**<sup>20</sup>** Our soul waits for the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is our help and our shield.<br/>
**<sup>21</sup>** For our heart is glad in Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because we trust in His holy name.<br/>
**<sup>22</sup>** Let Your lovingkindness, O LORD, be upon us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as we hope in You.<br/>


## Chapter 34

**<sup>1</sup>** I will bless the LORD at all times;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His praise shall continually be in my mouth.<br/>
**<sup>2</sup>** My soul makes its boast in the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the humble shall hear and be glad.<br/>
**<sup>3</sup>** Magnify the LORD with me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let us exalt His name together.

**<sup>4</sup>** I sought the LORD, and He answered me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and delivered me from all my fears.<br/>
**<sup>5</sup>** They looked to Him and were radiant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their faces shall never be ashamed.<br/>
**<sup>6</sup>** This poor man cried, and the LORD heard him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and saved him out of all his troubles.<br/>
**<sup>7</sup>** The angel of the LORD encamps around those who fear Him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and delivers them.

**<sup>8</sup>** Taste and see that the LORD is good!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Blessed is the man who takes refuge in Him!<br/>
**<sup>9</sup>** Fear the LORD, you His saints,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for those who fear Him have no lack.<br/>
**<sup>10</sup>** The young lions suffer want and hunger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but those who seek the LORD lack no good thing.

**<sup>11</sup>** Come, O sons, listen to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will teach you the fear of the LORD.<br/>
**<sup>12</sup>** Who is the man who desires life<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and loves many days, that he may see good?<br/>
**<sup>13</sup>** Keep your tongue from evil<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your lips from speaking deceit.<br/>
**<sup>14</sup>** Turn away from evil and do good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;seek peace and pursue it.

**<sup>15</sup>** The eyes of the LORD are toward the righteous<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His ears toward their cry.<br/>
**<sup>16</sup>** The face of the LORD is against those who do evil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to cut off the memory of them from the earth.<br/>
**<sup>17</sup>** When the righteous cry for help, the LORD hears<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and delivers them out of all their troubles.<br/>
**<sup>18</sup>** The LORD is near to the brokenhearted<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and saves the crushed in spirit.

**<sup>19</sup>** Many are the afflictions of the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the LORD delivers him out of them all.<br/>
**<sup>20</sup>** He keeps all his bones;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;not one of them is broken.<br/>
**<sup>21</sup>** Evil will slay the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those who hate the righteous will be condemned.<br/>
**<sup>22</sup>** The LORD redeems the soul of His servants;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;none of those who take refuge in Him will be condemned.<br/>


## Chapter 35

**<sup>1</sup>** Contend, O Lord, with those who contend against me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;fight against those who fight me.<br/>
**<sup>2</sup>** Take up shield and armor; rise up and come to my aid. **<sup>3</sup>** Draw out the spear and javelin against my pursuers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;say to my soul, “I am your salvation.”

**<sup>4</sup>** Let those who seek my life be put to shame and dishonored;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let those who plot evil against me be turned back and humiliated.<br/>
**<sup>5</sup>** Let them be like chaff before the wind, with the angel of the Lord driving them away. **<sup>6</sup>** Let their path be dark and slippery, with the angel of the Lord pursuing them. **<sup>7</sup>** For without cause they hid their net for me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;without reason they dug a pit for my soul.<br/>
**<sup>8</sup>** Let destruction come upon them unexpectedly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the net they hid ensnare them; let them fall into their own pit to their ruin.

**<sup>9</sup>** Then my soul will rejoice in the Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it will delight in His salvation.<br/>
**<sup>10</sup>** All my bones will say, “O Lord, who is like You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who rescues the poor from those too strong for them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the poor and needy from those who rob them?”

**<sup>11</sup>** Malicious witnesses rise up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they accuse me of things I know nothing about.<br/>
**<sup>12</sup>** They repay me evil for good, leaving my soul bereft. **<sup>13</sup>** Yet when they were sick, I put on sackcloth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I humbled myself with fasting, and my prayer returned to my own heart.<br/>
**<sup>14</sup>** I went about as though grieving for a friend or brother;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I bowed down in mourning, as one lamenting a mother.<br/>
**<sup>15</sup>** But when I stumbled, they rejoiced and gathered together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they gathered against me, attackers I did not know, tearing at me without ceasing.<br/>
**<sup>16</sup>** Like godless mockers at a feast, they gnashed their teeth at me.

**<sup>17</sup>** O Lord, how long will You look on?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Rescue my soul from their ravages, my precious life from the lions.<br/>
**<sup>18</sup>** I will give You thanks in the great assembly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;among a mighty throng I will praise You.

**<sup>19</sup>** Do not let those who are wrongfully my enemies rejoice over me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not let those who hate me without cause wink their eyes.<br/>
**<sup>20</sup>** For they do not speak peace, but devise deceitful words against those who are quiet in the land. **<sup>21</sup>** They open their mouths wide against me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they say, “Aha, aha! Our eyes have seen it!”

**<sup>22</sup>** You have seen this, O Lord; do not remain silent.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O Lord, do not be far from me.<br/>
**<sup>23</sup>** Awake and rise to my defense, to my cause, my God and my Lord. **<sup>24</sup>** Vindicate me, O Lord my God, according to Your righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not let them rejoice over me.<br/>
**<sup>25</sup>** Do not let them say in their hearts, “Aha, just what we wanted!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do not let them say, “We have swallowed him up.”<br/>
**<sup>26</sup>** Let all who rejoice at my calamity be ashamed and confounded together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let those who exalt themselves over me be clothed with shame and dishonor.

**<sup>27</sup>** Let those who delight in my righteousness shout for joy and be glad;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them say continually, “The Lord be exalted, who delights in the prosperity of His servant.”<br/>
**<sup>28</sup>** And my tongue will proclaim Your righteousness and Your praise all day long. 

## Chapter 36

**<sup>1</sup>** A declaration of rebellion resides in the heart of the wicked; there is no dread of God before their eyes. **<sup>2</sup>** For they flatter themselves in their own sight, thinking their guilt will not be uncovered or despised. **<sup>3</sup>** The words of their mouth are wicked and deceitful; they have stopped acting wisely or doing good. **<sup>4</sup>** They plot wickedness on their beds; they commit themselves to a crooked path; they do not reject evil.

**<sup>5</sup>** Your steadfast love, O Lord, reaches to the heavens, your faithfulness extends to the clouds. **<sup>6</sup>** Your righteousness is like the mighty mountains, your judgments are like the vast deep; you preserve both man and beast, O Lord. **<sup>7</sup>** How precious is your steadfast love, O God! The sons of man take refuge in the shadow of your wings. **<sup>8</sup>** They feast on the abundance of your house, and you give them drink from the river of your delights. **<sup>9</sup>** For with you is the fountain of life; in your light we see light.

**<sup>10</sup>** Continue your steadfast love to those who know you, and your righteousness to the upright in heart. **<sup>11</sup>** Do not let the foot of the arrogant trample me, nor the hand of the wicked drive me away. **<sup>12</sup>** There the evildoers have fallen; they are thrust down and cannot rise. 

## Chapter 37

**<sup>1</sup>** Do not be provoked by evildoers; do not be envious of those who do wrong. **<sup>2</sup>** For like grass they will soon wither, and like green plants they will fade away. **<sup>3</sup>** Trust in the Lord and do good; dwell in the land and cultivate faithfulness. **<sup>4</sup>** Delight yourself in the Lord, and He will give you the desires of your heart. **<sup>5</sup>** Commit your way to the Lord; trust in Him, and He will act. **<sup>6</sup>** He will bring forth your righteousness like the light, and your justice like the noonday sun.

**<sup>7</sup>** Be still before the Lord and wait patiently for Him; do not be provoked by the man who prospers in his way, by the man who carries out wicked schemes. **<sup>8</sup>** Cease from anger and forsake wrath; do not be provoked—it leads only to evil. **<sup>9</sup>** For evildoers will be cut off, but those who wait for the Lord will inherit the land. **<sup>10</sup>** Yet a little while, and the wicked man will be no more; though you look for his place, he will not be there. **<sup>11</sup>** But the humble will inherit the land and will delight in abundant peace.

**<sup>12</sup>** The wicked man plots against the righteous and gnashes his teeth at him. **<sup>13</sup>** The Lord laughs at him, for He sees that his day is coming. **<sup>14</sup>** The wicked have drawn the sword and bent their bow to bring down the poor and needy, to slay those whose way is upright. **<sup>15</sup>** Their sword will enter their own heart, and their bows will be broken.

**<sup>16</sup>** Better is the little that the righteous man has than the abundance of many wicked men. **<sup>17</sup>** For the arms of the wicked will be broken, but the Lord upholds the righteous. **<sup>18</sup>** The Lord knows the days of the blameless, and their inheritance will last forever. **<sup>19</sup>** They will not be ashamed        In evil times, and in days of famine they will be satisfied. **<sup>20</sup>** But the wicked will perish; the enemies of the Lord, like the glory of the pastures, will vanish—they will vanish like smoke.

**<sup>21</sup>** The wicked man borrows and does not repay, but the righteous man is gracious and gives. **<sup>22</sup>** For those blessed by Him will inherit the land, but those cursed by Him will be cut off. **<sup>23</sup>** The steps of a man are established by the Lord, and He delights in his way. **<sup>24</sup>** Though he falls, he will not be cast down, for the Lord upholds his hand.

**<sup>25</sup>** I have been young, and now I am old, yet I have not seen the righteous forsaken or his children begging for bread. **<sup>26</sup>** All day long he is gracious and lends, and his offspring are a blessing. **<sup>27</sup>** Turn away from evil and do good, and dwell forever. **<sup>28</sup>** For the Lord loves justice and will not forsake His godly ones; they are preserved forever, but the offspring of the wicked will be cut off. **<sup>29</sup>** The righteous will inherit the land and dwell in it forever.

**<sup>30</sup>** The mouth of the righteous man utters wisdom, and his tongue speaks justice. **<sup>31</sup>** The law of his God is in his heart; his steps do not slip. **<sup>32</sup>** The wicked man watches the righteous and seeks to kill him. **<sup>33</sup>** The Lord will not abandon him to his hand or let him be condemned when he is judged.

**<sup>34</sup>** Wait for the Lord and keep His way, and He will exalt you to inherit the land; when the wicked are cut off, you will see it. **<sup>35</sup>** I have seen a wicked, ruthless man flourishing like a luxuriant native tree. **<sup>36</sup>** But he passed away, and behold, he was no more; though I sought him, he could not be found.

**<sup>37</sup>** Observe the blameless man and consider the upright, for the man of peace has a future. **<sup>38</sup>** But transgressors will be destroyed together; the future of the wicked will be cut off. **<sup>39</sup>** The salvation of the righteous is from the Lord; He is their stronghold in the time of trouble. **<sup>40</sup>** The Lord helps them and delivers them; He delivers them from the wicked and saves them, because they take refuge in Him. 

## Chapter 38

**<sup>1</sup>** O Lord, do not rebuke me in your anger, nor discipline me in your wrath. **<sup>2</sup>** For your arrows have pierced me, and your hand has come down upon me. **<sup>3</sup>** There is no soundness in my flesh because of your indignation; there is no health in my bones because of my sin. **<sup>4</sup>** For my iniquities have gone over my head; like a heavy burden, they are too heavy for me. **<sup>5</sup>** My wounds stink and fester because of my foolishness. **<sup>6</sup>** I am bent over and greatly bowed down; I go about mourning all day long. **<sup>7</sup>** For my loins are filled with burning, and there is no soundness in my flesh. **<sup>8</sup>** I am feeble and utterly crushed; I groan because of the turmoil of my heart.

**<sup>9</sup>** Lord, all my longing is before you, and my sighing is not hidden from you. **<sup>10</sup>** My heart throbs, my strength fails me, and the light of my eyes—it also has gone from me. **<sup>11</sup>** My friends and companions stand aloof from my plague, and my kinsmen stand far off. **<sup>12</sup>** Those who seek my life lay snares for me; those who seek my hurt speak of ruin and meditate treachery all day long.

**<sup>13</sup>** But I am like a deaf man; I do not hear, like a mute man who does not open his mouth. **<sup>14</sup>** I have become like a man who does not hear, and in whose mouth are no rebukes. **<sup>15</sup>** For I hope in you, O Lord; you will answer, O Lord my God. **<sup>16</sup>** For I said, “Lest they rejoice over me; when my foot slips, they magnify themselves against me.” **<sup>17</sup>** For I am ready to fall, and my pain is always before me. **<sup>18</sup>** I confess my iniquity; I am sorry for my sin.

**<sup>19</sup>** But my enemies are vigorous; they are strong, and those who hate me wrongfully are multiplied. **<sup>20</sup>** Those who render me evil for good accuse me because I follow after good. **<sup>21</sup>** Do not forsake me, O Lord; O my God, be not far from me. **<sup>22</sup>** Hasten to help me, O Lord, my salvation. 

## Chapter 39

**<sup>1</sup>** I said, "I will guard my ways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may not sin with my tongue;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will put a muzzle on my mouth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while the wicked are in my presence."

**<sup>2</sup>** I was silent and held my peace,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even from good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but my distress grew worse.

**<sup>3</sup>** My heart grew hot within me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as I meditated, the fire burned.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then I spoke with my tongue:

**<sup>4</sup>** "O Lord, make me know my end<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the measure of my days, what it is;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me know how fleeting I am.

**<sup>5</sup>** Behold, You have made my days a few handbreadths,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my lifetime is as nothing before You.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Surely every man stands as a mere breath.

**<sup>6</sup>** Surely man goes about as a shadow!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Surely they busy themselves in vain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he heaps up wealth, not knowing who will gather it.

**<sup>7</sup>** And now, O Lord, for what do I wait?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My hope is in You.

**<sup>8</sup>** Deliver me from all my transgressions;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not make me the scorn of the fool.

**<sup>9</sup>** I am silent; I do not open my mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for You have done it.

**<sup>10</sup>** Remove Your stroke from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am worn down by the blow of Your hand.

**<sup>11</sup>** When You discipline a man with rebukes for sin,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You consume like a moth what is dear to him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;surely every man is but a breath.

**<sup>12</sup>** Hear my prayer, O Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and give ear to my cry;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not be silent at my tears.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I am a sojourner with You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a foreigner, as all my fathers were.

**<sup>13</sup>** Look away from me, that I may regain strength<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before I depart and am no more.”<br/>


## Chapter 40

**<sup>1</sup>** I waited patiently for the Lord, and He turned to me and heard my cry. **<sup>2</sup>** He lifted me out of the pit of destruction, out of the muddy clay,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and set my feet on a rock, making my steps secure.<br/>
**<sup>3</sup>** He put a new song in my mouth, a hymn of praise to our God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Many will see and fear and put their trust in the Lord.

**<sup>4</sup>** Blessed is the man who makes the Lord his trust,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who does not turn to the proud or to those who follow lies.<br/>
**<sup>5</sup>** Lord my God, You have done many wondrous things—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your plans for us are beyond compare.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If I were to speak and declare them all, they would be too numerous to count.

**<sup>6</sup>** You take no delight in sacrifice and offering; You have opened my ears.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Burnt offerings and sin offerings You have not required.

**<sup>7</sup>** Then I said, “Here I am; in the scroll of the book it is written about me. **<sup>8</sup>** I delight to do Your will, my God; Your law is within my heart.”

**<sup>9</sup>** I have proclaimed righteousness in the great assembly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;indeed, I do not restrain my lips—You, Lord, know this.<br/>
**<sup>10</sup>** I have not hidden Your righteousness in my heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Rather, I have spoken openly of Your faithfulness and salvation.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have not concealed Your lovingkindness and truth from the great assembly.

**<sup>11</sup>** Lord, do not withhold Your mercy from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may Your lovingkindness and truth always guard me.<br/>
**<sup>12</sup>** For troubles without number have surrounded me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my iniquities have overtaken me—I cannot see.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They are more than the hairs of my head, and my courage has abandoned me.

**<sup>13</sup>** Lord, be pleased to rescue me; hurry to help me, O Lord. **<sup>14</sup>** Let those who seek to destroy my life be ashamed and humiliated together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let those who take delight in my harm be turned back in disgrace.<br/>
**<sup>15</sup>** Let those who say to me, “Aha! Aha!” be appalled because of their shame.

**<sup>16</sup>** But may all who seek You rejoice and be glad in You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may those who love Your salvation always say, “The Lord is great!”<br/>
**<sup>17</sup>** As for me, I am poor and needy, but the Lord thinks of me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are my help and my deliverer—my God, do not delay.<br/>


## Chapter 41

**<sup>1</sup>** Blessed is the man who considers the poor;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD will deliver him in the day of trouble.<br/>
**<sup>2</sup>** The LORD will protect him and keep him alive;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will be called blessed in the land.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You will not hand him over to the desire of his enemies.

**<sup>3</sup>** The LORD will sustain him on his sickbed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in his illness, You restore him to full health.<br/>
**<sup>4</sup>** As for me, I said, “O LORD, be gracious to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;heal my soul, for I have sinned against You.”

**<sup>5</sup>** My enemies speak evil of me: “When will he die and his name perish?” **<sup>6</sup>** And if one comes to see me, he speaks lies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his heart gathers iniquity for itself. When he goes out, he tells it abroad.<br/>
**<sup>7</sup>** All who hate me whisper together against me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they imagine the worst for me.

**<sup>8</sup>** They say, “A wicked thing is poured out upon him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;now that he lies down, he will not rise again.”<br/>
**<sup>9</sup>** Even my close friend, in whom I trusted,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who ate my bread, has lifted up his heel against me.<br/>
**<sup>10</sup>** But You, O LORD, be gracious to me and raise me up, that I may repay them.

**<sup>11</sup>** By this I know that You delight in me:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my enemy does not triumph over me.<br/>
**<sup>12</sup>** As for me, You uphold me in my integrity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and set me in Your presence forever.<br/>
**<sup>13</sup>** Blessed be the LORD, the God of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from everlasting to everlasting. Amen and Amen.<br/>


## Chapter 42

**<sup>1</sup>** As the deer pants for streams of water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so my soul pants for You, O God.<br/>
**<sup>2</sup>** My soul thirsts for God, for the living God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;When shall I come and appear before God?

**<sup>3</sup>** My tears have been my food day and night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while they continually say to me, “Where is your God?”<br/>
**<sup>4</sup>** These things I remember as I pour out my soul within me:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how I would go with the multitude,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;leading them in procession to the house of God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with a voice of joy and thanksgiving, a crowd keeping festival.

**<sup>5</sup>** Why are you cast down, O my soul?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And why are you in turmoil within me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hope in God, for I shall yet praise Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the salvation of my countenance and my God.

**<sup>6</sup>** My soul is cast down within me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore I remember You from the land of the Jordan<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the heights of Hermon, from Mount Mizar.<br/>
**<sup>7</sup>** Deep calls to deep at the roar of Your waterfalls;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all Your breakers and Your waves have gone over me.

**<sup>8</sup>** By day the Lord commands His lovingkindness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and at night His song is with me— a prayer to the God of my life.<br/>
**<sup>9</sup>** I say to God, my rock, “Why have You forgotten me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why must I go mourning because of the oppression of the enemy?”<br/>
**<sup>10</sup>** As with a deadly wound in my bones, my adversaries taunt me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while they say to me all day long, “Where is your God?”

**<sup>11</sup>** Why are you cast down, O my soul?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And why are you in turmoil within me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hope in God, for I shall yet praise Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the salvation of my countenance and my God.<br/>


## Chapter 43

**<sup>1</sup>** Vindicate me, O God, and plead my case against an ungodly nation;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;deliver me from the deceitful and wicked man.<br/>
**<sup>2</sup>** For You are the God of my refuge—why have You rejected me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why do I go about in mourning because of the oppression of the enemy?

**<sup>3</sup>** Send out Your light and Your truth—let them guide me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them bring me to Your holy mountain and to Your dwelling places.<br/>
**<sup>4</sup>** Then I will go to the altar of God, to God, my exceeding joy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will praise You with the lyre, O God, my God.

**<sup>5</sup>** Why are you cast down, O my soul, and why are you in turmoil within me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hope in God, for I shall again praise Him, my salvation and my God.<br/>


## Chapter 44

**<sup>1</sup>** O God, with our ears we have heard—our fathers have told us—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the work that you did in their days, in the days of old.<br/>
**<sup>2</sup>** You, with your own hand, drove out the nations, but them you planted;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you afflicted the peoples, but them you set free.<br/>
**<sup>3</sup>** For it was not by their sword that they took possession of the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor did their arm save them, but your right hand, your arm, and the light of your face—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you delighted in them.

**<sup>4</sup>** You are my King, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;command salvation for Jacob.<br/>
**<sup>5</sup>** Through you we push back our foes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;through your name we trample down those who rise against us.<br/>
**<sup>6</sup>** For not in my bow do I trust, and my sword does not save me. **<sup>7</sup>** But you have saved us from our foes and have put to shame those who hate us. **<sup>8</sup>** In God we have boasted all day long,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and we will give thanks to your name forever.

**<sup>9</sup>** Yet you have rejected us and disgraced us, and you do not go out with our armies. **<sup>10</sup>** You make us turn back from the foe, and those who hate us have taken spoil for themselves. **<sup>11</sup>** You make us like sheep for slaughter and have scattered us among the nations. **<sup>12</sup>** You sell your people for nothing and have gained no profit from their sale. **<sup>13</sup>** You make us a reproach to our neighbors, a scoffing and derision to those around us. **<sup>14</sup>** You make us a byword among the nations, a shaking of the head among the peoples. **<sup>15</sup>** All day long my disgrace is before me, and the shame of my face covers me **<sup>16</sup>** because of the voice of the one who taunts and reviles, because of the enemy and the avenger.

**<sup>17</sup>** All this has come upon us, yet we have not forgotten you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor have we been false to your covenant.<br/>
**<sup>18</sup>** Our heart has not turned back,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor have our steps departed from your way,<br/>
**<sup>19</sup>** though you have crushed us in the place of jackals<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and covered us with deep darkness.

**<sup>20</sup>** If we had forgotten the name of our God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or spread out our hands to a foreign god,<br/>
**<sup>21</sup>** would not God discover this?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For he knows the secrets of the heart.<br/>
**<sup>22</sup>** Yet for your sake we are killed all day long;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we are regarded as sheep to be slaughtered.

**<sup>23</sup>** Awake! Why do you sleep, O Lord?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Arise! Do not reject us forever.<br/>
**<sup>24</sup>** Why do you hide your face?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why do you forget our affliction and oppression?<br/>
**<sup>25</sup>** For our soul is bowed down to the dust;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our belly clings to the ground.<br/>
**<sup>26</sup>** Rise up; come to our help.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Redeem us for the sake of your steadfast love.<br/>


## Chapter 45

**<sup>1</sup>** My heart overflows with a good theme;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I address my verses to the king;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my tongue is the pen of a skillful scribe.<br/>
**<sup>2</sup>** You are fairer than the sons of men;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;grace is poured upon your lips;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore God has blessed you forever.<br/>
**<sup>3</sup>** Gird your sword on your thigh, O mighty one, in your splendor and your majesty!

**<sup>4</sup>** And in your majesty ride forth victoriously for the cause of truth and humility and righteousness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your right hand teach you awesome deeds.

**<sup>5</sup>** Your arrows are sharp—nations fall under you—the arrows are in the heart of the king’s enemies. **<sup>6</sup>** Your throne, O God, is forever and ever; a scepter of uprightness is the scepter of your kingdom. **<sup>7</sup>** You have loved righteousness and hated wickedness; therefore God, your God, has anointed you with the oil of joy above your companions. **<sup>8</sup>** All your garments are fragrant with myrrh and aloes and cassia;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from ivory palaces stringed instruments make you glad.

**<sup>9</sup>** Daughters of kings are among your noble women;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at your right hand stands the queen in gold from Ophir.

**<sup>10</sup>** Listen, O daughter, and see, and incline your ear:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;forget your people and your father’s house,

**<sup>11</sup>** and the king will desire your beauty.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Bow to him, for he is your lord.

**<sup>12</sup>** And the daughter of Tyre will come with a gift;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the wealthy of the people will seek your favor.

**<sup>13</sup>** The king’s daughter is all glorious within;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her clothing is interwoven with gold.

**<sup>14</sup>** In embroidered garments she is led to the king;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the virgins, her companions who follow her, are brought to you.

**<sup>15</sup>** They are led with joy and gladness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they enter into the palace of the king.

**<sup>16</sup>** In place of your fathers will be your sons;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you shall make them princes in all the earth.

**<sup>17</sup>** I will cause your name to be remembered in all generations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore the nations will praise you forever and ever.<br/>


## Chapter 46

**<sup>1</sup>** God is our refuge and strength, a very present help in trouble. **<sup>2</sup>** Therefore we will not fear, though the earth gives way, though the mountains be moved into the heart of the sea; **<sup>3</sup>** though its waters roar and foam, though the mountains tremble at its swelling. Selah **<sup>4</sup>** There is a river whose streams make glad the city of God, the holy dwelling place of the Most High. **<sup>5</sup>** God is in the midst of her; she shall not be shaken; God will help her at the break of dawn. **<sup>6</sup>** The nations rage, kingdoms totter; He raises His voice, the earth melts. **<sup>7</sup>** The Lord of hosts is with us; the God of Jacob is our fortress. Selah **<sup>8</sup>** Come, behold the works of the Lord, how He has brought desolations on the earth. **<sup>9</sup>** He makes wars cease to the end of the earth; He breaks the bow and shatters the spear; He burns the chariots with fire. **<sup>10</sup>** “Be still, and know that I am God. I will be exalted among the nations, I will be exalted on the earth.” **<sup>11</sup>** The Lord of hosts is with us; the God of Jacob is our fortress. Selah 

## Chapter 47

**<sup>1</sup>** Clap your hands, all you nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shout to God with a ringing voice of joy.<br/>
**<sup>2</sup>** For the LORD Most High is to be feared,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a great King over all the earth.

**<sup>3</sup>** He subdues nations under us<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and peoples beneath our feet.<br/>
**<sup>4</sup>** He chooses our inheritance for us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the pride of Jacob, whom He loves. Selah

**<sup>5</sup>** God has gone up with a shout,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD with the sound of a trumpet.<br/>
**<sup>6</sup>** Sing praises to God, sing praises;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sing praises to our King, sing praises.

**<sup>7</sup>** For God is the King of all the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sing a psalm of understanding.<br/>
**<sup>8</sup>** God reigns over the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God sits on His holy throne.

**<sup>9</sup>** The nobles of the peoples gather<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as the people of the God of Abraham;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the shields of the earth belong to God—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is greatly exalted.<br/>


## Chapter 48

**<sup>1</sup>** Great is the Lord and greatly to be praised in the city of our God, in His holy mountain. **<sup>2</sup>** Beautiful in elevation, the joy of the whole earth, Mount Zion on the far north, the city of the great King.

**<sup>3</sup>** God is in her citadels; He is known as her refuge. **<sup>4</sup>** For behold, the kings assembled, they passed by together.

**<sup>5</sup>** They saw it, then they were astounded; they were dismayed and fled in panic. **<sup>6</sup>** Trembling seized them there, anguish like that of a woman in labor.

**<sup>7</sup>** With the east wind You shattered the ships of Tarshish. **<sup>8</sup>** Just as we have heard, so have we seen in the city of the Lord of hosts, in the city of our God: God will establish her forever. Selah.

**<sup>9</sup>** We have meditated on Your loyal love, O God, in the midst of Your temple. **<sup>10</sup>** As is Your name, O God, so is Your praise to the ends of the earth; Your right hand is full of righteousness.

**<sup>11</sup>** Let Mount Zion rejoice, let the daughters of Judah exult because of Your judgments. **<sup>12</sup>** Walk around Zion, go all around her; count her towers.

**<sup>13</sup>** Consider her ramparts, examine her citadels, so that you may tell the next generation, **<sup>14</sup>** that this is God, our God forever and ever; He will guide us beyond death. 

## Chapter 49

**<sup>1</sup>** Hear this, all nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give ear, all inhabitants of the world,<br/>
**<sup>2</sup>** both low and high, rich and poor together. **<sup>3</sup>** My mouth shall speak wisdom, and the meditation of my heart shall be understanding. **<sup>4</sup>** I will incline my ear to a proverb;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will solve my riddle to the music of the lyre.

**<sup>5</sup>** Why should I fear in days of evil, when the iniquity of my foes surrounds me, **<sup>6</sup>** those who trust in their wealth and boast in the abundance of their riches? **<sup>7</sup>** A brother can by no means redeem;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a man cannot give to God a ransom for him—<br/>
**<sup>8</sup>** for the redemption of their soul is costly, and he must abandon the attempt forever— **<sup>9</sup>** so that he should live on forever and not see the pit.

**<sup>10</sup>** For he sees that wise men die; likewise the fool and the senseless perish, and leave their wealth to others. **<sup>11</sup>** Their graves are their houses forever, their dwelling places from generation to generation, though they had named lands after themselves. **<sup>12</sup>** But man, though in honor, does not endure; he is like the beasts that perish.

**<sup>13</sup>** This is the path of those who are foolish, and of those after them who approve of their sayings. Selah. **<sup>14</sup>** Like sheep they are appointed for the grave; death shall be their shepherd, and the upright shall rule over them in the morning. Their form shall waste away in the grave, far from their lofty abode.

**<sup>15</sup>** But God will redeem my soul from the hand of the grave, for He will receive me. Selah.

**<sup>16</sup>** Do not be afraid when a man becomes rich, when the glory of his house increases. **<sup>17</sup>** For when he dies he will carry nothing away; his glory will not descend after him. **<sup>18</sup>** Though he blesses himself during his life— and though men praise you when you prosper— **<sup>19</sup>** he shall go to the generation of his fathers; they shall never see the light.

**<sup>20</sup>** A man who is honored yet does not understand is like the beasts that perish. 

## Chapter 50

**<sup>1</sup>** The Mighty One, God, the LORD, has spoken and summoned the earth from the rising of the sun to its setting. **<sup>2</sup>** Out of Zion, the perfection of beauty, God has shone forth. **<sup>3</sup>** Our God comes and does not keep silence; a fire devours before Him, and around Him a mighty tempest rages. **<sup>4</sup>** He calls to the heavens above and to the earth, that He may judge His people: **<sup>5</sup>** "Gather to Me My faithful ones, those who have made a covenant with Me by sacrifice." **<sup>6</sup>** And the heavens declare His righteousness, for God Himself is judge. Selah.

**<sup>7</sup>** "Hear, O My people, and I will speak; O Israel, and I will testify against you: I am God, your God. **<sup>8</sup>** Not for your sacrifices do I rebuke you; your burnt offerings are continually before Me. **<sup>9</sup>** I will not take a bull from your house, nor goats from your folds. **<sup>10</sup>** For every beast of the forest is Mine, the cattle on a thousand hills. **<sup>11</sup>** I know all the birds of the mountains, and everything that moves in the field is Mine. **<sup>12</sup>** If I were hungry, I would not tell you, for the world and its fullness are Mine. **<sup>13</sup>** Do I eat the flesh of bulls, or drink the blood of goats?

**<sup>14</sup>** Offer to God a sacrifice of thanksgiving, and fulfill your vows to the Most High. **<sup>15</sup>** And call upon Me in the day of trouble; I will deliver you, and you shall glorify Me."

**<sup>16</sup>** But to the wicked God says: "What right have you to recite My statutes or to take My covenant on your lips? **<sup>17</sup>** For you hate discipline, and you cast My words behind you. **<sup>18</sup>** When you see a thief, you are pleased with him, and you keep company with adulterers. **<sup>19</sup>** You give your mouth free rein for evil, and your tongue frames deceit. **<sup>20</sup>** You sit and speak against your brother; you slander your own mother's son. **<sup>21</sup>** These things you have done, and I kept silent; you thought that I was one like yourself. But now I rebuke you and lay the charge before your eyes.

**<sup>22</sup>** Mark this, then, you who forget God, lest I tear you apart, and there be none to deliver. **<sup>23</sup>** He who offers a sacrifice of thanksgiving honors Me; and to him who orders his way rightly I will show the salvation of God." 

## Chapter 51

**<sup>1</sup>** Have mercy on me, O God, according to Your steadfast love; according to the greatness of Your compassion, blot out my transgressions. **<sup>2</sup>** Wash me thoroughly from my iniquity, and cleanse me from my sin. **<sup>3</sup>** For I know my transgressions, and my sin is ever before me. **<sup>4</sup>** Against You, and You alone, I have sinned, and have done what is evil in Your sight, so that You are justified when You speak, and blameless when You judge.

**<sup>5</sup>** Behold, I was brought forth in iniquity, and in sin my mother conceived me. **<sup>6</sup>** Behold, You desire truth in the inward parts, and in the hidden place You make me know wisdom.

**<sup>7</sup>** Purge me with hyssop, and I shall be clean; wash me, and I shall be whiter than snow. **<sup>8</sup>** Let me hear joy and gladness; let my bones, which You have crushed, rejoice. **<sup>9</sup>** Hide Your face from my sins, and blot out all my iniquities.

**<sup>10</sup>** Create in me a clean heart, O God, and renew a steadfast spirit within me. **<sup>11</sup>** Do not cast me away from Your presence, and do not take Your Holy Spirit from me. **<sup>12</sup>** Restore to me the joy of Your salvation, and sustain me with a willing spirit.

**<sup>13</sup>** Then I will teach transgressors Your ways, and sinners shall return to You.

**<sup>14</sup>** Deliver me from bloodguilt, O God, God of my salvation, and my tongue will sing aloud of Your righteousness. **<sup>15</sup>** O Lord, open my lips, and my mouth will declare Your praise.

**<sup>16</sup>** For You do not desire sacrifice, or I would give it; You do not take pleasure in burnt offerings. **<sup>17</sup>** The sacrifices of God are a broken spirit; a broken and contrite heart, O God, You will not despise.

**<sup>18</sup>** Do good to Zion in Your good pleasure; build the walls of Jerusalem. **<sup>19</sup>** Then You will delight in righteous sacrifices, in burnt offering and whole burnt offering; then bulls will be offered on Your altar. 

## Chapter 52

**<sup>1</sup>** Why do you boast of evil, O mighty man?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The steadfast love of God endures all day long.<br/>
**<sup>2</sup>** Your tongue devises destruction,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a sharpened razor, working deceit.<br/>
**<sup>3</sup>** You love evil more than good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lying more than speaking righteousness. Selah

**<sup>4</sup>** You love all devouring words,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O deceitful tongue.<br/>
**<sup>5</sup>** God will break you down forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will snatch you and tear you from your tent;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will uproot you from the land of the living. Selah

**<sup>6</sup>** The righteous shall see and fear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall laugh at him, saying,<br/>
**<sup>7</sup>** “Behold the man who did not make God his refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but trusted in the abundance of his riches,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and grew strong through his wickedness.”<br/>
**<sup>8</sup>** But I am like a green olive tree in the house of God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I trust in the steadfast love of God forever and ever.<br/>
**<sup>9</sup>** I will give thanks to You forever for what You have done;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will wait on Your name, for it is good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the presence of Your faithful ones.<br/>


## Chapter 53

**<sup>1</sup>** The fool says in his heart, “There is no God.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They are corrupt, and they have committed abominable injustice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is none who does good.<br/>
**<sup>2</sup>** God looks down from heaven upon the sons of man<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to see if there is one who understands, who seeks God.<br/>
**<sup>3</sup>** All of them have turned aside; together they have become corrupt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is none who does good, not even one.

**<sup>4</sup>** Do they not understand—those who work iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who devour My people as they eat bread,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not call upon God?

**<sup>5</sup>** There they were in great terror, where there was no terror,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for God scattered the bones of those who encamped against you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you put them to shame, for God rejected them.

**<sup>6</sup>** Oh that salvation for Israel would come out of Zion!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;When God restores the fortunes of His people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jacob will rejoice, Israel will be glad.<br/>


## Chapter 54

**<sup>1</sup>** O God, save me by Your name,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by Your might vindicate me.<br/>
**<sup>2</sup>** O God, hear my prayer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give ear to the words of my mouth.

**<sup>3</sup>** For strangers have risen against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ruthless men seek my life;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have not set God before them.

**<sup>4</sup>** Behold, God is my helper;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord is the upholder of my soul.<br/>
**<sup>5</sup>** He will repay the evil to my foes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in Your faithfulness, put an end to them.

**<sup>6</sup>** With a freewill offering I will sacrifice to You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will give thanks to Your name, O LORD, for it is good.<br/>
**<sup>7</sup>** For from every distress He has delivered me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my eye has looked in triumph upon my enemies.<br/>


## Chapter 55

**<sup>1</sup>** Give ear to my prayer, O God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not hide Yourself from my supplication.<br/>
**<sup>2</sup>** Attend to me and answer me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am restless in my complaint and I moan,<br/>
**<sup>3</sup>** because of the voice of the enemy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the oppression of the wicked.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For they cast iniquity upon me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in anger they bear a grudge against me.

**<sup>4</sup>** My heart writhes within me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the terrors of death have fallen upon me.<br/>
**<sup>5</sup>** Fear and trembling come upon me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and horror has overwhelmed me.<br/>
**<sup>6</sup>** And I say, “Oh, that I had wings like a dove!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I would fly away and be at rest.<br/>
**<sup>7</sup>** Behold, I would flee far away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I would lodge in the wilderness. Selah

**<sup>8</sup>** I would hasten my escape<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the stormy wind and tempest.”<br/>
**<sup>9</sup>** Confuse, O Lord, divide their tongues,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I see violence and strife in the city.<br/>
**<sup>10</sup>** Day and night they go around it on its walls,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and iniquity and trouble are within it;<br/>
**<sup>11</sup>** destruction is within it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;oppression and deceit do not depart from its public square.

**<sup>12</sup>** For it is not an enemy who reproaches me—then I could bear it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is not one who hates me who exalts himself against me—then I could hide from him.<br/>
**<sup>13</sup>** But it is you, a man my equal,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my companion and my familiar friend.<br/>
**<sup>14</sup>** We used to take sweet counsel together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;within the house of God we walked in the throng.

**<sup>15</sup>** Let death come upon them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them go down alive into the grave,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for evil is in their dwelling, in their midst.

**<sup>16</sup>** But I, I call to God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the LORD will save me.<br/>
**<sup>17</sup>** Evening and morning and at noon I complain and moan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He hears my voice.<br/>
**<sup>18</sup>** He redeems my soul in peace from the battle against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for many are against me.<br/>
**<sup>19</sup>** God will hear and humble them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He who is enthroned from of old. Selah

Because they do not change<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not fear God.**<sup>20</sup>** My companion has stretched out his hand against those at peace with him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has violated his covenant.<br/>
**<sup>21</sup>** His speech was smoother than butter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but war was in his heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his words were softer than oil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they were drawn swords.

**<sup>22</sup>** Cast your burden on the LORD, and He will sustain you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will never allow the righteous to be shaken.<br/>
**<sup>23</sup>** But You, O God, will bring them down to the pit of destruction;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;men of blood and deceit shall not live out half their days.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But as for me, I will trust in You.<br/>


## Chapter 56

**<sup>1</sup>** Be gracious to me, O God, for man tramples me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all day long an attacker oppresses me.<br/>
**<sup>2</sup>** My foes trample upon me all day long,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for many are attacking me proudly.<br/>
**<sup>3</sup>** When I am afraid, I will trust in you.

**<sup>4</sup>** In God, whose word I praise—in God I trust;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not be afraid. What can flesh do to me?

**<sup>5</sup>** All day long they twist my words;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all their thoughts are against me for evil.<br/>
**<sup>6</sup>** They stir up strife, they lurk,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they watch my steps, as they have waited for my life.<br/>
**<sup>7</sup>** Shall they escape in spite of their wrongdoing?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In anger, O God, bring down the nations.

**<sup>8</sup>** You have kept count of my wanderings;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;put my tears in your bottle—are they not in your book?<br/>
**<sup>9</sup>** Then my enemies will turn back on the day I call;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;this I know, that God is for me.

**<sup>10</sup>** In God, whose word I praise,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the Lord, whose word I praise,<br/>
**<sup>11</sup>** in God I trust; I will not be afraid.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What can man do to me?

**<sup>12</sup>** My vows to you, O God, are binding upon me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will render thank offerings to you.<br/>
**<sup>13</sup>** For you have delivered my soul from death,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yes, my feet from stumbling,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may walk before God in the light of life.<br/>


## Chapter 57

**<sup>1</sup>** Be gracious to me, O God, be gracious to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for in you my soul takes refuge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the shadow of your wings I will take refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until destruction passes by.<br/>
**<sup>2</sup>** I cry out to God Most High,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to God who accomplishes all things for me.<br/>
**<sup>3</sup>** He will send from heaven and save me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will reproach him who tramples upon me. Selah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God will send forth his mercy and his truth.<br/>
**<sup>4</sup>** My soul is in the midst of lions;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I lie down among those who devour with fire—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sons of man whose teeth are spears and arrows,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose tongue is a sharp sword.<br/>
**<sup>5</sup>** Be exalted above the heavens, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your glory be above all the earth.<br/>
**<sup>6</sup>** They set a net for my steps;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my soul was bowed down.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They dug a pit before me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they fell into it themselves. Selah.<br/>
**<sup>7</sup>** My heart is steadfast, O God, my heart is steadfast;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing and make melody.<br/>
**<sup>8</sup>** Awake, my glory!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Awake, harp and lyre!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will awaken the dawn.<br/>
**<sup>9</sup>** I will give thanks to you among the nations, O Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing praises to you among the peoples.<br/>
**<sup>10</sup>** For your mercy is great unto the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your truth unto the clouds.<br/>
**<sup>11</sup>** Be exalted above the heavens, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your glory be above all the earth.<br/>


## Chapter 58

**<sup>1</sup>** Do you indeed speak righteousness, O mighty ones?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do you judge uprightly, O sons of man?<br/>
**<sup>2</sup>** No, in your heart you work unrighteousness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with your hands you deal out violence on the earth.

**<sup>3</sup>** The wicked are estranged from the womb;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they go astray from birth, speaking lies.<br/>
**<sup>4</sup>** Their venom is like the venom of a serpent,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a deaf viper that stops its ear,<br/>
**<sup>5</sup>** so that it does not hear the voice of charmers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or of a cunning enchanter.

**<sup>6</sup>** O God, break the teeth in their mouths;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;tear out the fangs of the young lions, O LORD.<br/>
**<sup>7</sup>** Let them vanish like water that flows away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when he aims his arrows, let them be as though cut off.<br/>
**<sup>8</sup>** Let them be like a snail that melts away as it moves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like the stillborn child of a woman who never sees the sun.

**<sup>9</sup>** Before your pots can feel the heat of thorns,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whether green or burning, he will sweep them away.

**<sup>10</sup>** The righteous will rejoice when he sees the vengeance;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will wash his feet in the blood of the wicked.<br/>
**<sup>11</sup>** And man will say, “Surely there is a reward for the righteous;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;surely there is a God who judges on the earth.”<br/>


## Chapter 59

**<sup>1</sup>** Deliver me from my enemies, O my God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;set me on high from those who rise up against me.<br/>
**<sup>2</sup>** Deliver me from those who work evil, and save me from men of blood.

**<sup>3</sup>** For behold, they lie in wait for my life;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;fierce men stir up strife against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;not for my transgression nor for my sin, O LORD.<br/>
**<sup>4</sup>** Without guilt of mine, they run and prepare themselves;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;awake to meet me, and see!

**<sup>5</sup>** You, O LORD God of hosts, God of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rouse yourself to punish all the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;show no mercy to any treacherous evildoers. Selah.

**<sup>6</sup>** They return at evening, they howl like dogs,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and go around the city.<br/>
**<sup>7</sup>** Behold, they belch with their mouths;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;swords are in their lips—“For who hears?” they say.

**<sup>8</sup>** But you, O LORD, will laugh at them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you will hold all the nations in derision.<br/>
**<sup>9</sup>** O my Strength, I will watch for you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for God is my high fortress.

**<sup>10</sup>** My God in his steadfast love will meet me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God will let me look in triumph on my enemies.

**<sup>11</sup>** Do not kill them, lest my people forget;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make them wander by your power, and bring them down, O Lord, our shield.<br/>
**<sup>12</sup>** For the sin of their mouth, the word of their lips,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them be trapped in their pride;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and for cursing and lies that they utter,<br/>
**<sup>13</sup>** consume them in wrath, consume them till they are no more,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they may know that God rules in Jacob to the ends of the earth. Selah.

**<sup>14</sup>** They return at evening, they howl like dogs, and go around the city. **<sup>15</sup>** They wander about for food, and growl if they are not satisfied.

**<sup>16</sup>** But I will sing of your strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the morning I will sing aloud of your mercy.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For you have been a fortress for me and a refuge in the day of my distress.<br/>
**<sup>17</sup>** O my Strength, I will sing praises to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for God is my high fortress,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the God who shows me steadfast love.<br/>


## Chapter 60

**<sup>1</sup>** O God, you have rejected us, broken us; you have been angry—restore us. **<sup>2</sup>** You have made the land tremble; you have torn it open. Heal its fractures, for it is tottering. **<sup>3</sup>** You have shown your people hard things; you have given us wine to stagger us.

**<sup>4</sup>** You have set up a banner for those who fear you, that it may be displayed because of the truth. Selah. **<sup>5</sup>** That your beloved ones may be delivered, save with your right hand and answer us.

**<sup>6</sup>** God has spoken in his holiness: “I will exult; I will divide Shechem and measure out the Valley of Succoth. **<sup>7</sup>** Gilead is mine, and Manasseh is mine; Ephraim is the helmet of my head; Judah is my scepter. **<sup>8</sup>** Moab is my washbasin; upon Edom I cast my sandal; over Philistia I shout in triumph.”

**<sup>9</sup>** Who will bring me to the fortified city? Who will lead me to Edom? **<sup>10</sup>** Have you not rejected us, O God? You do not go out, O God, with our armies. **<sup>11</sup>** Give us help against the foe, for the help of man is worthless. **<sup>12</sup>** Through God we shall do valiantly, and he will tread down our foes. 

## Chapter 61

**<sup>1</sup>** Hear my cry, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;attend to my prayer.<br/>
**<sup>2</sup>** From the end of the earth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I call to you when my heart is faint;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lead me to the rock that is higher than I.<br/>
**<sup>3</sup>** For you have been a refuge for me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a strong tower against the enemy.

**<sup>4</sup>** Let me dwell in your tent forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me take refuge in the shelter of your wings.<br/>
**<sup>5</sup>** For you, O God, have heard my vows;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have given me the heritage of those who fear your name.

**<sup>6</sup>** You will add days to the king’s life;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his years will be as many generations.<br/>
**<sup>7</sup>** He will abide before God forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;appoint steadfast love and faithfulness to guard him.

**<sup>8</sup>** So I will sing praise to your name forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may fulfill my vows day after day.<br/>


## Chapter 62

**<sup>1</sup>** My soul waits in silence for God alone;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from him comes my salvation.<br/>
**<sup>2</sup>** He alone is my rock and my salvation, my fortress—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I shall not be greatly shaken.

**<sup>3</sup>** How long will you assail a man, all of you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to break him down, like a leaning wall, a tottering fence?<br/>
**<sup>4</sup>** Surely they plan to cast him down from his high place;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they take pleasure in falsehood.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They bless with their mouths,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but inwardly they curse.

**<sup>5</sup>** My soul, wait in silence for God alone,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for my hope is from him.<br/>
**<sup>6</sup>** He alone is my rock and my salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my fortress—I shall not be shaken.<br/>
**<sup>7</sup>** On God rests my salvation and my glory;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the rock of my strength, my refuge is in God.

**<sup>8</sup>** Trust in him at all times, O men;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;pour out your heart before him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God is a refuge for us.

**<sup>9</sup>** Surely men of low degree are vanity, and men of rank are a lie;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the balances they go up—they are altogether lighter than a breath.<br/>
**<sup>10</sup>** Do not trust in oppression, and do not set vain hopes in robbery;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if riches increase, do not set your heart upon them.

**<sup>11</sup>** God has spoken once, twice I have heard this:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that power belongs to God,<br/>
**<sup>12</sup>** and to you, O Lord, belongs steadfast love.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For you repay each man according to his work.<br/>


## Chapter 63

**<sup>1</sup>** O God, you are my God—earnestly I seek you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my soul thirsts for you, my flesh faints for you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in a dry and weary land without water.<br/>
**<sup>2</sup>** So I have looked upon you in the sanctuary,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;beholding your power and your glory.<br/>
**<sup>3</sup>** Because your steadfast love is better than life,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my lips will praise you.<br/>
**<sup>4</sup>** So I will bless you as long as I live;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in your name I will lift up my hands.

**<sup>5</sup>** My soul is satisfied as with marrow and fatness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my mouth will praise you with joyful lips,<br/>
**<sup>6</sup>** when I remember you on my bed<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and meditate on you in the night watches.<br/>
**<sup>7</sup>** For you have been my help,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in the shadow of your wings I will sing for joy.<br/>
**<sup>8</sup>** My soul clings to you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your right hand upholds me.

**<sup>9</sup>** But those who seek to destroy my life<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will go down into the depths of the earth;<br/>
**<sup>10</sup>** they shall be given over to the sword;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall be a portion for jackals.<br/>
**<sup>11</sup>** But the king will rejoice in God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;everyone who swears by him will exult,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the mouth of liars will be stopped.<br/>


## Chapter 64

**<sup>1</sup>** Hear my voice, O God, in my complaint;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;preserve my life from the terror of the enemy.<br/>
**<sup>2</sup>** Hide me from the secret plots of the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the throng of evildoers,<br/>
**<sup>3</sup>** who sharpen their tongue like a sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who aim bitter words like arrows,<br/>
**<sup>4</sup>** to shoot from ambush at the innocent;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shoot suddenly, without fear.

**<sup>5</sup>** They hold fast to their evil purpose;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they talk of laying hidden snares;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they say, “Who will see them?”<br/>
**<sup>6</sup>** They plot injustice, saying, “We have devised a perfect plan!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the inward mind and heart of man are deep.

**<sup>7</sup>** But God will shoot them with an arrow;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;suddenly they will be struck down.<br/>
**<sup>8</sup>** Their own tongue will bring them ruin;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all who see them will shake their heads.<br/>
**<sup>9</sup>** Then all men will fear;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will declare the work of God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and consider what he has done.<br/>
**<sup>10</sup>** The righteous will rejoice in the LORD and take refuge in him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the upright in heart will glory.<br/>


## Chapter 65

**<sup>1</sup>** Praise waits for you, O God, in Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to you shall the vow be fulfilled.<br/>
**<sup>2</sup>** O you who hear prayer,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to you all flesh will come.<br/>
**<sup>3</sup>** Iniquities prevail against me—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our transgressions, you will atone for them.<br/>
**<sup>4</sup>** Blessed is the man you choose and bring near, to dwell in your courts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;We shall be satisfied with the goodness of your house, the holiness of your temple.

**<sup>5</sup>** By awesome deeds in righteousness you answer us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O God of our salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the confidence of all the ends of the earth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and of the farthest sea,<br/>
**<sup>6</sup>** who establishes the mountains by his strength,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;being girded with might,<br/>
**<sup>7</sup>** who stills the roaring of the seas,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the roaring of their waves, and the tumult of the nations.<br/>
**<sup>8</sup>** Those who dwell at the ends of the earth stand in awe of your signs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you make the going out of the morning and the evening to shout for joy.

**<sup>9</sup>** You visit the earth and water it, you greatly enrich it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the river of God is full of water; you provide their grain, for so you have prepared it.<br/>
**<sup>10</sup>** You water its furrows abundantly, settling its ridges,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;softening it with showers, blessing its growth.<br/>
**<sup>11</sup>** You crown the year with your goodness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your paths drip with abundance.<br/>
**<sup>12</sup>** The pastures of the wilderness drip,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the hills gird themselves with joy.<br/>
**<sup>13</sup>** The meadows are clothed with flocks, and the valleys are covered with grain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shout and sing together for joy.<br/>


## Chapter 66

**<sup>1</sup>** Shout joyfully to God, all the earth. **<sup>2</sup>** Sing the glory of His name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make His praise glorious.<br/>
**<sup>3</sup>** Say to God, “How awesome are Your works!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Because of the greatness of Your power,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your enemies come bowing before You.<br/>
**<sup>4</sup>** All the earth will worship You and sing praises to You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will sing praises to Your name.”

**<sup>5</sup>** Come and see the works of God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is awesome in His deeds toward the sons of man.<br/>
**<sup>6</sup>** He turned the sea into dry land;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they passed through the river on foot;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Let us rejoice in Him there.<br/>
**<sup>7</sup>** He rules by His own power forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His eyes keep watch on the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let not the rebellious exalt themselves.

**<sup>8</sup>** Bless our God, O peoples,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and sound aloud the voice of His praise,<br/>
**<sup>9</sup>** who keeps our soul in life<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and does not allow our foot to slip.<br/>
**<sup>10</sup>** For You have tested us, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have refined us as silver is refined.<br/>
**<sup>11</sup>** You brought us into the net;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You laid a burden upon our loins.<br/>
**<sup>12</sup>** You made men ride over our heads;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we went through fire and through water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but You brought us out to a place of abundance.

**<sup>13</sup>** I shall come into Your house with burnt offerings;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I shall pay You my vows,<br/>
**<sup>14</sup>** which my lips uttered<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my mouth spoke when I was in distress.<br/>
**<sup>15</sup>** I shall offer to You burnt offerings of fatlings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the smoke of rams;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I shall offer bulls with male goats.

**<sup>16</sup>** Come and hear, all who fear God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will declare what He has done for my soul.<br/>
**<sup>17</sup>** I cried to Him with my mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He was glorified by my tongue.<br/>
**<sup>18</sup>** If I had regarded iniquity in my heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord would not have heard.<br/>
**<sup>19</sup>** But surely God has heard;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has given heed to the voice of my prayer.<br/>
**<sup>20</sup>** Blessed be God, who has not turned away my prayer<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor His lovingkindness from me.<br/>


## Chapter 67

**<sup>1</sup>** May God be gracious to us and bless us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cause His face to shine upon us,<br/>
**<sup>2</sup>** that Your way may be known on the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your salvation among all nations.

**<sup>3</sup>** Let the peoples praise You, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let all the peoples praise You.<br/>
**<sup>4</sup>** Let the nations be glad and sing for joy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for You will judge the peoples with uprightness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and guide the nations on the earth.

**<sup>5</sup>** Let the peoples praise You, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let all the peoples praise You.

**<sup>6</sup>** The earth has yielded its produce;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God, our God, will bless us.<br/>
**<sup>7</sup>** God will bless us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the ends of the earth will fear Him.<br/>


## Chapter 68

**<sup>1</sup>** Let God arise, let His enemies be scattered;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let those who hate Him flee before Him.<br/>
**<sup>2</sup>** As smoke is driven away, so drive them away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as wax melts before the fire, so let the wicked perish before God.<br/>
**<sup>3</sup>** But the righteous shall be glad;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall rejoice before God and exult with joy.

**<sup>4</sup>** Sing to God, sing praises to His name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lift up a song to Him who rides through the deserts—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His name is the LORD—exult before Him.<br/>
**<sup>5</sup>** A father to the fatherless and a judge for the widows<br/>
&nbsp;&nbsp;&nbsp;&nbsp;is God in His holy habitation.<br/>
**<sup>6</sup>** God sets the solitary in families;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He brings out those who are bound with chains,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the rebellious dwell in a parched land.

**<sup>7</sup>** O God, when You went out before Your people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when You marched through the wilderness—Selah<br/>
**<sup>8</sup>** The earth trembled, the heavens also dropped rain at the presence of God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Sinai itself quaked at the presence of God, the God of Israel.<br/>
**<sup>9</sup>** You caused abundant rain to fall, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You confirmed Your inheritance when it was weary.<br/>
**<sup>10</sup>** Your congregation dwelled in it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You, O God, prepared it in Your goodness for the poor.

**<sup>11</sup>** The Lord gives the command;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;great is the company of those who proclaim it.<br/>
**<sup>12</sup>** Kings of armies flee—they flee!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And she who remains at home divides the spoil.<br/>
**<sup>13</sup>** Though you lie among the sheepfolds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the wings of a dove are covered with silver,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its pinions with shimmering gold.<br/>
**<sup>14</sup>** When the Almighty scattered kings there, it snowed on Zalmon.

**<sup>15</sup>** A mountain of God is the mountain of Bashan;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a mountain of many peaks is the mountain of Bashan.<br/>
**<sup>16</sup>** Why do you look with envy, O mountains of many peaks,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the mountain which God has desired for His dwelling?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Yes, the LORD will dwell there forever.<br/>
**<sup>17</sup>** The chariots of God are twice ten thousand, thousands upon thousands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Lord is among them at Sinai in holiness.<br/>
**<sup>18</sup>** You have ascended on high, You have led captive captives;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have received gifts among men, even among the rebellious,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that the LORD God might dwell there.

**<sup>19</sup>** Blessed be the Lord, who daily bears us up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God is our salvation. Selah<br/>
**<sup>20</sup>** Our God is a God of deliverances,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to the LORD, the Lord, belongs escape from death.<br/>
**<sup>21</sup>** But God will shatter the heads of His enemies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the hairy scalp of him who walks in guilt.

**<sup>22</sup>** The Lord said, “I will bring them back from Bashan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will bring them back from the depths of the sea,<br/>
**<sup>23</sup>** that your foot may shatter them in blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the tongue of your dogs may have its share from the enemies.”

**<sup>24</sup>** They have seen Your processions, O God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the processions of my God, my King, into the sanctuary.<br/>
**<sup>25</sup>** The singers went before, the musicians followed after,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the midst were maidens playing tambourines.<br/>
**<sup>26</sup>** Bless God in the congregations, the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O you who are from the fountain of Israel.<br/>
**<sup>27</sup>** There is Benjamin, the youngest, ruling over them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the princes of Judah in their throng, the princes of Zebulun, the princes of Naphtali.

**<sup>28</sup>** Your God has commanded your strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;show Yourself strong, O God, as You have done for us before.<br/>
**<sup>29</sup>** Because of Your temple at Jerusalem kings will bring gifts to You. **<sup>30</sup>** Rebuke the beasts of the reeds, the herd of bulls with the calves of the peoples, trampling underfoot the pieces of silver;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has scattered the peoples who delight in war.<br/>
**<sup>31</sup>** Envoys will come out of Egypt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Cush will hasten to stretch out her hands to God.

**<sup>32</sup>** Sing to God, O kingdoms of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sing praises to the Lord—Selah<br/>
**<sup>33</sup>** To Him who rides in the heavens, the ancient heavens;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;behold, He sends out His voice, a mighty voice.<br/>
**<sup>34</sup>** Ascribe strength to God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His majesty is over Israel, and His strength is in the skies.<br/>
**<sup>35</sup>** O God, You are awesome from Your sanctuary;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the God of Israel gives strength and power to the people. Blessed be God!<br/>


## Chapter 69

**<sup>1</sup>** Save me, O God, for the waters have come up to my neck. **<sup>2</sup>** I sink in deep mire, where there is no footing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have come into deep waters, and the flood sweeps over me.<br/>
**<sup>3</sup>** I am weary with my crying; my throat is parched;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my eyes fail while I wait for my God.

**<sup>4</sup>** More numerous than the hairs of my head are those who hate me without cause;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;mighty are those who would destroy me, my enemies falsely;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;what I did not steal, I must restore.<br/>
**<sup>5</sup>** O God, you know my folly,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my guilt is not hidden from you.

**<sup>6</sup>** Let not those who wait for you be put to shame through me, O Lord GOD of hosts;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let not those who seek you be dishonored through me, O God of Israel.<br/>
**<sup>7</sup>** For it is for your sake that I have borne reproach,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that shame has covered my face.<br/>
**<sup>8</sup>** I have become a stranger to my brothers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and an alien to my mother’s sons.<br/>
**<sup>9</sup>** For zeal for your house has consumed me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the reproaches of those who reproach you have fallen on me.

**<sup>10</sup>** When I wept and humbled my soul with fasting,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it became my reproach.<br/>
**<sup>11</sup>** When I made sackcloth my clothing,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I became a byword to them.<br/>
**<sup>12</sup>** Those who sit in the gate speak against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I am the song of the drunkards.

**<sup>13</sup>** But as for me, my prayer is to you, O LORD, at an acceptable time;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O God, in the abundance of your steadfast love, answer me in your saving faithfulness.<br/>
**<sup>14</sup>** Deliver me from the mire, and do not let me sink;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me be delivered from those who hate me, and from the deep waters.<br/>
**<sup>15</sup>** Do not let the flood sweep over me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or the deep swallow me up,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or the pit close its mouth over me.

**<sup>16</sup>** Answer me, O LORD, for your steadfast love is good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to your abundant mercy, turn to me.<br/>
**<sup>17</sup>** Do not hide your face from your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am in distress; make haste to answer me.<br/>
**<sup>18</sup>** Draw near to my soul and redeem it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;ransom me because of my enemies.

**<sup>19</sup>** You know my reproach, and my shame and my dishonor;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my adversaries are all before you.<br/>
**<sup>20</sup>** Reproach has broken my heart, and I am in despair.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I looked for pity, but there was none,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and for comforters, but I found none.<br/>
**<sup>21</sup>** They gave me poison for food,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and for my thirst they gave me vinegar to drink.

**<sup>22</sup>** Let their table before them become a snare,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and when they are at peace, let it become a trap.<br/>
**<sup>23</sup>** Let their eyes be darkened so that they cannot see,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and make their loins tremble continually.<br/>
**<sup>24</sup>** Pour out your indignation upon them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let your burning anger overtake them.<br/>
**<sup>25</sup>** May their camp be desolate;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let no one dwell in their tents.

**<sup>26</sup>** For they persecute him whom you have struck down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they recount the pain of those you have wounded.<br/>
**<sup>27</sup>** Add guilt to their guilt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let them not come into your righteousness.<br/>
**<sup>28</sup>** Let them be blotted out of the book of the living;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them not be enrolled among the righteous.

**<sup>29</sup>** But I am afflicted and in pain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your salvation, O God, set me on high.<br/>
**<sup>30</sup>** I will praise the name of God with a song;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will magnify him with thanksgiving.<br/>
**<sup>31</sup>** This will please the LORD more than an ox,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or a bull with horns and hoofs.

**<sup>32</sup>** The humble will see and be glad;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who seek God, let your hearts revive.<br/>
**<sup>33</sup>** For the LORD hears the needy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and does not despise his own who are prisoners.

**<sup>34</sup>** Let heaven and earth praise him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the seas and everything that moves in them.<br/>
**<sup>35</sup>** For God will save Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and build the cities of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall dwell there and possess it;<br/>
**<sup>36</sup>** the offspring of his servants shall inherit it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those who love his name shall dwell in it.<br/>


## Chapter 70

**<sup>1</sup>** O God, hasten to deliver me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD, make haste to help me.<br/>
**<sup>2</sup>** Let those who seek my life be put to shame and confounded;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let those who desire my harm be turned back and humiliated.<br/>
**<sup>3</sup>** Let those who say, “Aha! Aha!” turn back because of their shame. **<sup>4</sup>** Let all who seek you rejoice and be glad in you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let those who love your salvation say continually, “God is great!”<br/>
**<sup>5</sup>** But I am afflicted and needy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O God, hasten to me!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are my help and my deliverer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD, do not delay.<br/>


## Chapter 71

**<sup>1</sup>** In you, O LORD, I have taken refuge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me never be put to shame.<br/>
**<sup>2</sup>** In your righteousness deliver me and rescue me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;incline your ear to me and save me.<br/>
**<sup>3</sup>** Be to me a rock of refuge to which I may continually come;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have given the command to save me, for you are my rock and my fortress.

**<sup>4</sup>** Rescue me, O my God, from the hand of the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the grasp of the unjust and cruel man.<br/>
**<sup>5</sup>** For you are my hope, O Lord GOD, my trust from my youth. **<sup>6</sup>** Upon you I have leaned from before my birth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you are the one who took me from my mother’s womb.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My praise is continually of you.

**<sup>7</sup>** I have been as a wonder to many,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but you are my strong refuge.<br/>
**<sup>8</sup>** My mouth is filled with your praise,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with your glory all day long.

**<sup>9</sup>** Do not cast me off in the time of old age;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not forsake me when my strength is spent.<br/>
**<sup>10</sup>** For my enemies speak against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those who watch for my life conspire together,<br/>
**<sup>11</sup>** saying, “God has forsaken him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;pursue and seize him, for there is none to deliver.”<br/>
**<sup>12</sup>** O God, do not be far from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O my God, make haste to help me.<br/>
**<sup>13</sup>** Let those who are adversaries of my soul be put to shame and consumed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let those who seek to harm me be covered with scorn and disgrace.

**<sup>14</sup>** But as for me, I will hope continually,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will praise you yet more and more.<br/>
**<sup>15</sup>** My mouth will recount your righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your salvation all day long, for I do not know their extent.<br/>
**<sup>16</sup>** I will come with the mighty deeds of the Lord GOD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will make mention of your righteousness, yours alone.

**<sup>17</sup>** O God, you have taught me from my youth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to this day I declare your wondrous deeds.<br/>
**<sup>18</sup>** Even when I am old and gray, O God, do not forsake me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until I declare your strength to the next generation, your might to all who are to come.

**<sup>19</sup>** Your righteousness, O God, reaches to the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who have done great things;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O God, who is like you?<br/>
**<sup>20</sup>** You who have shown me many troubles and calamities will revive me again;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the depths of the earth you will bring me up again.<br/>
**<sup>21</sup>** You will increase my greatness and comfort me once again.

**<sup>22</sup>** I will also praise you with the harp for your faithfulness, O my God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing praises to you with the lyre, O Holy One of Israel.<br/>
**<sup>23</sup>** My lips will shout for joy when I sing praises to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my soul, which you have redeemed.<br/>
**<sup>24</sup>** My tongue also will speak of your righteousness all day long,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for those who seek to harm me are put to shame and disgraced.<br/>


## Chapter 72

**<sup>1</sup>** Give the king your judgments, O God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your righteousness to the son of the king.<br/>
**<sup>2</sup>** May he judge your people with righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your afflicted with justice.<br/>
**<sup>3</sup>** Let the mountains bring peace to the people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the hills, righteousness.<br/>
**<sup>4</sup>** May he bring justice to the afflicted of the people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;save the children of the needy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and crush the oppressor.

**<sup>5</sup>** Let them fear you while the sun endures,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and as long as the moon, throughout all generations.<br/>
**<sup>6</sup>** May he be like rain that falls on the mown grass,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like showers that water the earth.<br/>
**<sup>7</sup>** In his days may the righteous flourish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and abundance of peace until the moon is no more.

**<sup>8</sup>** May he have dominion from sea to sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the River to the ends of the earth.<br/>
**<sup>9</sup>** Let those who dwell in the desert bow before him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his enemies lick the dust.<br/>
**<sup>10</sup>** May the kings of Tarshish and of the coastlands render tribute,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the kings of Sheba and Seba bring gifts.<br/>
**<sup>11</sup>** Let all kings bow down before him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all nations serve him.

**<sup>12</sup>** For he delivers the needy when he cries,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the afflicted also, and him who has no helper.<br/>
**<sup>13</sup>** He has pity on the poor and needy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the souls of the needy he saves.<br/>
**<sup>14</sup>** From oppression and violence he redeems their soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and precious is their blood in his sight.

**<sup>15</sup>** May he live, and may the gold of Sheba be given to him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may prayer be made for him continually,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and blessings invoked for him all day long.<br/>
**<sup>16</sup>** May there be abundance of grain in the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the tops of the mountains may it wave;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may its fruit be like Lebanon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may men flourish from the city like the grass of the earth.

**<sup>17</sup>** May his name endure forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may his name continue as long as the sun;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may men be blessed in him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all nations call him blessed.

**<sup>18</sup>** Blessed be the LORD God, the God of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who alone does wondrous things.<br/>
**<sup>19</sup>** And blessed be his glorious name forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may the whole earth be filled with his glory. Amen and Amen.

**<sup>20</sup>** The prayers of David the son of Jesse are ended. 

## Chapter 73

**<sup>1</sup>** Truly God is good to Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to those who are pure in heart.<br/>
**<sup>2</sup>** But as for me, my feet had almost stumbled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my steps had nearly slipped.<br/>
**<sup>3</sup>** For I was envious of the arrogant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I saw the prosperity of the wicked.

**<sup>4</sup>** For they have no pains until death,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their bodies are fat and sleek.<br/>
**<sup>5</sup>** They are not in trouble as other men are;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are not plagued like the rest of mankind.<br/>
**<sup>6</sup>** Therefore pride is their necklace;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;violence covers them like a garment.<br/>
**<sup>7</sup>** Their eyes bulge with abundance;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the imaginations of their heart overflow.<br/>
**<sup>8</sup>** They scoff and speak with malice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;loftily they threaten oppression.<br/>
**<sup>9</sup>** They set their mouths against the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their tongues strut through the earth.

**<sup>10</sup>** Therefore his people turn back to them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and waters of fullness are drained by them.<br/>
**<sup>11</sup>** And they say, “How does God know?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And is there knowledge in the Most High?”<br/>
**<sup>12</sup>** Behold, these are the wicked—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;always at ease, they increase in wealth.

**<sup>13</sup>** Surely in vain I have kept my heart pure<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and washed my hands in innocence.<br/>
**<sup>14</sup>** For all day long I am afflicted<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and every morning brings punishment.

**<sup>15</sup>** If I had said, “I will speak thus,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;behold, I would have betrayed the generation of your children.<br/>
**<sup>16</sup>** But when I pondered to understand this,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it was trouble in my eyes,<br/>
**<sup>17</sup>** until I came into the sanctuary of God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then I understood their end.

**<sup>18</sup>** Truly you set them in slippery places;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you make them fall to ruin.<br/>
**<sup>19</sup>** How suddenly they are brought to desolation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;swept away in terrors!<br/>
**<sup>20</sup>** Like a dream when one awakes, O Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when you rouse yourself, you despise their image.

**<sup>21</sup>** When my heart was embittered<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I was pierced in my inward parts,<br/>
**<sup>22</sup>** I was brutish and ignorant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I was like a beast before you.<br/>
**<sup>23</sup>** Yet I am continually with you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you hold my right hand.<br/>
**<sup>24</sup>** You guide me with your counsel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and afterward you will receive me to glory.

**<sup>25</sup>** Whom have I in heaven but you?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And there is nothing on earth I desire besides you.<br/>
**<sup>26</sup>** My flesh and my heart may fail,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but God is the strength of my heart and my portion forever.

**<sup>27</sup>** For behold, those who are far from you will perish;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you destroy everyone who is unfaithful to you.<br/>
**<sup>28</sup>** But as for me, the nearness of God is my good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have made the Lord GOD my refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may tell of all your works.<br/>


## Chapter 74

**<sup>1</sup>** O God, why have you rejected us forever?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why does your anger smoke against the sheep of your pasture?<br/>
**<sup>2</sup>** Remember your congregation, which you purchased of old,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the tribe of your inheritance, whom you redeemed—Mount Zion, where you have dwelled.<br/>
**<sup>3</sup>** Direct your steps to the perpetual ruins;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the enemy has laid waste everything in the sanctuary.

**<sup>4</sup>** Your foes have roared in the midst of your meeting place;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have set up their signs for signs.<br/>
**<sup>5</sup>** It was as if one raised an axe in a forest of trees, **<sup>6</sup>** and now all its carved work they smash with hatchet and hammers. **<sup>7</sup>** They have set your sanctuary on fire;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have profaned the dwelling place of your name, bringing it to the ground.<br/>
**<sup>8</sup>** They said in their heart, “Let us completely subdue them!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They burned all the meeting places of God in the land.

**<sup>9</sup>** We do not see our signs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is no longer any prophet,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and none among us knows for how long.<br/>
**<sup>10</sup>** How long, O God, is the foe to scoff?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is the enemy to revile your name forever?<br/>
**<sup>11</sup>** Why do you hold back your hand, your right hand?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Draw it from your bosom and destroy them!

**<sup>12</sup>** Yet God is my king of old,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;working salvation in the midst of the earth.<br/>
**<sup>13</sup>** You divided the sea by your strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you broke the heads of the sea monsters on the waters.<br/>
**<sup>14</sup>** You crushed the head of Leviathan;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you gave him as food for the creatures of the wilderness.<br/>
**<sup>15</sup>** You split open springs and brooks;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you dried up ever-flowing streams.<br/>
**<sup>16</sup>** Yours is the day, yours also the night;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have established the light and the sun.<br/>
**<sup>17</sup>** You have set all the boundaries of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have made summer and winter.

**<sup>18</sup>** Remember this, O LORD, how the enemy scoffs,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And how a foolish people reviles your name.<br/>
**<sup>19</sup>** Do not give the soul of your dove to the wild beast;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not forget the life of your afflicted forever.<br/>
**<sup>20</sup>** Have regard for the covenant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the dark places of the land are full of the haunts of violence.<br/>
**<sup>21</sup>** Let not the oppressed turn back in shame;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the afflicted and needy praise your name.

**<sup>22</sup>** Arise, O God, plead your cause;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;remember how the foolish man scoffs at you all day long.<br/>
**<sup>23</sup>** Do not forget the clamor of your foes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the uproar of those who rise up against you, which ascends continually.<br/>


## Chapter 75

**<sup>1</sup>** We give thanks to you, O God, we give thanks,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for your name is near; men recount your wondrous deeds.

**<sup>2</sup>** When I choose the appointed time,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I judge with equity.<br/>
**<sup>3</sup>** When the earth and all its inhabitants tremble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is I who steady its pillars. Selah

**<sup>4</sup>** I say to the boastful, “Do not boast,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to the wicked, “Do not lift up the horn.<br/>
**<sup>5</sup>** Do not lift up your horn on high,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not speak with an arrogant neck.”

**<sup>6</sup>** For lifting people up does not come from the east or from the west,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Neither from the wilderness,<br/>
**<sup>7</sup>** but God is the judge:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he brings one down and lifts up another.

**<sup>8</sup>** For in the hand of the LORD there is a cup,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with foaming wine, fully mixed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he pours out from it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the wicked of the earth shall drain it down to the dregs.

**<sup>9</sup>** But I will declare it forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing praises to the God of Jacob.<br/>
**<sup>10</sup>** And all the horns of the wicked I will cut off,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the horns of the righteous shall be lifted up.<br/>


## Chapter 76

**<sup>1</sup>** God is known in Judah;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his name is great in Israel.<br/>
**<sup>2</sup>** His tabernacle is in Salem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his dwelling place in Zion.<br/>
**<sup>3</sup>** There he broke the flashing arrows,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the shield, the sword, and the weapons of war. Selah

**<sup>4</sup>** Glorious are you, majestic from the mountains of prey. **<sup>5</sup>** The stouthearted were plundered; they slept their sleep,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and none of the warriors could lift their hands.<br/>
**<sup>6</sup>** At your rebuke, O God of Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;both rider and horse lay stunned.

**<sup>7</sup>** You, even you, are to be feared;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who can stand before you once your anger is aroused?<br/>
**<sup>8</sup>** From heaven you pronounced judgment;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the earth feared and was still,<br/>
**<sup>9</sup>** when God arose to execute judgment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to save all the humble of the earth. Selah

**<sup>10</sup>** For the wrath of man shall praise you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the remainder of wrath you gird yourself.<br/>
**<sup>11</sup>** Make vows to the LORD your God and fulfill them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let all who are around him bring tribute to the one to be feared.<br/>
**<sup>12</sup>** He cuts off the spirit of princes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he is feared by the kings of the earth.<br/>


## Chapter 77

**<sup>1</sup>** I cry aloud to God—aloud to God, that he may hear me. **<sup>2</sup>** In the day of my trouble I sought the Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my hand was stretched out in the night and did not grow weary;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my soul refused to be comforted.

**<sup>3</sup>** I remember God, and I moan;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I meditate, and my spirit grows faint. Selah<br/>
**<sup>4</sup>** You hold open my eyelids;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am so troubled that I cannot speak.<br/>
**<sup>5</sup>** I consider the days of old,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the years of long ago.<br/>
**<sup>6</sup>** I call to mind my song in the night;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I meditate with my heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my spirit searches diligently:

**<sup>7</sup>** “Will the Lord spurn forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and never again show favor?<br/>
**<sup>8</sup>** Has his loyal love ceased forever?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Has his promise come to an end for all time?<br/>
**<sup>9</sup>** Has God forgotten to be gracious?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Has he shut up his compassion in anger?” Selah

**<sup>10</sup>** Then I said, “It is my grief,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that the right hand of the Most High has changed.”

**<sup>11</sup>** I will remember the deeds of the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yes, I will remember your wonders of old.<br/>
**<sup>12</sup>** I will meditate on all your work<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ponder your mighty deeds.<br/>
**<sup>13</sup>** Your way, O God, is holy.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What god is great like God?

**<sup>14</sup>** You are the God who works wonders;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have made known your might among the nations.<br/>
**<sup>15</sup>** With your arm you redeemed your people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the sons of Jacob and Joseph. Selah

**<sup>16</sup>** The waters saw you, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the waters saw you—and they writhed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even the depths trembled.<br/>
**<sup>17</sup>** The clouds poured out water;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the skies gave forth a sound;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your arrows flashed to and fro.

**<sup>18</sup>** The voice of your thunder was in the whirlwind;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lightnings lit up the world;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the earth trembled and shook.<br/>
**<sup>19</sup>** Your way was through the sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your path through the great waters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet your footprints were unseen.

**<sup>20</sup>** You led your people like a flock<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by the hand of Moses and Aaron.<br/>


## Chapter 78

**<sup>1</sup>** Give ear, O my people, to my instruction;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;incline your ears to the words of my mouth.<br/>
**<sup>2</sup>** I will open my mouth with a parable;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will utter hidden sayings of old,<br/>
**<sup>3</sup>** which we have heard and known,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our fathers have told us.<br/>
**<sup>4</sup>** We will not hide them from their children,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;telling to the next generation the praises of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his strength and his wondrous deeds that he has done.

**<sup>5</sup>** For he established a testimony in Jacob<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and set a law in Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which he commanded our fathers to teach their children,<br/>
**<sup>6</sup>** so that the next generation might know them—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the children yet to be born—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they might arise and tell them to their children,<br/>
**<sup>7</sup>** that they might put their trust in God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and not forget the works of God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but keep his commandments;<br/>
**<sup>8</sup>** and not be like their fathers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a stubborn and rebellious generation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a generation that did not set its heart aright,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and whose spirit was not faithful to God.

**<sup>9</sup>** The sons of Ephraim, armed with the bow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;turned back on the day of battle.<br/>
**<sup>10</sup>** They did not keep the covenant of God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and refused to walk in his law.<br/>
**<sup>11</sup>** They forgot his deeds<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his wonders that he had shown them.

**<sup>12</sup>** He did marvelous things in the sight of their fathers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the land of Egypt, in the fields of Zoan.<br/>
**<sup>13</sup>** He divided the sea and caused them to pass through,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he made the waters stand like a heap.<br/>
**<sup>14</sup>** He led them with a cloud by day<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the night with a light of fire.<br/>
**<sup>15</sup>** He split rocks in the wilderness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gave them abundant drink as from the deep.<br/>
**<sup>16</sup>** He brought streams out of the rock<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and caused waters to flow down like rivers.

**<sup>17</sup>** Yet they continued to sin against him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to rebel against the Most High in the desert.<br/>
**<sup>18</sup>** They tested God in their heart<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by demanding food to satisfy their cravings.<br/>
**<sup>19</sup>** They spoke against God, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Can God prepare a table in the wilderness?<br/>
**<sup>20</sup>** See how he struck the rock so that water gushed out<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and streams overflowed.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Can he also give bread<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or provide meat for his people?”

**<sup>21</sup>** Therefore the LORD heard and was full of wrath;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a fire was kindled against Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and anger also rose against Israel,<br/>
**<sup>22</sup>** because they did not believe in God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not trust in his salvation.<br/>
**<sup>23</sup>** Yet he commanded the skies above<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and opened the doors of heaven.<br/>
**<sup>24</sup>** He rained down manna upon them to eat<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gave them the grain of heaven.<br/>
**<sup>25</sup>** Man ate the bread of angels;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he sent them food in abundance.

**<sup>26</sup>** He caused the east wind to blow in the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by his power he led out the south wind.<br/>
**<sup>27</sup>** He rained meat upon them like dust,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and winged birds like the sand of the seas.<br/>
**<sup>28</sup>** He made them fall in the midst of their camp,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all around their dwellings.<br/>
**<sup>29</sup>** So they ate and were well filled,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he gave them what they craved.<br/>
**<sup>30</sup>** But before they had satisfied their craving,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while the food was still in their mouths,<br/>
**<sup>31</sup>** the anger of God rose against them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he killed the strongest of them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and laid low the young men of Israel.

**<sup>32</sup>** In spite of all this they still sinned<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not believe in his wondrous works.<br/>
**<sup>33</sup>** So he made their days vanish like a breath,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their years in sudden terror.<br/>
**<sup>34</sup>** When he killed them, they sought him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they returned and earnestly sought God.<br/>
**<sup>35</sup>** They remembered that God was their rock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the Most High God their redeemer.<br/>
**<sup>36</sup>** But they flattered him with their mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lied to him with their tongue.<br/>
**<sup>37</sup>** For their heart was not steadfast toward him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor were they faithful to his covenant.

**<sup>38</sup>** But he, being compassionate, forgave their iniquity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not destroy them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Often he turned his anger away<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not stir up all his wrath.<br/>
**<sup>39</sup>** He remembered that they were but flesh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a wind that passes and does not return.

**<sup>40</sup>** How often they rebelled against him in the wilderness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and grieved him in the desert!<br/>
**<sup>41</sup>** Again and again they tested God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and provoked the Holy One of Israel.<br/>
**<sup>42</sup>** They did not remember his power<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or the day when he redeemed them from the foe,<br/>
**<sup>43</sup>** when he performed his signs in Egypt<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his wonders in the fields of Zoan.

**<sup>44</sup>** He turned their rivers to blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that they could not drink from their streams.<br/>
**<sup>45</sup>** He sent among them swarms of flies, which devoured them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and frogs, which destroyed them.<br/>
**<sup>46</sup>** He gave their crops to the caterpillar<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the fruit of their labor to the locust.<br/>
**<sup>47</sup>** He destroyed their vines with hail<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their sycamores with frost.<br/>
**<sup>48</sup>** He gave over their livestock to the hail<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their flocks to fiery bolts.

**<sup>49</sup>** He sent upon them his burning anger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;wrath and indignation and distress,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a band of destroying angels.<br/>
**<sup>50</sup>** He cleared a path for his anger;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he did not spare them from death<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but gave their lives over to the plague.<br/>
**<sup>51</sup>** He struck all the firstborn in Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the first fruits of their strength in the tents of Ham.

**<sup>52</sup>** Then he led out his people like sheep<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and guided them in the wilderness like a flock.<br/>
**<sup>53</sup>** He led them in safety, so that they were not afraid,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the sea overwhelmed their enemies.<br/>
**<sup>54</sup>** And he brought them to his holy territory,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the mountain which his right hand had acquired.<br/>
**<sup>55</sup>** He drove out nations before them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and allotted them an inheritance by lot<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and made the tribes of Israel dwell in their tents.

**<sup>56</sup>** Yet they tested and rebelled against the Most High God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not keep his testimonies,<br/>
**<sup>57</sup>** but turned back and acted treacherously like their fathers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they twisted like a deceitful bow.<br/>
**<sup>58</sup>** For they provoked him to anger with their high places<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and moved him to jealousy with their idols.<br/>
**<sup>59</sup>** God heard and was full of wrath,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he utterly rejected Israel.

**<sup>60</sup>** He abandoned the dwelling at Shiloh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the tent where he had dwelled among men,<br/>
**<sup>61</sup>** and he gave his strength into captivity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his glory into the hand of the foe.<br/>
**<sup>62</sup>** He gave his people over to the sword<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and was furious with his inheritance.<br/>
**<sup>63</sup>** Fire devoured their young men,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their maidens had no marriage song.<br/>
**<sup>64</sup>** Their priests fell by the sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their widows made no lamentation.

**<sup>65</sup>** Then the Lord awoke as from sleep,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a warrior shouting because of wine.<br/>
**<sup>66</sup>** And he struck his enemies back;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he put them to everlasting shame.<br/>
**<sup>67</sup>** He rejected the tent of Joseph;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he did not choose the tribe of Ephraim,<br/>
**<sup>68</sup>** but he chose the tribe of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Mount Zion, which he loved.<br/>
**<sup>69</sup>** He built his sanctuary like the heights,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like the earth which he has established forever.

**<sup>70</sup>** He chose David his servant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and took him from the sheepfolds;<br/>
**<sup>71</sup>** from tending the ewes that nurse<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he brought him to shepherd Jacob his people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Israel his inheritance.<br/>
**<sup>72</sup>** So he shepherded them according to the integrity of his heart<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and guided them with skillful hands.<br/>


## Chapter 79

**<sup>1</sup>** O God, the nations have come into your inheritance;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have defiled your holy temple;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have laid Jerusalem in ruins.<br/>
**<sup>2</sup>** They have given the dead bodies of your servants as food for the birds of the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the flesh of your faithful ones to the beasts of the earth.<br/>
**<sup>3</sup>** They have poured out their blood like water all around Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there was no one to bury them.<br/>
**<sup>4</sup>** We have become a reproach to our neighbors,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a mockery and derision to those around us.

**<sup>5</sup>** How long, O LORD? Will you be angry forever?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Will your jealousy burn like fire?<br/>
**<sup>6</sup>** Pour out your wrath on the nations that do not know you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on the kingdoms that do not call on your name.<br/>
**<sup>7</sup>** For they have devoured Jacob<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and laid waste his habitation.

**<sup>8</sup>** Do not remember our former iniquities;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your compassion come quickly to meet us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for we are brought very low.<br/>
**<sup>9</sup>** Help us, O God of our salvation, for the glory of your name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;deliver us and atone for our sins, for your name’s sake.<br/>
**<sup>10</sup>** Why should the nations say, “Where is their God?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Let the avenging of the blood of your servants that has been shed<br/>
&nbsp;&nbsp;&nbsp;&nbsp;be known among the nations before our eyes.

**<sup>11</sup>** Let the groaning of the prisoner come before you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to the greatness of your power, preserve those doomed to die.<br/>
**<sup>12</sup>** Return sevenfold into the lap of our neighbors<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the reproach with which they have reproached you, O Lord.<br/>
**<sup>13</sup>** But we, your people and the sheep of your pasture,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will give thanks to you forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from generation to generation we will recount your praise.<br/>


## Chapter 80

**<sup>1</sup>** Give ear, O Shepherd of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who lead Joseph like a flock.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You who are enthroned upon the cherubim, shine forth<br/>
**<sup>2</sup>** before Ephraim and Benjamin and Manasseh.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Stir up your strength<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and come to save us.

**<sup>3</sup>** Restore us, O God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cause your face to shine, that we may be saved.

**<sup>4</sup>** O LORD God of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how long will you be angry with the prayer of your people?<br/>
**<sup>5</sup>** You have fed them with the bread of tears<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and given them tears to drink in full measure.<br/>
**<sup>6</sup>** You make us an object of contention to our neighbors,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our enemies laugh among themselves.

**<sup>7</sup>** Restore us, O God of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cause your face to shine, that we may be saved.

**<sup>8</sup>** You brought a vine out of Egypt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you drove out the nations and planted it.<br/>
**<sup>9</sup>** You cleared the ground for it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it took deep root and filled the land.<br/>
**<sup>10</sup>** The mountains were covered with its shade,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the mighty cedars with its branches.<br/>
**<sup>11</sup>** It sent out its branches to the sea<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its shoots to the River.

**<sup>12</sup>** Why have you broken down its walls,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that all who pass along the way pluck its fruit?<br/>
**<sup>13</sup>** The boar from the forest ravages it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all that move in the field feed on it.

**<sup>14</sup>** O God of hosts, return, we pray!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Look down from heaven, and see,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and take care of this vine,<br/>
**<sup>15</sup>** even the shoot your right hand has planted,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the son whom you have made strong for yourself.<br/>
**<sup>16</sup>** It is burned with fire; it is cut down;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they perish at the rebuke of your face.

**<sup>17</sup>** Let your hand be upon the man of your right hand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the son of man whom you have made strong for yourself.<br/>
**<sup>18</sup>** Then we shall not turn back from you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give us life, and we will call upon your name.

**<sup>19</sup>** Restore us, O LORD God of hosts;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;cause your face to shine, that we may be saved.<br/>


## Chapter 81

**<sup>1</sup>** Sing aloud to God our strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shout for joy to the God of Jacob.<br/>
**<sup>2</sup>** Raise a song; sound the tambourine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the sweet lyre with the harp.<br/>
**<sup>3</sup>** Blow the trumpet at the new moon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the full moon, on our feast day.

**<sup>4</sup>** For it is a statute for Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a judgment of the God of Jacob.<br/>
**<sup>5</sup>** He established it as a decree in Joseph<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when he went out over the land of Egypt.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I heard a language I did not know:

**<sup>6</sup>** “I relieved his shoulder of the burden;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his hands were freed from the basket.<br/>
**<sup>7</sup>** In distress you called, and I delivered you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I answered you in the secret place of thunder;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I tested you at the waters of Meribah. Selah

**<sup>8</sup>** Hear, O my people, and I will admonish you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O Israel, if you would but listen to me!<br/>
**<sup>9</sup>** There shall be no strange god among you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you shall not bow down to a foreign god.<br/>
**<sup>10</sup>** I am the LORD your God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who brought you up out of the land of Egypt.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Open your mouth wide, and I will fill it.

**<sup>11</sup>** But my people did not listen to my voice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel would not submit to me.<br/>
**<sup>12</sup>** So I gave them over to the stubbornness of their heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to walk in their own counsels.

**<sup>13</sup>** Oh that my people would listen to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that Israel would walk in my ways!<br/>
**<sup>14</sup>** I would soon subdue their enemies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and turn my hand against their adversaries.<br/>
**<sup>15</sup>** Those who hate the LORD would cringe before him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their time of punishment would last forever.<br/>
**<sup>16</sup>** But he would feed him with the finest of the wheat,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with honey from the rock I would satisfy you.<br/>


## Chapter 82

**<sup>1</sup>** God stands in the divine assembly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the midst of the gods he renders judgment.

**<sup>2</sup>** “How long will you judge unjustly<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and show partiality to the wicked? Selah<br/>
**<sup>3</sup>** Give justice to the weak and the fatherless;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;uphold the rights of the afflicted and the destitute.<br/>
**<sup>4</sup>** Rescue the weak and the needy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;deliver them from the hand of the wicked.”

**<sup>5</sup>** They have neither knowledge nor understanding;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they walk about in darkness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the foundations of the earth are shaken.

**<sup>6</sup>** I said, “You are gods,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sons of the Most High, all of you;<br/>
**<sup>7</sup>** nevertheless, like man you shall die,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and fall like any prince.”

**<sup>8</sup>** Arise, O God, judge the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you shall inherit all the nations.<br/>


## Chapter 83

**<sup>1</sup>** O God, do not keep silent;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not hold your peace or be still, O God.

**<sup>2</sup>** Look how your enemies make an uproar;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who hate you have lifted up their heads.<br/>
**<sup>3</sup>** They devise cunning plots against your people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they conspire against your treasured ones.<br/>
**<sup>4</sup>** They say, “Come, let us wipe them out as a nation;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the name of Israel be remembered no more!”<br/>
**<sup>5</sup>** For with one mind they conspire together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against you they make a conspiracy.

**<sup>6</sup>** The tents of Edom and the Ishmaelites,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Moab and the Hagrites,<br/>
**<sup>7</sup>** Gebal and Ammon and Amalek,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Philistia with the inhabitants of Tyre;<br/>
**<sup>8</sup>** even Assyria has joined them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have become the arm of the sons of Lot. Selah

**<sup>9</sup>** Do to them as to Midian,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as to Sisera and Jabin at the wadi Kishon,<br/>
**<sup>10</sup>** who were destroyed at En-dor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who became dung for the ground.<br/>
**<sup>11</sup>** Make their nobles like Oreb and Zeeb,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all their princes like Zebah and Zalmunna,<br/>
**<sup>12</sup>** who said, “Let us take possession<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for ourselves of the pastures of God.”

**<sup>13</sup>** O my God, make them like whirling dust,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like chaff before the wind.<br/>
**<sup>14</sup>** As fire consumes the forest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as flame sets the mountains ablaze,<br/>
**<sup>15</sup>** so pursue them with your storm<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and terrify them with your tempest.<br/>
**<sup>16</sup>** Fill their faces with shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they may seek your name, O LORD.<br/>
**<sup>17</sup>** Let them be put to shame and dismayed forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them perish in disgrace,<br/>
**<sup>18</sup>** that they may know that you alone,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose name is the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;are Most High over all the earth.<br/>


## Chapter 84

**<sup>1</sup>** How lovely are your dwelling places,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD of hosts!<br/>
**<sup>2</sup>** My soul longs—indeed, it faints—for the courts of the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my heart and my flesh cry out for the living God.<br/>
**<sup>3</sup>** Even the sparrow has found a home,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the swallow a nest for herself, where she may lay her young—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at your altars, O LORD of hosts, my King and my God.<br/>
**<sup>4</sup>** Blessed are those who dwell in your house;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are ever praising you. Selah

**<sup>5</sup>** Blessed is the man whose strength is in you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in whose heart are the highways to Zion.<br/>
**<sup>6</sup>** As they pass through the Valley of Baca,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they make it a place of springs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the early rain also covers it with blessings.<br/>
**<sup>7</sup>** They go from strength to strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;each one appears before God in Zion.<br/>
**<sup>8</sup>** O LORD God of hosts, hear my prayer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give ear, O God of Jacob. Selah

**<sup>9</sup>** Look upon our shield, O God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and look upon the face of your anointed.<br/>
**<sup>10</sup>** For a day in your courts is better than a thousand elsewhere.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I would rather stand at the threshold of the house of my God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;than dwell in the tents of wickedness.<br/>
**<sup>11</sup>** For the LORD God is a sun and a shield;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD gives grace and glory;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no good thing does he withhold<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from those who walk uprightly.<br/>
**<sup>12</sup>** O LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;blessed is the man who trusts in you.<br/>


## Chapter 85

**<sup>1</sup>** You showed favor to your land, O LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you restored the fortunes of Jacob.<br/>
**<sup>2</sup>** You forgave the iniquity of your people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you covered all their sin. Selah<br/>
**<sup>3</sup>** You withdrew all your wrath;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you turned from your burning anger.<br/>
**<sup>4</sup>** Restore us, O God of our salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and put away your indignation toward us.

**<sup>5</sup>** Will you be angry with us forever?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Will you prolong your anger from generation to generation?<br/>
**<sup>6</sup>** Will you not revive us again,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that your people may rejoice in you?<br/>
**<sup>7</sup>** Show us your steadfast love, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and grant us your salvation.<br/>
**<sup>8</sup>** Let me hear what God the LORD will speak,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he will speak peace to his people, to his saints—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but let them not return to folly.

**<sup>9</sup>** Surely his salvation is near to those who fear him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that glory may dwell in our land.<br/>
**<sup>10</sup>** Steadfast love and faithfulness meet;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;righteousness and peace kiss each other.<br/>
**<sup>11</sup>** Faithfulness springs up from the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and righteousness looks down from heaven.<br/>
**<sup>12</sup>** Indeed, the LORD will give what is good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our land will yield its produce.<br/>
**<sup>13</sup>** Righteousness will go before him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will make his footsteps a pathway.<br/>


## Chapter 86

**<sup>1</sup>** Incline your ear, O LORD, and answer me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am afflicted and needy.<br/>
**<sup>2</sup>** Preserve my life, for I am faithful;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you are my God—save your servant who trusts in you.<br/>
**<sup>3</sup>** Be gracious to me, O Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I cry to you all day long.<br/>
**<sup>4</sup>** Gladden the soul of your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for unto you, O Lord, I lift up my soul.

**<sup>5</sup>** For you, O Lord, are good and forgiving,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;abounding in steadfast love to all who call on you.<br/>
**<sup>6</sup>** Give ear, O LORD, to my prayer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;listen to the voice of my supplications.<br/>
**<sup>7</sup>** In the day of my trouble I call on you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you will answer me.<br/>
**<sup>8</sup>** There is none like you among the gods, O Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor are there any works like yours.

**<sup>9</sup>** All the nations you have made shall come and bow down before you, O Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall glorify your name.<br/>
**<sup>10</sup>** For you are great and do wondrous deeds;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you alone are God.<br/>
**<sup>11</sup>** Teach me your way, O LORD, that I may walk in your truth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;train my heart to fear your name.<br/>
**<sup>12</sup>** I will give thanks to you, O Lord my God, with all my heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will glorify your name forever.

**<sup>13</sup>** For great is your steadfast love toward me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have delivered my soul from the depths of the grave.<br/>
**<sup>14</sup>** O God, arrogant men have risen up against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a band of violent men seeks my life,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they do not set you before them.<br/>
**<sup>15</sup>** But you, O Lord, are a God merciful and gracious,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;slow to anger, and abounding in steadfast love and faithfulness.<br/>
**<sup>16</sup>** Turn to me and be gracious to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give your strength to your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and save the son of your maidservant.<br/>
**<sup>17</sup>** Show me a sign for good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that those who hate me may see it and be put to shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because you, O LORD, have helped me and comforted me.<br/>


## Chapter 87

**<sup>1</sup>** His foundation is on the holy mountains. **<sup>2</sup>** The LORD loves the gates of Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;more than all the dwellings of Jacob.<br/>
**<sup>3</sup>** Glorious things are spoken of you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O city of God.<br/>
**<sup>4</sup>** “I will mention Rahab and Babylon among those who know me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even Philistia and Tyre, along with Cush will say ‘This one was born there.’”

**<sup>5</sup>** And of Zion it will be said, “This one and that one were born in her,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the Most High himself will establish her.<br/>
**<sup>6</sup>** The LORD will record, when he registers the peoples,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“This one was born there.”<br/>
**<sup>7</sup>** Singers and flute players alike say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“All my springs are in you.”<br/>


## Chapter 88

**<sup>1</sup>** O LORD, God of my salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I cry out before you day and night.<br/>
**<sup>2</sup>** Let my prayer come before you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;incline your ear to my cry.<br/>
**<sup>3</sup>** For my soul is full of troubles,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my life draws near to the grave.<br/>
**<sup>4</sup>** I am counted among those who go down to the pit;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am like a man without strength,<br/>
**<sup>5</sup>** abandoned among the dead,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like the slain who lie in the grave,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whom you remember no more,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they are cut off from your hand.

**<sup>6</sup>** You have placed me in the lowest pit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in dark places, in the depths.<br/>
**<sup>7</sup>** Your wrath lies heavy upon me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you have afflicted me with all your waves. Selah<br/>
**<sup>8</sup>** You have put my companions far from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have made me an abomination to them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am shut in and cannot escape;<br/>
**<sup>9</sup>** my eye grows dim with sorrow.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I call upon you, O LORD, every day;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I spread out my hands to you.

**<sup>10</sup>** Will you work wonders for the dead?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Will the departed rise up to praise you? Selah<br/>
**<sup>11</sup>** Is your loyal love declared in the grave,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your faithfulness in the place of destruction?<br/>
**<sup>12</sup>** Are your wonders known in the darkness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or your righteousness in the land of forgetfulness?

**<sup>13</sup>** But I, O LORD, cry to you for help;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the morning my prayer comes before you.<br/>
**<sup>14</sup>** Why, O LORD, do you reject my life?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why do you hide your face from me?<br/>
**<sup>15</sup>** I am afflicted and close to death from my youth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I suffer your terrors—I am in despair.<br/>
**<sup>16</sup>** Your fierce wrath has swept over me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your terrors have destroyed me.<br/>
**<sup>17</sup>** They surround me like a flood all day long;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they close in on me altogether.<br/>
**<sup>18</sup>** You have removed lover and friend far from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the darkness is my companion.<br/>


## Chapter 89

**<sup>1</sup>** I will sing of the steadfast love of the LORD forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with my mouth I will make known your faithfulness to all generations.<br/>
**<sup>2</sup>** For I said, “Steadfast love will be built up forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the heavens you will establish your faithfulness.”

**<sup>3</sup>** “I have made a covenant with my chosen one;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have sworn to David my servant:<br/>
**<sup>4</sup>** ‘I will establish your offspring forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and build your throne for all generations.’” Selah

**<sup>5</sup>** The heavens praise your wonders, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your faithfulness also in the assembly of the holy ones.<br/>
**<sup>6</sup>** For who in the skies can be compared to the LORD?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who is like the LORD among the sons of God,<br/>
**<sup>7</sup>** a God greatly feared in the council of the holy ones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and awesome above all who are around him?

**<sup>8</sup>** O LORD God of hosts, who is mighty like you, O LORD?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your faithfulness surrounds you.<br/>
**<sup>9</sup>** You rule the raging of the sea;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when its waves rise, you still them.<br/>
**<sup>10</sup>** You crushed Rahab like a corpse;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with your strong arm you scattered your enemies.

**<sup>11</sup>** The heavens are yours; the earth also is yours;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the world and all that is in it, you founded them.<br/>
**<sup>12</sup>** The north and the south, you created them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Tabor and Hermon joyously praise your name.<br/>
**<sup>13</sup>** You have a mighty arm;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;strong is your hand, exalted is your right hand.

**<sup>14</sup>** Righteousness and justice are the foundation of your throne;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;steadfast love and faithfulness go before your face.<br/>
**<sup>15</sup>** Blessed are the people who know the festal shout,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who walk, O LORD, in the light of your face,<br/>
**<sup>16</sup>** who rejoice in your name all day long,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in your righteousness they are exalted.<br/>
**<sup>17</sup>** For you are the glory of their strength,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by your favor our horn is lifted up.<br/>
**<sup>18</sup>** For our shield belongs to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our king to the Holy One of Israel.

**<sup>19</sup>** Then you spoke in a vision to your faithful one and said:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I have set a crown on one who is mighty;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have exalted one chosen from the people.<br/>
**<sup>20</sup>** I have found David my servant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with my holy oil I have anointed him,<br/>
**<sup>21</sup>** so that my hand shall be established with him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my arm also shall strengthen him.

**<sup>22</sup>** The enemy shall not outwit him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the son of wickedness shall not humble him.<br/>
**<sup>23</sup>** I will crush his foes before him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and strike down those who hate him.<br/>
**<sup>24</sup>** My faithfulness and my steadfast love shall be with him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in my name his horn shall be exalted.<br/>
**<sup>25</sup>** I will set his hand on the sea<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his right hand on the rivers.<br/>
**<sup>26</sup>** He shall cry to me, ‘You are my Father,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my God, and the Rock of my salvation.’<br/>
**<sup>27</sup>** And I will make him the firstborn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the highest of the kings of the earth.

**<sup>28</sup>** My steadfast love I will keep for him forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my covenant shall stand firm for him.<br/>
**<sup>29</sup>** I will establish his offspring forever<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his throne as the days of the heavens.

**<sup>30</sup>** If his sons forsake my law<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not walk according to my rules,<br/>
**<sup>31</sup>** if they violate my statutes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not keep my commandments,<br/>
**<sup>32</sup>** then I will punish their transgression with the rod<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their iniquity with stripes;

**<sup>33</sup>** but I will not remove from him my steadfast love<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or be false to my faithfulness.<br/>
**<sup>34</sup>** I will not violate my covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or alter the word that went forth from my lips.

**<sup>35</sup>** Once for all I have sworn by my holiness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not lie to David.<br/>
**<sup>36</sup>** His offspring shall endure forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his throne as long as the sun before me.<br/>
**<sup>37</sup>** Like the moon it shall be established forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a faithful witness in the skies.” Selah

**<sup>38</sup>** But you have cast off and rejected;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you are full of wrath against your anointed.<br/>
**<sup>39</sup>** You have renounced the covenant with your servant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have defiled his crown in the dust.<br/>
**<sup>40</sup>** You have broken down all his walls;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have brought his strongholds to ruin.<br/>
**<sup>41</sup>** All who pass by plunder him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has become the scorn of his neighbors.<br/>
**<sup>42</sup>** You have exalted the right hand of his foes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have made all his enemies rejoice.<br/>
**<sup>43</sup>** You have also turned back the edge of his sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you have not made him stand in battle.

**<sup>44</sup>** You have ended his splendor<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cast his throne to the ground.<br/>
**<sup>45</sup>** You have shortened the days of his youth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have covered him with shame. Selah

**<sup>46</sup>** How long, O LORD? Will you hide yourself forever?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How long will your wrath burn like fire?<br/>
**<sup>47</sup>** Remember how short my time is!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For what futility have you created all the sons of man?<br/>
**<sup>48</sup>** What man can live and never see death?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who can deliver his life from the power of the grave? Selah

**<sup>49</sup>** Lord, where is your steadfast love of old,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which you swore to David in your faithfulness?<br/>
**<sup>50</sup>** Remember, O Lord, the reproach of your servants—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how I bear in my heart the taunts of all the many nations,<br/>
**<sup>51</sup>** with which your enemies mock, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with which they mock the footsteps of your anointed.

**<sup>52</sup>** Blessed be the LORD forever!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Amen and Amen.<br/>


## Chapter 90

**<sup>1</sup>** Lord, you have been our dwelling place<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in all generations.

**<sup>2</sup>** Before the mountains were born,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or you brought forth the earth and the world,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from everlasting to everlasting you are God.

**<sup>3</sup>** You turn man back to dust<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and say, “Return, sons of man.”<br/>
**<sup>4</sup>** For a thousand years in your sight<br/>
&nbsp;&nbsp;&nbsp;&nbsp;are like yesterday when it passes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or like a watch in the night.

**<sup>5</sup>** You sweep them away like a flood; they are like a dream,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like grass that is renewed in the morning.<br/>
**<sup>6</sup>** In the morning it flourishes and is renewed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the evening it fades and withers.

**<sup>7</sup>** For we are consumed by your anger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by your wrath we are dismayed.<br/>
**<sup>8</sup>** You have set our iniquities before you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our secret sins in the light of your presence.

**<sup>9</sup>** For all our days pass away under your wrath;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we bring our years to an end like a sigh.<br/>
**<sup>10</sup>** The days of our years are seventy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or if by strength, eighty;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet their pride is but toil and trouble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are soon gone, and we fly away.

**<sup>11</sup>** Who considers the power of your anger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your wrath according to the fear that is due you?

**<sup>12</sup>** So teach us to number our days<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that we may gain a heart of wisdom.

**<sup>13</sup>** Return, O LORD! How long?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Have compassion on your servants.<br/>
**<sup>14</sup>** Satisfy us in the morning with your steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that we may rejoice and be glad all our days.

**<sup>15</sup>** Make us glad for as many days as you have afflicted us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for as many years as we have seen evil.<br/>
**<sup>16</sup>** Let your work be shown to your servants,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your majesty to their children.

**<sup>17</sup>** Let the favor of the Lord our God be upon us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and establish the work of our hands upon us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yes, establish the work of our hands.<br/>


## Chapter 91

**<sup>1</sup>** He who dwells in the shelter of the Most High<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will abide in the shadow of the Almighty.<br/>
**<sup>2</sup>** I will say of the LORD, “My refuge and my fortress,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my God, in whom I trust.”

**<sup>3</sup>** For he will deliver you from the snare of the fowler<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the deadly pestilence.<br/>
**<sup>4</sup>** He will cover you with his feathers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and under his wings you will take refuge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His faithfulness is a shield and buckler.

**<sup>5</sup>** You will not fear the terror of the night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor the arrow that flies by day,<br/>
**<sup>6</sup>** nor the pestilence that stalks in darkness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor the destruction that lays waste at noonday.

**<sup>7</sup>** A thousand may fall at your side,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ten thousand at your right hand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but it will not come near you.<br/>
**<sup>8</sup>** You will only look with your eyes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and see the recompense of the wicked.

**<sup>9</sup>** For you have made the LORD your refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Most High your dwelling place.<br/>
**<sup>10</sup>** No evil shall befall you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no plague shall draw near your tent.

**<sup>11</sup>** For he will command his angels concerning you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to guard you in all your ways.<br/>
**<sup>12</sup>** On their hands they will lift you up,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so you do not strike your foot against a stone.<br/>
**<sup>13</sup>** You will tread upon the lion and the cobra;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the young lion and the serpent you will trample underfoot.

**<sup>14</sup>** “Because he has set his love upon me, I will deliver him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will set him on high, because he knows my name.<br/>
**<sup>15</sup>** He will call upon me, and I will answer him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will be with him in trouble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will rescue him and honor him.<br/>
**<sup>16</sup>** With long life I will satisfy him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and show him my salvation.”<br/>


## Chapter 92

**<sup>1</sup>** It is good to give thanks to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to sing praises to your name, O Most High,<br/>
**<sup>2</sup>** to declare your steadfast love in the morning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your faithfulness by night,<br/>
**<sup>3</sup>** with the ten-stringed lute and the harp,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the melody of the lyre.

**<sup>4</sup>** For you, O LORD, have made me glad by your work;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the deeds of your hands I sing for joy.<br/>
**<sup>5</sup>** How great are your works, O LORD!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your thoughts are very deep.

**<sup>6</sup>** A brutish man does not know,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor does a fool understand this:<br/>
**<sup>7</sup>** though the wicked sprout like grass<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all evildoers flourish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will be destroyed forever.<br/>
**<sup>8</sup>** But you, O LORD, are in heaven forever.

**<sup>9</sup>** For I see your enemies, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;only look how your enemies will perish;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all evildoers will be scattered.

**<sup>10</sup>** But you have exalted my horn like that of the wild ox;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have anointed me with fresh oil.<br/>
**<sup>11</sup>** My eyes have seen the downfall of my enemies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my ears have heard of the doom of the evildoers who rise up against me.

**<sup>12</sup>** The righteous will flourish like the palm tree<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and grow like a cedar in Lebanon.<br/>
**<sup>13</sup>** Planted in the house of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will flourish in the courts of our God.<br/>
**<sup>14</sup>** They will still bear fruit in old age;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will be full of sap and fresh,<br/>
**<sup>15</sup>** declaring that the LORD is upright;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is my rock, and there is no unrighteousness in Him.<br/>


## Chapter 93

**<sup>1</sup>** The LORD reigns; He is clothed with majesty;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD is clothed; He has girded Himself with strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;indeed, the world is established; it shall not be moved.<br/>
**<sup>2</sup>** Your throne is established from of old;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are from everlasting.<br/>
**<sup>3</sup>** The floods have lifted up, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the floods have lifted up their voice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the floods lift up their pounding waves.<br/>
**<sup>4</sup>** More than the voices of many waters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;more than the mighty breakers of the sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD on high is mighty.<br/>
**<sup>5</sup>** Your testimonies are very sure;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;holiness befits Your house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD, forevermore.<br/>


## Chapter 94

**<sup>1</sup>** O LORD, God of vengeance,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;God of vengeance, shine forth.<br/>
**<sup>2</sup>** Rise up, O Judge of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;repay the proud what they deserve.

**<sup>3</sup>** How long shall the wicked, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how long shall the wicked exult?<br/>
**<sup>4</sup>** They pour out arrogant words;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the evildoers boast of themselves.<br/>
**<sup>5</sup>** They crush Your people, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and afflict Your heritage.<br/>
**<sup>6</sup>** They kill the widow and the sojourner,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and murder the fatherless.

**<sup>7</sup>** And they say, “The LORD does not see;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the God of Jacob does not understand.”<br/>
**<sup>8</sup>** Understand, you senseless among the people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you fools, when will you become wise?

**<sup>9</sup>** He who planted the ear, does He not hear?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He who formed the eye, does He not see?<br/>
**<sup>10</sup>** He who disciplines nations, will He not punish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He who teaches man knowledge?<br/>
**<sup>11</sup>** The LORD knows the thoughts of man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they are but a breath.

**<sup>12</sup>** Blessed is the man whom You discipline, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and teach out of Your law,<br/>
**<sup>13</sup>** to give him rest from days of trouble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until a pit is dug for the wicked.<br/>
**<sup>14</sup>** For the LORD will not forsake His people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will not abandon His heritage.<br/>
**<sup>15</sup>** For judgment will again be righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the upright in heart will follow it.

**<sup>16</sup>** Who will rise up for me against the wicked?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who will stand for me against evildoers?<br/>
**<sup>17</sup>** If the LORD had not been my help,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my soul would soon have dwelt in silence.<br/>
**<sup>18</sup>** When I said, “My foot is slipping,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your steadfast love, O LORD, supported me.<br/>
**<sup>19</sup>** When my anxious thoughts multiplied within me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your consolations delighted my soul.

**<sup>20</sup>** Can a throne of destruction be allied with You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;one that frames mischief by statute?<br/>
**<sup>21</sup>** They band together against the life of the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and condemn the innocent to death.<br/>
**<sup>22</sup>** But the LORD has been my stronghold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my God the rock of my refuge.<br/>
**<sup>23</sup>** And He will repay them for their iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will destroy them for their evil;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD our God will destroy them.<br/>


## Chapter 95

**<sup>1</sup>** Oh come, let us sing to the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let us make a joyful noise to the rock of our salvation.<br/>
**<sup>2</sup>** Let us come before His presence with thanksgiving;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let us make a joyful noise to Him with songs of praise.

**<sup>3</sup>** For the LORD is a great God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a great King above all gods.<br/>
**<sup>4</sup>** In His hand are the depths of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the heights of the mountains are His also.

**<sup>5</sup>** The sea is His, for He made it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His hands formed the dry land.<br/>
**<sup>6</sup>** Oh come, let us worship and bow down;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let us kneel before the LORD our Maker.

**<sup>7</sup>** For He is our God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and we are the people of His pasture<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the sheep of His hand.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Today, if you hear His voice,<br/>
**<sup>8</sup>** do not harden your heart, as at Meribah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as on the day at Massah in the wilderness,<br/>
**<sup>9</sup>** when your fathers tested Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they tried Me, though they had seen My work.

**<sup>10</sup>** For forty years I loathed that generation<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and said, “They are a people who go astray in their heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they have not known My ways.”<br/>
**<sup>11</sup>** Therefore I swore in My wrath,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“They shall not enter My rest.”<br/>


## Chapter 96

**<sup>1</sup>** Sing to the LORD a new song;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sing to the LORD, all the earth.<br/>
**<sup>2</sup>** Sing to the LORD, bless His name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;proclaim His salvation from day to day.<br/>
**<sup>3</sup>** Declare His glory among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His marvelous works among all the peoples.

**<sup>4</sup>** For great is the LORD, and greatly to be praised;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is to be feared above all gods.<br/>
**<sup>5</sup>** For all the gods of the nations are idols,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the LORD made the heavens.<br/>
**<sup>6</sup>** Splendor and majesty are before Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;strength and beauty are in His sanctuary.

**<sup>7</sup>** Ascribe to the LORD, O families of the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;ascribe to the LORD glory and strength.<br/>
**<sup>8</sup>** Ascribe to the LORD the glory due His name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;bring an offering, and come into His courts.<br/>
**<sup>9</sup>** Worship the LORD in the beauty of holiness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;tremble before Him, all the earth.

**<sup>10</sup>** Say among the nations, “The LORD reigns!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Yes, the world is established; it shall not be moved;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will judge the peoples with equity.”<br/>
**<sup>11</sup>** Let the heavens rejoice, and let the earth be glad;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the sea roar, and all that fills it.<br/>
**<sup>12</sup>** Let the field exult, and everything in it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then shall all the trees of the forest sing for joy<br/>
**<sup>13</sup>** before the LORD, for He comes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He comes to judge the earth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will judge the world in righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the peoples in His truth.<br/>


## Chapter 97

**<sup>1</sup>** The LORD reigns, let the earth rejoice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the many coastlands be glad.<br/>
**<sup>2</sup>** Clouds and thick darkness are around Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;righteousness and justice are the foundation of His throne.<br/>
**<sup>3</sup>** Fire goes before Him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and burns up His adversaries all around.<br/>
**<sup>4</sup>** His lightnings light up the world;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the earth sees and trembles.

**<sup>5</sup>** The mountains melt like wax before the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the Lord of all the earth.<br/>
**<sup>6</sup>** The heavens declare His righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the peoples see His glory.<br/>
**<sup>7</sup>** All who serve carved images are put to shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who boast in idols;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;worship Him, all you gods.<br/>
**<sup>8</sup>** Zion hears and is glad,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the daughters of Judah rejoice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of Your judgments, O LORD.

**<sup>9</sup>** For You, O LORD, are Most High over all the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are exalted far above all gods.<br/>
**<sup>10</sup>** O you who love the LORD, hate evil!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He preserves the lives of His saints;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He delivers them from the hand of the wicked.<br/>
**<sup>11</sup>** Light is sown for the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and joy for the upright in heart.<br/>
**<sup>12</sup>** Rejoice in the LORD, you righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and give thanks to His holy name.<br/>


## Chapter 98

**<sup>1</sup>** Sing to the LORD a new song,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He has done marvelous things;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His right hand and His holy arm<br/>
&nbsp;&nbsp;&nbsp;&nbsp;have worked salvation for Him.<br/>
**<sup>2</sup>** The LORD has made known His salvation;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has revealed His righteousness in the sight of the nations.<br/>
**<sup>3</sup>** He has remembered His steadfast love and faithfulness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the house of Israel.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All the ends of the earth have seen<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the salvation of our God.

**<sup>4</sup>** Make a joyful noise to the LORD, all the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;break forth into joyful song and sing praises.<br/>
**<sup>5</sup>** Sing praises to the LORD with the lyre,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the lyre and the sound of melody.<br/>
**<sup>6</sup>** With trumpets and the sound of the horn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make a joyful noise before the King, the LORD.

**<sup>7</sup>** Let the sea roar, and all that fills it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the world and those who dwell in it.<br/>
**<sup>8</sup>** Let the rivers clap their hands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the mountains sing together for joy<br/>
**<sup>9</sup>** before the LORD, for He comes to judge the earth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will judge the world with righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the peoples with equity.<br/>


## Chapter 99

**<sup>1</sup>** The LORD reigns; let the nations tremble.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He sits enthroned upon the cherubim; let the earth quake.<br/>
**<sup>2</sup>** The LORD is great in Zion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is exalted over all the nations.

**<sup>3</sup>** Let them praise Your great and awesome name.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Holy is He.<br/>
**<sup>4</sup>** The strength of the King loves justice.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have established equity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have executed justice and righteousness in Jacob.

**<sup>5</sup>** Exalt the LORD our God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;worship at His footstool.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Holy is He.<br/>
**<sup>6</sup>** Moses and Aaron were among His priests,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Samuel also among those who called upon His name.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They called to the LORD, and He answered them.

**<sup>7</sup>** In a pillar of cloud He spoke to them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they kept His testimonies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the statute that He gave them.<br/>
**<sup>8</sup>** O LORD our God, You answered them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a forgiving God were You to them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but an avenger of their deeds.

**<sup>9</sup>** Exalt the LORD our God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and worship at His holy mountain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the LORD our God is holy.<br/>


## Chapter 100

**<sup>1</sup>** Make a joyful noise to the LORD, all the earth. **<sup>2</sup>** Serve the LORD with gladness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;come before Him with joyful singing.<br/>
**<sup>3</sup>** Know that the LORD, He is God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;It is He who made us, and not we ourselves;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we are His people, and the sheep of His pasture.<br/>
**<sup>4</sup>** Enter His gates with thanksgiving,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His courts with praise.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Give thanks to Him, bless His name.<br/>
**<sup>5</sup>** For the LORD is good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His steadfast love endures forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His faithfulness to all generations.<br/>


## Chapter 101

**<sup>1</sup>** I will sing of steadfast love and justice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to You, O LORD, I will make music.<br/>
**<sup>2</sup>** I will ponder the way that is blameless.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Oh, when will You come to me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will walk with integrity of heart within my house.<br/>
**<sup>3</sup>** I will not set before my eyes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;anything that is worthless.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I hate the work of those who fall away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it shall not cling to me.<br/>
**<sup>4</sup>** A perverse heart shall be far from me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will know nothing of evil.<br/>
**<sup>5</sup>** Whoever slanders his neighbor in secret,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;him I will put to silence;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whoever has haughty eyes and an arrogant heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;him I will not endure.<br/>
**<sup>6</sup>** My eyes will be on the faithful of the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they may dwell with me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he who walks in the way that is blameless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he shall minister to me.<br/>
**<sup>7</sup>** No one who practices deceit<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall dwell in my house;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no one who utters lies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall continue before my eyes.<br/>
**<sup>8</sup>** Morning by morning I will destroy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the wicked of the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;cutting off all evildoers<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the city of the LORD.<br/>


## Chapter 102

**<sup>1</sup>** Hear my prayer, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let my cry come to You.<br/>
**<sup>2</sup>** Do not hide Your face from me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day of my distress.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Incline Your ear to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day when I call, answer me speedily.<br/>
**<sup>3</sup>** For my days pass away like smoke,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my bones burn like a furnace.

**<sup>4</sup>** My heart is struck down like grass and withers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I forget to eat my bread.<br/>
**<sup>5</sup>** Because of my loud groaning<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my bones cling to my flesh.

**<sup>6</sup>** I am like a desert owl of the wilderness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am like an owl of the waste places.<br/>
**<sup>7</sup>** I lie awake;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am like a lonely bird on a housetop.

**<sup>8</sup>** All day long my enemies taunt me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who deride me use my name for a curse.<br/>
**<sup>9</sup>** For I eat ashes like bread<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and mingle my drink with tears,<br/>
**<sup>10</sup>** because of Your indignation and wrath;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for You have lifted me up and cast me down.

**<sup>11</sup>** My days are like a lengthening shadow;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I wither away like grass.<br/>
**<sup>12</sup>** But You, O LORD, are enthroned forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your name endures to all generations.

**<sup>13</sup>** You will arise and have compassion on Zion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for it is the time to show favor to her;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the appointed time has come.<br/>
**<sup>14</sup>** For Your servants hold her stones dear<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have pity on her dust.

**<sup>15</sup>** The nations will fear the name of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the kings of the earth Your glory.<br/>
**<sup>16</sup>** For the LORD builds up Zion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He appears in His glory.<br/>
**<sup>17</sup>** He regards the prayer of the destitute<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and does not despise their prayer.

**<sup>18</sup>** Let this be written for a generation to come,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that a people yet to be created may praise the LORD,<br/>
**<sup>19</sup>** that He looked down from His holy height,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from heaven the LORD looked at the earth,<br/>
**<sup>20</sup>** to hear the groaning of the prisoner,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to set free those doomed to die,<br/>
**<sup>21</sup>** that they may declare in Zion the name of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in Jerusalem His praise,<br/>
**<sup>22</sup>** when peoples gather together,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and kingdoms, to serve the LORD.

**<sup>23</sup>** He has broken my strength in midcourse;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has shortened my days.<br/>
**<sup>24</sup>** I say, “O my God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not take me away in the midst of my days—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your years endure throughout all generations.”<br/>
**<sup>25</sup>** Of old You laid the foundation of the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the heavens are the work of Your hands.<br/>
**<sup>26</sup>** They will perish, but You remain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will all wear out like a garment.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You will change them like a robe,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will pass away.<br/>
**<sup>27</sup>** But You are the same,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Your years have no end.<br/>
**<sup>28</sup>** The children of Your servants shall dwell secure;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their offspring shall be established before You.<br/>


## Chapter 103

**<sup>1</sup>** Bless the LORD, O my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all that is within me, bless His holy name.<br/>
**<sup>2</sup>** Bless the LORD, O my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not forget all His benefits,<br/>
**<sup>3</sup>** who forgives all your iniquity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who heals all your diseases,<br/>
**<sup>4</sup>** who redeems your life from the pit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who crowns you with steadfast love and mercy,<br/>
**<sup>5</sup>** who satisfies you with good<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that your youth is renewed like the eagle’s.

**<sup>6</sup>** The LORD works righteousness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and justice for all who are oppressed.<br/>
**<sup>7</sup>** He made known His ways to Moses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His acts to the children of Israel.<br/>
**<sup>8</sup>** The LORD is merciful and gracious,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;slow to anger and abounding in steadfast love.<br/>
**<sup>9</sup>** He will not always contend,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor will He keep His anger forever.

**<sup>10</sup>** He does not deal with us according to our sins,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor repay us according to our iniquities.<br/>
**<sup>11</sup>** For as high as the heavens are above the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so great is His steadfast love toward those who fear Him.<br/>
**<sup>12</sup>** As far as the east is from the west,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so far does He remove our transgressions from us.<br/>
**<sup>13</sup>** As a father has compassion on his children,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so the LORD has compassion on those who fear Him.

**<sup>14</sup>** For He knows our frame;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He remembers that we are dust.<br/>
**<sup>15</sup>** As for man, his days are like grass;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he flourishes like a flower of the field;<br/>
**<sup>16</sup>** for the wind passes over it, and it is gone,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its place knows it no more.

**<sup>17</sup>** But the steadfast love of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;is from everlasting to everlasting on those who fear Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His righteousness to their children’s children,<br/>
**<sup>18</sup>** to those who keep His covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and remember to do His commandments.

**<sup>19</sup>** The LORD has established His throne in the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His kingdom rules over all.<br/>
**<sup>20</sup>** Bless the LORD, you His angels,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;mighty in strength, who do His word,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;obeying the voice of His word.<br/>
**<sup>21</sup>** Bless the LORD, all His hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His ministers, who do His will.<br/>
**<sup>22</sup>** Bless the LORD, all His works,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in all places of His dominion.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Bless the LORD, O my soul.<br/>


## Chapter 104

**<sup>1</sup>** Bless the LORD, O my soul.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD my God, You are very great;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are clothed with splendor and majesty,<br/>
**<sup>2</sup>** covering Yourself with light as with a garment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;stretching out the heavens like a tent.

**<sup>3</sup>** He lays the beams of His chambers on the waters;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He makes the clouds His chariot;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He rides on the wings of the wind.<br/>
**<sup>4</sup>** He makes His messengers winds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His ministers a flaming fire.

**<sup>5</sup>** He set the earth on its foundations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that it should never be moved.<br/>
**<sup>6</sup>** You covered it with the deep as with a garment;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the waters stood above the mountains.<br/>
**<sup>7</sup>** At Your rebuke they fled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the sound of Your thunder they took to flight.<br/>
**<sup>8</sup>** The mountains rose, the valleys sank down<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the place that You appointed for them.<br/>
**<sup>9</sup>** You set a boundary that they may not pass,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that they might not again cover the earth.

**<sup>10</sup>** You make springs gush forth in the valleys;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they flow between the hills;<br/>
**<sup>11</sup>** they give drink to every beast of the field;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the wild donkeys quench their thirst.<br/>
**<sup>12</sup>** Beside them the birds of the heavens dwell;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they sing among the branches.

**<sup>13</sup>** From Your lofty abode You water the mountains;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the earth is satisfied with the fruit of Your work.<br/>
**<sup>14</sup>** You cause the grass to grow for the cattle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and plants for man to cultivate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that he may bring forth food from the earth,<br/>
**<sup>15</sup>** and wine to gladden the heart of man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;oil to make his face shine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and bread to strengthen man’s heart.

**<sup>16</sup>** The trees of the LORD are well watered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the cedars of Lebanon that He planted.<br/>
**<sup>17</sup>** In them the birds build their nests;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the stork has her home in the fir trees.<br/>
**<sup>18</sup>** The high mountains are for the wild goats;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the cliffs are a refuge for the rock badgers.

**<sup>19</sup>** He made the moon to mark the seasons;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the sun knows its time for setting.<br/>
**<sup>20</sup>** You make darkness, and it is night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when all the beasts of the forest creep about.

**<sup>21</sup>** The young lions roar for their prey,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;seeking their food from God.<br/>
**<sup>22</sup>** When the sun rises, they withdraw<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lie down in their dens.<br/>
**<sup>23</sup>** Man goes out to his work<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to his labor until the evening.

**<sup>24</sup>** O LORD, how manifold are Your works!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In wisdom You have made them all;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the earth is full of Your creatures.<br/>
**<sup>25</sup>** Here is the sea, great and wide,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which teems with creatures innumerable,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;living things both small and great.<br/>
**<sup>26</sup>** There go the ships,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Leviathan, which You formed to play in it.

**<sup>27</sup>** These all look to You,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to give them their food in due season.<br/>
**<sup>28</sup>** When You give it to them, they gather it up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when You open Your hand, they are filled with good things.<br/>
**<sup>29</sup>** When You hide Your face, they are dismayed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when You take away their breath, they die<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and return to their dust.<br/>
**<sup>30</sup>** When You send forth Your Spirit, they are created,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and You renew the face of the ground.

**<sup>31</sup>** May the glory of the LORD endure forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may the LORD rejoice in His works,<br/>
**<sup>32</sup>** who looks on the earth and it trembles,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who touches the mountains and they smoke.

**<sup>33</sup>** I will sing to the LORD as long as I live;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing praise to my God while I have being.<br/>
**<sup>34</sup>** May my meditation be pleasing to Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I rejoice in the LORD.

**<sup>35</sup>** Let sinners be consumed from the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let the wicked be no more.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Bless the LORD, O my soul.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 105

**<sup>1</sup>** Give thanks to the LORD, call upon His name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make known His deeds among the peoples.<br/>
**<sup>2</sup>** Sing to Him, sing praises to Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;tell of all His wondrous works.<br/>
**<sup>3</sup>** Glory in His holy name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the hearts of those who seek the LORD rejoice.<br/>
**<sup>4</sup>** Seek the LORD and His strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;seek His face continually.

**<sup>5</sup>** Remember the wondrous works that He has done,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His miracles, and the judgments He uttered,<br/>
**<sup>6</sup>** O offspring of Abraham His servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;children of Jacob, His chosen ones.<br/>
**<sup>7</sup>** He is the LORD our God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His judgments are in all the earth.<br/>
**<sup>8</sup>** He remembers His covenant forever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the word that He commanded, for a thousand generations,<br/>
**<sup>9</sup>** the covenant that He made with Abraham,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His sworn promise to Isaac,<br/>
**<sup>10</sup>** which He confirmed to Jacob as a statute,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to Israel as an everlasting covenant,<br/>
**<sup>11</sup>** saying, “To you I will give the land of Canaan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as your portion for an inheritance.”

**<sup>12</sup>** When they were few in number,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of little account, and sojourners in it,<br/>
**<sup>13</sup>** wandering from nation to nation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from one kingdom to another people,<br/>
**<sup>14</sup>** He allowed no man to oppress them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He rebuked kings on their account,<br/>
**<sup>15</sup>** saying, “Do not touch My anointed ones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do My prophets no harm.”

**<sup>16</sup>** When He summoned a famine on the land<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and broke all supply of bread,<br/>
**<sup>17</sup>** He had sent a man ahead of them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Joseph, who was sold as a slave.<br/>
**<sup>18</sup>** His feet were hurt with fetters;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his neck was put in a collar of iron;<br/>
**<sup>19</sup>** until what he had said came to pass,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the word of the LORD tested him.

**<sup>20</sup>** The king sent and released him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the ruler of the peoples set him free;<br/>
**<sup>21</sup>** he made him lord of his house<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ruler of all his possessions,<br/>
**<sup>22</sup>** to bind his princes at his pleasure<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to teach his elders wisdom.

**<sup>23</sup>** Then Israel came to Egypt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jacob sojourned in the land of Ham.<br/>
**<sup>24</sup>** And the LORD made His people very fruitful<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and made them stronger than their foes.<br/>
**<sup>25</sup>** He turned their hearts to hate His people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to deal craftily with His servants.

**<sup>26</sup>** He sent Moses His servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Aaron, whom He had chosen.<br/>
**<sup>27</sup>** They performed His signs among them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and miracles in the land of Ham.<br/>
**<sup>28</sup>** He sent darkness, and made the land dark;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they did not rebel against His words.<br/>
**<sup>29</sup>** He turned their waters into blood<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and caused their fish to die.<br/>
**<sup>30</sup>** Their land swarmed with frogs,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even in the chambers of their kings.<br/>
**<sup>31</sup>** He spoke, and there came swarms of flies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gnats throughout their land.<br/>
**<sup>32</sup>** He gave them hail for rain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and fiery bolts in their land.<br/>
**<sup>33</sup>** He struck down their vines and fig trees<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shattered the trees of their territory.<br/>
**<sup>34</sup>** He spoke, and the locusts came,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;young locusts without number,<br/>
**<sup>35</sup>** which devoured all the vegetation in their land<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ate up the fruit of their ground.<br/>
**<sup>36</sup>** He struck down all the firstborn in their land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the firstfruits of all their strength.

**<sup>37</sup>** Then He brought out Israel with silver and gold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there was none among His tribes who stumbled.<br/>
**<sup>38</sup>** Egypt was glad when they departed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for dread of them had fallen upon them.<br/>
**<sup>39</sup>** He spread a cloud for a covering,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and fire to give light by night.<br/>
**<sup>40</sup>** They asked, and He brought quail,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He gave them bread from heaven in abundance.<br/>
**<sup>41</sup>** He opened the rock, and water gushed out;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it flowed through the desert like a river.<br/>
**<sup>42</sup>** For He remembered His holy promise,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Abraham His servant.

**<sup>43</sup>** So He brought His people out with joy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His chosen ones with singing.<br/>
**<sup>44</sup>** And He gave them the lands of the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they inherited the fruit of the peoples’ labor,<br/>
**<sup>45</sup>** that they might keep His statutes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and observe His laws.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 106

**<sup>1</sup>** Praise the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Give thanks to the LORD, for He is good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His steadfast love endures forever.

**<sup>2</sup>** Who can utter the mighty deeds of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or declare all His praise?

**<sup>3</sup>** Blessed are those who observe justice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who do righteousness at all times.

**<sup>4</sup>** Remember me, O LORD, when You show favor to Your people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;help me when You save them,<br/>
**<sup>5</sup>** that I may see the prosperity of Your chosen ones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may rejoice in the gladness of Your nation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may glory with Your inheritance.

**<sup>6</sup>** We have sinned, both we and our fathers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we have committed iniquity, we have done wickedly.<br/>
**<sup>7</sup>** Our fathers, when they were in Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;did not consider Your wondrous works;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they did not remember the abundance of Your steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but rebelled by the sea, at the Red Sea.<br/>
**<sup>8</sup>** Yet He saved them for His name’s sake,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that He might make known His mighty power.

**<sup>9</sup>** He rebuked the Red Sea, and it became dry,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He led them through the deep as through a desert.<br/>
**<sup>10</sup>** So He saved them from the hand of the foe<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and redeemed them from the power of the enemy.<br/>
**<sup>11</sup>** And the waters covered their adversaries;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;not one of them was left.<br/>
**<sup>12</sup>** Then they believed His words;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they sang His praise.

**<sup>13</sup>** But they soon forgot His works;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they did not wait for His counsel.<br/>
**<sup>14</sup>** They had a wanton craving in the wilderness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and put God to the test in the desert.<br/>
**<sup>15</sup>** He gave them what they asked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but sent a wasting disease among them.

**<sup>16</sup>** When men in the camp were jealous of Moses<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Aaron, the holy one of the LORD,<br/>
**<sup>17</sup>** the earth opened and swallowed up Dathan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and covered the company of Abiram.<br/>
**<sup>18</sup>** Fire also broke out in their company;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the flame burned up the wicked.

**<sup>19</sup>** They made a calf in Horeb<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and worshiped a metal image.<br/>
**<sup>20</sup>** They exchanged the glory of God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the image of an ox that eats grass.<br/>
**<sup>21</sup>** They forgot God, their Savior,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who had done great things in Egypt,<br/>
**<sup>22</sup>** wondrous works in the land of Ham,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and awesome deeds by the Red Sea.<br/>
**<sup>23</sup>** Therefore He said He would destroy them—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;had not Moses, His chosen one,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;stood in the breach before Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to turn away His wrath from destroying them.

**<sup>24</sup>** Then they despised the pleasant land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;having no faith in His promise.<br/>
**<sup>25</sup>** They murmured in their tents,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not obey the voice of the LORD.<br/>
**<sup>26</sup>** Therefore He lifted His hand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and swore to them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that He would make them fall in the wilderness,<br/>
**<sup>27</sup>** and would make their offspring fall among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;scattering them among the lands.

**<sup>28</sup>** Then they yoked themselves to Baal of Peor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ate sacrifices offered to the dead;<br/>
**<sup>29</sup>** they provoked the LORD to anger with their deeds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a plague broke out among them.<br/>
**<sup>30</sup>** Then Phinehas stood up and intervened,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the plague was stayed.<br/>
**<sup>31</sup>** And that was counted to him as righteousness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from generation to generation forever.

**<sup>32</sup>** They angered Him at the waters of Meribah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it went ill with Moses on their account,<br/>
**<sup>33</sup>** for they made his spirit bitter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he spoke rashly with his lips.<br/>
**<sup>34</sup>** They did not destroy the peoples,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as the LORD commanded them,<br/>
**<sup>35</sup>** but they mixed with the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and learned to do as they did.<br/>
**<sup>36</sup>** They served their idols,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which became a snare to them.<br/>
**<sup>37</sup>** They sacrificed their sons<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their daughters to the demons;<br/>
**<sup>38</sup>** they poured out innocent blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the blood of their sons and daughters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whom they sacrificed to the idols of Canaan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the land was polluted with blood.<br/>
**<sup>39</sup>** Thus they became unclean by their acts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and played the whore in their deeds.<br/>
**<sup>40</sup>** Then the anger of the LORD was kindled against His people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He abhorred His inheritance.

**<sup>41</sup>** He gave them into the hand of the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that those who hated them ruled over them.<br/>
**<sup>42</sup>** Their enemies oppressed them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they were brought into subjection under their power.<br/>
**<sup>43</sup>** Many times He delivered them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but they were rebellious in their purposes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and were brought low through their iniquity.<br/>
**<sup>44</sup>** Nevertheless, He looked upon their distress,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when He heard their cry.

**<sup>45</sup>** For their sake He remembered His covenant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and relented according to the abundance of His steadfast love.<br/>
**<sup>46</sup>** He caused them to be pitied<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by all those who held them captive.<br/>
**<sup>47</sup>** Save us, O LORD our God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gather us from among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that we may give thanks to Your holy name<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and glory in Your praise.<br/>
**<sup>48</sup>** Blessed be the LORD, the God of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from everlasting to everlasting.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And let all the people say, “Amen!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 107

**<sup>1</sup>** Give thanks to the LORD, for He is good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His steadfast love endures forever.<br/>
**<sup>2</sup>** Let the redeemed of the LORD say so,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whom He has redeemed from the hand of the enemy,<br/>
**<sup>3</sup>** and gathered in from the lands,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the east and from the west,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the north and from the sea.<br/>
**<sup>4</sup>** They wandered in the wilderness, in a desert way;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they found no city to dwell in.<br/>
**<sup>5</sup>** Hungry and thirsty,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their soul fainted within them.<br/>
**<sup>6</sup>** Then they cried to the LORD in their trouble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He delivered them from their distresses.<br/>
**<sup>7</sup>** He led them by a straight way,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;till they reached a city to dwell in.<br/>
**<sup>8</sup>** Let them thank the LORD for His steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His wondrous works to the sons of man.<br/>
**<sup>9</sup>** For He satisfies the longing soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the hungry soul He fills with good things.

**<sup>10</sup>** Some sat in darkness and in the shadow of death,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;prisoners in affliction and in irons,<br/>
**<sup>11</sup>** for they had rebelled against the words of God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and spurned the counsel of the Most High.<br/>
**<sup>12</sup>** So He humbled their heart with labor;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they stumbled, and there was none to help.<br/>
**<sup>13</sup>** Then they cried to the LORD in their trouble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He delivered them from their distresses.<br/>
**<sup>14</sup>** He brought them out of darkness and the shadow of death,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and broke their bonds apart.<br/>
**<sup>15</sup>** Let them thank the LORD for His steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His wondrous works to the sons of man.<br/>
**<sup>16</sup>** For He shatters the doors of bronze<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cuts in two the bars of iron.

**<sup>17</sup>** Fools, through their sinful ways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and because of their iniquities, were afflicted.<br/>
**<sup>18</sup>** Their soul loathed any kind of food,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they drew near to the gates of death.<br/>
**<sup>19</sup>** Then they cried to the LORD in their trouble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He delivered them from their distresses.<br/>
**<sup>20</sup>** He sent out His word and healed them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and delivered them from their destruction.<br/>
**<sup>21</sup>** Let them thank the LORD for His steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His wondrous works to the sons of man.<br/>
**<sup>22</sup>** And let them offer sacrifices of thanksgiving,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and tell of His deeds with songs of joy.

**<sup>23</sup>** Those who went down to the sea in ships,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;doing business on the mighty waters,<br/>
**<sup>24</sup>** they saw the deeds of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His wondrous works in the deep.<br/>
**<sup>25</sup>** For He spoke and raised the stormy wind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which lifted up the waves of the sea.<br/>
**<sup>26</sup>** They mounted up to heaven; they went down to the depths;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their courage melted away in their calamity.<br/>
**<sup>27</sup>** They reeled and staggered like drunken men,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and were at their wits’ end.<br/>
**<sup>28</sup>** Then they cried to the LORD in their trouble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He delivered them from their distresses.<br/>
**<sup>29</sup>** He made the storm be still,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the waves of the sea were hushed.<br/>
**<sup>30</sup>** Then they were glad that the waters were quiet,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He brought them to their desired haven.<br/>
**<sup>31</sup>** Let them thank the LORD for His steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His wondrous works to the sons of man.<br/>
**<sup>32</sup>** Let them extol Him in the congregation of the people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and praise Him in the assembly of the elders.

**<sup>33</sup>** He turns rivers into a desert,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;springs of water into thirsty ground,<br/>
**<sup>34</sup>** a fruitful land into a salty waste,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the wickedness of its inhabitants.<br/>
**<sup>35</sup>** He turns a desert into pools of water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a parched land into springs of water.<br/>
**<sup>36</sup>** And there He makes the hungry dwell,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they establish a city to dwell in.<br/>
**<sup>37</sup>** They sow fields and plant vineyards,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and get a fruitful yield.<br/>
**<sup>38</sup>** By His blessing they multiply greatly,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He does not let their cattle diminish.<br/>
**<sup>39</sup>** When they are diminished and brought low<br/>
&nbsp;&nbsp;&nbsp;&nbsp;through oppression, evil, and sorrow,<br/>
**<sup>40</sup>** He pours contempt on princes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and makes them wander in trackless wastes;<br/>
**<sup>41</sup>** but He raises up the needy out of affliction<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and makes their families like flocks.<br/>
**<sup>42</sup>** The upright see it and are glad,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all wickedness shuts its mouth.<br/>
**<sup>43</sup>** Whoever is wise, let him attend to these things;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them consider the steadfast love of the LORD.<br/>


## Chapter 108

**<sup>1</sup>** My heart is steadfast, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing, I will make melody with all my being.<br/>
**<sup>2</sup>** Awake, harp and lyre!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will awaken the dawn.

**<sup>3</sup>** I will give thanks to You, O LORD, among the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing praises to You among the peoples.<br/>
**<sup>4</sup>** For great above the heavens is Your steadfast love;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your faithfulness reaches to the skies.

**<sup>5</sup>** Be exalted, O God, above the heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let Your glory be over all the earth.<br/>
**<sup>6</sup>** That Your beloved ones may be delivered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give salvation by Your right hand and answer me.

**<sup>7</sup>** God has spoken in His holiness:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I will exult, I will divide up Shechem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and portion out the Valley of Succoth.<br/>
**<sup>8</sup>** Gilead is Mine; Manasseh is Mine;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Ephraim is the helmet of My head;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Judah is My scepter.<br/>
**<sup>9</sup>** Moab is My washbasin;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;upon Edom I cast My shoe;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;over Philistia I shout in triumph.”<br/>
**<sup>10</sup>** Who will bring me to the fortified city?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who will lead me to Edom?

**<sup>11</sup>** Have You not rejected us, O God?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You do not go forth, O God, with our armies.<br/>
**<sup>12</sup>** Give us help against the foe,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for vain is the salvation of man.<br/>
**<sup>13</sup>** With God we shall do valiantly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is He who will tread down our foes.<br/>


## Chapter 109

**<sup>1</sup>** O God of my praise, do not be silent. **<sup>2</sup>** For the mouth of the wicked and the mouth of the deceitful<br/>
&nbsp;&nbsp;&nbsp;&nbsp;have opened against me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have spoken to me with a lying tongue.<br/>
**<sup>3</sup>** They encircle me with words of hatred,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and attack me without cause.

**<sup>4</sup>** In return for my love they accuse me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but I am all prayer.<br/>
**<sup>5</sup>** So they repay me evil for good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and hatred for my love.

**<sup>6</sup>** Appoint a wicked man over him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let an accuser stand at his right hand.<br/>
**<sup>7</sup>** When he is judged, let him come out guilty;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let his prayer become sin.<br/>
**<sup>8</sup>** Let his days be few;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let another take his office.<br/>
**<sup>9</sup>** Let his children be fatherless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his wife a widow.<br/>
**<sup>10</sup>** Let his children wander about and beg,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them seek sustenance far from their ruined homes.

**<sup>11</sup>** Let the creditor seize all that he has;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let strangers plunder the fruit of his labor.<br/>
**<sup>12</sup>** Let there be none to extend kindness to him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor any to be gracious to his fatherless children.<br/>
**<sup>13</sup>** Let his posterity be cut off;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the generation to come let their name be blotted out.<br/>
**<sup>14</sup>** Let the iniquity of his fathers be remembered before the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let not the sin of his mother be blotted out.

**<sup>15</sup>** Let them be before the LORD continually,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that He may cut off the memory of them from the earth.<br/>
**<sup>16</sup>** Because he did not remember to show kindness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but pursued the afflicted and poor man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the brokenhearted, to put him to death.

**<sup>17</sup>** He loved cursing, and it came upon him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he did not delight in blessing, and it was far from him.<br/>
**<sup>18</sup>** He clothed himself with cursing as his garment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it came into his body like water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and like oil into his bones.

**<sup>19</sup>** Let it be to him as the garment he wraps around him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and as a belt he always wears.<br/>
**<sup>20</sup>** Let this be the LORD’s repayment to my accusers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to those who speak evil against my life.

**<sup>21</sup>** But You, O LORD my Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;act on my behalf for Your name’s sake;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because Your steadfast love is good, deliver me.<br/>
**<sup>22</sup>** For I am afflicted and needy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my heart is wounded within me.

**<sup>23</sup>** I fade away like a shadow at evening;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am shaken off like a locust.<br/>
**<sup>24</sup>** My knees are weak from fasting,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my flesh grows lean with no fat.

**<sup>25</sup>** I have become a reproach to them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when they see me, they shake their heads.<br/>
**<sup>26</sup>** Help me, O LORD my God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;save me according to Your steadfast love,<br/>
**<sup>27</sup>** that they may know that this is Your hand;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that You, O LORD, have done it.<br/>
**<sup>28</sup>** Let them curse, but You bless;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when they rise up, let them be put to shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but Your servant will rejoice.<br/>
**<sup>29</sup>** Let my accusers be clothed with dishonor;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them cover themselves with their own shame as with a cloak.

**<sup>30</sup>** With my mouth I will give great thanks to the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will praise Him in the midst of the multitude.<br/>
**<sup>31</sup>** For He stands at the right hand of the needy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to save him from those who condemn his soul to death.<br/>


## Chapter 110

**<sup>1</sup>** The LORD says to my lord:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Sit at My right hand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until I make your enemies your footstool.”<br/>
**<sup>2</sup>** The LORD will stretch forth the scepter of Your strength from Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;saying, “Rule in the midst of Your enemies.”

**<sup>3</sup>** Your people will offer themselves freely on the day of Your power,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in holy garments;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the womb of the dawn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the dew of Your youth is Yours.<br/>
**<sup>4</sup>** The LORD has sworn<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will not change His mind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“You are a priest forever<br/>
&nbsp;&nbsp;&nbsp;&nbsp;after the order of Melchizedek.”

**<sup>5</sup>** The Lord is at Your right hand;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will shatter kings on the day of His wrath.<br/>
**<sup>6</sup>** He will judge among the nations, filling them with corpses;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will shatter the head over the wide earth.<br/>
**<sup>7</sup>** He will drink from the brook by the way;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore He will lift up His head.<br/>


## Chapter 111

**<sup>1</sup>** Praise the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will give thanks to the LORD with my whole heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the council of the upright, and in the congregation.

**<sup>2</sup>** Great are the works of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;studied by all who delight in them.<br/>
**<sup>3</sup>** Splendid and majestic is His work,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His righteousness endures forever.

**<sup>4</sup>** He has caused His wonders to be remembered;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD is gracious and merciful.<br/>
**<sup>5</sup>** He provides food for those who fear Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He remembers His covenant forever.

**<sup>6</sup>** He has shown His people the power of His works,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in giving them the inheritance of the nations.<br/>
**<sup>7</sup>** The works of His hands are faithful and just;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all His precepts are trustworthy.<br/>
**<sup>8</sup>** They are established forever and ever,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to be performed with faithfulness and uprightness.

**<sup>9</sup>** He sent redemption to His people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has commanded His covenant forever.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Holy and awesome is His name.<br/>
**<sup>10</sup>** The fear of the LORD is the beginning of wisdom;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all who practice them have good understanding.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His praise endures forever.<br/>


## Chapter 112

**<sup>1</sup>** Praise the LORD!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Blessed is the man who fears the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who greatly delights in His commandments.<br/>
**<sup>2</sup>** His offspring will be mighty in the land;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the generation of the upright will be blessed.<br/>
**<sup>3</sup>** Wealth and riches are in his house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his righteousness endures forever.<br/>
**<sup>4</sup>** Light rises in the darkness for the upright;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is gracious, compassionate, and righteous.<br/>
**<sup>5</sup>** It is well with the man who deals generously and lends;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who conducts his affairs with justice.<br/>
**<sup>6</sup>** For the righteous will never be shaken;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will be remembered forever.<br/>
**<sup>7</sup>** He is not afraid of bad news;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his heart is steadfast, trusting in the LORD.<br/>
**<sup>8</sup>** His heart is secure; he will not be afraid,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until he looks in triumph on his adversaries.<br/>
**<sup>9</sup>** He has distributed freely, he has given to the poor;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his righteousness endures forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his horn will be exalted in honor.<br/>
**<sup>10</sup>** The wicked man sees it and is angry;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he gnashes his teeth and melts away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the desire of the wicked will perish.<br/>


## Chapter 113

**<sup>1</sup>** Praise the LORD!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise, O servants of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise the name of the LORD!<br/>
**<sup>2</sup>** Blessed be the name of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from this time forth and forevermore!<br/>
**<sup>3</sup>** From the rising of the sun to its setting,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the name of the LORD is to be praised!

**<sup>4</sup>** The LORD is high above all nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His glory above the heavens.<br/>
**<sup>5</sup>** Who is like the LORD our God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who is seated on high,<br/>
**<sup>6</sup>** who looks far down<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the heavens and the earth?

**<sup>7</sup>** He raises the poor from the dust<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lifts the needy from the ash heap,<br/>
**<sup>8</sup>** to make them sit with princes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the princes of His people.<br/>
**<sup>9</sup>** He gives the barren woman a home,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;making her the joyous mother of children.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD!<br/>


## Chapter 114

**<sup>1</sup>** When Israel went out from Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the house of Jacob from a people of strange speech,<br/>
**<sup>2</sup>** Judah became His sanctuary,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel His dominion.

**<sup>3</sup>** The sea saw and fled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Jordan turned back.<br/>
**<sup>4</sup>** The mountains skipped like rams,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the hills like lambs.

**<sup>5</sup>** What ails you, O sea, that you flee?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O Jordan, that you turn back?<br/>
**<sup>6</sup>** O mountains, that you skip like rams?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O hills, like lambs?

**<sup>7</sup>** Tremble, O earth, at the presence of the Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the presence of the God of Jacob,<br/>
**<sup>8</sup>** who turns the rock into a pool of water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the flint into a spring of water.<br/>


## Chapter 115

**<sup>1</sup>** Not to us, O LORD, not to us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but to Your name give glory,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of Your steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of Your faithfulness.

**<sup>2</sup>** Why should the nations say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Where now is their God?”<br/>
**<sup>3</sup>** Our God is in the heavens;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He does whatever He pleases.<br/>
**<sup>4</sup>** Their idols are silver and gold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the work of human hands.<br/>
**<sup>5</sup>** They have mouths, but do not speak;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;eyes, but do not see.<br/>
**<sup>6</sup>** They have ears, but do not hear;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;noses, but do not smell.<br/>
**<sup>7</sup>** They have hands, but do not feel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;feet, but do not walk;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they make no sound in their throat.<br/>
**<sup>8</sup>** Those who make them will become like them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;everyone who trusts in them.

**<sup>9</sup>** O Israel, trust in the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is their help and their shield.<br/>
**<sup>10</sup>** O house of Aaron, trust in the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is their help and their shield.<br/>
**<sup>11</sup>** You who fear the LORD, trust in the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is their help and their shield.

**<sup>12</sup>** The LORD has remembered us; He will bless us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will bless the house of Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will bless the house of Aaron.<br/>
**<sup>13</sup>** He will bless those who fear the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the small together with the great.

**<sup>14</sup>** May the LORD give you increase,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you and your children.<br/>
**<sup>15</sup>** May you be blessed by the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Maker of heaven and earth.

**<sup>16</sup>** The heavens are the heavens of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the earth He has given to the sons of man.<br/>
**<sup>17</sup>** The dead do not praise the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor do any who go down into silence.<br/>
**<sup>18</sup>** But we will bless the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from this time forth and forever.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hallelujah.<br/>


## Chapter 116

**<sup>1</sup>** I love the LORD, for He has heard my voice<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my pleas for mercy.<br/>
**<sup>2</sup>** Because He has inclined His ear to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will call on Him as long as I live.

**<sup>3</sup>** The cords of death encompassed me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the terrors of the grave found me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I found distress and sorrow.<br/>
**<sup>4</sup>** Then I called on the name of the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“O LORD, I pray, deliver my life!”

**<sup>5</sup>** Gracious is the LORD, and righteous;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our God is compassionate.<br/>
**<sup>6</sup>** The LORD preserves the simple;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I was brought low, and He saved me.<br/>
**<sup>7</sup>** Return, my soul, to your rest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the LORD has dealt bountifully with you.

**<sup>8</sup>** For You have delivered my life from death,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my eyes from tears, my feet from stumbling.<br/>
**<sup>9</sup>** I will walk before the LORD in the land of the living.

**<sup>10</sup>** I believed, even when I said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I am greatly afflicted.”<br/>
**<sup>11</sup>** I said in my alarm,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“All men are liars.”

**<sup>12</sup>** What shall I render to the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for all His benefits toward me?<br/>
**<sup>13</sup>** I will lift up the cup of salvation<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and call on the name of the LORD.<br/>
**<sup>14</sup>** I will pay my vows to the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the presence of all His people.

**<sup>15</sup>** Precious in the sight of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;is the death of His faithful ones.<br/>
**<sup>16</sup>** O LORD, I am indeed Your servant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am Your servant, the son of Your maidservant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have loosed my bonds.<br/>
**<sup>17</sup>** I will offer to You the sacrifice of thanksgiving<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and call on the name of the LORD.<br/>
**<sup>18</sup>** I will pay my vows to the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the presence of all His people,<br/>
**<sup>19</sup>** in the courts of the house of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in your midst, O Jerusalem.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hallelujah.<br/>


## Chapter 117

**<sup>1</sup>** Praise the LORD, all nations; extol Him, all peoples. **<sup>2</sup>** For His steadfast love prevails over us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the faithfulness of the LORD endures forever.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Hallelujah.<br/>


## Chapter 118

**<sup>1</sup>** Give thanks to the LORD, for He is good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His steadfast love endures forever.

**<sup>2</sup>** Let Israel say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“His steadfast love endures forever.”<br/>
**<sup>3</sup>** Let the house of Aaron say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“His steadfast love endures forever.”<br/>
**<sup>4</sup>** Let those who fear the LORD say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“His steadfast love endures forever.”

**<sup>5</sup>** Out of distress I called upon the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD answered me and set me in a spacious place.<br/>
**<sup>6</sup>** The LORD is with me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not fear. What can man do to me?<br/>
**<sup>7</sup>** The LORD is with me, as my helper;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore I will look in triumph on those who hate me.

**<sup>8</sup>** It is better to take refuge in the LORD than to trust in man. **<sup>9</sup>** It is better to take refuge in the LORD than to trust in princes.

**<sup>10</sup>** All nations surrounded me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the name of the LORD I cut them off.<br/>
**<sup>11</sup>** They surrounded me, yes, they surrounded me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the name of the LORD I cut them off.<br/>
**<sup>12</sup>** They surrounded me like bees;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they were extinguished like a fire of thorns;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the name of the LORD I cut them off.<br/>
**<sup>13</sup>** You pushed me hard to make me fall,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the LORD helped me.

**<sup>14</sup>** The LORD is my strength and my song;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has become my salvation.<br/>
**<sup>15</sup>** A sound of joyful shouting and salvation is in the tents of the righteous;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the right hand of the LORD does valiantly.<br/>
**<sup>16</sup>** The right hand of the LORD is exalted;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the right hand of the LORD does valiantly.<br/>
**<sup>17</sup>** I shall not die, but live,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and declare the works of the LORD.<br/>
**<sup>18</sup>** The LORD has disciplined me severely,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but He has not given me over to death.

**<sup>19</sup>** Open to me the gates of righteousness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will enter through them, I will give thanks to the LORD.<br/>
**<sup>20</sup>** This is the gate of the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the righteous shall enter through it.<br/>
**<sup>21</sup>** I give You thanks, for You have answered me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have become my salvation.

**<sup>22</sup>** The stone the builders rejected<br/>
&nbsp;&nbsp;&nbsp;&nbsp;has become the cornerstone.<br/>
**<sup>23</sup>** This is the LORD’s doing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is marvelous in our eyes.<br/>
**<sup>24</sup>** This is the day the LORD has made;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let us rejoice and be glad in it.

**<sup>25</sup>** O LORD, save now, I pray;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O LORD, grant success, I pray.<br/>
**<sup>26</sup>** Blessed is he who comes in the name of the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we bless you from the house of the LORD.<br/>
**<sup>27</sup>** The LORD is God, and He has given us light;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;bind the festal sacrifice with cords to the horns of the altar.

**<sup>28</sup>** You are my God, and I will give You thanks;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are my God, I will exalt You.

**<sup>29</sup>** Give thanks to the LORD, for He is good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His steadfast love endures forever.<br/>


## Chapter 119

**<sup>1</sup>** Blessed are the undefiled in the way,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who walk in the law of the LORD.<br/>
**<sup>2</sup>** Blessed are those who keep His testimonies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who seek Him with all their heart.<br/>
**<sup>3</sup>** They also do no iniquity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they walk in His ways.<br/>
**<sup>4</sup>** You have commanded Your precepts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they be kept diligently.<br/>
**<sup>5</sup>** Oh, that my ways were established<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to keep Your statutes!<br/>
**<sup>6</sup>** Then I would not be ashamed<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I regard all Your commandments.<br/>
**<sup>7</sup>** I will give You thanks with an upright heart<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I learn Your righteous judgments.<br/>
**<sup>8</sup>** I will keep Your statutes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not utterly forsake me.

**<sup>9</sup>** How can a young man keep his way pure?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;By guarding it according to Your word.<br/>
**<sup>10</sup>** With all my heart I have sought You;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me not stray from Your commandments.<br/>
**<sup>11</sup>** I have treasured Your word in my heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I might not sin against You.<br/>
**<sup>12</sup>** Blessed are You, O LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;teach me Your statutes.<br/>
**<sup>13</sup>** With my lips I have declared<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the judgments of Your mouth.<br/>
**<sup>14</sup>** I rejoice in the way of Your testimonies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as much as in all riches.<br/>
**<sup>15</sup>** I will meditate on Your precepts<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and regard Your ways.<br/>
**<sup>16</sup>** I will delight in Your statutes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not forget Your word.

**<sup>17</sup>** Deal bountifully with Your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may live and keep Your word.<br/>
**<sup>18</sup>** Open my eyes, that I may behold<br/>
&nbsp;&nbsp;&nbsp;&nbsp;wondrous things from Your law.<br/>
**<sup>19</sup>** I am a sojourner on the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not hide Your commandments from me.<br/>
**<sup>20</sup>** My soul is consumed with longing<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for Your judgments at all times.<br/>
**<sup>21</sup>** You rebuke the proud, the cursed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who wander from Your commandments.<br/>
**<sup>22</sup>** Remove from me scorn and contempt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have kept Your testimonies.<br/>
**<sup>23</sup>** Even though princes sit and speak against me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your servant meditates on Your statutes.<br/>
**<sup>24</sup>** Your testimonies are my delight,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are my counselors.

**<sup>25</sup>** My soul clings to the dust;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;revive me according to Your word.<br/>
**<sup>26</sup>** I have declared my ways, and You answered me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;teach me Your statutes.<br/>
**<sup>27</sup>** Make me understand the way of Your precepts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may meditate on Your wondrous works.<br/>
**<sup>28</sup>** My soul weeps because of grief;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;strengthen me according to Your word.<br/>
**<sup>29</sup>** Remove from me the way of falsehood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and graciously grant me Your law.<br/>
**<sup>30</sup>** I have chosen the way of faithfulness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have set Your judgments before me.<br/>
**<sup>31</sup>** I cling to Your testimonies, O LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not let me be put to shame.<br/>
**<sup>32</sup>** I will run in the way of Your commandments,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for You enlarge my heart.

**<sup>33</sup>** Teach me, O LORD, the way of Your statutes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will keep it to the end.<br/>
**<sup>34</sup>** Give me understanding, that I may keep Your law<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and observe it with my whole heart.<br/>
**<sup>35</sup>** Make me walk in the path of Your commandments,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for in it I delight.<br/>
**<sup>36</sup>** Incline my heart to Your testimonies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and not to dishonest gain.<br/>
**<sup>37</sup>** Turn my eyes away from worthless things,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and revive me in Your ways.<br/>
**<sup>38</sup>** Establish Your word to Your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which leads to the fear of You.<br/>
**<sup>39</sup>** Turn away my reproach which I dread,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for Your judgments are good.<br/>
**<sup>40</sup>** Behold, I long for Your precepts;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;revive me in Your righteousness.<br/>
**<sup>41</sup>** Let Your steadfast love come to me, O LORD, Your salvation according to Your word. **<sup>42</sup>** So I will have an answer for him who reproaches me, for I trust in Your word. **<sup>43</sup>** Do not take the word of truth utterly from my mouth, for I wait for Your judgments. **<sup>44</sup>** So I will keep Your law continually, forever and ever. **<sup>45</sup>** And I will walk in liberty, for I seek Your precepts. **<sup>46</sup>** I will speak of Your testimonies before kings and will not be ashamed. **<sup>47</sup>** I will delight in Your commandments, which I love. **<sup>48</sup>** I will lift up my hands to Your commandments, which I love, and I will meditate on Your statutes.

**<sup>49</sup>** Remember the word to Your servant, in which You have made me hope. **<sup>50</sup>** This is my comfort in my affliction, that Your word has revived me. **<sup>51</sup>** The arrogant utterly deride me, but I do not turn aside from Your law. **<sup>52</sup>** I remember Your judgments of old, O LORD, and I take comfort. **<sup>53</sup>** Rage seizes me because of the wicked, who forsake Your law. **<sup>54</sup>** Your statutes have been my songs in the house of my sojourning. **<sup>55</sup>** I remember Your name in the night, O LORD, and keep Your law. **<sup>56</sup>** This has been mine, that I have kept Your precepts.

**<sup>57</sup>** The LORD is my portion; I have promised to keep Your words. **<sup>58</sup>** I entreat Your favor with all my heart; be gracious to me according to Your word. **<sup>59</sup>** I have considered my ways and turned my feet to Your testimonies. **<sup>60</sup>** I hasten and do not delay to keep Your commandments. **<sup>61</sup>** The cords of the wicked surround me, but I have not forgotten Your law. **<sup>62</sup>** At midnight I rise to give thanks to You because of Your righteous judgments. **<sup>63</sup>** I am a companion of all who fear You and of those who keep Your precepts. **<sup>64</sup>** The earth is full of Your steadfast love, O LORD; teach me Your statutes.

**<sup>65</sup>** You have dealt well with Your servant, O LORD, according to Your word. **<sup>66</sup>** Teach me good judgment and knowledge, for I believe in Your commandments. **<sup>67</sup>** Before I was afflicted I went astray, but now I keep Your word. **<sup>68</sup>** You are good and do good; teach me Your statutes. **<sup>69</sup>** The arrogant smear me with lies, but I keep Your precepts with all my heart. **<sup>70</sup>** Their heart is unfeeling like fat, but I delight in Your law. **<sup>71</sup>** It is good for me that I was afflicted, that I might learn Your statutes. **<sup>72</sup>** The law of Your mouth is better to me than thousands of gold and silver pieces.

**<sup>73</sup>** Your hands made me and fashioned me; give me understanding that I may learn Your commandments. **<sup>74</sup>** Those who fear You shall see me and rejoice, because I hope in Your word. **<sup>75</sup>** I know, O LORD, that Your judgments are righteous, and that in faithfulness You have afflicted me. **<sup>76</sup>** Let Your steadfast love now comfort me, according to Your promise to Your servant. **<sup>77</sup>** Let Your compassion come to me, that I may live, for Your law is my delight. **<sup>78</sup>** Let the arrogant be ashamed, for they have wronged me with falsehood; I will meditate on Your precepts. **<sup>79</sup>** Let those who fear You turn to me, and those who know Your testimonies. **<sup>80</sup>** Let my heart be blameless in Your statutes, that I may not be put to shame.

**<sup>81</sup>** My soul longs for Your salvation; I hope in Your word. **<sup>82</sup>** My eyes fail for Your promise, saying, “When will You comfort me?” **<sup>83</sup>** For I have become like a wineskin in the smoke, yet I do not forget Your statutes. **<sup>84</sup>** How many are the days of Your servant? When will You execute judgment on those who persecute me? **<sup>85</sup>** The proud have dug pits for me, those who do not live according to Your law. **<sup>86</sup>** All Your commandments are faithful; they persecute me with falsehood—help me! **<sup>87</sup>** They almost consumed me on the earth, but I have not forsaken Your precepts. **<sup>88</sup>** Revive me according to Your steadfast love, that I may keep the testimony of Your mouth.

**<sup>89</sup>** Forever, O LORD, Your word is firmly fixed in the heavens. **<sup>90</sup>** Your faithfulness endures to all generations; You established the earth, and it stands. **<sup>91</sup>** They stand this day according to Your ordinances, for all things are Your servants. **<sup>92</sup>** If Your law had not been my delight, I would have perished in my affliction. **<sup>93</sup>** I will never forget Your precepts, for by them You have given me life. **<sup>94</sup>** I am Yours; save me, for I have sought Your precepts. **<sup>95</sup>** The wicked lie in wait to destroy me, but I consider Your testimonies. **<sup>96</sup>** I have seen a limit to all perfection, but Your commandment is exceedingly broad.

**<sup>97</sup>** Oh, how I love Your law! It is my meditation all the day. **<sup>98</sup>** Your commandments make me wiser than my enemies, for they are ever with me. **<sup>99</sup>** I have more insight than all my teachers, for Your testimonies are my meditation. **<sup>100</sup>** I understand more than the aged, because I keep Your precepts. **<sup>101</sup>** I have restrained my feet from every evil way, that I may keep Your word. **<sup>102</sup>** I have not turned aside from Your judgments, for You Yourself have taught me. **<sup>103</sup>** How sweet are Your words to my taste, sweeter than honey to my mouth! **<sup>104</sup>** Through Your precepts I get understanding; therefore I hate every false way.

**<sup>105</sup>** Your word is a lamp to my feet and a light to my path. **<sup>106</sup>** I have sworn and confirmed to keep Your righteous judgments. **<sup>107</sup>** I am afflicted very much; revive me, O LORD, according to Your word. **<sup>108</sup>** Accept, O LORD, the freewill offerings of my mouth, and teach me Your judgments. **<sup>109</sup>** My life is continually in my hand, yet I do not forget Your law. **<sup>110</sup>** The wicked have set a snare for me, yet I have not strayed from Your precepts. **<sup>111</sup>** Your testimonies are my heritage forever, for they are the joy of my heart. **<sup>112</sup>** I have inclined my heart to perform Your statutes forever, to the end.

**<sup>113</sup>** I hate the double-minded, but I love Your law. **<sup>114</sup>** You are my hiding place and my shield; I hope in Your word. **<sup>115</sup>** Depart from me, evildoers, that I may keep the commandments of my God. **<sup>116</sup>** Uphold me according to Your word, that I may live, and do not let me be ashamed of my hope. **<sup>117</sup>** Hold me up, that I may be safe and have regard for Your statutes continually. **<sup>118</sup>** You reject all who stray from Your statutes, for their deceit is falsehood. **<sup>119</sup>** You remove all the wicked of the earth like dross; therefore I love Your testimonies. **<sup>120</sup>** My flesh trembles for fear of You, and I am afraid of Your judgments.

**<sup>121</sup>** I have done what is just and right; do not leave me to my oppressors. **<sup>122</sup>** Guarantee the welfare of Your servant; let not the proud oppress me. **<sup>123</sup>** My eyes fail for Your salvation and for the fulfillment of Your righteous promise. **<sup>124</sup>** Deal with Your servant according to Your steadfast love, and teach me Your statutes. **<sup>125</sup>** I am Your servant; give me understanding, that I may know Your testimonies. **<sup>126</sup>** It is time for the LORD to act, for they have broken Your law. **<sup>127</sup>** Therefore I love Your commandments above gold, yes, above fine gold. **<sup>128</sup>** Therefore I regard all Your precepts as right in every way; I hate every false path.

**<sup>129</sup>** Your testimonies are wonderful; therefore my soul keeps them. **<sup>130</sup>** The unfolding of Your words gives light; it gives understanding to the simple. **<sup>131</sup>** I open my mouth and pant, because I long for Your commandments. **<sup>132</sup>** Turn to me and be gracious to me, as is Your way with those who love Your name. **<sup>133</sup>** Establish my steps by Your word, and let no iniquity have dominion over me. **<sup>134</sup>** Redeem me from the oppression of man, that I may keep Your precepts. **<sup>135</sup>** Make Your face shine upon Your servant, and teach me Your statutes. **<sup>136</sup>** Streams of tears flow from my eyes, because men do not keep Your law.

**<sup>137</sup>** Righteous are You, O LORD, and upright are Your judgments. **<sup>138</sup>** You have commanded Your testimonies in righteousness and great faithfulness. **<sup>139</sup>** My zeal consumes me, because my foes forget Your words. **<sup>140</sup>** Your word is very pure, and Your servant loves it. **<sup>141</sup>** I am small and despised, yet I do not forget Your precepts. **<sup>142</sup>** Your righteousness is everlasting, and Your law is truth. **<sup>143</sup>** Trouble and distress have come upon me, yet Your commandments are my delight. **<sup>144</sup>** The righteousness of Your testimonies is everlasting; give me understanding, that I may live.

**<sup>145</sup>** I call with my whole heart; answer me, O LORD. I will keep Your statutes. **<sup>146</sup>** I call to You; save me, that I may observe Your testimonies. **<sup>147</sup>** I rise before dawn and cry for help; I hope in Your word. **<sup>148</sup>** My eyes are awake before the watches of the night, that I may meditate on Your promise. **<sup>149</sup>** Hear my voice according to Your steadfast love; O LORD, revive me according to Your justice. **<sup>150</sup>** Those who pursue wickedness draw near; they are far from Your law. **<sup>151</sup>** You are near, O LORD, and all Your commandments are truth. **<sup>152</sup>** Long have I known from Your testimonies that You have established them forever.

**<sup>153</sup>** Look upon my affliction and deliver me, for I do not forget Your law. **<sup>154</sup>** Plead my cause and redeem me; revive me according to Your promise. **<sup>155</sup>** Salvation is far from the wicked, for they do not seek Your statutes. **<sup>156</sup>** Great are Your mercies, O LORD; revive me according to Your ordinances. **<sup>157</sup>** Many are my persecutors and my foes, yet I do not turn from Your testimonies. **<sup>158</sup>** I look upon the faithless with loathing, because they do not keep Your word. **<sup>159</sup>** Consider how I love Your precepts; revive me, O LORD, according to Your steadfast love. **<sup>160</sup>** The sum of Your word is truth, and every one of Your righteous ordinances endures forever.

**<sup>161</sup>** Princes persecute me without cause, but my heart stands in awe of Your word. **<sup>162</sup>** I rejoice at Your word as one who finds great spoil. **<sup>163</sup>** I hate and abhor falsehood, but I love Your law. **<sup>164</sup>** Seven times a day I praise You because of Your righteous judgments. **<sup>165</sup>** Great peace have those who love Your law, and nothing causes them to stumble. **<sup>166</sup>** I hope for Your salvation, O LORD, and I do Your commandments. **<sup>167</sup>** My soul keeps Your testimonies, and I love them exceedingly. **<sup>168</sup>** I keep Your precepts and Your testimonies, for all my ways are before You.

**<sup>169</sup>** Let my cry come near before You, O LORD; give me understanding according to Your word. **<sup>170</sup>** Let my supplication come before You; deliver me according to Your promise. **<sup>171</sup>** My lips will pour forth praise, for You teach me Your statutes. **<sup>172</sup>** My tongue will sing of Your word, for all Your commandments are righteous. **<sup>173</sup>** Let Your hand be ready to help me, for I have chosen Your precepts. **<sup>174</sup>** I long for Your salvation, O LORD, and Your law is my delight. **<sup>175</sup>** Let my soul live and praise You, and let Your ordinances help me. **<sup>176</sup>** I have gone astray like a lost sheep; seek Your servant, for I do not forget Your commandments. 

## Chapter 120

**<sup>1</sup>** In my distress I called to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He answered me.<br/>
**<sup>2</sup>** Deliver my soul, O LORD, from lying lips,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from a deceitful tongue.<br/>
**<sup>3</sup>** What shall be given to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and what more shall be done to you, deceitful tongue?<br/>
**<sup>4</sup>** Sharp arrows of the warrior,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with burning coals of the broom tree.

**<sup>5</sup>** Woe to me, that I sojourn in Meshech,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I dwell among the tents of Kedar!<br/>
**<sup>6</sup>** Too long has my soul had its dwelling<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with those who hate peace.<br/>
**<sup>7</sup>** I am for peace,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but when I speak, they are for war.<br/>


## Chapter 121

**<sup>1</sup>** I lift up my eyes to the mountains—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from where will my help come?<br/>
**<sup>2</sup>** My help comes from the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Maker of heaven and earth.

**<sup>3</sup>** He will not allow your foot to slip;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your Keeper will not slumber.<br/>
**<sup>4</sup>** Behold, He who keeps Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will neither slumber nor sleep.

**<sup>5</sup>** The LORD is your Keeper;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD is your shade at your right hand.<br/>
**<sup>6</sup>** The sun will not strike you by day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor the moon by night.

**<sup>7</sup>** The LORD will keep you from all evil;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will keep your soul.<br/>
**<sup>8</sup>** The LORD will keep your going out and your coming in<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from this time forth and forever.<br/>


## Chapter 122

**<sup>1</sup>** I rejoiced when they said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Let us go to the house of the LORD.”<br/>
**<sup>2</sup>** Our feet have been standing<br/>
&nbsp;&nbsp;&nbsp;&nbsp;within your gates, O Jerusalem.

**<sup>3</sup>** Jerusalem, built as a city<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that is joined together as one,<br/>
**<sup>4</sup>** to which the tribes go up,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the tribes of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as a statute for Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to give thanks to the name of the LORD.<br/>
**<sup>5</sup>** For there thrones for judgment were set,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the thrones of the house of David.

**<sup>6</sup>** Pray for the peace of Jerusalem:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“May those who love you be secure.<br/>
**<sup>7</sup>** May there be peace within your walls,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;prosperity within your palaces.”<br/>
**<sup>8</sup>** For the sake of my brothers and my companions,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will now say, “Peace be within you.”<br/>
**<sup>9</sup>** For the sake of the house of the LORD our God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will seek your good.<br/>


## Chapter 123

**<sup>1</sup>** To you I lift up my eyes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who are enthroned in the heavens.<br/>
**<sup>2</sup>** As the eyes of a servant look to the hand of his master,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as the eyes of a maidservant to the hand of her mistress,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so our eyes look to the LORD our God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until he shows us favor.

**<sup>3</sup>** Show us favor, O LORD, show us favor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for we have had our fill of contempt.<br/>
**<sup>4</sup>** Our soul has had its fill<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of the mockery of the self-assured,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of the contempt of the proud.<br/>


## Chapter 124

**<sup>1</sup>** “If the LORD had not been for us,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let Israel now say,<br/>
**<sup>2</sup>** “If the LORD had not been for us<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when men rose up against us,<br/>
**<sup>3</sup>** then they would have swallowed us alive,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when their anger burned against us;<br/>
**<sup>4</sup>** then the waters would have swept us away,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a torrent would have passed over us;<br/>
**<sup>5</sup>** then over us would have passed<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the raging waters.”

**<sup>6</sup>** Blessed be the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who has not given us as prey to their teeth.<br/>
**<sup>7</sup>** Our soul has escaped like a bird<br/>
&nbsp;&nbsp;&nbsp;&nbsp;out of the snare of the fowlers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the snare is broken, and we have escaped.

**<sup>8</sup>** Our help is in the name of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Maker of heaven and earth.<br/>


## Chapter 125

**<sup>1</sup>** Those who trust in the LORD are like Mount Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which cannot be moved but abides forever.<br/>
**<sup>2</sup>** As the mountains surround Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so the LORD surrounds his people now and forever.<br/>
**<sup>3</sup>** The scepter of the wicked shall not rest<br/>
&nbsp;&nbsp;&nbsp;&nbsp;over the allotted portion of the righteous;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lest the righteous extend their hands to iniquity.<br/>
**<sup>4</sup>** Do good, O LORD, to those who are good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the upright in heart.<br/>
**<sup>5</sup>** But as for those who turn aside to crooked ways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD will lead them away with evildoers.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Peace be upon Israel.<br/>


## Chapter 126

**<sup>1</sup>** When the LORD restored the fortunes of Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we were like men who dream.<br/>
**<sup>2</sup>** Then our mouth was filled with laughter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our tongue with shouts of joy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then they said among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“The LORD has done great things for them.”<br/>
**<sup>3</sup>** The LORD has done great things for us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we rejoiced.

**<sup>4</sup>** Restore our fortunes, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like streams in the Negev.<br/>
**<sup>5</sup>** Those who sow with tears<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall reap with shouts of joy.<br/>
**<sup>6</sup>** He goes along weeping,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;carrying the bag of seed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he shall surely come with shouts of joy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;carrying his sheaves.<br/>


## Chapter 127

**<sup>1</sup>** Unless the LORD builds the house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;its builders labor in vain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;unless the LORD watches over the city,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the watchman stays awake in vain.<br/>
**<sup>2</sup>** It is in vain that you rise early,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that you sit up late,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;eating the bread of toil;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he gives sleep to his beloved.<br/>
**<sup>3</sup>** Sons are an inheritance from the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the fruit of the womb a reward.<br/>
**<sup>4</sup>** Like arrows in the hand of a warrior,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so are the sons of one’s youth.<br/>
**<sup>5</sup>** Blessed is the man whose quiver is filled with them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he shall not be put to shame<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when he speaks with his enemies in the gate.<br/>


## Chapter 128

**<sup>1</sup>** Blessed is every man who fears the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who walks in his ways.<br/>
**<sup>2</sup>** You shall eat the labor of your hands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you shall be blessed, and it shall be well with you.<br/>
**<sup>3</sup>** Your wife shall be like a fruitful vine<br/>
&nbsp;&nbsp;&nbsp;&nbsp;within your house;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your sons like olive shoots<br/>
&nbsp;&nbsp;&nbsp;&nbsp;around your table.<br/>
**<sup>4</sup>** Yes, in this way shall the man be blessed<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who fears the LORD.<br/>
**<sup>5</sup>** May the LORD bless you from Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that you may see the good of Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the days of your life;<br/>
**<sup>6</sup>** and that you may see your sons’ sons.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Peace upon Israel.<br/>


## Chapter 129

**<sup>1</sup>** “Greatly have they afflicted me from my youth”—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let Israel now say—<br/>
**<sup>2</sup>** “Greatly have they afflicted me from my youth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they have not prevailed against me.<br/>
**<sup>3</sup>** The plowmen plowed upon my back;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they made their furrows long.”<br/>
**<sup>4</sup>** The LORD is righteous;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has cut the cords of the wicked.<br/>
**<sup>5</sup>** Let all who hate Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;be put to shame and turned backward.<br/>
**<sup>6</sup>** Let them be like grass on the housetops,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which withers before it is pulled up,<br/>
**<sup>7</sup>** with which the reaper does not fill his hand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor the binder of sheaves his arms;<br/>
**<sup>8</sup>** and none who pass by say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“The blessing of the LORD be upon you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we bless you in the name of the LORD.”<br/>


## Chapter 130

**<sup>1</sup>** From the depths I call to you, O LORD; **<sup>2</sup>** Lord, hear my voice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let your ears be attentive<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to my plea for mercy.

**<sup>3</sup>** If you should mark iniquities, Lord,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Lord, who could stand?<br/>
**<sup>4</sup>** But with you there is forgiveness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that you may be feared.

**<sup>5</sup>** I wait for the LORD—my soul waits—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in his word I hope;<br/>
**<sup>6</sup>** my soul waits for the Lord<br/>
&nbsp;&nbsp;&nbsp;&nbsp;more than watchmen for the morning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;more than watchmen for the morning.

**<sup>7</sup>** O Israel, wait for the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for with the LORD is steadfast love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with him is abundant redemption.<br/>
**<sup>8</sup>** And he will redeem Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from all his iniquities.<br/>


## Chapter 131

**<sup>1</sup>** LORD, my heart is not proud,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor are my eyes lifted high,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor have I walked in great matters<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or in things too wondrous for me.<br/>
**<sup>2</sup>** Surely I have composed and quieted my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a weaned child with his mother;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a weaned child upon me is my soul.

**<sup>3</sup>** Let Israel wait for the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from now until forever.<br/>


## Chapter 132

**<sup>1</sup>** LORD, remember for David<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all his hardship—<br/>
**<sup>2</sup>** how he swore to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;vowed to the Mighty One of Jacob:<br/>
**<sup>3</sup>** “I will not enter the tent of my house;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not go up upon the couch of my bed;<br/>
**<sup>4</sup>** I will not give sleep to my eyes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;slumber to my eyelids,<br/>
**<sup>5</sup>** until I find a place for the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a dwelling for the Mighty One of Jacob.”

**<sup>6</sup>** Look, we heard of it in Ephrathah;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we found it in the fields of the forest.<br/>
**<sup>7</sup>** Let us go into his dwelling-place;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let us bow down at his footstool.

**<sup>8</sup>** Rise, LORD, to your resting-place,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you and the ark of your strength.<br/>
**<sup>9</sup>** Let your priests be clothed with righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let your faithful ones shout for joy.<br/>
**<sup>10</sup>** For the sake of David your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not turn away the face of your anointed.

**<sup>11</sup>** The LORD swore to David in truth—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will not turn from it—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“From the fruit of your body I will set one upon your throne.<br/>
**<sup>12</sup>** If your sons keep my covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my testimonies that I teach them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their sons also will sit upon your throne forever.”

**<sup>13</sup>** For the LORD has chosen Zion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has desired it for his dwelling:<br/>
**<sup>14</sup>** “This is my resting-place forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;here I will dwell, for I have desired it.<br/>
**<sup>15</sup>** I will bless its provisions abundantly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will satisfy its needy with bread.<br/>
**<sup>16</sup>** I will clothe its priests with salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its faithful ones will shout loudly for joy.<br/>
**<sup>17</sup>** There I will cause a horn for David to spring up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have set in place a lamp for my anointed.<br/>
**<sup>18</sup>** His enemies I will clothe with shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but upon him his crown will shine.”<br/>


## Chapter 133

**<sup>1</sup>** How good and how pleasant it is<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for brothers to dwell together in unity.<br/>
**<sup>2</sup>** It is like the precious oil on the head,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;running down upon the beard,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;running down upon Aaron’s beard,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;running down over the collar of his robes.<br/>
**<sup>3</sup>** It is like the dew of Hermon<br/>
&nbsp;&nbsp;&nbsp;&nbsp;coming down upon the mountains of Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for there the LORD commanded the blessing —<br/>
&nbsp;&nbsp;&nbsp;&nbsp;life forever.<br/>


## Chapter 134

**<sup>1</sup>** Come! Praise the LORD, all you servants of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who stand by night in the house of the LORD.<br/>
**<sup>2</sup>** Lift up your hands in holiness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and bless the LORD.<br/>
**<sup>3</sup>** May the LORD bless you from Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Maker of heaven and earth.<br/>


## Chapter 135

**<sup>1</sup>** Praise the LORD. Praise the name of the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise Him, you servants of the LORD,<br/>
**<sup>2</sup>** you who stand in the house of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the courts of the house of our God.<br/>
**<sup>3</sup>** Praise the LORD, for the LORD is good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sing to His name, for it is pleasant.<br/>
**<sup>4</sup>** For the LORD has chosen Jacob for Himself,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel as His treasured possession.<br/>
**<sup>5</sup>** I know that the LORD is great,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our Lord is above all gods.<br/>
**<sup>6</sup>** Whatever the LORD desires He does,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in heaven and on earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the seas and all the depths.<br/>
**<sup>7</sup>** He brings up clouds from the ends of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He makes lightning for the rain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He brings the wind out of His storehouses.<br/>
**<sup>8</sup>** He struck the firstborn of Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;both of man and of beast.<br/>
**<sup>9</sup>** He sent signs and wonders into your midst, Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against Pharaoh and all his servants.<br/>
**<sup>10</sup>** He struck down many nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and killed mighty kings,<br/>
**<sup>11</sup>** Sihon king of the Amorites,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Og king of Bashan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the kingdoms of Canaan.<br/>
**<sup>12</sup>** He gave their land as a heritage,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a heritage to Israel His people.<br/>
**<sup>13</sup>** Your name, LORD, endures forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your remembrance, LORD, through all generations.<br/>
**<sup>14</sup>** For the LORD will judge His people<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will have compassion on His servants.<br/>
**<sup>15</sup>** The idols of the nations are silver and gold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the work of human hands.<br/>
**<sup>16</sup>** They have mouths but do not speak;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have eyes but do not see;<br/>
**<sup>17</sup>** they have ears but do not hear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor is there breath in their mouths.<br/>
**<sup>18</sup>** Those who make them become like them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all who trust in them.<br/>
**<sup>19</sup>** House of Israel, bless the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;house of Aaron, bless the LORD;<br/>
**<sup>20</sup>** house of Levi, bless the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who fear the LORD, bless the LORD.<br/>
**<sup>21</sup>** Bless the LORD from Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He who dwells in Jerusalem.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 136

**<sup>1</sup>** Give thanks to the LORD, for He is good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>2</sup>** Give thanks to the God of gods,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>3</sup>** Give thanks to the Lord of lords,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>4</sup>** To Him who alone does great wonders,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>5</sup>** To Him who made the heavens with understanding,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>6</sup>** To Him who spread out the earth upon the waters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>7</sup>** To Him who made the great lights,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>8</sup>** The sun to rule by day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>9</sup>** The moon and stars to rule by night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>10</sup>** To Him who struck Egypt through their firstborn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>11</sup>** And brought Israel out from among them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>12</sup>** With a strong hand and an outstretched arm,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>13</sup>** To Him who divided the Sea of Reeds into parts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>14</sup>** And made Israel pass through the midst of it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>15</sup>** And shook off Pharaoh and his army into the Sea of Reeds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>16</sup>** To Him who led His people through the wilderness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>17</sup>** To Him who struck great kings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>18</sup>** And killed mighty kings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>19</sup>** Sihon king of the Amorites,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>20</sup>** And Og king of Bashan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>21</sup>** And gave their land as a heritage,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>22</sup>** A heritage to Israel His servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>23</sup>** Who remembered us in our low estate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>24</sup>** And rescued us from our adversaries,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>25</sup>** Who gives food to all flesh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>
**<sup>26</sup>** Give thanks to the God of heaven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for His loyal love endures forever.<br/>


## Chapter 137

**<sup>1</sup>** By the rivers of Babylon, there we sat down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we also wept when we remembered Zion.<br/>
**<sup>2</sup>** On the willows in its midst<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we hung up our lyres.<br/>
**<sup>3</sup>** For there our captors demanded songs of us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and our tormentors asked for joy, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Sing for us one of the songs of Zion.”<br/>
**<sup>4</sup>** How can we sing the song of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on foreign soil?<br/>
**<sup>5</sup>** If I forget you, O Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may my right hand forget its skill.<br/>
**<sup>6</sup>** May my tongue cling to my palate<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if I do not remember you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if I do not set Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;above my highest joy.<br/>
**<sup>7</sup>** Remember, LORD, against the sons of Edom<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the day of Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when they said, “Tear it down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;tear it down to its foundations!”<br/>
**<sup>8</sup>** Daughter of Babylon, doomed to destruction,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;blessed is he who repays you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for what you have done to us.<br/>
**<sup>9</sup>** Blessed is he who seizes your little ones<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and dashes them against the rock.<br/>


## Chapter 138

**<sup>1</sup>** I will give you thanks with all my heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the gods I will sing your praise.<br/>
**<sup>2</sup>** I will bow toward your holy temple<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and give thanks to your name for your loyal love and your faithfulness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you have exalted your word above every name.<br/>
**<sup>3</sup>** On the day I called, you answered me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you made me bold with strength in my soul.<br/>
**<sup>4</sup>** All the kings of the earth will give you thanks, LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they have heard the words of your mouth.<br/>
**<sup>5</sup>** And they will sing of the ways of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for great is the glory of the LORD.<br/>
**<sup>6</sup>** For though the LORD is exalted,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he sees the lowly,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the lofty he knows from afar.<br/>
**<sup>7</sup>** Though I walk in the midst of distress, you preserve my life;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you stretch out your hand against the anger of my enemies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your right hand saves me.<br/>
**<sup>8</sup>** The LORD will complete what concerns me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your loyal love, LORD, is everlasting—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not abandon the work of your hands.<br/>


## Chapter 139

**<sup>1</sup>** LORD, you have searched me and known me. **<sup>2</sup>** You know my sitting down and my rising up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you discern my thoughts from afar.<br/>
**<sup>3</sup>** You measure out my path and my lying down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you are acquainted with all my ways.<br/>
**<sup>4</sup>** For there is not a word on my tongue,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but you, LORD, know it completely.<br/>
**<sup>5</sup>** You hem me in behind and before,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you lay your hand upon me.<br/>
**<sup>6</sup>** Such knowledge is too extraordinary for me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is too high—I cannot reach it.

**<sup>7</sup>** Where can I go from your Spirit?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Or where can I flee from your presence?<br/>
**<sup>8</sup>** If I ascend to the heavens, you are there;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if I make my bed in the grave, you are there.<br/>
**<sup>9</sup>** If I rise up on the wings of the dawn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or dwell at the farthest end of the sea,<br/>
**<sup>10</sup>** even there your hand will lead me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your right hand will take hold of me.<br/>
**<sup>11</sup>** And if I say, “Surely darkness will cover me,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then the night becomes light around me.<br/>
**<sup>12</sup>** Even darkness is not dark to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the night shines like the day;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;darkness and light are alike to you.

**<sup>13</sup>** For you formed my inward parts;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you knit me together in my mother’s womb.<br/>
**<sup>14</sup>** I will give you thanks, for I am fearfully and wonderfully made;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your works are wonderful—my soul knows this very well.<br/>
**<sup>15</sup>** My frame was not hidden from you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I was made in secret,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;woven in the depths of the earth.<br/>
**<sup>16</sup>** Your eyes saw my unformed substance,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in your book all of them were written—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the days that were fashioned for me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when none of them yet existed.<br/>
**<sup>17</sup>** How precious to me are your thoughts, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how vast is their sum!<br/>
**<sup>18</sup>** If I should count them, they would outnumber the sand;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I awake, I am still with you.

**<sup>19</sup>** O that you would slay the wicked, O God—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and men of blood, depart from me!<br/>
**<sup>20</sup>** They speak of you with evil intent;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your adversaries take your name in vain.<br/>
**<sup>21</sup>** Do I not hate those who hate you, LORD?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And do I not loathe those who rise up against you?<br/>
**<sup>22</sup>** I hate them with complete hatred;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I count them as my enemies.

**<sup>23</sup>** Search me, O God, and know my heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;test me and know my anxious thoughts.<br/>
**<sup>24</sup>** And see if any harmful way is in me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lead me in the everlasting way.<br/>


## Chapter 140

**<sup>1</sup>** Deliver me, O LORD, from an evil man;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;preserve me from a violent man<br/>
**<sup>2</sup>** who thinks up evil in his heart;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all day long they assemble for war.<br/>
**<sup>3</sup>** Their tongue is sharp as a serpent’s;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the venom of a viper lies under their lips. Selah

**<sup>4</sup>** Keep me, LORD, from the hands of the wicked;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;preserve me from violent men<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who plot to make my feet slip.<br/>
**<sup>5</sup>** The arrogant have set a trap for me with ropes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;spreading a net by the path;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have hidden snares for me. Selah

**<sup>6</sup>** I said to the LORD, “You are my God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;listen, O LORD, to the voice of my supplication.”<br/>
**<sup>7</sup>** O LORD, my God and strength of my salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you cover my head in the day of battle.<br/>
**<sup>8</sup>** Do not grant, LORD, the desires of the wicked;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not let their evil plan succeed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or they will be exalted. Selah

**<sup>9</sup>** May the leaders of those who surround me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;be covered by the perverseness of their own words.<br/>
**<sup>10</sup>** Let burning coals fall upon them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them be thrown into the fire—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;into deep pits, that they rise not up again.<br/>
**<sup>11</sup>** A slanderer shall not be established in the land;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the violent and wicked man shall be hunted to his destruction.<br/>
**<sup>12</sup>** I know that the LORD will maintain<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the cause of the afflicted,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the rights of the needy.<br/>
**<sup>13</sup>** Surely the righteous will give thanks to Your name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the upright will dwell in Your presence.<br/>


## Chapter 141

**<sup>1</sup>** LORD, I call to you—hurry to me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;give ear to my voice when I call to you.<br/>
**<sup>2</sup>** Let my prayer be set before you like incense,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the lifting up of my hands like the evening offering.<br/>
**<sup>3</sup>** Set a guard, LORD, over my mouth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;keep watch at the door of my lips.<br/>
**<sup>4</sup>** Do not let my heart incline to an evil thing,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to practice wicked deeds with wicked men;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let me not eat of their delicacies.<br/>
**<sup>5</sup>** Let a righteous man strike me—it is kindness: let him rebuke me—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is oil on my head; let my head not refuse it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Yet my prayer is still against their evil deeds.<br/>
**<sup>6</sup>** When their judges are thrown down beside rocky cliffs,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will hear my words,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they are pleasant.<br/>
**<sup>7</sup>** As when one plows and breaks up the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so our bones are scattered at the mouth of the grave.<br/>
**<sup>8</sup>** But my eyes are toward you, O LORD, my Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in you I seek refuge—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not leave my life exposed.<br/>
**<sup>9</sup>** Keep me from the trap they have set for me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the snares of workers of wickedness.<br/>
**<sup>10</sup>** Let the wicked fall into their own nets together, while I pass by safely. 

## Chapter 142

**<sup>1</sup>** With my voice I cry out to the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with my voice I plead for mercy from the LORD.<br/>
**<sup>2</sup>** I pour out my complaint before him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I lay out my distress before him.<br/>
**<sup>3</sup>** When my spirit grows faint within me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you yourself know my path.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In the way where I walk<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have hidden a trap for me.<br/>
**<sup>4</sup>** Look to my right and see—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is no one who acknowledges me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have no more refuge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no one inquires after my well-being.

**<sup>5</sup>** I cry to you, LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I say, “You are my refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my portion in the land of the living.”<br/>
**<sup>6</sup>** Listen to my cry,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am brought very low;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rescue me from my pursuers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they are too strong for me.<br/>
**<sup>7</sup>** Bring my soul out of the prison,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may give thanks to your name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the righteous will gather around me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you will deal generously with me.<br/>


## Chapter 143

**<sup>1</sup>** Hear my prayer, O LORD; give ear to my cry for mercy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;answer me in your faithfulness and in your righteousness.<br/>
**<sup>2</sup>** Do not enter into judgment with your servant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for no man living is righteous before you.<br/>
**<sup>3</sup>** For the enemy has pursued my soul;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has crushed my life to the ground;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has made me dwell in darkness<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like those long dead.<br/>
**<sup>4</sup>** And my spirit grows faint within me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;within me my heart is desolate.<br/>
**<sup>5</sup>** I remember the days of old;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I meditate on all your works;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I ponder the work of your hands.<br/>
**<sup>6</sup>** I stretch out my hands to you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my soul thirsts for you like a parched land. Selah.

**<sup>7</sup>** Answer me quickly, O LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my spirit fails.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do not hide your face from me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lest I become like those descending to the grave.<br/>
**<sup>8</sup>** Let me hear your steadfast love in the morning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for in you I trust.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Make known to me the way I should walk,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for to you I lift up my soul.<br/>
**<sup>9</sup>** Deliver me from my enemies, O LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I flee to you for refuge.<br/>
**<sup>10</sup>** Teach me to do your will,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you are my God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Let your good Spirit lead me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on level ground.<br/>
**<sup>11</sup>** For your name’s sake, O LORD, let me live;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in your righteousness bring my soul out of distress.<br/>
**<sup>12</sup>** And in your steadfast love cut off my enemies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and destroy all who afflict my soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am your servant.<br/>


## Chapter 144

**<sup>1</sup>** Blessed be the LORD, my rock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who trains my hands for war,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my fingers for battle;<br/>
**<sup>2</sup>** my steadfast love and my fortress,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my stronghold and my deliverer,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my shield, in whom I take refuge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who subdues my foes beneath me.

**<sup>3</sup>** O LORD, what is man that you regard him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or the son of man that you take account of him?<br/>
**<sup>4</sup>** Man is like a breath;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his days are like a passing shadow.

**<sup>5</sup>** O LORD, bend your heavens and come down;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;touch the mountains that they may smoke.<br/>
**<sup>6</sup>** Flash forth lightning and scatter them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shoot your arrows and rout them.<br/>
**<sup>7</sup>** Stretch out your hands from on high;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rescue me and deliver me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from great waters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the hand of foreigners,<br/>
**<sup>8</sup>** whose mouth speaks falsehood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and whose right hand is a right hand of deceit.

**<sup>9</sup>** I will sing a new song to you, O God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on a harp of ten strings I will make melody to you,<br/>
**<sup>10</sup>** who gives salvation to kings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who rescues David his servant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the deadly sword.<br/>
**<sup>11</sup>** Rescue me and deliver me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the hand of foreigners,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose mouth speaks falsehood<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and whose right hand is a right hand of deceit.

**<sup>12</sup>** May our sons be like plants grown up in their youth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;our daughters like corner pillars<br/>
&nbsp;&nbsp;&nbsp;&nbsp;crafted for the structure of a palace;<br/>
**<sup>13</sup>** may our storehouses be full,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yielding all kinds of produce;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may our flocks increase by thousands,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by tens of thousands in our fields;<br/>
**<sup>14</sup>** may our cattle be heavy with young;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may there be no breach, no going out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no cry of distress in our streets.<br/>
**<sup>15</sup>** Blessed are the people to whom such things belong;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;blessed are the people whose God is the LORD.<br/>


## Chapter 145

**<sup>1</sup>** I will exalt you, my God, the King,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will bless your name forever and ever.<br/>
**<sup>2</sup>** Every day I will bless you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will praise your name forever and ever.<br/>
**<sup>3</sup>** Great is the LORD and greatly to be praised,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his greatness is unsearchable.<br/>
**<sup>4</sup>** One generation will praise your works to the next,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will declare your mighty acts.<br/>
**<sup>5</sup>** On the glorious splendor of your majesty<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on your wondrous works I will meditate.<br/>
**<sup>6</sup>** And they will speak of the might of your awesome deeds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will recount your greatness.<br/>
**<sup>7</sup>** They will pour forth the memory of your abundant goodness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will sing aloud of your righteousness.<br/>
**<sup>8</sup>** The LORD is gracious and compassionate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;slow to anger and great in steadfast love.<br/>
**<sup>9</sup>** The LORD is good to all,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his compassion is over all his works.<br/>
**<sup>10</sup>** All your works will give thanks to you, O LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your saints will bless you.<br/>
**<sup>11</sup>** They will speak of the glory of your kingdom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will talk of your might,<br/>
**<sup>12</sup>** to make known to the sons of man his mighty deeds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the glorious splendor of his kingdom.<br/>
**<sup>13</sup>** Your kingdom is an everlasting kingdom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your dominion endures through all generations.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD is faithful in all his words,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and kind in all his works.<br/>
**<sup>14</sup>** The LORD upholds all who fall,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and raises up all who are bowed down.<br/>
**<sup>15</sup>** The eyes of all look to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you give them their food in its season.<br/>
**<sup>16</sup>** You open your hand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and satisfy the desire of every living thing.<br/>
**<sup>17</sup>** The LORD is righteous in all his ways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and kind in all his works.<br/>
**<sup>18</sup>** The LORD is near to all who call on him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to all who call on him in truth.<br/>
**<sup>19</sup>** He fulfills the desire of those who fear him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he hears their cry and saves them.<br/>
**<sup>20</sup>** The LORD guards all who love him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but all the wicked he will destroy.<br/>
**<sup>21</sup>** My mouth will speak the praise of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all flesh will bless his holy name<br/>
&nbsp;&nbsp;&nbsp;&nbsp;forever and ever.<br/>


## Chapter 146

**<sup>1</sup>** Praise the LORD. Praise the LORD, O my soul. **<sup>2</sup>** I will praise the LORD while I live;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will sing praises to my God while I exist.<br/>
**<sup>3</sup>** Do not trust in princes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in a son of man in whom there is no salvation.<br/>
**<sup>4</sup>** His spirit departs, he returns to the ground;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on that very day his plans vanish.<br/>
**<sup>5</sup>** Blessed is he whose help is the God of Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose hope is in the LORD his God,<br/>
**<sup>6</sup>** who made heaven and earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the sea and all that is in them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who keeps faith forever;<br/>
**<sup>7</sup>** who executes justice for the oppressed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who gives bread to the hungry.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD sets prisoners free;<br/>
**<sup>8</sup>** the LORD opens the eyes of the blind;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD raises up those who are bowed down;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD loves the righteous.<br/>
**<sup>9</sup>** The LORD guards the sojourners;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he upholds the fatherless and the widow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but he overthrows the way of the wicked.<br/>
**<sup>10</sup>** The LORD will reign forever—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your God, O Zion, to all generations.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 147

**<sup>1</sup>** Praise the LORD, for it is good to sing praises to our God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for it is pleasant, and praise is fitting.<br/>
**<sup>2</sup>** The LORD builds Jerusalem;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he gathers the outcasts of Israel.<br/>
**<sup>3</sup>** He heals the brokenhearted<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and binds up their wounds.<br/>
**<sup>4</sup>** He counts the number of the stars;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he gives names to all of them.<br/>
**<sup>5</sup>** Great is our Lord and abundant in power;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his understanding is without measure.<br/>
**<sup>6</sup>** The LORD lifts up the afflicted;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he casts the wicked down to the ground.

**<sup>7</sup>** Sing to the LORD with thanksgiving;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make melody to our God with the lyre.<br/>
**<sup>8</sup>** He covers the sky with clouds;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he prepares rain for the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he makes grass grow on the mountains.<br/>
**<sup>9</sup>** He gives food to the beasts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to the young ravens when they cry.<br/>
**<sup>10</sup>** He does not delight in the strength of the horse;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor takes pleasure in how strong a man's legs are.<br/>
**<sup>11</sup>** The LORD takes pleasure in those who fear him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in those who hope in his steadfast love.

**<sup>12</sup>** Praise the LORD, O Jerusalem;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise your God, O Zion.<br/>
**<sup>13</sup>** For he strengthens the bars of your gates;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he blesses your sons within you.<br/>
**<sup>14</sup>** He makes peace in your borders;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he satisfies you with the finest of wheat.<br/>
**<sup>15</sup>** He sends out his command to the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his word runs swiftly.<br/>
**<sup>16</sup>** He gives snow like wool;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he scatters frost like ashes.<br/>
**<sup>17</sup>** He casts forth his ice like crumbs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who can stand before his cold?<br/>
**<sup>18</sup>** He sends out his word and melts them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he makes his wind blow, and the waters flow.<br/>
**<sup>19</sup>** He declares his word to Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his statutes and his judgments to Israel.<br/>
**<sup>20</sup>** He has not dealt thus with any nation;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and as for his judgments, they do not know them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 148

**<sup>1</sup>** Praise the LORD. Praise the LORD from the heavens;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him in the heights.<br/>
**<sup>2</sup>** Praise him, all his angels;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him, all his hosts.<br/>
**<sup>3</sup>** Praise him, sun and moon;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him, all stars of light.<br/>
**<sup>4</sup>** Praise him, you highest heavens,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you waters above the heavens.<br/>
**<sup>5</sup>** Let them praise the name of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he commanded and they were created.<br/>
**<sup>6</sup>** And he established them forever and ever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he gave a decree, and it will not pass away.<br/>
**<sup>7</sup>** Praise the LORD from the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you sea monsters and all in the depths;<br/>
**<sup>8</sup>** fire and hail, snow and mist,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;stormy wind executing his word;<br/>
**<sup>9</sup>** mountains and all hills,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;fruit trees and all cedars;<br/>
**<sup>10</sup>** beasts and all cattle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;creeping things and winged birds;<br/>
**<sup>11</sup>** kings of the earth and all nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;princes and all judges of the earth;<br/>
**<sup>12</sup>** young men and also young women,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;old men and youths;<br/>
**<sup>13</sup>** let them praise the name of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for his name alone is exalted;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his majesty is above earth and heaven.<br/>
**<sup>14</sup>** And he has raised up a horn for his people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a praise for all his saints,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the sons of Israel, a people near to him.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 149

**<sup>1</sup>** Praise the LORD. Sing to the LORD a new song,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his praise in the assembly of the faithful.<br/>
**<sup>2</sup>** Let Israel rejoice in his Maker;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let the sons of Zion be glad in their King.<br/>
**<sup>3</sup>** Let them praise his name with dancing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them make melody to him with tambourine and lyre.<br/>
**<sup>4</sup>** For the LORD takes pleasure in his people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he adorns the afflicted with salvation.<br/>
**<sup>5</sup>** Let the faithful exult in glory;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let them sing aloud on their beds.<br/>
**<sup>6</sup>** Let the high praises of God be in their throats,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a two-edged sword in their hands,<br/>
**<sup>7</sup>** to execute vengeance on the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and punishments on the peoples,<br/>
**<sup>8</sup>** to bind their kings with chains,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their nobles with shackles of iron,<br/>
**<sup>9</sup>** to execute on them the written judgment—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;this is honor for all his faithful ones.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>


## Chapter 150

**<sup>1</sup>** Praise the LORD. Praise God in his sanctuary;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him in his mighty expanse.<br/>
**<sup>2</sup>** Praise him for his mighty deeds;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him according to his abundant greatness.<br/>
**<sup>3</sup>** Praise him with the blast of the horn;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him with harp and lyre.<br/>
**<sup>4</sup>** Praise him with tambourine and dancing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him with strings and flute.<br/>
**<sup>5</sup>** Praise him with sounding cymbals;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise him with cymbals of loud acclaim.<br/>
**<sup>6</sup>** Let everything that has breath praise the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Praise the LORD.<br/>
