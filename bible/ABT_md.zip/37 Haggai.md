# Haggai

## Chapter 1

**<sup>1</sup>** In the second year of King Darius, in the sixth month, on the first day of the month, the word of the LORD came by the hand of Haggai the prophet to Zerubbabel son of Shealtiel, governor of Judah, and to Joshua son of Jehozadak, the high priest: **<sup>2</sup>** “Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;These people say, ‘The time has not yet come<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to rebuild the house of the LORD.’”

**<sup>3</sup>** Then the word of the LORD came by the hand of Haggai the prophet: **<sup>4</sup>** “Is it a time for you yourselves to dwell in your paneled houses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while this house lies in ruins?<br/>
**<sup>5</sup>** Now therefore, thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Consider your ways.<br/>
**<sup>6</sup>** You have sown much, and harvested little.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You eat, but you never have enough.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You drink, but you never have your fill.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You clothe yourselves, but no one is warm.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he who earns wages<br/>
&nbsp;&nbsp;&nbsp;&nbsp;does so to put them into a bag with holes.

**<sup>7</sup>** Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Consider your ways.<br/>
**<sup>8</sup>** Go up to the hills and bring wood and build the house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I may take pleasure in it<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and that I may be glorified, says the LORD.<br/>
**<sup>9</sup>** You looked for much, and behold, it came to little.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And when you brought it home, I blew it away.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why? declares the LORD of hosts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Because of My house that lies in ruins,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while each of you busies himself with his own house.<br/>
**<sup>10</sup>** Therefore the heavens above you have withheld the dew,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the earth has withheld its produce.<br/>
**<sup>11</sup>** And I have called for a drought on the land and the hills,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the grain, the new wine, the oil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on what the ground brings forth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on man and beast,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on all their labors.”

**<sup>12</sup>** Then Zerubbabel son of Shealtiel, and Joshua son of Jehozadak, the high priest, with all the remnant of the people, obeyed the voice of the LORD their God and the words of Haggai the prophet, as the LORD their God had sent him. And the people feared the LORD. **<sup>13</sup>** Then Haggai, the messenger of the LORD, spoke to the people with the LORD’s message:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I am with you, declares the LORD.”<br/>
**<sup>14</sup>** And the LORD stirred up the spirit of Zerubbabel son of Shealtiel, governor of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the spirit of Joshua son of Jehozadak, the high priest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the spirit of all the remnant of the people.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And they came and worked on the house of the LORD of hosts, their God,<br/>
**<sup>15</sup>** on the twenty-fourth day of the month,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the sixth month,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the second year of King Darius.<br/>


## Chapter 2

**<sup>1</sup>** In the seventh month, on the twenty-first day of the month, the word of the LORD came by the hand of Haggai the prophet: **<sup>2</sup>** “Speak now to Zerubbabel son of Shealtiel, governor of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to Joshua son of Jehozadak, the high priest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to all the remnant of the people, and say,<br/>
**<sup>3</sup>** ‘Who is left among you who saw this house in its former glory?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And how do you see it now?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is it not as nothing in your eyes?<br/>
**<sup>4</sup>** Yet now be strong, O Zerubbabel, declares the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Be strong, O Joshua son of Jehozadak, the high priest.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Be strong, all you people of the land, declares the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Work, for I am with you, declares the LORD of hosts,<br/>
**<sup>5</sup>** according to the covenant that I made with you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when you came out of Egypt.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My Spirit remains in your midst.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do not fear.’

**<sup>6</sup>** For thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Yet once more, in a little while,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will shake the heavens and the earth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the sea and the dry land.<br/>
**<sup>7</sup>** And I will shake all nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that the treasures of all nations shall come in,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will fill this house with glory,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>8</sup>** The silver is Mine, and the gold is Mine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD of hosts.<br/>
**<sup>9</sup>** The latter glory of this house shall be greater than the former,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And in this place I will give peace,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD of hosts.”

**<sup>10</sup>** On the twenty-fourth day of the ninth month,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the second year of Darius,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the word of the LORD came by Haggai the prophet:<br/>
**<sup>11</sup>** “Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Ask the priests about the law:<br/>
**<sup>12</sup>** ‘If someone carries holy meat in the fold of his garment<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and touches with his fold bread or stew or wine or oil<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or any kind of food,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;does it become holy?’”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The priests answered and said, “No.”

**<sup>13</sup>** Then Haggai said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“If someone who is unclean by contact with a dead body<br/>
&nbsp;&nbsp;&nbsp;&nbsp;touches any of these,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;does it become unclean?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The priests answered and said, “It does become unclean.”<br/>
**<sup>14</sup>** Then Haggai answered and said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“So it is with this people, and with this nation before Me, declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and so with every work of their hands.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And what they offer there is unclean.<br/>
**<sup>15</sup>** Now then, consider from this day onward.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Before stone was placed upon stone in the temple of the LORD,<br/>
**<sup>16</sup>** how did you fare?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;When one came to a heap of twenty measures, there were but ten.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;When one came to the wine vat to draw fifty measures, there were but twenty.<br/>
**<sup>17</sup>** I struck you and all the products of your toil<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with blight and mildew and hail,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet you did not turn to Me, declares the LORD.<br/>
**<sup>18</sup>** Consider from this day onward,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the twenty-fourth day of the ninth month.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Since the day that the foundation of the LORD’s temple was laid,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;consider:<br/>
**<sup>19</sup>** Is the seed yet in the barn?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Indeed, the vine, the fig tree, the pomegranate, and the olive tree have yielded nothing.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But from this day on I will bless you.”

**<sup>20</sup>** The word of the LORD came a second time to Haggai<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the twenty-fourth day of the month:<br/>
**<sup>21</sup>** “Speak to Zerubbabel, governor of Judah, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am about to shake the heavens and the earth,<br/>
**<sup>22</sup>** and to overthrow the throne of kingdoms.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am about to destroy the strength of the kingdoms of the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and overthrow the chariots and their riders.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And the horses and their riders shall go down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;every one by the sword of his brother.<br/>
**<sup>23</sup>** On that day, declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will take you, O Zerubbabel My servant, the son of Shealtiel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and make you like a signet ring,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have chosen you, declares the LORD of hosts.”<br/>
