# The Second General Epistle of John

## Chapter 1

**<sup>1</sup>** The elder to the elect lady and her children, whom I love in truth—and not I alone, but also all who know the truth— **<sup>2</sup>** because of the truth that abides in us and will be with us forever: **<sup>3</sup>** Grace, mercy, peace will be with us from God the Father and from Jesus Christ the Son of the Father, in truth and love.

**<sup>4</sup>** I rejoiced greatly to find some of your children walking in truth, just as we received the commandment from the Father. **<sup>5</sup>** And now I ask you, lady—not as though I were writing you a new commandment, but one we have had from the beginning—that we love one another. **<sup>6</sup>** And this is love: that we walk according to His commandments. This is the commandment, just as you heard from the beginning, so that you should walk in it.

**<sup>7</sup>** For many deceivers (those who do not confess Jesus Christ as coming in the flesh) have gone out into the world. Such a person is a deceiver, and the antichrist. **<sup>8</sup>** Watch yourselves, so that you do not lose what we have worked for, but that you may receive a full reward. **<sup>9</sup>** Everyone who goes too far and does not abide in the teaching of Christ does not have God. The one who abides in the teaching—this one has both the Father and the Son. **<sup>10</sup>** If anyone comes to you and does not bring this teaching, do not receive him into your house and do not greet him. **<sup>11</sup>** For the one who greets him shares in his evil works.

**<sup>12</sup>** Though I have much to write to you, I do not want to do so with parchment and ink, but I hope to come to you and speak face to face, so that our joy may be complete. **<sup>13</sup>** The children of your elect sister greet you. 