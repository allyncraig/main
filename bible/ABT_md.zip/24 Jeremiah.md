# The Book of the Prophet Jeremiah

## Chapter 1

**<sup>1</sup>** The words of Jeremiah son of Hilkiah, of the priests who were in Anathoth in the land of Benjamin, **<sup>2</sup>** to whom the word of the LORD came in the days of Josiah son of Amon, king of Judah, in the thirteenth year of his reign. **<sup>3</sup>** It also came in the days of Jehoiakim son of Josiah, king of Judah, until the end of the eleventh year of Zedekiah son of Josiah, king of Judah, until the exile of Jerusalem in the fifth month.

**<sup>4</sup>** Now the word of the LORD came to me, saying, **<sup>5</sup>** “Before I formed you in the womb I knew you, and before you came forth from the womb I set you apart; I appointed you as a prophet to the nations.” **<sup>6</sup>** Then I said, “Alas, Lord GOD! You can see that I do not know how to speak, for I am but a youth.” **<sup>7</sup>** But the LORD said to me, “Do not say, ‘I am but a youth,’ for to all to whom I send you, you shall go, and whatever I command you, you shall speak. **<sup>8</sup>** Do not be afraid of them, for I am with you to deliver you,” declares the LORD.

**<sup>9</sup>** Then the LORD stretched out his hand and touched my mouth. And the LORD said to me, “I have put my words in your mouth. **<sup>10</sup>** See, I have set you this day over nations and over kingdoms, to uproot and to tear down, to destroy and to overthrow, to build and to plant.”

**<sup>11</sup>** And the word of the LORD came to me, saying, “What do you see, Jeremiah?” And I said, “I see a branch of an almond tree.” **<sup>12</sup>** Then the LORD said to me, “You have seen well, for I am watching over my word to perform it.”

**<sup>13</sup>** And the word of the LORD came to me a second time, saying, “What do you see?” And I said, “I see a boiling pot, and its face is from the north.” **<sup>14</sup>** Then the LORD said to me, “From the north evil shall be unleashed upon all the inhabitants of the land. **<sup>15</sup>** For you will see how I am summoning all the clans of the kingdoms of the north,” declares the LORD. “They shall come, and each shall set his throne at the entrance of the gates of Jerusalem, and against all its walls round about, and against all the cities of Judah. **<sup>16</sup>** And I will utter my judgments against them concerning all their evil, because they have forsaken me, and have made offerings to other gods, and worshiped the work of their own hands.

**<sup>17</sup>** But you, gird up your loins, and arise, and speak to them all that I command you. Do not be dismayed before them, lest I dismay you before them. **<sup>18</sup>** And I vow to you, I make you this day a fortified city, an iron pillar, and bronze walls, against the whole land—against the kings of Judah, its princes, its priests, and the people of the land. **<sup>19</sup>** They shall fight against you, but they shall not prevail against you, for I am with you,” declares the LORD, “to deliver you.” 

## Chapter 2

**<sup>1</sup>** And the word of the LORD came to me, saying, **<sup>2</sup>** “Go and proclaim in the hearing of Jerusalem, saying, ‘Thus says the LORD: I remember the devotion of your youth, your love as a bride, how you followed after me in the wilderness, in a land not sown. **<sup>3</sup>** Israel was holy to the LORD, the firstfruits of his harvest; all who ate of it became guilty, disaster came upon them,’ declares the LORD.”

**<sup>4</sup>** Hear the word of the LORD, O house of Jacob, and all the clans of the house of Israel. **<sup>5</sup>** Thus says the LORD: “What wrong did your fathers find in me, that they went far from me, and walked after what is worthless, and became worthless? **<sup>6</sup>** They did not say, ‘Where is the LORD who brought us up out of the land of Egypt, who led us through the wilderness, through a land of deserts and pits, through a land of drought and deep darkness, through a land that no man passed through, and where no man dwelt?’ **<sup>7</sup>** I brought you into a fertile land, to eat its fruit and its good things. But when you entered, you defiled my land, and you made my heritage an abomination. **<sup>8</sup>** The priests did not say, ‘Where is the LORD?’ Those who handle the law did not know me; the shepherds transgressed against me; the prophets prophesied by Baal and went after things that do not profit.

**<sup>9</sup>** Therefore I will contend with you again,” declares the LORD, “and with your children’s children I will contend. **<sup>10</sup>** For cross over to the coasts of Kittim and see, and send to Kedar and observe closely, and see if there has ever been such a thing. **<sup>11</sup>** Has a nation ever changed its gods, though they are no gods? But my people have changed their glory for that which does not profit. **<sup>12</sup>** Be appalled, O heavens, at this, be shocked, be utterly desolate,” declares the LORD. **<sup>13</sup>** “For my people have committed two evils: they have forsaken me, the fountain of living waters, to hew for themselves cisterns, broken cisterns that cannot hold water.

**<sup>14</sup>** Is Israel a slave? Was he born a servant? Why then has he become plunder? **<sup>15</sup>** Young lions have roared against him, they have raised their voice. They have made his land a waste; his cities are burned and inhabited2. **<sup>16</sup>** Even the men of Noph and Tahpanhes shave the crown of your head. **<sup>17</sup>** Have you not brought this upon yourself by forsaking the LORD your God, when he was leading you in the way? **<sup>18</sup>** And now what have you to do with the road to Egypt, to drink the waters of the Shihor? Or what have you to do with the road to Assyria, to drink the waters of the River? **<sup>19</sup>** Your own evil will discipline you, and your apostasies will reprove you. Know then and see that it is evil and bitter to forsake the LORD your God, and the fear of me is not in you,” declares the Lord GOD of hosts.

**<sup>20</sup>** “For long ago you broke your yoke and tore off your bonds, and you said, ‘I will not serve!’ Indeed, on every high hill and under every green tree you sprawled as a harlot. **<sup>21</sup>** Yet I planted you a choice vine, wholly of pure seed. How then have you turned degenerate and become a wild vine? **<sup>22</sup>** Though you wash yourself with lye and use much soap, your guilt is stained before me,” declares the Lord GOD. **<sup>23</sup>** “How can you say, ‘I am not defiled; I have not gone after the Baals’? Look at your way in the valley; know what you have done—like a swift young she-camel running here and there, **<sup>24</sup>** a wild donkey accustomed to the wilderness, in the heat of her desire sniffing the wind. Who can restrain her lust? None who seek her need weary themselves; in her month they will find her. **<sup>25</sup>** Keep your foot from being unshod and your throat from thirst. But you said, ‘It is hopeless, for I have loved foreigners, and after them I will go.’

**<sup>26</sup>** As the thief is ashamed when he is found, so the house of Israel shall be ashamed—they, their kings, their princes, their priests, and their prophets— **<sup>27</sup>** who say to a tree, ‘You are my father,’ and to a stone, ‘You gave me birth.’ For they have turned their back to me, and not their face. But in the time of their trouble they say, ‘Arise and save us!’ **<sup>28</sup>** But where are your gods that you made for yourself? Let them arise, if they can save you in the time of your trouble! For as numerous as your cities are your gods, O Judah.

**<sup>29</sup>** “Why do you contend with me? You all have transgressed against me,” declares the LORD. **<sup>30</sup>** “In vain I have struck your children; they accepted no discipline. Your own sword has devoured your prophets like a ravening lion. **<sup>31</sup>** O generation, consider the word of the LORD. Have I been a wilderness to Israel, or a land of deep darkness? Why do my people say, ‘We are free to roam; we will not come to you anymore’? **<sup>32</sup>** Can a virgin forget her ornaments, or a bride her sash? Yet my people have forgotten me days without number.

**<sup>33</sup>** How well you direct your course to seek love! Therefore you have even taught your ways to the wicked women. **<sup>34</sup>** Also on your skirts is found the lifeblood of the innocent poor; you did not find them breaking in. Yet in spite of all these things, **<sup>35</sup>** you say, ‘I am innocent; surely his anger has turned from me.’ Behold, I will enter into judgment with you, because you say, ‘I have not sinned.’ **<sup>36</sup>** Why do you go about so much, changing your way? You will be put to shame by Egypt as you were put to shame by Assyria. **<sup>37</sup>** From this place also you will go out with your hands on your head; for the LORD has rejected those in whom you trust, and you will not prosper through them. 

## Chapter 3

**<sup>1</sup>** It is said, “If a man sends away his wife, and she goes from him and becomes another man’s, will he return to her again? Would not that land be utterly defiled? But you have played the harlot with many lovers—and yet you return to me,” declares the LORD. **<sup>2</sup>** “Lift up your eyes to the bare heights, and see! Where have you not been ravished? By the roads you sat for them like an Arab in the wilderness. You have polluted the land with your harlotries and with your wickedness. **<sup>3</sup>** Therefore the showers have been withheld, and the spring rain has not come; yet you had the forehead of a harlot; you refused to be ashamed. **<sup>4</sup>** Have you not just now called to me, ‘My Father, you are the friend of my youth— **<sup>5</sup>** will he be angry forever, will he keep it to the end?’ But even though you have spoken like this, you continue doing all the evil you can.”

**<sup>6</sup>** And the LORD said to me in the days of King Josiah, “Have you seen what faithless Israel has done? She went up on every high hill and under every green tree, and there played the harlot. **<sup>7</sup>** I said, ‘After she has done all these things, she will return to me,’ but she did not return, and her treacherous sister Judah saw it. **<sup>8</sup>** She saw that for all the adulteries of faithless Israel I had sent her away and given her a bill of divorce, yet her treacherous sister Judah did not fear, but she also went and played the harlot. **<sup>9</sup>** And it came to pass, through the lightness of her harlotry, that she defiled the land and committed adultery with stone and with tree. **<sup>10</sup>** Yet in spite of all this her treacherous sister Judah did not return to me with her whole heart, but only in pretense,” declares the LORD.

**<sup>11</sup>** And the LORD said to me, “Faithless Israel has shown herself more righteous than treacherous Judah. **<sup>12</sup>** Go and proclaim these words toward the north, and say: ‘Return, faithless Israel,’ declares the LORD. ‘I will not look upon you in anger, for I am merciful,’ declares the LORD. ‘I will not be angry forever. **<sup>13</sup>** Only acknowledge your guilt, that you have rebelled against the LORD your God, and have scattered your favors among strangers under every green tree, and have not obeyed my voice,’ declares the LORD. **<sup>14</sup>** Return, O faithless children,” declares the LORD, “for I am your master, and I will take you, one from a city and two from a clan, and I will bring you to Zion. **<sup>15</sup>** Then I will give you shepherds after my own heart, who will feed you with knowledge and understanding.

**<sup>16</sup>** And it shall come to pass, when you have multiplied and become fruitful in the land, in those days,” declares the LORD, “they will no longer say, ‘The ark of the covenant of the LORD.’ It shall not come to mind, nor shall they remember it, nor shall they miss it, nor shall it be made again. **<sup>17</sup>** At that time they shall call Jerusalem the throne of the LORD, and all nations shall gather to it, to the name of the LORD in Jerusalem, and they shall no longer walk after the stubbornness of their evil heart. **<sup>18</sup>** In those days the house of Judah shall walk with the house of Israel, and together they shall come from the land of the north to the land that I gave your fathers as a heritage.

**<sup>19</sup>** I said, ‘How I would set you among my sons and give you a pleasant land, the most beautiful heritage of the nations!’ And I said, ‘You will call me, My Father, and not turn away from following me.’ **<sup>20</sup>** Surely, as a wife treacherously leaves her husband, so you have dealt treacherously with me, O house of Israel,” declares the LORD.

**<sup>21</sup>** A voice is heard on the bare heights, the weeping and pleading of the sons of Israel, because they have perverted their way, they have forgotten the LORD their God. **<sup>22</sup>** “Return, O faithless sons; I will heal your faithlessness.” “Behold, we come to you, for you are the LORD our God. **<sup>23</sup>** Truly the hills are a delusion, the tumult on the mountains. Truly in the LORD our God is the salvation of Israel. **<sup>24</sup>** But the shameful thing has devoured the labor of our fathers from our youth—their flocks and their herds, their sons and their daughters. **<sup>25</sup>** Let us lie down in our shame, and let our dishonor cover us. For we have sinned against the LORD our God, we and our fathers, from our youth even to this day, and we have not obeyed the voice of the LORD our God.” 

## Chapter 4

**<sup>1</sup>** “If you return, O Israel,” declares the LORD, “if you return to me, if you remove your abominations from before me, and do not waver, **<sup>2</sup>** and if you swear, ‘As the LORD lives,’ in truth, in justice, and in righteousness, then nations shall bless themselves in him, and in him they shall glory.”

**<sup>3</sup>** For thus says the LORD to the men of Judah and to Jerusalem: “Break up your fallow ground, and do not sow among thorns. **<sup>4</sup>** Circumcise yourselves to the LORD, remove the foreskins of your hearts, O men of Judah and inhabitants of Jerusalem, lest my wrath go forth like fire, and burn with none to quench it, because of the vileness of your deeds.”

**<sup>5</sup>** Declare in Judah, and proclaim in Jerusalem, and say: “Blow the trumpet in the land; cry aloud and say, ‘Assemble, and let us go into the fortified cities!’ **<sup>6</sup>** Raise a standard toward Zion, flee for safety, do not delay, for I am bringing disaster from the north, great destruction. **<sup>7</sup>** A lion has come up from his thicket, a destroyer of nations has set out; he has gone forth from his place to make your land a waste; your cities will be ruins without inhabitant. **<sup>8</sup>** For this put on sackcloth, lament and wail, for the fierce anger of the LORD has not turned back from us.”

**<sup>9</sup>** And it shall come to pass in that day, declares the LORD, that the heart of the king shall perish, and the heart of the princes, and the priests shall be appalled, and the prophets shall be astounded. **<sup>10</sup>** Then I said, “Ah, Lord GOD! Surely you have utterly deceived this people and Jerusalem, saying, ‘You shall have peace,’ whereas the sword reaches to the very soul.”

**<sup>11</sup>** At that time it shall be said to this people and to Jerusalem, “A scorching wind from the bare heights in the wilderness toward the daughter of my people, not to winnow and not to cleanse, **<sup>12</sup>** a wind too full for these things, shall come at my command. Now I myself will speak judgment against them.”

**<sup>13</sup>** Behold, he comes up like clouds, his chariots like the whirlwind, his horses swifter than eagles. Woe to us, for we are ruined! **<sup>14</sup>** O Jerusalem, wash your heart from evil, that you may be saved. How long shall your wicked thoughts lodge within you? **<sup>15</sup>** For a voice declares from Dan, and proclaims trouble from the hills of Ephraim. **<sup>16</sup>** Make it known to the nations, behold, proclaim against Jerusalem, “Besiegers are coming from a distant land, and they raise their voice against the cities of Judah. **<sup>17</sup>** Like keepers of a field they are against her all around, because she has rebelled against me,” declares the LORD.

**<sup>18</sup>** Your ways and your deeds have brought this upon you; this is your evil; how bitter, how it has reached to your heart.

**<sup>19</sup>** My anguish, my anguish! I writhe in pain. O walls of my heart! My heart is pounding within me; I cannot keep silent, for I hear the sound of the trumpet, the alarm of war. **<sup>20</sup>** Crash follows upon crash; for the whole land is laid waste. Suddenly my tents are laid waste, my curtains in a moment. **<sup>21</sup>** How long must I see the standard and hear the sound of the trumpet? **<sup>22</sup>** “For my people are foolish; they do not know me; they are stupid children; they have no understanding. They are skilled in doing evil, but how to do good they do not know.”

**<sup>23</sup>** I looked on the earth, and behold, it was formless and void; and to the heavens, and they had no light. **<sup>24</sup>** I looked on the mountains, and behold, they were quaking, and all the hills moved to and fro. **<sup>25</sup>** I looked, and behold, there was no man, and all the birds of the heavens had fled. **<sup>26</sup>** I looked, and behold, the fruitful land was a wilderness, and all its cities were torn down before the LORD, before his fierce anger.

**<sup>27</sup>** For thus says the LORD, “The whole land shall be a desolation; yet I will not make a full end. **<sup>28</sup>** For this the earth shall mourn, and the heavens above be dark, because I have spoken, I have purposed; I will not relent nor will I turn back from it.”

**<sup>29</sup>** At the sound of horsemen and archers every city flees; they go into the thickets, they climb among the rocks; every city is forsaken, and no man dwells in them. **<sup>30</sup>** And you, O desolate one, what will you do? Though you clothe yourself with scarlet, though you adorn yourself with ornaments of gold, though you enlarge your eyes with paint, in vain you beautify yourself. Your lovers despise you; they seek your life. **<sup>31</sup>** For I heard a cry like that of a woman in labor, anguish as of one giving birth to her first child—the cry of the daughter of Zion gasping for breath, stretching out her hands: “Woe is me! For I am fainting before murderers.” 

## Chapter 5

**<sup>1</sup>** Roam about through the streets of Jerusalem, look and take note, search in her open places, if you can find a man, if there is one who does justice, who seeks truth, then I will pardon her. **<sup>2</sup>** Though they say, “As the LORD lives,” surely they swear falsely. **<sup>3</sup>** O LORD, do not your eyes look for truth? You struck them, but they felt no pain; you consumed them, but they refused to accept discipline. They made their faces harder than rock; they refused to turn back.

**<sup>4</sup>** Then I said, “Surely these are the poor; they are foolish, for they do not know the way of the LORD, the judgment of their God. **<sup>5</sup>** I will go to the great and speak to them, for they know the way of the LORD, the judgment of their God.” But they all alike had broken the yoke; they had torn off the bonds. **<sup>6</sup>** Therefore a lion from the forest strikes them down, a wolf of the deserts ravages them, a leopard watches over their cities. Everyone who goes out from them shall be torn in pieces, because their transgressions are many, their apostasies are great.

**<sup>7</sup>** “Why should I pardon you? Your sons have forsaken me and sworn by those who are not gods. When I had fed them to the full, they committed adultery and trooped to the house of harlots. **<sup>8</sup>** They were well-fed lusty stallions, each neighing after his neighbor’s wife. **<sup>9</sup>** Shall I not punish them for these things?” declares the LORD. “Shall I not avenge myself on such a nation as this?”

**<sup>10</sup>** “Go up through her rows of vines and destroy, but do not make a full end; strip away her branches, for they are not the LORD’s. **<sup>11</sup>** For the house of Israel and the house of Judah have been utterly treacherous toward me,” declares the LORD. **<sup>12</sup>** They have lied about the LORD and said, “It is not he; no disaster will come upon us, nor shall we see sword or famine. **<sup>13</sup>** The prophets are but wind, and the word is not in them. Thus it shall be done to them!”

**<sup>14</sup>** Therefore thus says the LORD, the God of hosts: “Because you have spoken this word, I am making my words in your mouth a fire, and this people wood, and it shall consume them. **<sup>15</sup>** See how I am bringing against you a nation from afar, O house of Israel,” declares the LORD. “It is an enduring nation, it is an ancient nation, a nation whose language you do not know, nor can you understand what they say. **<sup>16</sup>** Their quiver is like an open tomb; they are all mighty men. **<sup>17</sup>** They shall eat up your harvest and your food; they shall eat up your sons and your daughters; they shall eat up your flocks and your herds; they shall eat up your vines and your fig trees; with the sword they shall demolish your fortified cities in which you trust.

**<sup>18</sup>** Yet even in those days,” declares the LORD, “I will not make a full end of you. **<sup>19</sup>** And when they say, ‘Why has the LORD our God done all these things to us?’ then you shall say to them, ‘As you have forsaken me and served foreign gods in your land, so you shall serve strangers in a land that is not yours.’”

**<sup>20</sup>** Declare this in the house of Jacob and proclaim it in Judah, saying, **<sup>21</sup>** “Hear this, O foolish and senseless people, who have eyes but see not, who have ears but hear not. **<sup>22</sup>** Do you not fear me?” declares the LORD. “Do you not tremble before me? I placed the sand as the boundary for the sea, an everlasting decree that it cannot pass. Though its waves toss, they cannot prevail; though they roar, they cannot cross over it. **<sup>23</sup>** But this people has a stubborn and rebellious heart; they have turned aside and gone away. **<sup>24</sup>** They do not say in their heart, ‘Let us fear the LORD our God, who gives the rain, both the early and the latter, in its season, who keeps for us the appointed weeks of harvest.’ **<sup>25</sup>** Your iniquities have turned these away, and your sins have withheld good from you.

**<sup>26</sup>** For wicked men are found among my people; they lurk like fowlers lying in wait; they set a trap, they catch men. **<sup>27</sup>** Like a cage full of birds, so their houses are full of deceit; therefore they have become great and rich. **<sup>28</sup>** They have grown fat and sleek. They also excel in deeds of wickedness; they do not plead the cause, the cause of the orphan, that they may prosper; and they do not defend the right of the needy. **<sup>29</sup>** Shall I not punish them for these things?” declares the LORD. “Shall I not avenge myself on such a nation as this?”

**<sup>30</sup>** An appalling and horrible thing has happened in the land: **<sup>31</sup>** the prophets prophesy falsely, and the priests rule at their own direction. My people love to have it so, but what will you do at the end of it? 

## Chapter 6

**<sup>1</sup>** Flee for safety, O sons of Benjamin, from the midst of Jerusalem! Blow the trumpet in Tekoa, and raise a signal over Beth-haccherem, for disaster looms from the north, great destruction. **<sup>2</sup>** The comely and delicate one, the daughter of Zion, I will cut off. **<sup>3</sup>** Shepherds with their flocks shall come against her; they shall pitch their tents around her, each shall pasture in his place.

**<sup>4</sup>** “Prepare war against her; arise, and let us attack at noon! Woe to us, for the day declines, for the shadows of evening lengthen! **<sup>5</sup>** Arise, and let us attack by night, and destroy her palaces!” **<sup>6</sup>** For thus says the LORD of hosts: “Cut down her trees, and cast up a siege mound against Jerusalem. This is the city to be punished; there is nothing but oppression within her. **<sup>7</sup>** As a well keeps its waters fresh, so she keeps her wickedness fresh. Violence and destruction are heard in her; sickness and wounds are ever before me. **<sup>8</sup>** Be warned, O Jerusalem, lest I turn from you in disgust, lest I make you a desolation, an uninhabited land.”

**<sup>9</sup>** Thus says the LORD of hosts: “They shall thoroughly glean the remnant of Israel as a vine; turn back your hand again, like a grape gatherer, over the branches.” **<sup>10</sup>** To whom shall I speak and give warning, that they may hear? See how their ears are uncircumcised, and they cannot listen? Observe how the word of the LORD is to them an object of scorn; they take no pleasure in it. **<sup>11</sup>** But I am full of the wrath of the LORD; I am weary of holding it in. “Pour it out upon the children in the street, and upon the gatherings of young men also; for both husband and wife shall be taken, the old and the very aged. **<sup>12</sup>** Their houses shall be turned over to others, their fields and wives together, for I will stretch out my hand against the inhabitants of the land,” declares the LORD. **<sup>13</sup>** “For from the least of them to the greatest, everyone is greedy for unjust gain; and from prophet to priest, everyone deals falsely. **<sup>14</sup>** They have healed the wound of my people lightly, saying, ‘Peace, peace,’ when there is no peace. **<sup>15</sup>** Were they ashamed when they committed abominations? No, they were not at all ashamed; they did not know how to blush. Therefore they shall fall among those who fall; at the time that I punish them, they shall stumble,” says the LORD.

**<sup>16</sup>** Thus says the LORD: “Stand by the roads and look, and ask for the ancient paths, where the good way is, and walk in it, and find rest for your souls. But they said, ‘We will not walk in it.’ **<sup>17</sup>** I set watchmen over you, saying, ‘Pay attention to the sound of the trumpet!’ But they said, ‘We will not pay attention.’ **<sup>18</sup>** Therefore hear, O nations, and know, O congregation, what will happen to them. **<sup>19</sup>** Hear, O earth; I am bringing disaster upon this people, the fruit of their schemes, because they have not paid attention to my words, and as for my law, they have rejected it. **<sup>20</sup>** What use to me is frankincense that comes from Sheba, or sweet cane from a distant land? Your burnt offerings are not acceptable, nor are your sacrifices pleasing to me.”

**<sup>21</sup>** Therefore thus says the LORD: “I will lay before this people stumbling blocks, against which fathers and sons together shall stumble; neighbor and friend shall perish.” **<sup>22</sup>** Thus says the LORD: “A people is coming from the land of the north, a great nation is stirring from the farthest parts of the earth. **<sup>23</sup>** They lay hold on bow and spear; they are cruel and have no mercy; their voice roars like the sea, and they ride on horses, arrayed as a man for battle against you, O daughter of Zion!” **<sup>24</sup>** We have heard the report of it; our hands grow feeble; anguish has seized us, pain as of a woman in labor. **<sup>25</sup>** Do not go out into the field, nor walk on the road, for the enemy has a sword; terror is on every side.

**<sup>26</sup>** O daughter of my people, put on sackcloth, and roll in ashes; make mourning as for an only son, most bitter lamentation, for suddenly the destroyer will come upon us. **<sup>27</sup>** “I have made you a tester of metals among my people, that you may know and test their way. **<sup>28</sup>** They are all stubbornly rebellious, going about as slanderers; they are bronze and iron; all of them act corruptly. **<sup>29</sup>** The bellows blow fiercely; the lead is consumed by the fire; in vain the refining goes on, for the wicked are not removed. **<sup>30</sup>** They are called rejected silver, for the LORD has rejected them.” 

## Chapter 7

**<sup>1</sup>** The word that came to Jeremiah from the LORD, saying, **<sup>2</sup>** Stand in the gate of the house of the LORD, and proclaim there this word, and say, Hear the word of the LORD, all Judah, who enter by these gates to worship the LORD. **<sup>3</sup>** Thus says the LORD of hosts, the God of Israel: Amend your ways and your deeds, and I will let you dwell in this place. **<sup>4</sup>** Do not trust in deceptive words, saying, The temple of the LORD, the temple of the LORD, the temple of the LORD are these. **<sup>5</sup>** For if you truly amend your ways and your deeds, if you truly practice justice between a man and his neighbor, **<sup>6</sup>** if you do not oppress the sojourner, the fatherless, or the widow, and do not shed innocent blood in this place, nor walk after other gods to your own ruin, **<sup>7</sup>** then I will let you dwell in this place, in the land that I gave to your fathers forever and ever.

**<sup>8</sup>** Observe and see how you trust in deceptive words to no avail. **<sup>9</sup>** Will you steal, murder, commit adultery, swear falsely, burn incense to Baal, and walk after other gods that you have not known, **<sup>10</sup>** and then come and stand before Me in this house, which is called by My name, and say, We are delivered—so that you may continue to do all these abominations? **<sup>11</sup>** Has this house, which is called by My name, become a den of robbers in your sight? Behold, I, even I, have seen it, declares the LORD. **<sup>12</sup>** But go now to My place that was in Shiloh, where I made My name dwell at the first, and see what I did to it because of the wickedness of My people Israel. **<sup>13</sup>** And now, because you have done all these deeds, declares the LORD, and I spoke to you, rising up early and speaking, but you did not listen, and I called you but you did not answer, **<sup>14</sup>** therefore I will do to the house that is called by My name, in which you trust, and to the place that I gave to you and to your fathers, as I did to Shiloh. **<sup>15</sup>** And I will cast you out of My sight, as I have cast out all your brothers, the whole seed of Ephraim.

**<sup>16</sup>** As for you, do not pray for this people, nor lift up cry or prayer for them, and do not intercede with Me, for I will not hear you. **<sup>17</sup>** Do you not see what they are doing in the cities of Judah and in the streets of Jerusalem? **<sup>18</sup>** The children gather wood, and the fathers kindle the fire, and the women knead dough, to make cakes for the queen of heaven; and they pour out drink offerings to other gods, that they may provoke Me to anger. **<sup>19</sup>** Do they provoke Me to anger? declares the LORD. Is it not themselves, to their own shame? **<sup>20</sup>** Therefore thus says the Lord GOD: Behold, My anger and My wrath will be poured out on this place, on man, on beast, on the trees of the field, and on the fruit of the ground; and it will burn and not be quenched.

**<sup>21</sup>** Thus says the LORD of hosts, the God of Israel: Add your burnt offerings to your sacrifices and eat the flesh. **<sup>22</sup>** For I did not speak with your fathers or command them in the day that I brought them out of the land of Egypt concerning burnt offerings or sacrifices. **<sup>23</sup>** But this thing I commanded them, saying, Obey My voice, and I will be your God, and you will be My people; and walk in all the way that I command you, that it may go well with you. **<sup>24</sup>** But they did not listen or incline their ear, but walked in the counsels and in the stubbornness of their evil heart, and went backward and not forward. **<sup>25</sup>** From the day that your fathers came out of the land of Egypt until this day, I have sent to you all My servants the prophets, daily rising early and sending them. **<sup>26</sup>** Yet they did not listen to Me or incline their ear, but stiffened their neck; they did worse than their fathers. **<sup>27</sup>** You shall speak all these words to them, but they will not listen to you; you shall call to them, but they will not answer you. **<sup>28</sup>** And you shall say to them, This is the nation that did not obey the voice of the LORD their God, nor receive correction. Truth has perished and is cut off from their mouth.

**<sup>29</sup>** Cut off your hair and cast it away, and lift up a lamentation on the bare heights; for the LORD has rejected and forsaken the generation of His wrath. **<sup>30</sup>** For the sons of Judah have done evil in My sight, declares the LORD; they have set their detestable things in the house which is called by My name, to defile it. **<sup>31</sup>** They have built the high places of Topheth, which is in the Valley of Ben Hinnom, to burn their sons and their daughters in the fire, which I did not command, nor did it come into My mind. **<sup>32</sup>** Therefore, observe how the days are coming, declares the LORD, when it will no longer be called Topheth or the Valley of Ben Hinnom, but the Valley of Slaughter; for they will bury in Topheth until there is no more place. **<sup>33</sup>** And the dead bodies of this people will be food for the birds of the heavens and for the beasts of the earth, and no one will frighten them away. **<sup>34</sup>** Then I will cause to cease from the cities of Judah and from the streets of Jerusalem the voice of mirth and the voice of gladness, the voice of the bridegroom and the voice of the bride; for the land will become a desolation. 

## Chapter 8

**<sup>1</sup>** At that time, declares the LORD, they will bring out the bones of the kings of Judah, and the bones of his princes, and the bones of the priests, and the bones of the prophets, and the bones of the inhabitants of Jerusalem, from their graves. **<sup>2</sup>** And they will spread them before the sun, and the moon, and all the host of heaven, which they have loved, and which they have served, and after which they have walked, and which they have sought, and to which they have bowed down. They will not be gathered or buried; they will be as dung on the face of the ground. **<sup>3</sup>** And death will be chosen rather than life by all the remnant that remains of this evil family, that remain in all the places where I have driven them, declares the LORD of hosts.

**<sup>4</sup>** And you shall say to them, Thus says the LORD: Do men fall and not rise up again? Does one turn away and not return? **<sup>5</sup>** Why then has this people of Jerusalem turned away in perpetual backsliding? They hold fast to deceit, they refuse to return. **<sup>6</sup>** I listened and heard, but they do not speak what is right; no man repents of his wickedness, saying, What have I done? Everyone turns to his own course, like a horse plunging headlong into battle. **<sup>7</sup>** Even the stork in the heavens knows her appointed times; and the turtledove, and the swallow, and the crane keep the time of their coming; but My people do not know the judgment of the LORD.

**<sup>8</sup>** How can you say, "We are wise, and the law of the LORD is with us," when you can see the lying pen of the scribes has made it into a lie. **<sup>9</sup>** The wise men are put to shame, they are dismayed and caught. They have rejected the word of the LORD, and what wisdom do they have? **<sup>10</sup>** Therefore I will give their wives to others, their fields to those who will inherit them; for from the least even to the greatest, everyone is greedy for gain; from the prophet even to the priest, everyone deals falsely. **<sup>11</sup>** They have healed the wound of the daughter of My people lightly, saying, Peace, peace, when there is no peace. **<sup>12</sup>** Were they ashamed when they had committed abomination? No, they were not at all ashamed, and they did not know how to blush. Therefore they will fall among those who fall; "in the time of their punishment they will be cast down," says the LORD. **<sup>13</sup>** "I will utterly consume them," declares the LORD; "no grapes will be on the vine, nor figs on the fig tree, and the leaf will wither, and what I have given them will pass away from them."

**<sup>14</sup>** Why do we sit still? Assemble yourselves, and let us enter the fortified cities, and let us be silent there; for the LORD our God has silenced us, and given us poisoned water to drink, because we have sinned against the LORD. **<sup>15</sup>** We looked for peace, but no good came; for a time of healing, but behold, terror. **<sup>16</sup>** The snorting of his horses is heard from Dan; at the sound of the neighing of his stallions the whole land trembles; for they come and devour the land and all that is in it, the city and those who dwell in it. **<sup>17</sup>** For behold, I am sending among you serpents, adders that cannot be charmed, and they will bite you, declares the LORD.

**<sup>18</sup>** My comfort in sorrow is faint within me; my heart is sick within me. **<sup>19</sup>** Behold, the cry of the daughter of my people from a land far and wide: Is the LORD not in Zion? Is her King not within her? Why have they provoked Me to anger with their carved images, with foreign vanities? **<sup>20</sup>** The harvest is past, the summer is ended, and we are not saved. **<sup>21</sup>** For the wound of the daughter of my people I am crushed; I mourn, dismay has taken hold of me. **<sup>22</sup>** Is there no balm in Gilead? Is there no physician there? Why then has the healing of the daughter of my people not come about? 

## Chapter 9

**<sup>1</sup>** Oh that my head were waters, and my eyes a fountain of tears, that I might weep day and night for the slain of the daughter of my people! **<sup>2</sup>** Oh that I had in the desert a lodging place for travelers, that I might leave my people and go from them! For they are all adulterers, an assembly of treacherous men. **<sup>3</sup>** They bend their tongue like their bow for lies; but they are not valiant for truth upon the earth; for they proceed from evil to evil, and they do not know Me, declares the LORD.

**<sup>4</sup>** Beware of your neighbor, and put no trust in any brother; for every brother will utterly supplant, and every neighbor goes about as a slanderer. **<sup>5</sup>** Everyone deceives his neighbor, and does not speak the truth; they have taught their tongue to speak lies, they weary themselves committing iniquity. **<sup>6</sup>** Your dwelling is in the midst of deceit; through deceit they refuse to know Me, declares the LORD.

**<sup>7</sup>** Therefore thus says the LORD of hosts: "I will refine them and test them; for what else can I do because of the daughter of My people? **<sup>8</sup>** Their tongue is a deadly arrow; it speaks deceit; with his mouth one speaks peace to his neighbor, but in his heart he lays in wait for him." **<sup>9</sup>** "Shall I not punish them for these things?" declares the LORD. "Shall I not avenge Myself on a nation such as this?"

**<sup>10</sup>** For the mountains I will lift up weeping and wailing, and for the pastures of the wilderness a lament, because they are laid waste so that no one passes through, and the sound of the livestock is not heard; both the birds of the heavens and the beasts have fled, they are gone. **<sup>11</sup>** And I will make Jerusalem a heap of ruins, a haunt of jackals; and I will make the cities of Judah a desolation, without inhabitant.

**<sup>12</sup>** Who is the man so wise that he may understand this? And to whom has the mouth of the LORD spoken, that he may declare it? Why is the land ruined and laid waste like a wilderness, so that no one passes through? **<sup>13</sup>** And the LORD said, "Because they have forsaken My law which I set before them, and have not obeyed My voice or walked according to it, **<sup>14</sup>** but have walked after the stubbornness of their own heart and after the Baals, as their fathers taught them," **<sup>15</sup>** therefore thus says the LORD of hosts, the God of Israel: "I will feed them, this people, with wormwood, and give them poisoned water to drink. **<sup>16</sup>** I will scatter them also among the nations, whom neither they nor their fathers have known; and I will send the sword after them until I have consumed them."

**<sup>17</sup>** Thus says the LORD of hosts: "Consider, and call for the mourning women, that they may come; and send for the skillful women, that they may come." **<sup>18</sup>** Let them make haste and lift up a wailing for us, that our eyes may run down with tears, and our eyelids gush with water. **<sup>19</sup>** For the sound of wailing is heard from Zion: "How we are ruined! We are greatly ashamed, because we have forsaken the land, because they have cast down our dwellings." **<sup>20</sup>** Yet hear the word of the LORD, O women, and let your ear receive the word of His mouth; teach your daughters wailing, and every neighbor her lament. **<sup>21</sup>** For death has climbed through our windows, it has entered our palaces, to cut off the children from the streets, the young men from the squares. **<sup>22</sup>** Speak, "Thus declares the LORD: 'The dead bodies of men will fall like dung on the open field, and like sheaves after the reaper, and no one will gather them.'"

**<sup>23</sup>** Thus says the LORD: "Let not the wise man boast in his wisdom, let not the mighty man boast in his might, let not the rich man boast in his riches." **<sup>24</sup>** "But let him who boasts, boast in this, that he understands and knows Me, that I am the LORD who practices steadfast love, justice, and righteousness in the earth; for in these I delight," declares the LORD.

**<sup>25</sup>** "Look! The days are coming," declares the LORD, "when I will punish all who are circumcised only in the flesh— **<sup>26</sup>** Egypt, Judah, Edom, the sons of Ammon, Moab, and all who dwell in the wilderness who clip the corners of their hair; for all the nations are uncircumcised, and all the house of Israel are uncircumcised in heart." 

## Chapter 10

**<sup>1</sup>** Hear the word which the LORD speaks to you, O house of Israel. **<sup>2</sup>** Thus says the LORD: "Do not learn the way of the nations, and do not be terrified by the signs of the heavens, though the nations are terrified by them." **<sup>3</sup>** For the customs of the peoples are vanity; for one cuts a tree from the forest, the work of the hands of a craftsman with the axe. **<sup>4</sup>** They decorate it with silver and with gold; they fasten it with nails and hammers so that it does not totter. **<sup>5</sup>** They are like a scarecrow in a cucumber field, and they cannot speak; they must be carried, because they cannot walk. Do not be afraid of them, for they cannot do evil, neither is it in them to do good.

**<sup>6</sup>** There is none like You, O LORD; You are great, and Your name is great in might. **<sup>7</sup>** Who would not fear You, O King of the nations? For this is Your due. Among all the wise men of the nations and in all their kingdoms there is none like You. **<sup>8</sup>** They are altogether dull and foolish; instruction from idols is wood. **<sup>9</sup>** Silver beaten into plates is brought from Tarshish, and gold from Uphaz, the work of a craftsman and of the hands of a goldsmith. Their clothing is blue and purple; they are all the work of skilled men. **<sup>10</sup>** But the LORD is the true God; He is the living God and the everlasting King. At His wrath the earth trembles, and the nations cannot endure His indignation.

**<sup>11</sup>** Thus you shall say to them: "The gods who did not make the heavens and the earth will perish from the earth and from under the heavens."

**<sup>12</sup>** It is He who made the earth by His power, who established the world by His wisdom, and by His understanding stretched out the heavens. **<sup>13</sup>** When He utters His voice, there is a tumult of waters in the heavens, and He causes the clouds to rise from the ends of the earth; He makes lightning for the rain, and brings out the wind from His storehouses. **<sup>14</sup>** Every man is stupid and without knowledge; every goldsmith is put to shame by his idol; for his molten image is a lie, and there is no breath in them. **<sup>15</sup>** They are vanity, a work of delusion; in the time of their punishment they will perish. **<sup>16</sup>** The Portion of Jacob is not like these; for He is the one who formed all things, and Israel is the tribe of His inheritance; the LORD of hosts is His name.

**<sup>17</sup>** Gather up your bundle from the ground, you who dwell under siege. **<sup>18</sup>** For thus says the LORD: At this time I will sling out the inhabitants of the land, and will distress them, that they may find it so. **<sup>19</sup>** Woe is me because of my hurt! My wound is severe. But I said, Truly this is my sickness, and I must bear it. **<sup>20</sup>** My tent is destroyed, and all my cords are broken; my children have gone from me, and they are no more; there is no one to stretch out my tent again or to set up my curtains. **<sup>21</sup>** For the shepherds are stupid and do not seek the LORD; therefore they have not prospered, and all their flock is scattered. **<sup>22</sup>** A sound of rumor!—it comes, and a great commotion out of the land of the north, to make the cities of Judah a desolation, a haunt of jackals.

**<sup>23</sup>** I know, O LORD, that the way of a man is not in himself; it is not in man who walks, to be able to direct his own steps. **<sup>24</sup>** Correct me, O LORD, but in justice; not in Your anger, lest You bring me to nothing. **<sup>25</sup>** Pour out Your wrath on the nations that do not know You, and on the families that do not call on Your name; for they have devoured Jacob, yes, they have devoured him and consumed him, and have laid waste his habitation. 

## Chapter 11

**<sup>1</sup>** The word that came to Jeremiah from the LORD, saying, **<sup>2</sup>** “Hear the words of this covenant, and speak to the men of Judah and to the inhabitants of Jerusalem. **<sup>3</sup>** You shall say to them, ‘Thus says the LORD, the God of Israel: Cursed is the man who does not hear the words of this covenant, **<sup>4</sup>** which I commanded your fathers in the day that I brought them out of the land of Egypt, out of the iron furnace, saying, "Obey My voice and do all that I command you; so you will be My people, and I will be your God, **<sup>5</sup>** that I may establish the oath which I swore to your fathers, to give them a land flowing with milk and honey, as it is this day."’” Then I answered and said, “Amen, O LORD.”

**<sup>6</sup>** And the LORD said to me, “Proclaim all these words in the cities of Judah and in the streets of Jerusalem, saying, ‘Hear the words of this covenant and do them. **<sup>7</sup>** For I solemnly warned your fathers in the day that I brought them up out of the land of Egypt, even to this day, rising early and warning, saying, "Obey My voice." **<sup>8</sup>** Yet they did not obey or incline their ear, but everyone walked in the stubbornness of his evil heart. So I brought on them all the words of this covenant, which I commanded them to do, but they did not.’”

**<sup>9</sup>** And the LORD said to me, “A conspiracy is found among the men of Judah and among the inhabitants of Jerusalem. **<sup>10</sup>** They have turned back to the iniquities of their forefathers who refused to hear My words, and they have gone after other gods to serve them. The house of Israel and the house of Judah have broken My covenant which I made with their fathers.” **<sup>11</sup>** Therefore thus says the LORD: “I am bringing disaster upon them which they cannot escape; and though they cry out to Me, I will not listen to them. **<sup>12</sup>** Then the cities of Judah and the inhabitants of Jerusalem will go and cry out to the gods to whom they burn incense; but they surely will not save them in the time of their disaster. **<sup>13</sup>** For your gods are as many as your cities, O Judah; and as many as the streets of Jerusalem are the altars you have set up to the shameful thing, altars to burn incense to Baal.”

**<sup>14</sup>** “As for you, do not pray for this people, nor lift up a cry or prayer for them; for I will not listen when they call to Me because of their disaster. **<sup>15</sup>** What right has My beloved in My house, when she has done many vile deeds? Can the flesh of holy offerings remove you from your evil, so that you can rejoice? **<sup>16</sup>** The LORD once called you a green olive tree, beautiful with good fruit; but with the roar of a great storm He has set fire to it, and its branches are broken. **<sup>17</sup>** The LORD of hosts, who planted you, has pronounced disaster against you because of the evil of the house of Israel and the house of Judah, which they have done to provoke Me to anger by burning incense to Baal.”

**<sup>18</sup>** The LORD made it known to me, and I knew; then You showed me their deeds. **<sup>19</sup>** But I was like a gentle lamb led to the slaughter; I did not know that they had devised plots against me, saying, “Let us destroy the tree with its fruit, and cut him off from the land of the living, so that his name may be remembered no more.” **<sup>20</sup>** But, O LORD of hosts, who judges righteously, who tests the heart and the mind, let me see Your vengeance upon them; for to You have I committed my cause.

**<sup>21</sup>** Therefore thus says the LORD concerning the men of Anathoth, who seek your life, saying, “Do not prophesy in the name of the LORD, or you will die by our hand”— **<sup>22</sup>** therefore thus says the LORD of hosts: “I will punish them; the young men will die by the sword, their sons and their daughters will die by famine, **<sup>23</sup>** and none of them will be left. For I will bring disaster upon the men of Anathoth, the year of their punishment.” 

## Chapter 12

**<sup>1</sup>** Righteous are You, O LORD, when I bring a case before You; yet I would speak with You about justice. Why does the way of the wicked prosper? Why are all those at ease who deal treacherously? **<sup>2</sup>** You have planted them, and they have taken root; they grow, they even bear fruit. You are near in their mouth but far from their heart. **<sup>3</sup>** But You, O LORD, know me; You see me, and You test my heart toward You. Pull them out like sheep for slaughter, and set them apart for the day of killing. **<sup>4</sup>** How long will the land mourn, and the grass of every field wither? Because of the evil of those who dwell in it, the beasts and the birds are swept away, because they said, “He will not see our latter end.”

**<sup>5</sup>** “If you have run with footmen and they have wearied you, how then can you contend with horses? And if you fall in a land of peace, how will you do in the thickets of the Jordan? **<sup>6</sup>** For even your brothers and the house of your father, even they have dealt treacherously with you; even they have cried aloud after you. Do not believe them, though they speak fair words to you.”

**<sup>7</sup>** “I have forsaken My house, I have abandoned My heritage; I have given the beloved of My soul into the hand of her enemies. **<sup>8</sup>** My heritage has become to Me like a lion in the forest; she has roared against Me, therefore I hate her. **<sup>9</sup>** Is My heritage to Me like a speckled bird of prey? Are the birds of prey against her all around? Go, assemble all the beasts of the field, bring them to devour. **<sup>10</sup>** Many shepherds have destroyed My vineyard, they have trampled My portion underfoot, they have made My pleasant portion a desolate wilderness. **<sup>11</sup>** They have made it a desolation; desolate, it mourns before Me. The whole land is made desolate, because no man lays it to heart. **<sup>12</sup>** Destroyers have come upon all the bare heights in the wilderness; for the sword of the LORD devours from one end of the land even to the other; no flesh has peace. **<sup>13</sup>** They have sown wheat but have reaped thorns; they have worn themselves out but gain nothing. They are ashamed of their harvests because of the fierce anger of the LORD.”

**<sup>14</sup>** Thus says the LORD concerning all My evil neighbors who touch the inheritance that I have caused My people Israel to inherit: “I am about to uproot them from their land, and I will uproot the house of Judah from among them. **<sup>15</sup>** And after I have uprooted them, I will again have compassion on them, and I will bring them back each to his heritage and each to his land. **<sup>16</sup>** And it shall come to pass, if they will diligently learn the ways of My people, to swear by My name, ‘As the LORD lives,’ even as they taught My people to swear by Baal, then they shall be built up in the midst of My people. **<sup>17</sup>** But if they will not listen, I will utterly uproot and destroy that nation, declares the LORD.” 

## Chapter 13

**<sup>1</sup>** Thus the LORD said to me: “Go and buy yourself a linen loincloth, and put it around your waist, but do not put it in water.” **<sup>2</sup>** So I bought a loincloth according to the word of the LORD and put it around my waist. **<sup>3</sup>** And the word of the LORD came to me a second time, saying, **<sup>4</sup>** “Take the loincloth that you bought, which is around your waist, and arise, go to the Euphrates, and hide it there in a cleft of the rock.” **<sup>5</sup>** So I went and hid it by the Euphrates, as the LORD commanded me. **<sup>6</sup>** And it came to pass after many days that the LORD said to me, “Arise, go to the Euphrates, and take from there the loincloth that I commanded you to hide there.” **<sup>7</sup>** So I went to the Euphrates and dug, and I took the loincloth from the place where I had hidden it. And the loincloth was ruined; it was good for nothing.

**<sup>8</sup>** Then the word of the LORD came to me, saying, **<sup>9</sup>** “Thus says the LORD: In this way I will ruin the pride of Judah and the great pride of Jerusalem. **<sup>10</sup>** This evil people, who refuse to hear my words, who walk in the stubbornness of their heart, and who have gone after other gods to serve them and to bow down to them, shall be like this loincloth, which is good for nothing. **<sup>11</sup>** For as the loincloth clings to the waist of a man, so I caused all the house of Israel and all the house of Judah to cling to me—declares the LORD—to be my people, for renown, for praise, and for glory, but they did not listen.”

**<sup>12</sup>** “Therefore you shall speak to them this word: ‘Thus says the LORD, the God of Israel: Every jar shall be filled with wine.’ And when they say to you, ‘Do we not indeed know that every jar shall be filled with wine?’ **<sup>13</sup>** Then you shall say to them, ‘Thus says the LORD: Look here, I am about to fill with drunkenness all the inhabitants of this land—the kings who sit on David’s throne, the priests, the prophets, and all the inhabitants of Jerusalem. **<sup>14</sup>** And I will dash them one against another, fathers and sons together—declares the LORD. I will not show pity or spare or have compassion, that I should not destroy them.’”

**<sup>15</sup>** Hear and give ear; do not be proud, for the LORD has spoken. **<sup>16</sup>** Give glory to the LORD your God before he brings darkness, and before your feet stumble on the mountains at twilight; while you look for light, he turns it into gloom and makes it deep darkness. **<sup>17</sup>** But if you will not listen, my soul will weep in secret for your pride; my eyes will weep bitterly and run down with tears, because the flock of the LORD has been taken captive.

**<sup>18</sup>** Say to the king and to the queen mother:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Sit down low,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for your crown of glory<br/>
&nbsp;&nbsp;&nbsp;&nbsp;has come down from your head.”

**<sup>19</sup>** The cities of the Negev are shut up, with no one to open them; all Judah is taken into exile, wholly taken into exile. **<sup>20</sup>** Lift up your eyes and see<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who come from the north.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Where is the flock that was given you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your beautiful sheep?

**<sup>21</sup>** What will you say when he sets over you—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those you yourself taught to be allies for your head?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Will not pangs take hold of you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a woman in labor?<br/>
**<sup>22</sup>** And if you say in your heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Why have these things come upon me?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the greatness of your iniquity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your skirts are uncovered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your heels suffer violence.<br/>
**<sup>23</sup>** Can the Ethiopian change his skin,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or the leopard his spots?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then you also can do good<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who are accustomed to doing evil.

**<sup>24</sup>** So I will scatter them like chaff<br/>
&nbsp;&nbsp;&nbsp;&nbsp;driven by the wind of the wilderness.<br/>
**<sup>25</sup>** This is your lot,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the portion measured to you from me—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because you have forgotten me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and trusted in lies.<br/>
**<sup>26</sup>** I myself will also lift up your skirts over your face,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that your shame may be seen.<br/>
**<sup>27</sup>** Your adulteries and your lustful neighings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the lewdness of your whoredom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the hills in the field I have seen.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Woe to you, Jerusalem!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How long will you remain unclean?<br/>


## Chapter 14

**<sup>1</sup>** The word of the LORD that came to Jeremiah concerning the droughts.

**<sup>2</sup>** Judah mourns, and her gates languish; they sit in mourning on the ground, and the cry of Jerusalem goes up. **<sup>3</sup>** Their nobles send their servants for water; they come to the cisterns, they find no water. They return with their vessels empty, ashamed and humiliated, and they cover their heads. **<sup>4</sup>** Because the ground is cracked, for there has been no rain in the land, the farmers are ashamed; they cover their heads. **<sup>5</sup>** Even the doe in the field gives birth and abandons her young, because there is no grass. **<sup>6</sup>** The wild donkeys stand on the barren heights, they pant for air like jackals; their eyes fail, for there is no vegetation.

**<sup>7</sup>** Though our iniquities testify against us, act, O LORD, for Your name’s sake. For our apostasies are many; we have sinned against You. **<sup>8</sup>** O Hope of Israel, its Savior in time of distress, why should You be like a stranger in the land, like a traveler who turns aside to spend only the night? **<sup>9</sup>** Why should You be like a man confused, like a mighty man unable to save? Yet You, O LORD, are in our midst, and Your name has been called upon us; do not leave us.

**<sup>10</sup>** Thus says the LORD concerning this people: “They have loved to wander; they have not restrained their feet. Therefore the LORD does not accept them; now He will remember their iniquity and punish their sins.”

**<sup>11</sup>** And the LORD said to me, “Do not pray for the welfare of this people. **<sup>12</sup>** Though they fast, I will not listen to their cry; though they offer burnt offering and grain offering, I will not accept them. But by the sword, by famine, and by pestilence I will consume them.”

**<sup>13</sup>** Then I said, “Ah, Lord GOD! See, the prophets are saying to them, ‘You will not see the sword, nor will you have famine, but I will give you assured peace in this place.’” **<sup>14</sup>** And the LORD said to me, “The prophets are prophesying lies in My name. I did not send them, nor did I command them or speak to them. They are prophesying to you a lying vision, worthless divination, and the deceit of their own mind. **<sup>15</sup>** Therefore thus says the LORD concerning the prophets who prophesy in My name though I did not send them, yet they say, ‘Sword and famine will not be in this land’—by sword and famine those prophets shall perish. **<sup>16</sup>** And the people to whom they prophesy shall be thrown out into the streets of Jerusalem because of famine and sword, with none to bury them, them, their wives, their sons, or their daughters. I will pour out their evil upon them.”

**<sup>17</sup>** And you shall say this word to them:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Let my eyes run with tears night and day, and let them not cease, for the virgin daughter of my people is crushed with a great wound, with a very grievous blow.<br/>
**<sup>18</sup>** If I go out into the field, there are those slain by the sword; and if I enter the city, there are those wasted with famine. For both prophet and priest roam about the land, and they do not know what they are doing.”

**<sup>19</sup>** Have You utterly rejected Judah? Has Your soul loathed Zion? Why have You struck us so that there is no healing for us? We looked for peace, but nothing good came; for a time of healing, but only saw terror. **<sup>20</sup>** We acknowledge, O LORD, our wickedness, the iniquity of our fathers, for we have sinned against You. **<sup>21</sup>** Do not spurn us, for Your name’s sake; do not dishonor Your glorious throne; remember, and do not break Your covenant with us. **<sup>22</sup>** Are there any among the worthless idols of the nations who bring rain? Or can the heavens give showers? Is it not You, O LORD our God? Therefore we hope in You, for You are the one who does all these things. 

## Chapter 15

**<sup>1</sup>** And the LORD said to me, “Even though Moses and Samuel stood before Me, My soul would not turn toward this people. Send them away from My presence, and let them go. **<sup>2</sup>** And if they ask you, ‘Where shall we go?’ then you shall say to them, ‘Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Those destined for death, to death;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those destined for the sword, to the sword;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those destined for famine, to famine;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those destined for captivity, to captivity.’

**<sup>3</sup>** I will appoint over them four kinds of doom, declares the LORD: the sword to kill, the dogs to drag away, the birds of the heavens and the beasts of the earth to devour and destroy. **<sup>4</sup>** And I will make them a horror to all the kingdoms of the earth because of Manasseh son of Hezekiah, king of Judah, for what he did in Jerusalem.

**<sup>5</sup>** For who will have pity on you, O Jerusalem, or who will grieve for you? Who will turn aside to ask about your welfare? **<sup>6</sup>** You have rejected Me, declares the LORD; you keep going backward. So I will stretch out My hand against you and destroy you; I am weary of relenting. **<sup>7</sup>** I will winnow them with a winnowing fork at the gates of the land; I will bereave them of children, I will destroy My people, for they did not turn from their ways. **<sup>8</sup>** Their widows became more numerous to Me than the sand of the seas; I brought against the mother of young men a destroyer at noonday. I made anguish and terror fall upon her suddenly. **<sup>9</sup>** She who bore seven languishes; she has breathed out her life. Her sun went down while it was yet day; she has been shamed and humiliated. And their remnant I will give to the sword before their enemies, declares the LORD.”

**<sup>10</sup>** Woe to me, my mother, that you bore me, a man of strife and a man of contention to all the land! I have not lent, nor have men lent to me, yet everyone curses me. **<sup>11</sup>** The LORD said, “Surely I will deliver you for good; surely I will make your enemies plead with you in the time of disaster and in the time of distress. **<sup>12</sup>** Can one break iron, iron from the north, and bronze? **<sup>13</sup>** Your wealth and your treasures I will give as plunder without price, for all your sins throughout your borders. **<sup>14</sup>** I will make you serve your enemies in a land you do not know, for a fire is kindled in My anger; it will burn upon you.”

**<sup>15</sup>** You know, O LORD; remember me and visit me, and take vengeance for me on my persecutors. In Your patience, do not take me away; know that for Your sake I bear reproach. **<sup>16</sup>** Your words were found, and I ate them, and Your word was to me the joy and delight of my heart, for I am called by Your name, O LORD God of hosts. **<sup>17</sup>** I did not sit in the company of merrymakers, nor did I rejoice; I sat alone because of Your hand, for You had filled me with indignation. **<sup>18</sup>** Why is my pain unending, and my wound incurable, refusing to be healed? Will You indeed be to me like a deceptive stream, like waters that are not reliable?

**<sup>19</sup>** Therefore thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“If you return, I will restore you, and you shall stand before Me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If you utter what is precious and not what is worthless, you shall be as My mouth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They shall turn to you, but you shall not turn to them.<br/>
**<sup>20</sup>** And I will make you to this people a fortified wall of bronze;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will fight against you, but they shall not prevail over you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am with you to save you and deliver you, declares the LORD.<br/>
**<sup>21</sup>** I will deliver you from the hand of the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will redeem you from the grasp of the ruthless.”<br/>


## Chapter 16

**<sup>1</sup>** The word of the LORD came to me, saying, **<sup>2</sup>** “You shall not take a wife for yourself, nor shall you have sons or daughters in this place.” **<sup>3</sup>** For thus says the LORD concerning the sons and daughters who are born in this place, and concerning their mothers who bear them, and their fathers who beget them in this land: **<sup>4</sup>** “They shall die of deadly diseases; they shall not be mourned, nor shall they be buried. They shall be like dung on the face of the ground. They shall perish by sword and famine, and their carcasses shall be food for the birds of the heavens and for the beasts of the earth.”

**<sup>5</sup>** For thus says the LORD: “Do not enter the house of mourning, nor go to lament or grieve for them, for I have taken away My peace from this people, declares the LORD, My steadfast love and mercy. **<sup>6</sup>** Both great and small shall die in this land; they shall not be buried, and men shall not mourn for them, nor cut themselves, nor shave their heads for them. **<sup>7</sup>** They shall not break bread for the mourner to comfort him for the dead, nor shall they give him the cup of consolation to drink for his father or his mother.

**<sup>8</sup>** And do not enter the house of feasting to sit with them, to eat and drink. **<sup>9</sup>** For thus says the LORD of hosts, the God of Israel: “I am about to cause to cease from this place, before your eyes and in your days, the voice of joy and the voice of gladness, the voice of the bridegroom and the voice of the bride.”

**<sup>10</sup>** And when you declare to this people all these words, and they say to you, “Why has the LORD pronounced all this great disaster against us? What is our iniquity? What is the sin that we have committed against the LORD our God?”— **<sup>11</sup>** then you shall say to them, “Because your fathers have forsaken Me, declares the LORD, and have gone after other gods and served them and bowed down to them, but Me they have forsaken and My law they have not kept. **<sup>12</sup>** And you have done worse than your fathers, for every one of you follows the stubbornness of his evil heart, so that you do not listen to Me. **<sup>13</sup>** Therefore I will hurl you out of this land into a land that neither you nor your fathers have known, and there you shall serve other gods day and night, for I will show you no favor.”

**<sup>14</sup>** “Therefore, the days are coming, declares the LORD, when it will no longer be said, ‘As the LORD lives, who brought up the sons of Israel out of the land of Egypt,’ **<sup>15</sup>** but, ‘As the LORD lives, who brought up the sons of Israel out of the land of the north and out of all the lands where He had driven them.’ For I will bring them back to their land that I gave to their fathers.

**<sup>16</sup>** Look, I am sending for many fishermen, declares the LORD, and they shall fish them out; and afterward I will send for many hunters, and they shall hunt them from every mountain and every hill, and out of the clefts of the rocks. **<sup>17</sup>** For My eyes are on all their ways; they are not hidden from My face, nor is their iniquity concealed from My eyes. **<sup>18</sup>** But first I will doubly repay their iniquity and their sin, because they have polluted My land with the carcasses of their detestable idols and have filled My inheritance with their abominations.”

**<sup>19</sup>** O LORD, my strength and my stronghold, my refuge in the day of distress, to You shall the nations come from the ends of the earth and say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Our fathers have inherited nothing but lies, worthless things in which there is no profit.<br/>
**<sup>20</sup>** Can man make gods for himself? Yet they are no gods!”

**<sup>21</sup>** “Therefore, behold, I will make them know, this once I will make them know My hand and My might, and they shall know that My name is the LORD.” 

## Chapter 17

**<sup>1</sup>** The sin of Judah is written with a pen of iron; with a point of diamond it is engraved on the tablet of their heart and on the horns of their altars, **<sup>2</sup>** while their children remember their altars and their Asherim beside every green tree and on the high hills, **<sup>3</sup>** on the mountains in the open country. Your wealth and all your treasures I will give as plunder, along with your high places, because of sin throughout all your territory. **<sup>4</sup>** You shall let go of your heritage that I gave you; I will make you serve your enemies in a land that you do not know, for you have kindled a fire in My anger; it will burn forever.

**<sup>5</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Cursed is the man who trusts in man<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and makes flesh his strength,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and whose heart turns away from the LORD.<br/>
**<sup>6</sup>** He will be like a shrub in the desert,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall not see when good comes.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will dwell in the parched places of the wilderness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in a salt land where no one lives.

**<sup>7</sup>** Blessed is the man who trusts in the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and whose trust is the LORD.<br/>
**<sup>8</sup>** He will be like a tree planted by the water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that sends out its roots by the stream.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;It does not fear when heat comes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for its leaves remain green.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;It is not anxious in the year of drought,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor does it cease to bear fruit.”

**<sup>9</sup>** The heart is deceitful above all things, and incurable—who can understand it? **<sup>10</sup>** I, the LORD, search the heart and test the mind, to give every man according to his ways, according to the fruit of his deeds.

**<sup>11</sup>** Like a partridge that hatches eggs it did not lay is the one who gains wealth unjustly. In the middle of his days it will desert him, and at his end he will be a fool.

**<sup>12</sup>** A glorious throne set on high from the beginning is the place of our sanctuary. **<sup>13</sup>** O LORD, the hope of Israel, all who forsake You shall be put to shame; those who turn away from You shall be written in the dust, for they have forsaken the LORD, the fountain of living water.

**<sup>14</sup>** Heal me, O LORD, and I shall be healed; save me, and I shall be saved, for You are my praise. **<sup>15</sup>** Look how they keep saying to me, “Where is the word of the LORD? Let it come now!” **<sup>16</sup>** But I have not run away from being a shepherd who follows You, nor have I desired the day of disaster. You know what came out of my lips; it was before You. **<sup>17</sup>** Do not be a terror to me; You are my refuge in the day of disaster. **<sup>18</sup>** Let my persecutors be put to shame, but do not let me be put to shame; let them be dismayed, but do not let me be dismayed. Bring upon them the day of disaster; crush them with double destruction.

**<sup>19</sup>** Thus said the LORD to me: “Go and stand in the gate of the sons of the people, through which the kings of Judah come in and through which they go out, and in all the gates of Jerusalem, **<sup>20</sup>** and say to them, ‘Hear the word of the LORD, O kings of Judah and all Judah, and all inhabitants of Jerusalem, who enter by these gates. **<sup>21</sup>** Thus says the LORD: Take care for the sake of your lives, and do not carry a burden on the Sabbath day or bring it in by the gates of Jerusalem. **<sup>22</sup>** And do not carry a burden out of your houses on the Sabbath day or do any work, but keep the Sabbath day holy, as I commanded your fathers. **<sup>23</sup>** Yet they did not listen or incline their ear, but stiffened their neck, that they might not hear and not receive instruction.

**<sup>24</sup>** But if you diligently listen to Me, declares the LORD, to bring in no burden through the gates of this city on the Sabbath day, but keep the Sabbath day holy and do no work on it, **<sup>25</sup>** then kings and princes who sit on the throne of David shall enter through the gates of this city, riding in chariots and on horses, they and their princes, the men of Judah and the inhabitants of Jerusalem. And this city shall be inhabited forever. **<sup>26</sup>** And they shall come from the cities of Judah and the places around Jerusalem, from the land of Benjamin, from the Shephelah, from the hill country, and from the Negev, bringing burnt offerings and sacrifices, grain offerings and frankincense, and bringing thank offerings to the house of the LORD. **<sup>27</sup>** But if you do not listen to Me, to keep the Sabbath day holy and not to carry a burden when you enter the gates of Jerusalem on the Sabbath day, then I will kindle a fire in its gates, and it shall devour the palaces of Jerusalem and not be quenched.’” 

## Chapter 18

**<sup>1</sup>** The word that came to Jeremiah from the LORD: **<sup>2</sup>** “Arise and go down to the potter’s house, and there I will let you hear My words.” **<sup>3</sup>** So I went down to the potter’s house, and there he was working at the wheel. **<sup>4</sup>** But the vessel he was making of clay was spoiled in the hand of the potter, so he reworked it into another vessel, as it seemed good to the potter to make.

**<sup>5</sup>** Then the word of the LORD came to me: **<sup>6</sup>** “O house of Israel, can I not do with you as this potter has done? declares the LORD. Like the clay in the potter’s hand, so are you in My hand, O house of Israel. **<sup>7</sup>** At one moment I may speak concerning a nation or a kingdom, to pluck up and break down and destroy it, **<sup>8</sup>** but if that nation against which I have spoken turns from its evil, I will relent of the disaster that I intended to do to it. **<sup>9</sup>** And at another moment I may speak concerning a nation or a kingdom, to build and to plant it, **<sup>10</sup>** but if it does evil in My sight, not listening to My voice, then I will relent of the good with which I had intended to bless it.

**<sup>11</sup>** Now therefore, say to the men of Judah and the inhabitants of Jerusalem: ‘Thus says the LORD: I am shaping disaster against you and devising a plan against you. Turn back, each of you from his evil way, and amend your ways and your deeds.’ **<sup>12</sup>** But they say, ‘It is hopeless, for we will follow our own plans, and each of us will act according to the stubbornness of his evil heart.’

**<sup>13</sup>** Therefore thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Ask now among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who has heard such things?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The virgin Israel has done<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a most horrible thing.<br/>
**<sup>14</sup>** Does the snow of Lebanon leave<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the crags of Sirion?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do the cold flowing waters<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from afar ever run dry?<br/>
**<sup>15</sup>** Yet My people have forgotten Me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they burn offerings to worthless idols.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They have stumbled in their ways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the ancient paths,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to walk in byways,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;not on the highway,<br/>
**<sup>16</sup>** making their land a horror,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a thing to be hissed at forever.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Everyone who passes by it is appalled<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shakes his head.<br/>
**<sup>17</sup>** Like the east wind I will scatter them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the enemy.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will show them My back, not My face,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day of their disaster.”

**<sup>18</sup>** Then they said, “Come, let us devise plans against Jeremiah, for the law will not perish from the priest, nor counsel from the wise, nor the word from the prophet. Come, let us strike him with the tongue, and let us not pay attention to any of his words.”

**<sup>19</sup>** Give attention to me, O LORD, and hear the voice of my adversaries. **<sup>20</sup>** Shall evil be repaid for good? Yet they have dug a pit for my life. Remember how I stood before You to speak good for them, to turn away Your wrath from them. **<sup>21</sup>** Therefore give their children to famine; hand them over to the power of the sword. Let their wives be bereaved of children and widows; let their men be struck down by death, their young men struck down by the sword in battle. **<sup>22</sup>** Let a cry be heard from their houses when You bring a raiding party suddenly upon them, for they have dug a pit to capture me and laid snares for my feet. **<sup>23</sup>** But You, O LORD, know all their plans to kill me. Do not forgive their iniquity or blot out their sin from Your sight. Let them be overthrown before You; deal with them in the time of Your anger. 

## Chapter 19

**<sup>1</sup>** Thus says the LORD: “Go, buy a potter’s earthenware flask, and take some of the elders of the people and some of the elders of the priests, **<sup>2</sup>** and go out to the Valley of Ben-hinnom, which is at the entrance of the Potsherd Gate, and proclaim there the words that I speak to you. **<sup>3</sup>** You shall say, ‘Hear the word of the LORD, O kings of Judah and inhabitants of Jerusalem. Thus says the LORD of hosts, the God of Israel: Look! I am bringing disaster upon this place that will make the ears of everyone who hears of it tingle. **<sup>4</sup>** Because they have forsaken Me and have made this place foreign, and have burned sacrifices in it to other gods that neither they nor their fathers nor the kings of Judah ever knew, and because they have filled this place with the blood of innocents, **<sup>5</sup>** and have built the high places of Baal to burn their sons in the fire as burnt offerings to Baal—which I did not command or decree, nor did it come into My mind— **<sup>6</sup>** therefore, look how the days are coming, declares the LORD, when this place shall no longer be called Topheth, or the Valley of Ben-hinnom, but the Valley of Slaughter.

**<sup>7</sup>** And in this place I will make void the plans of Judah and Jerusalem, and I will cause them to fall by the sword before their enemies, and by the hand of those who seek their life. I will give their carcasses as food to the birds of the heavens and to the beasts of the earth. **<sup>8</sup>** And I will make this city a horror, a thing to be hissed at. Everyone who passes by it will be appalled and hiss because of all its wounds. **<sup>9</sup>** And I will make them eat the flesh of their sons and their daughters, and each shall eat the flesh of his neighbor in the siege and in the distress with which their enemies and those who seek their life afflict them.’

**<sup>10</sup>** “Then you shall break the flask in the sight of the men who go with you, **<sup>11</sup>** and you shall say to them, ‘Thus says the LORD of hosts: So will I break this people and this city, as one breaks a potter’s vessel, so that it cannot be mended. They shall bury in Topheth because there will be no other place to bury. **<sup>12</sup>** Thus will I do to this place, declares the LORD, and to its inhabitants, making this city like Topheth. **<sup>13</sup>** The houses of Jerusalem and the houses of the kings of Judah—all the houses on whose roofs offerings have been burned to all the host of heaven, and drink offerings have been poured out to other gods—shall be defiled like the place of Topheth.’”

**<sup>14</sup>** Then Jeremiah came from Topheth, where the LORD had sent him to prophesy, and he stood in the court of the LORD’s house and said to all the people, **<sup>15</sup>** “Thus says the LORD of hosts, the God of Israel: Look! I am bringing upon this city and upon all its towns all the disaster that I have pronounced against it, because they have stiffened their neck, refusing to hear My words.” 

## Chapter 20

**<sup>1</sup>** Now Pashhur son of Immer the priest, who was chief officer in the house of the LORD, heard Jeremiah prophesying these things. **<sup>2</sup>** Then Pashhur struck Jeremiah the prophet and put him in the stocks that were in the upper Benjamin Gate of the house of the LORD. **<sup>3</sup>** But on the next day, when Pashhur brought Jeremiah out of the stocks, Jeremiah said to him, “The LORD does not call your name Pashhur, but Magor-missabib. **<sup>4</sup>** For thus says the LORD: You will see how I will make you a terror to yourself and to all your friends. They shall fall by the sword of their enemies before your eyes, and I will give all Judah into the hand of the king of Babylon. He shall carry them captive to Babylon and shall strike them down with the sword. **<sup>5</sup>** Moreover, I will give all the wealth of this city, all its gains, all its prized belongings, and all the treasures of the kings of Judah into the hand of their enemies. They shall plunder them and seize them and carry them to Babylon. **<sup>6</sup>** And you, Pashhur, and all who live in your house shall go into captivity. You shall go to Babylon, and there you shall die, and there you shall be buried, you and all your friends, to whom you have prophesied lies.”

**<sup>7</sup>** O LORD, You have enticed me, and I was enticed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You are stronger than I, and You prevailed.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have become a laughingstock all the day;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;everyone mocks me.<br/>
**<sup>8</sup>** For whenever I speak, I cry out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I shout, “Violence and destruction!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the word of the LORD has become for me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a reproach and derision all the day.<br/>
**<sup>9</sup>** If I say, “I will not mention Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or speak any more in His name,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is in my heart as it were a burning fire<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shut up in my bones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I am weary with holding it in,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I cannot.

**<sup>10</sup>** For I hear many whispering.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Terror is all around!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Denounce him! Let us denounce him!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;say all my close friends,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;watching for my fall.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Perhaps he will be deceived;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then we can overcome him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and take our revenge on him.”

**<sup>11</sup>** But the LORD is with me as a dread warrior;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore my persecutors will stumble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will not prevail.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They will be greatly shamed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they will not succeed.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their eternal dishonor<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will never be forgotten.<br/>
**<sup>12</sup>** O LORD of hosts, who tests the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who sees the heart and the mind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let me see Your vengeance upon them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for to You I have committed my cause.

**<sup>13</sup>** Sing to the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;praise the LORD!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For He has delivered the life of the needy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the hand of evildoers.

**<sup>14</sup>** Cursed be the day on which I was born!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The day when my mother bore me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let it not be blessed!<br/>
**<sup>15</sup>** Cursed be the man who brought the news<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to my father, “A son is born to you,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;making him very glad.<br/>
**<sup>16</sup>** Let that man be like the cities<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that the LORD overthrew without pity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let him hear a cry in the morning<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and an alarm at noon,<br/>
**<sup>17</sup>** because he did not kill me in the womb;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so my mother would have been my grave,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her womb forever pregnant.<br/>
**<sup>18</sup>** Why did I come out from the womb<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to see toil and sorrow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and spend my days in shame?<br/>


## Chapter 21

**<sup>1</sup>** The word that came to Jeremiah from the LORD when King Zedekiah sent to him Pashhur son of Malchiah and Zephaniah son of Maaseiah the priest, saying, **<sup>2</sup>** “Inquire now of the LORD for us, for Nebuchadrezzar king of Babylon is fighting against us. Perhaps the LORD will deal with us according to all his wondrous deeds, so that he will go up from us.”

**<sup>3</sup>** Then Jeremiah said to them, “You shall say this to Zedekiah: **<sup>4</sup>** ‘The LORD, the God of Israel, says: I am about to turn back the weapons of war that are in your hands, with which you are fighting the king of Babylon and the Chaldeans who are besieging you outside the wall, and I will gather them into the midst of this city. **<sup>5</sup>** And I myself will fight against you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with an outstretched hand and with a mighty arm,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in anger and in wrath and in great fury.<br/>
**<sup>6</sup>** And I will strike the inhabitants of this city, both man and beast; they will die of a great plague.

**<sup>7</sup>** And after that—declares the LORD—I will give Zedekiah king of Judah and his servants and the people, those who remain in this city from the plague, the sword, and the famine, into the hand of Nebuchadrezzar king of Babylon, into the hand of their enemies, and into the hand of those who seek their lives. He will strike them with the edge of the sword; he will not spare them, nor have pity, nor have compassion.’

**<sup>8</sup>** And to this people you shall say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘The LORD says:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Look, I am setting before you the way of life<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the way of death.<br/>
**<sup>9</sup>** Whoever stays in this city will die<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by the sword and by famine and by plague,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but whoever goes out and surrenders to the Chaldeans<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who are besieging you will live,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his life will be his spoil.<br/>
**<sup>10</sup>** For I have set my face against this city for harm and not for good—declares the LORD. It will be given into the hand of the king of Babylon, and he will burn it with fire.’

**<sup>11</sup>** And concerning the house of the king of Judah, say: **<sup>12</sup>** ‘House of David, the LORD says:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Administer justice every morning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and rescue the one robbed from the hand of the oppressor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that my wrath does not go out like fire<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and burn with no one to quench it<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the evil of your deeds.’

**<sup>13</sup>** “Look, I am against you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O inhabitant of the valley,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rock of the plain—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who say, ‘Who will come down against us,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and who will enter our dwellings?’<br/>
**<sup>14</sup>** I will punish you according to the fruit of your deeds—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will kindle a fire in her forest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it will consume all that is around her.”<br/>


## Chapter 22

**<sup>1</sup>** Thus says the LORD: “Go down to the house of the king of Judah, and speak there this word, **<sup>2</sup>** and say, ‘Hear the word of the LORD, O king of Judah, who sits on the throne of David—you, and your servants, and your people who enter these gates. **<sup>3</sup>** Thus says the LORD: Do justice and righteousness, and deliver from the hand of the oppressor him who has been robbed. Do no wrong or violence to the sojourner, the fatherless, or the widow, nor shed innocent blood in this place. **<sup>4</sup>** For if you indeed do this thing, then kings who sit on David’s throne will enter through the gates of this house, riding in chariot and on horses, he and his servants and his people. **<sup>5</sup>** But if you will not listen to these words, I swear by myself—declares the LORD—that this house shall become a ruin.’”

**<sup>6</sup>** For thus says the LORD concerning the house of the king of Judah:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“You are Gilead to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the summit of Lebanon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet surely I will make you a wilderness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;cities without inhabitant.<br/>
**<sup>7</sup>** I will prepare destroyers against you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;each with his weapons,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will cut down your choice cedars<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and throw them into the fire.”

**<sup>8</sup>** And many nations will pass by this city, and each man will say to his neighbor, “Why has the LORD dealt in this way with this great city?” **<sup>9</sup>** And they will answer, “Because they forsook the covenant of the LORD their God and worshiped other gods and served them.”

**<sup>10</sup>** Do not weep for the dead,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not mourn for him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but weep bitterly for him who goes away,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he shall return no more<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and see the land of his birth.<br/>
**<sup>11</sup>** For thus says the LORD concerning Shallum son of Josiah, king of Judah, who reigned instead of Josiah his father, and who went out from this place: “He shall not return here anymore, **<sup>12</sup>** but in the place where they carried him captive, there shall he die, and he shall not see this land again.”

**<sup>13</sup>** Woe to him who builds his house by unrighteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his upper rooms by injustice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who makes his neighbor serve him for nothing<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and does not give him his wages,<br/>
**<sup>14</sup>** who says, “I will build myself a great house<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with spacious upper rooms,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who cuts out windows for it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;paneling it with cedar<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and painting it with vermilion.

**<sup>15</sup>** Do you think you are a king<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because you compete in cedar?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Did not your father eat and drink<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do justice and righteousness?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then it went well with him.<br/>
**<sup>16</sup>** He judged the cause of the poor and needy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then it went well.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is not this to know me?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>17</sup>** But your eyes and your heart<br/>
&nbsp;&nbsp;&nbsp;&nbsp;are set only on your covetousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on shedding innocent blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on practicing oppression and violence.<br/>
**<sup>18</sup>** Therefore thus says the LORD concerning Jehoiakim son of Josiah, king of Judah:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“They shall not lament for him, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Ah, my brother!’ or ‘Ah, sister!’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They shall not lament for him, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Ah, lord!’ or ‘Ah, his majesty!’<br/>
**<sup>19</sup>** With the burial of a donkey he shall be buried—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;dragged and thrown out<br/>
&nbsp;&nbsp;&nbsp;&nbsp;beyond the gates of Jerusalem.”

**<sup>20</sup>** Go up to Lebanon and cry out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lift up your voice in Bashan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cry out from Abarim,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for all your lovers are destroyed.<br/>
**<sup>21</sup>** I spoke to you in your prosperity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but you said, “I will not listen.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;This has been your way from your youth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that you have not obeyed my voice.

**<sup>22</sup>** The wind shall shepherd away all your shepherds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your lovers shall go into captivity.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then you will be ashamed and confounded<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of all your wickedness.<br/>
**<sup>23</sup>** O inhabitant of Lebanon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nested among the cedars,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how you will groan when pangs come upon you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;pain as of a woman in labor!

**<sup>24</sup>** “As I live,” declares the LORD, “though Coniah son of Jehoiakim, king of Judah, were the signet ring on my right hand, yet I would tear you off **<sup>25</sup>** and give you into the hand of those who seek your life, into the hand of those whom you fear, even into the hand of Nebuchadnezzar king of Babylon and into the hand of the Chaldeans. **<sup>26</sup>** And I will hurl you and your mother who bore you into another land, where you were not born, and there you shall die. **<sup>27</sup>** But to the land to which they long to return, there they shall not return.”

**<sup>28</sup>** Is this man Coniah a despised, shattered jar?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is he a vessel no one delights in?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why are he and his children hurled out<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cast into a land that they do not know?<br/>
**<sup>29</sup>** O land, land, land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;hear the word of the LORD!<br/>
**<sup>30</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Write this man down as childless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a man who shall not prosper in his days,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for none of his offspring shall prosper,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;sitting on the throne of David<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ruling again in Judah.”<br/>


## Chapter 23

**<sup>1</sup>** “Woe to the shepherds who destroy and scatter the sheep of my pasture!” declares the LORD. **<sup>2</sup>** Therefore thus says the LORD, the God of Israel, concerning the shepherds who shepherd my people: “You have scattered my flock and driven them away, and you have not attended to them. Behold, I will attend to you for the evil of your deeds—declares the LORD. **<sup>3</sup>** Then I myself will gather the remnant of my flock out of all the lands where I have driven them, and I will bring them back to their fold, and they shall be fruitful and multiply. **<sup>4</sup>** And I will set shepherds over them who will shepherd them, and they shall fear no more, nor be dismayed, nor shall any be missing—declares the LORD.”

**<sup>5</sup>** “The days are coming—declares the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I will raise up for David a righteous Branch,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he shall reign as king and deal wisely,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall execute justice and righteousness in the land.<br/>
**<sup>6</sup>** In his days Judah will be saved,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Israel will dwell securely.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And this is the name by which he will be called:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘The LORD is our righteousness.’”

**<sup>7</sup>** “Therefore, the days are coming—declares the LORD—when they shall no longer say, ‘As the LORD lives, who brought up the people of Israel out of the land of Egypt,’ **<sup>8</sup>** but, ‘As the LORD lives, who brought up and led the offspring of the house of Israel out of the land of the north and out of all the countries where he had driven them.’ Then they shall dwell in their own land.”

**<sup>9</sup>** Concerning the prophets:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My heart is broken within me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all my bones tremble.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am like a drunken man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a man overcome by wine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and because of his holy words.<br/>
**<sup>10</sup>** For the land is full of adulterers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the curse the land mourns,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the pastures of the wilderness are dried up.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their course is evil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their might is not right.<br/>
**<sup>11</sup>** “Both prophet and priest are ungodly;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even in my house I have found their evil—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>12</sup>** Therefore their way shall be to them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like slippery paths in the darkness;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall be driven away and fall in it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will bring disaster upon them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the year of their punishment—declares the LORD.”

**<sup>13</sup>** In the prophets of Samaria I saw an unsavory thing:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they prophesied by Baal<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and led my people Israel astray.<br/>
**<sup>14</sup>** But in the prophets of Jerusalem I have seen a horrible thing:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they commit adultery and walk in lies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they strengthen the hands of evildoers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that no one turns from his evil.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They are all like Sodom to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her inhabitants like Gomorrah.<br/>
**<sup>15</sup>** Therefore thus says the LORD of hosts concerning the prophets:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Behold, I will feed them with bitter food<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and give them poisoned water to drink,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for from the prophets of Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;ungodliness has gone out into all the land.”

**<sup>16</sup>** Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Do not listen to the words of the prophets who prophesy to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;filling you with empty hopes.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They speak visions of their own minds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;not from the mouth of the LORD.<br/>
**<sup>17</sup>** They keep saying to those who despise the word of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘It shall be well with you’;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to everyone who stubbornly follows his own heart, they say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘No disaster shall come upon you.’”<br/>
**<sup>18</sup>** For who has stood in the council of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to see and hear his word,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or who has paid attention to his word and listened?

**<sup>19</sup>** Look! The storm of the LORD!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Wrath has gone forth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a whirling tempest;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it will burst upon the head of the wicked.<br/>
**<sup>20</sup>** The anger of the LORD will not turn back<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until he has executed and accomplished<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the intents of his heart.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In the latter days you will understand it clearly.<br/>
**<sup>21</sup>** “I did not send the prophets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they ran;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I did not speak to them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they prophesied.<br/>
**<sup>22</sup>** But if they had stood in my council,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then they would have proclaimed my words to my people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they would have turned them from their evil way,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the evil of their deeds.”

**<sup>23</sup>** “Am I a God at hand,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“and not a God far away?<br/>
**<sup>24</sup>** Can a man hide himself in secret places<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that I cannot see him?—declares the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do I not fill heaven and earth?—declares the LORD.”

**<sup>25</sup>** “I have heard what the prophets have said who prophesy lies in my name, saying, ‘I have dreamed, I have dreamed!’ **<sup>26</sup>** How long shall there be lies in the heart of the prophets who prophesy lies, and who prophesy the deceit of their own heart, **<sup>27</sup>** who think to make my people forget my name by their dreams that they tell one another, as their fathers forgot my name for Baal? **<sup>28</sup>** Let the prophet who has a dream tell the dream, but let him who has my word speak my word faithfully. What has straw in common with grain?—declares the LORD. **<sup>29</sup>** Is not my word like fire—declares the LORD—and like a hammer that breaks the rock in pieces?

**<sup>30</sup>** Therefore see how I am against the prophets—declares the LORD—who steal my words from one another. **<sup>31</sup>** Behold, I am against the prophets—declares the LORD—who use their tongues and declare, ‘Says the LORD.’ **<sup>32</sup>** Pay attention! I am against those who prophesy lying dreams—declares the LORD—and who tell them and lead my people astray by their lies and their recklessness, when I did not send them or command them. So they do not profit this people at all—declares the LORD.”

**<sup>33</sup>** “When this people, or a prophet, or a priest asks you, ‘What is the burden of the LORD?’ you shall say to them, ‘You are the burden, and I will cast you off—declares the LORD.’ **<sup>34</sup>** And as for the prophet, priest, or anyone of the people who says, ‘The burden of the LORD,’ I will punish that man and his household. **<sup>35</sup>** Thus shall you say, every one to his neighbor and every one to his brother, ‘What has the LORD answered?’ or ‘What has the LORD spoken?’ **<sup>36</sup>** But ‘the burden of the LORD’ you shall mention no more, for the burden is every man’s own word, and you pervert the words of the living God, the LORD of hosts, our God. **<sup>37</sup>** Thus you shall say to the prophet, ‘What has the LORD answered you?’ or ‘What has the LORD spoken?’ **<sup>38</sup>** But if you say, ‘The burden of the LORD,’ thus says the LORD: Because you have said these words, ‘The burden of the LORD,’ when I sent to you, saying, ‘You shall not say, “The burden of the LORD,”’ **<sup>39</sup>** therefore, see how I will surely lift you up and cast you away from my presence, you and the city that I gave to you and your fathers. **<sup>40</sup>** And I will bring upon you everlasting reproach and perpetual shame, which shall not be forgotten.” 

## Chapter 24

**<sup>1</sup>** The LORD showed me, and there were two baskets of figs placed before the temple of the LORD, after Nebuchadnezzar king of Babylon had taken into exile Jeconiah son of Jehoiakim, king of Judah, and the officials of Judah, and the craftsmen and the smiths, and had brought them to Babylon from Jerusalem. **<sup>2</sup>** One basket had very good figs, like first-ripe figs, and the other basket had very bad figs, so bad they could not be eaten.

**<sup>3</sup>** The LORD said to me, “What do you see, Jeremiah?” And I said, “Figs—the good figs are very good, and the bad are very bad, so bad they cannot be eaten.”

**<sup>4</sup>** Then the word of the LORD came to me: **<sup>5</sup>** “Thus says the LORD, the God of Israel: Like these good figs, so I regard as good the exiles of Judah, whom I have sent away from this place to the land of the Chaldeans. **<sup>6</sup>** For I will set my eyes on them for good, and I will bring them back to this land. I will build them up and not pull them down; I will plant them and not uproot them. **<sup>7</sup>** I will give them a heart to know me, that I am the LORD, and they will be my people and I will be their God, for they will return to me with their whole heart.

**<sup>8</sup>** But like the bad figs that are so bad they cannot be eaten, surely thus says the LORD, so I will treat Zedekiah king of Judah, his officials, the remnant of Jerusalem who remain in this land, and those who dwell in the land of Egypt. **<sup>9</sup>** I will make them an object of horror, an evil thing to all the kingdoms of the earth—a reproach, a proverb, a taunt, and a curse, in every place where I drive them. **<sup>10</sup>** I will send the sword, famine, and pestilence against them, until they are destroyed from the land that I gave to them and to their fathers.” 

## Chapter 25

**<sup>1</sup>** The word that came to Jeremiah concerning all the people of Judah in the fourth year of Jehoiakim the son of Josiah, king of Judah, which was the first year of Nebuchadnezzar king of Babylon. **<sup>2</sup>** Which Jeremiah the prophet spoke to all the people of Judah and to all the inhabitants of Jerusalem, saying: **<sup>3</sup>** From the thirteenth year of Josiah the son of Amon, king of Judah, even to this day—these twenty-three years the word of the LORD has come to me; I rose early and spoke to you, and I said: “Turn now, every man from his evil way and from the evil of your deeds, and dwell on the land that the LORD gave to you and to your fathers forever and ever.” **<sup>4</sup>** Yet you have not listened to me, says the LORD, nor inclined your ear to hear. **<sup>5</sup>** And the LORD has sent to you all his servants the prophets, rising early and sending them, but you have not listened and have not inclined your ear to hear. **<sup>6</sup>** They have said, “Turn now, every one from his evil way, and from the evil of your doings, and serve the LORD your God, and you will then dwell in the land that he gave to you and to your fathers”; but you did not come near to me, says the LORD. **<sup>7</sup>** And you have not humbled yourselves, though I corrected you—says the LORD—and you have not spoken of turning from your wicked ways.

**<sup>8</sup>** Therefore thus says the LORD of hosts: “Because you have not listened to my words, **<sup>9</sup>** I will summon all the families of the north,” says the LORD, “and I will call to Nebuchadnezzar king of Babylon, my servant, and bring them against this land, and against its inhabitants, and against all these nations all around; and I will utterly destroy them, and make them an object of horror, and an everlasting ruin. **<sup>10</sup>** And I will bring upon them the calamous shout of a warrior’s war, and against them will be a cry of distress—‘Wedding!’ and ‘Gladness!’ and ‘Bridegroom!’ and ‘Bride!’ and sound of millstones; **<sup>11</sup>** and I will make this whole land a desolation, and its proud ones shall serve the king of Babylon seventy years. **<sup>12</sup>** Then after seventy years are completed, I will punish the king of Babylon, and that nation, says the LORD, for their iniquity, and the land of the Chaldeans; and I will make it a perpetual waste.

**<sup>13</sup>** And I will bring upon that land all my words which I have pronounced against it—all that is written in this book, which Jeremiah prophesied concerning all the nations. **<sup>14</sup>** For many nations and great kings shall serve themselves of them also; so will I repay them according to their deeds and according to the work of their hands.

**<sup>15</sup>** For thus says the LORD, the God of Israel, to me: “Take this cup of the wine of wrath from my hand, and make all the nations to drink of it to whom I send you, **<sup>16</sup>** to wit: Jerusalem and the cities of Judah, and its kings, its princes, and all the people of the land; **<sup>17</sup>** and to the other nations, to whom I send you—even to Elam, and to Moab, and to the children of Ammon, and to all the kings of Tyrus, and to all the kings of Zidon, and to the kings of the coastlands which lie across the sea; **<sup>18</sup>** and to Dedan, and to Tema, and to Buz, and to all who cut the borders of the desert; **<sup>19</sup>** and all the kings of Arabia, and all the kings of the mixed-multitude that dwell in the wilderness; **<sup>20</sup>** and all the kings of Zimri, and all the kings of Elam, and all the kings of Media; **<sup>21</sup>** and all the kings of the north, far and near, one after another, and all the kingdoms of the earth which are on the face of the earth; and the king of Sheshach shall drink after them.” **<sup>22</sup>** You shall say to them: “Thus says the LORD of hosts, the God of Israel: ‘Drink, be drunk, and vomit, and fall and never rise, because of the sword which I will send among you.’ **<sup>23</sup>** And if they refuse to take the cup from your hand to drink, then say to them: ‘Thus says the LORD of hosts: You shall certainly drink! **<sup>24</sup>** For I begin to bring calamity on the city which is called by my name, and you shall be utterly cut off. You shall not be unpunished, for I call for a sword on all the inhabitants of the earth,’ says the LORD of hosts.

**<sup>25</sup>** Thus says the LORD of hosts: “Call for the wailing around, and come, let every man bring a lamentation; **<sup>26</sup>** for the LORD has said, ‘I will slay the young men with the sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the young men and the virgins,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the young men and the old man;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will slay the married man with the sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the sojourner with him.’<br/>
**<sup>27</sup>** ‘And I will bring their dead bodies before the sun and the moon, and set them out for the birds of the air and the beasts of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the flesh of the slain shall be food for the birds of the air, and for the wild beasts of the earth.’<br/>
**<sup>28</sup>** And I will make them drunk in their blood, even as with wine; and with the blood of the slain, of the slaughtered, of the righteous and the wicked, of the king and of the princes, of the mighty of the earth. **<sup>29</sup>** And I will summon a sword against all the inhabitants of the earth,’ says the LORD of hosts.

**<sup>30</sup>** “Proclaim in the cities of Judah, and in the streets of Jerusalem, and say: ‘Beat your breasts, and cry; for the fierce anger of the LORD is not turned back from us.’ **<sup>31</sup>** And say to the nations: ‘Thus says the LORD: “I set my eyes on you for evil, and not for good; and I will give you over to the sword, and to captivity, and to spoil, and to disgrace among the nations to whom you do not know. **<sup>32</sup>** For thus says the LORD of hosts: “Behold, disaster shall go forth from nation to nation, and a great whirlwind shall be raised up from the farthest parts of the earth. **<sup>33</sup>** And the slain of the LORD shall be at that day from one end of the earth even to the other end; they shall not be lamented, or gathered, or buried; they shall be dung on the surface of the ground. **<sup>34</sup>** Wail, shepherds, and cry; and wallow yourselves in the ashes, O leaders of the flock; for the days of your slaughter and of your dispersions are ended; you shall fall like a precious vessel. **<sup>35</sup>** And the shepherds shall have no way to flee, nor the leaders of the flock to escape. **<sup>36</sup>** A voice of the cry of the shepherds, and a wail of the leaders of the flock, for the LORD has plundered their pasture; **<sup>37</sup>** and the peaceable folds are ruined; for the LORD, the LORD of hosts, has struck them with a fierce blow. **<sup>38</sup>** He has left his lair like a lion; because of the fierce anger of the LORD he has left his land; for their land is desolation, because of the fierceness of the LORD’s anger.’” 

## Chapter 26

**<sup>1</sup>** At the beginning of the reign of Jehoiakim the son of Josiah, king of Judah, this word came from the LORD, saying, **<sup>2</sup>** “Thus says the LORD: Stand in the court of the house of the LORD, and speak to all the cities of Judah that come to worship in the house of the LORD all the words that I command you to speak to them; do not hold back a word. **<sup>3</sup>** Perhaps they will listen, and every man turn from his evil way, that I may relent of the disaster which I plan to bring on them because of the evil of their deeds. **<sup>4</sup>** And you shall say to them, ‘Thus says the LORD: If you will not listen to Me, to walk in My law which I have set before you, **<sup>5</sup>** to listen to the words of My servants the prophets, whom I have sent to you again and again, though you have not listened, **<sup>6</sup>** then I will make this house like Shiloh, and I will make this city a curse to all the nations of the earth.’”

**<sup>7</sup>** The priests and the prophets and all the people heard Jeremiah speaking these words in the house of the LORD. **<sup>8</sup>** And when Jeremiah had finished speaking all that the LORD had commanded him to speak to all the people, the priests and the prophets and all the people seized him, saying, “You must surely die! **<sup>9</sup>** Why have you prophesied in the name of the LORD, saying, ‘This house will be like Shiloh, and this city will be desolate, without inhabitant’?” And all the people gathered against Jeremiah in the house of the LORD.

**<sup>10</sup>** When the princes of Judah heard these things, they came up from the king’s house to the house of the LORD and took their seat at the entry of the New Gate of the house of the LORD. **<sup>11</sup>** Then the priests and the prophets spoke to the princes and to all the people, saying, “This man deserves the sentence of death, for he has prophesied against this city, as you have heard with your own ears.”

**<sup>12</sup>** Then Jeremiah spoke to all the princes and to all the people, saying, “The LORD sent me to prophesy against this house and against this city all the words that you have heard. **<sup>13</sup>** Now therefore amend your ways and your deeds, and obey the voice of the LORD your God, and the LORD will relent of the disaster that He has pronounced against you. **<sup>14</sup>** But as for me, as you see, I am in your hand; do with me as is good and right in your eyes. **<sup>15</sup>** Only know for certain that if you put me to death, you will bring innocent blood on yourselves and on this city and on its inhabitants; for truly the LORD has sent me to you to speak all these words in your hearing.”

**<sup>16</sup>** Then the princes and all the people said to the priests and to the prophets, “This man does not deserve the sentence of death, for he has spoken to us in the name of the LORD our God.” **<sup>17</sup>** Then certain of the elders of the land rose up and spoke to all the assembly of the people, saying, **<sup>18</sup>** “Micah of Moresheth prophesied in the days of Hezekiah king of Judah, and he spoke to all the people of Judah, saying, ‘Zion will be plowed as a field, Jerusalem will become heaps of ruins, and the mountain of the house a wooded height.’ **<sup>19</sup>** Did Hezekiah king of Judah and all Judah put him to death? Did he not fear the LORD and entreat the favor of the LORD, and the LORD relented of the disaster which He had pronounced against them? But we are about to bring great disaster on ourselves.”

**<sup>20</sup>** There was also a man who prophesied in the name of the LORD, Uriah the son of Shemaiah from Kiriath-jearim; and he prophesied against this city and against this land in words like those of Jeremiah. **<sup>21</sup>** And when King Jehoiakim, with all his mighty men and all the princes, heard his words, the king sought to put him to death; but when Uriah heard of it, he was afraid and fled and went to Egypt. **<sup>22</sup>** Then King Jehoiakim sent men to Egypt: Elnathan the son of Achbor, and certain men with him, into Egypt. **<sup>23</sup>** They brought Uriah out of Egypt and took him to King Jehoiakim, who struck him down with the sword and cast his dead body into the burial place of the common people.

**<sup>24</sup>** But the hand of Ahikam the son of Shaphan was with Jeremiah, so that he was not given into the hand of the people to be put to death. 

## Chapter 27

**<sup>1</sup>** In the beginning of the reign of Jehoiakim the son of Josiah, king of Judah, this word came to Jeremiah from the LORD, saying, **<sup>2</sup>** Thus says the LORD to me: Make for yourself bands and bars, and put them on your neck. **<sup>3</sup>** And send them to the king of Edom, and to the king of Moab, and to the king of the children of Ammon, and to the king of Tyre, and to the king of Zidon, by the hand of the messengers who come to Jerusalem to Zedekiah king of Judah. **<sup>4</sup>** And command them to say to their masters: Thus says the LORD of hosts, the God of Israel—thus shall you say to your masters: **<sup>5</sup>** I have made the earth, the man, and the beast that are on the face of the earth, by my great power and by my outstretched arm; and I give it to whom it seems good to me. **<sup>6</sup>** And now I have given all these lands into the hand of Nebuchadnezzar king of Babylon, my servant; and even the beasts of the field I have given him to serve him. **<sup>7</sup>** And all the nations shall serve him, and his son, and his son’s son, until the time of his own land comes; then many nations and great kings shall serve themselves of him. **<sup>8</sup>** But the nation and the kingdom that will not serve Nebuchadnezzar king of Babylon, nor put their neck under the yoke of the king of Babylon, that nation I will punish, says the LORD, with sword, famine, and pestilence, until I have consumed them by his hand. **<sup>9</sup>** And you shall not listen to your prophets, or to your diviners, or to your dreamers, or to your soothsayers, or to your sorcerers who speak to you, saying, “You shall not serve the king of Babylon.” **<sup>10</sup>** For they prophesy a lie to you, to remove you far from your land; and I will drive you out, and you will perish. **<sup>11</sup>** But the nation that brings its neck under the yoke of the king of Babylon and serves him, I will let that nation remain in its land, says the LORD; and they shall till it and dwell in it. **<sup>12</sup>** And to Zedekiah king of Judah I spoke according to all these words, saying: Bring your neck under the yoke of the king of Babylon, and serve him and his people, and live. **<sup>13</sup>** Why will you die, you and your people, by sword, by famine, and by pestilence, as the LORD spoke concerning the nation that will not serve the king of Babylon? **<sup>14</sup>** And do not listen to the words of the prophets who say to you, “You shall not serve the king of Babylon,” for they prophesy a lie to you. **<sup>15</sup>** For I did not send them, says the LORD, and they prophesy falsely in my name, to drive you out and to make you perish—you and the prophets who prophesy to you.

**<sup>16</sup>** And to the priests and to all this people I said: Thus says the LORD: Do not listen to the words of your prophets who prophesy to you, saying, “The vessels of the LORD’s house will soon be restored from Babylon”; for they prophesy a lie to you. **<sup>17</sup>** Do not heed them—serve the king of Babylon and live! Why will this city become waste? **<sup>18</sup>** If they are prophets, and if the word of the LORD is with them, let them make intercession for them to the LORD of hosts, that the vessels that remain in the house of the LORD, in the house of the king of Judah, and in Jerusalem, may not go to Babylon. **<sup>19</sup>** For thus says the LORD of hosts concerning the pillars, concerning the sea, concerning the bases, and concerning all the vessels that remain in this city, **<sup>20</sup>** which Nebuchadnezzar king of Babylon did not take away in the captivity of Jeconiah the son of Jehoiakim king of Judah from Jerusalem to Babylon, along with all the nobles of Judah and Jerusalem. **<sup>21</sup>** For thus says the LORD of hosts, the God of Israel, concerning the vessels that remain in the house of the LORD, and in the house of the king of Judah, and in Jerusalem: **<sup>22</sup>** They shall be brought to Babylon, and there they shall be until the day of my visitation; then I will bring them up and restore them to this place. 

## Chapter 28

**<sup>1</sup>** And it happened in that same year, at the beginning of the reign of Zedekiah king of Judah, in the fourth year, in the fifth month, that Hananiah son of Azzur the prophet, who was from Gibeon, spoke to me in the house of the LORD, in the presence of the priests and all the people, saying, **<sup>2</sup>** Thus says the LORD of hosts, the God of Israel: I have broken the yoke of the king of Babylon. **<sup>3</sup>** Within two full years I will bring back to this place all the vessels of the house of the LORD that Nebuchadnezzar king of Babylon took from this place and carried to Babylon. **<sup>4</sup>** And Jeconiah son of Jehoiakim, king of Judah, and all the exiles of Judah who went to Babylon—I will bring them back to this place, says the LORD, for I will break the yoke of the king of Babylon.

**<sup>5</sup>** Then Jeremiah the prophet spoke to Hananiah the prophet in the presence of the priests and in the presence of all the people who were standing in the house of the LORD. **<sup>6</sup>** And Jeremiah the prophet said, Amen! May the LORD do so; may the LORD confirm your words which you have prophesied, to bring back the vessels of the house of the LORD and all the exiles from Babylon to this place. **<sup>7</sup>** Nevertheless, hear now this word that I speak in your ears and in the ears of all the people: **<sup>8</sup>** The prophets who were before me and before you from ancient times prophesied against many lands and against great kingdoms—of war, of evil, and of pestilence. **<sup>9</sup>** The prophet who prophesies of peace—when the word of that prophet comes to pass, then that prophet will be known as one whom the LORD has truly sent.

**<sup>10</sup>** Then Hananiah the prophet took the bar from off the neck of Jeremiah the prophet and broke it. **<sup>11</sup>** And Hananiah spoke in the presence of all the people, saying, Thus says the LORD: In this way will I break the yoke of Nebuchadnezzar king of Babylon from the neck of all the nations within two full years. And Jeremiah the prophet went his way.

**<sup>12</sup>** Then the word of the LORD came to Jeremiah after Hananiah the prophet had broken the bar from off the neck of Jeremiah the prophet, saying, **<sup>13</sup>** Go and say to Hananiah: Thus says the LORD: You have broken bars of wood, but instead you shall make bars of iron. **<sup>14</sup>** For thus says the LORD of hosts, the God of Israel: I have put an iron yoke on the neck of all these nations, that they may serve Nebuchadnezzar king of Babylon; and they shall serve him, and I have even given him the beasts of the field.

**<sup>15</sup>** Then Jeremiah the prophet said to Hananiah the prophet, Listen, Hananiah! The LORD has not sent you, and you have made this nation trust in a lie. **<sup>16</sup>** Therefore thus says the LORD: I am about to send you off the face of the ground; this year you shall die, because you have spoken rebellion against the LORD. **<sup>17</sup>** And Hananiah the prophet died in that same year, in the seventh month. 

## Chapter 29

**<sup>1</sup>** These are the words of the letter that Jeremiah the prophet sent from Jerusalem to the rest of the elders of the exile, and to the priests, and to the prophets, and to all the exiles whom Nebuchadnezzar had taken from Jerusalem to Babylon— **<sup>2</sup>** after King Jeconiah, and the queen mother, and the court officials, and the princes of Judah and Jerusalem, and the craftsmen, and the smiths had departed from Jerusalem— **<sup>3</sup>** by the hand of Elasah son of Shaphan, and Gemariah son of Hilkiah, whom Zedekiah king of Judah sent to Babylon, to Nebuchadnezzar king of Babylon, saying: **<sup>4</sup>** Thus says the LORD of hosts, the God of Israel, to all the exiles whom I sent from Jerusalem to Babylon: **<sup>5</sup>** Build houses and dwell in them, and plant gardens and eat their fruit. **<sup>6</sup>** Take wives and beget sons and daughters; and take wives for your sons and give your daughters to husbands, so that they may bear sons and daughters, and increase there and do not decrease. **<sup>7</sup>** And seek the welfare of the city where I have sent you into exile, and pray to the LORD for it, for in its welfare you shall have welfare. **<sup>8</sup>** For thus says the LORD of hosts, the God of Israel: Do not let your prophets who are among you and your diviners deceive you, and do not listen to the dreams they are dreaming for you, **<sup>9</sup>** for they prophesy falsely to you in my name; I did not send them, declares the LORD.

**<sup>10</sup>** For thus says the LORD: When seventy years for Babylon are fulfilled, I will visit you and will confirm to you my good word, to bring you back to this place. **<sup>11</sup>** For I know the thoughts that I am planning for you, declares the LORD, thoughts of welfare and not of evil, to give you a future and hope. **<sup>12</sup>** Then you will call upon me and come and pray to me, and I will listen to you. **<sup>13</sup>** And you will seek me and find me when you seek me with all your heart. **<sup>14</sup>** And I will let you find me, declares the LORD, and I will restore your fortunes and gather you from all the nations and from all the places where I have driven you, declares the LORD, and I will bring you back to the place from which I sent you into exile.

**<sup>15</sup>** Because you have said, “The LORD has raised up prophets for us in Babylon”— **<sup>16</sup>** thus says the LORD concerning the king who sits on the throne of David, and concerning all the people who dwell in this city, your brothers who did not go with you into exile— **<sup>17</sup>** thus says the LORD of hosts: I am sending against them the sword, the famine, and the pestilence, and I will make them like rotten figs that cannot be eaten because they are so bad, **<sup>18</sup>** and I will pursue them with the sword, with the famine, and with the pestilence, and I will make them a horror to all the kingdoms of the earth, a curse and a desolation and a hissing and a reproach among all the nations where I have driven them, **<sup>19</sup>** because they did not listen to my words, declares the LORD, which I sent to them by my servants the prophets, rising early and sending them, but you did not listen, declares the LORD. **<sup>20</sup>** But you, hear the word of the LORD, all you exiles whom I sent from Jerusalem to Babylon.

**<sup>21</sup>** Thus says the LORD of hosts, the God of Israel, concerning Ahab son of Kolaiah and concerning Zedekiah son of Maaseiah, who prophesy a lie to you in my name: I am giving them into the hand of Nebuchadnezzar king of Babylon, and he shall strike them down before your eyes. **<sup>22</sup>** And this curse shall be taken up by all the exiles of Judah who are in Babylon, saying, “May the LORD make you like Zedekiah and like Ahab, whom the king of Babylon roasted in the fire,” **<sup>23</sup>** because they have done an outrage in Israel, and have committed adultery with the wives of their neighbors, and have spoken a lie in my name which I did not command them. And I, the one who knows and witnesses, am the LORD.

**<sup>24</sup>** And to Shemaiah the Nehelamite you shall speak, saying: **<sup>25</sup>** Thus says the LORD of hosts, the God of Israel: Because you have sent letters in your own name to all the people who are in Jerusalem, and to Zephaniah son of Maaseiah the priest, and to all the priests, saying, **<sup>26</sup>** The LORD has appointed you priest instead of Jehoiada the priest, so that there should be officers in the house of the LORD to put any man who is mad and prophesies into the stocks and into the neck-iron— **<sup>27</sup>** and now, why have you not rebuked Jeremiah of Anathoth, who is prophesying to you? **<sup>28</sup>** For he has sent to us in Babylon, saying, “It will be a long time; build houses and dwell in them, and plant gardens and eat their fruit.” **<sup>29</sup>** And Zephaniah the priest read this letter in the hearing of Jeremiah the prophet. **<sup>30</sup>** Then the word of the LORD came to Jeremiah, saying, **<sup>31</sup>** Send to all the exiles, saying: Thus says the LORD concerning Shemaiah the Nehelamite: Because Shemaiah has prophesied to you, though I did not send him, and has made you trust in a lie, **<sup>32</sup>** therefore thus says the LORD: I am about to punish Shemaiah the Nehelamite and his descendants. He shall not have a man living among this people, and he shall not see the good that I am about to do for my people, declares the LORD, for he has spoken rebellion against the LORD. 

## Chapter 30

**<sup>1</sup>** The word that came to Jeremiah from the LORD, saying: **<sup>2</sup>** Thus says the LORD, the God of Israel: Write for yourself all the words that I have spoken to you in a book. **<sup>3</sup>** For days are coming—declares the LORD—when I will restore the fortunes of my people Israel and Judah, says the LORD, and I will bring them back to the land that I gave to their fathers, and they shall possess it.

**<sup>4</sup>** And these are the words that the LORD spoke concerning Israel and concerning Judah. **<sup>5</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;We have heard a voice of trembling,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of fear and not of peace.<br/>
**<sup>6</sup>** Ask now, and see<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whether a man gives birth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why then do I see every man<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with his hands on his waist like a woman in labor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and every face turned pale?<br/>
**<sup>7</sup>** Alas, for that day is great,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is none like it;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it is a time of distress for Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet he shall be saved from it.

**<sup>8</sup>** And it shall come to pass in that day—declares the LORD of hosts—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I will break his yoke from your neck,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will tear off your bonds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and strangers shall no longer make him serve.<br/>
**<sup>9</sup>** But they shall serve the LORD their God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and David their king,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whom I will raise up for them.

**<sup>10</sup>** And you, do not fear, O Jacob my servant—declares the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not be dismayed, O Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will save you from afar,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your offspring from the land of their captivity.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jacob shall return and be quiet and at ease,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no one shall make him afraid.<br/>
**<sup>11</sup>** For I am with you—declares the LORD—to save you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I will make a full end of all the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;where I scattered you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but of you I will not make a full end;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet I will correct you in due measure,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will not leave you unpunished.

**<sup>12</sup>** For thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your injury is incurable,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your wound is severe.<br/>
**<sup>13</sup>** There is no one to plead your cause;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no healing for your wound,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no remedy for you.<br/>
**<sup>14</sup>** All your lovers have forgotten you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they do not seek you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I have struck you with the blow of an enemy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the chastisement of a cruel one,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because your guilt was great,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your sins were many.<br/>
**<sup>15</sup>** Why do you cry out over your injury?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your pain is incurable.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Because your guilt was great<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your sins were many,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have done these things to you.<br/>
**<sup>16</sup>** Therefore all who devour you shall be devoured,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all your adversaries—all of them—shall go into captivity.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Those who plunder you shall become plunder,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all who prey upon you I will give up for prey.<br/>
**<sup>17</sup>** For I will restore health to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will heal your wounds—declares the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they called you an outcast,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;saying, “This is Zion; no one seeks her.”

**<sup>18</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will restore the fortunes of Jacob’s tents,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have compassion on his dwellings;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the city shall be rebuilt upon its mound,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the palace shall stand where it should.<br/>
**<sup>19</sup>** And thanksgiving shall come out of them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the sound of those who celebrate;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will multiply them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall not be few;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will honor them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall not be low.<br/>
**<sup>20</sup>** And his sons shall be as before,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his congregation shall be established before me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will punish all who oppress them.<br/>
**<sup>21</sup>** And his leader shall be from among him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his ruler shall come out from his midst;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will cause him to draw near, and he shall approach me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for who would pledge his heart to approach me?—declares the LORD.<br/>
**<sup>22</sup>** And you shall be my people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will be your God.

**<sup>23</sup>** Look, the tempest of the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;wrath has gone out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a sweeping storm;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it will burst upon the head of the wicked.<br/>
**<sup>24</sup>** The fierce anger of the LORD will not turn back<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until he has done and accomplished the purposes of his heart.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In the latter days you will understand this.<br/>


## Chapter 31

**<sup>1</sup>** At that time, says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will be the God of all the families of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will be My people.<br/>
**<sup>2</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;A people who survived the sword<br/>
&nbsp;&nbsp;&nbsp;&nbsp;found grace in the wilderness—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel, when I went to give him rest.<br/>
**<sup>3</sup>** The LORD appeared to me from afar:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have loved you with an everlasting love;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore I have drawn you with loyalty.<br/>
**<sup>4</sup>** Again I will build you, and you will be built,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O virgin Israel.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Again you will adorn yourself with tambourines<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and go out in the dances of those who rejoice.<br/>
**<sup>5</sup>** Again you will plant vineyards<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the hills of Samaria;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the planters will plant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will enjoy the fruit.<br/>
**<sup>6</sup>** For a day is coming when watchmen<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will call on the hills of Ephraim:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Arise, let us go up to Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the LORD our God.”

**<sup>7</sup>** For thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Sing with joy for Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and raise shouts for the head of the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;make your praises heard and say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“LORD, save Your people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the remnant of Israel.”<br/>
**<sup>8</sup>** I am going to bring them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the land of the north,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will gather them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the farthest parts of the earth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Among them will be the blind and the lame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the pregnant woman and she who is in labor, together;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a great assembly will return here.<br/>
**<sup>9</sup>** With weeping they will come,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with pleas for mercy I will lead them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will make them walk beside streams of water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on a straight path in which they will not stumble;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am a father to Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Ephraim is My firstborn.<br/>
**<sup>10</sup>** Hear the word of the LORD, O nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and declare it in the far coastlands;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;say, “He who scattered Israel will gather him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will keep him as a shepherd keeps his flock.”<br/>
**<sup>11</sup>** For the LORD has ransomed Jacob<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and has redeemed him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the hand of one stronger than he.<br/>
**<sup>12</sup>** They will come and sing in the height of Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will stream to the goodness of the LORD—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to grain, to wine, and to oil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to the young of the flock and of the herd.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their life will be like a watered garden,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will never again languish.<br/>
**<sup>13</sup>** Then the young woman will rejoice in the dance,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the young men and the old together,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will turn their mourning into joy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will comfort them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and give them gladness for sorrow.<br/>
**<sup>14</sup>** And I will satisfy the soul of the priests with abundance,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and My people will be satisfied with My goodness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.

**<sup>15</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;A voice is heard in Ramah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lamentation and bitter weeping:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Rachel is weeping for her sons;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she refuses to be comforted for her sons,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they are no more.<br/>
**<sup>16</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Restrain your voice from weeping<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your eyes from tears,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for there is a reward for your work,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will return from the land of the enemy.<br/>
**<sup>17</sup>** And there is hope for your future,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your sons will return to their own border.<br/>
**<sup>18</sup>** I have surely heard Ephraim grieving:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“You have disciplined me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I was disciplined<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like an untrained calf.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Turn me back, and I will be turned,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for You are the LORD my God.<br/>
**<sup>19</sup>** For after I turned away, I repented;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and after I came to understand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I struck my thigh.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I was ashamed and even humiliated,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I bore the disgrace of my youth.”<br/>
**<sup>20</sup>** Is Ephraim My dear son?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is he a child of delight?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For as often as I speak against him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I surely still remember him.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Therefore My inner parts yearn for him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will surely have mercy on him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>
**<sup>21</sup>** Set up markers for yourself;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;place guideposts for yourself;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;set your mind on the highway,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the road by which you went.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Return, O virgin Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;return to these your cities.<br/>
**<sup>22</sup>** How long will you wander,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O faithless daughter?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the LORD has created a new thing in the land—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a woman will surround a man.

**<sup>23</sup>** Thus says the LORD of hosts, the God of Israel:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Once more they will speak this word in the land of Judah and in its towns when I restore their fortunes:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“The LORD bless you, O habitation of righteousness, O holy hill.”<br/>
**<sup>24</sup>** And Judah and all its towns will dwell in it together—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the farmers and those who wander with the flocks.<br/>
**<sup>25</sup>** For I will satisfy the weary soul,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and every faint soul I will replenish.<br/>
**<sup>26</sup>** At this I awoke and looked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and my sleep had been pleasant to me.

**<sup>27</sup>** Days are coming, says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I will sow the house of Israel and the house of Judah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the seed of man and the seed of beast.<br/>
**<sup>28</sup>** And it will be that just as I have watched over them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to uproot and to tear down<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to pull down and to destroy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to bring harm,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so I will watch over them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to build and to plant,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>
**<sup>29</sup>** In those days they will no longer say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Fathers have eaten sour grapes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the teeth of the sons are set on edge.”<br/>
**<sup>30</sup>** Instead, each man will die for his own sin;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;every man who eats the sour grapes—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his teeth will be set on edge.

**<sup>31</sup>** Days are coming, says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I will make a new covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with the house of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with the house of Judah,<br/>
**<sup>32</sup>** not like the covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I made with their fathers<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day I took them by the hand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to bring them out of the land of Egypt—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My covenant which they broke,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;though I was a husband to them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>
**<sup>33</sup>** For this is the covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I will make with the house of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;after those days, says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will put My law within them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will write it on their heart.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And I will be their God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will be My people.<br/>
**<sup>34</sup>** And a man will no longer teach his neighbor<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a man his brother, saying, “Know the LORD,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for all of them will know Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the least of them to the greatest of them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will forgive their guilt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will remember their sin no more.

**<sup>35</sup>** Thus says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who gives the sun for light by day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the statutes of the moon and the stars<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for light by night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who stirs up the sea so that its waves roar—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD of hosts is His name:<br/>
**<sup>36</sup>** If these statutes depart from before Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then the seed of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will cease from being a nation before Me forever.<br/>
**<sup>37</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If the heavens above can be measured,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the foundations of the earth below searched out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then I will also reject all the seed of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for all that they have done,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>
**<sup>38</sup>** Days are coming, says the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when the city will be rebuilt for the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the Tower of Hananel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the Corner Gate.<br/>
**<sup>39</sup>** And the measuring line will go out farther,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;straight to the hill of Gareb,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and then it will turn to Goah.<br/>
**<sup>40</sup>** And the whole valley of the corpses and of the ashes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the fields as far as the Wadi Kidron<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the corner of the Horse Gate toward the east,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be holy to the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it will not be uprooted or overthrown again<br/>
&nbsp;&nbsp;&nbsp;&nbsp;forever.<br/>


## Chapter 32

**<sup>1</sup>** The word that came to Jeremiah from the LORD in the tenth year of Zedekiah king of Judah, which was the eighteenth year of Nebuchadnezzar. **<sup>2</sup>** Now Pharaoh’s army had withdrawn from Jerusalem at that time because the Chaldeans had made a raid against Pharaoh’s army at Carchemish on the Euphrates and had routed them. **<sup>3</sup>** Then the word of the LORD came to Jeremiah, while he was shut up in the court of the guard which was in the house of the LORD, saying, **<sup>4</sup>** “Take for yourself evidence of purchase—witnesses, and seal the deed—buy the field for yourself, for the land is given into the hand of the Chaldeans.” **<sup>5</sup>** So Hanamel my uncle’s son came to me in the court of the guard, in accordance with the word of the LORD, and he said to me, “Buy my field which is at Anathoth, for the right of redemption belongs to you; buy it for yourself.” Then I knew that this was the word of the LORD.

**<sup>6</sup>** And I bought the field of Hanamel my uncle’s son, that was in Anathoth, and weighed out the money to him—seventeen shekels of silver. **<sup>7</sup>** And I wrote the deed, and sealed it, and called witnesses, and weighed out the silver on the scales. **<sup>8</sup>** And I took the deed of purchase, both the sealed copy according to the law and the open copy, **<sup>9</sup>** and I gave the deed of purchase to Baruch son of Neriah son of Mahseiah, in the sight of Hanamel my uncle’s son, and in the sight of the witnesses who signed the deed of purchase, before all the Judeans who sat in the court of the guard. **<sup>10</sup>** And I charged Baruch before them, saying, **<sup>11</sup>** “Thus says the LORD of hosts, the God of Israel: Take these deeds, this deed of purchase—both the sealed deed and the open deed—and put them in an earthenware vessel, that they may last many days. **<sup>12</sup>** For thus says the LORD of hosts, the God of Israel: Houses and fields and vineyards shall again be bought in this land.”

**<sup>13</sup>** And I prayed to the LORD, saying, **<sup>14</sup>** “Ah, Lord GOD! You have made the heavens and the earth by your great power and by your outstretched arm; there is nothing too hard for you,

**<sup>15</sup>** who shows steadfast love to thousands, but repays the guilt of fathers into the bosom of their children after them, O great and mighty God, the LORD of hosts, is your name,

**<sup>16</sup>** great in counsel and mighty in deed; whose eyes are open upon all the ways of the sons of man, to give every one according to his ways and according to the fruit of his doings— **<sup>17</sup>** who brought your people Israel out of the land of Egypt with signs and wonders, with a strong hand and an outstretched arm, and with great terror; **<sup>18</sup>** and who gave them this land, which you swore to their fathers to give them—a land flowing with milk and honey; **<sup>19</sup>** and they came in and took possession of it, but they did not obey you or walk in your law; they did nothing of all that you commanded them to do; therefore you have made all this disaster come upon them. **<sup>20</sup>** Look, the siege ramps have come up into the city to take it, and the city is given into the hand of the Chaldeans who fight against it by the sword and by famine and by pestilence; and what you have spoken has come to pass, and you see it. **<sup>21</sup>** Yet you, Lord GOD, said to me, ‘Buy the field for money and call in witnesses, and seal the deed in the sight of many witnesses’—and I thought, ‘This is the word of the LORD.’ ”

**<sup>22</sup>** Then the word of the LORD came to Jeremiah, saying, **<sup>23</sup>** “Thus says the LORD of hosts, the God of Israel: I am the God of all the families of the earth; is anything too hard for me? **<sup>24</sup>** Therefore thus says the LORD: I am about to give this city into the hand of the Chaldeans and into the hand of Nebuchadnezzar king of Babylon, and he will take it; **<sup>25</sup>** and the Chaldeans who fight against this city will come and set this city on fire and burn it, and those houses on whose roofs they offered incense to Baal and poured out drink offerings to other gods, to provoke me to anger.

**<sup>26</sup>** For the sons of Israel and the sons of Judah have only done evil in my sight from their youth; for the sons of Israel have provoked me by the work of their hands, says the LORD. **<sup>27</sup>** For this city has been to me like a provocation and a provoked thing from the day they built it even to this day, that I should remove it from my sight, **<sup>28</sup>** because of all the evil of the sons of Israel and of the sons of Judah, which they have done to provoke me—they, their kings, their princes, their priests, and their prophets, and the men of Judah and the inhabitants of Jerusalem. **<sup>29</sup>** They have turned to me their back and not their face; though I taught them rising early and teaching them, they have not listened to receive instruction. **<sup>30</sup>** But they set their abominations in the house that is called by my name, to defile it. **<sup>31</sup>** And they built the high places of Baal in the Valley of the Son of Hinnom, to cause their sons and their daughters to pass through the fire to Molech, which I did not command them, nor did it enter into my mind that they should do this abomination, in order to cause Judah to sin.

**<sup>32</sup>** “Therefore thus says the LORD, the God of Israel: Now I am about to bring on this city and on all its towns all the disaster that I have declared against it, because they have stiffened their neck and would not listen to my words.” **<sup>33</sup>** The word of the LORD came to Jeremiah, saying, **<sup>34</sup>** “Thus says the LORD: The men who are running away to the land of the Chaldeans shall live; they shall build houses and inhabit them; they shall plant vineyards and eat their fruit. **<sup>35</sup>** And I will bring back the captives of Judah and the captives of Israel; and I will rebuild them as at the first.

**<sup>36</sup>** I will multiply them, and they shall not be diminished; I will make them honored, and they shall not be small. **<sup>37</sup>** Their children also shall be as before, and their congregation shall be established before me, and I will punish all their oppressors. **<sup>38</sup>** And I will grant them possession of the nations, and they shall possess the land with the wealth of the nations; and I will make them to increase in number, and they shall not diminish. **<sup>39</sup>** Thus says the LORD: If the people remain in this land, at the end of the days they will say, ‘The LORD has built up for us the houses that the kings of Judah have destroyed, and he has planted for us vineyards that the princes of Judah have razed.’ **<sup>40</sup>** “Therefore do not pray for this people, nor lift up a cry or prayer for them, nor make intercession to me; for I will not hear you. **<sup>41</sup>** Do you not see what they are doing in the cities of Judah and in the streets of Jerusalem? **<sup>42</sup>** The children gather wood, the fathers kindle the fire, and the women knead dough to make cakes for the queen of heaven; and they pour out drink offerings to other gods that they may provoke me to anger. **<sup>43</sup>** “Do they also provoke me to anger?” says the LORD. “Do they not provoke themselves to the shame of their own faces?” **<sup>44</sup>** Therefore thus says the LORD: I will remove them from this place into the land that they do not know, and I will give them that land as a possession that they did not know, and they shall serve other gods day and night; for I will not show them favor. 

## Chapter 33

**<sup>1</sup>** The word of the LORD came to Jeremiah a second time while he was still confined in the courtyard of the guard, saying, **<sup>2</sup>** Thus says the LORD who fashions it, the LORD who forms it to establish it, whose name is the LORD: **<sup>3</sup>** Call to Me and I will answer you, and I will tell you great and inaccessible things that you do not know. **<sup>4</sup>** For thus says the LORD, the God of Israel, concerning the houses of this city and concerning the houses of the kings of Judah that are torn down to make a defense against the siege ramps and against the sword, **<sup>5</sup>** while they come to fight the Chaldeans and to fill them with the corpses of the men whom I strike down in My anger and in My wrath, for I have hidden My face from this city because of all their evil:

**<sup>6</sup>** Now I am going to bring it healing and cure, and I will heal them and reveal to them an abundance of peace and truth. **<sup>7</sup>** And I will restore the fortunes of Judah and the fortunes of Israel, and I will rebuild them as they were at the beginning. **<sup>8</sup>** And I will cleanse them from all their guilt by which they sinned against Me, and I will forgive all their guilt by which they sinned against Me and by which they rebelled against Me. **<sup>9</sup>** And this city shall become to Me a name of joy, a praise, and a glory before all the nations of the earth, who will hear all the good that I do for them, and they will tremble and quake because of all the good and because of all the peace that I make for it.

**<sup>10</sup>** Thus says the LORD: Again there will be heard in this place of which you say, “It is a waste without man or beast,” in the cities of Judah and in the streets of Jerusalem that are desolate without man and without inhabitant and without beast, **<sup>11</sup>** the sound of gladness and the sound of joy, the voice of the bridegroom and the voice of the bride, the voices of those who say, “Give thanks to the LORD of hosts, for the LORD is good, for His loyalty endures forever,” as they bring thanksgiving offerings into the house of the LORD. For I will restore the fortunes of the land as they were at the beginning, says the LORD.

**<sup>12</sup>** Thus says the LORD of hosts: Again in this place that is waste without man or beast, and in all its towns, there will be a grazing place for shepherds who make their flocks lie down. **<sup>13</sup>** In the towns of the hill country, in the towns of the Shephelah, in the towns of the Negev, in the land of Benjamin, in the surroundings of Jerusalem, and in the towns of Judah, flocks will again pass under the hand of the one who counts them, says the LORD.

**<sup>14</sup>** Look, days are coming, says the LORD, when I will fulfill the good word that I spoke concerning the house of Israel and concerning the house of Judah. **<sup>15</sup>** In those days and at that time I will cause a righteous Branch to spring up for David, and He will execute justice and righteousness in the land. **<sup>16</sup>** In those days Judah will be saved and Jerusalem will dwell securely, and this is what she will be called: The LORD is our righteousness.

**<sup>17</sup>** For thus says the LORD: David shall never lack a man to sit on the throne of the house of Israel, **<sup>18</sup>** and the priests, the Levites, shall never lack a man before Me to offer burnt offering and to burn grain offering and to make sacrifice continually.

**<sup>19</sup>** And the word of the LORD came to Jeremiah, saying, **<sup>20</sup>** Thus says the LORD: If you can break My covenant with the day and My covenant with the night, so that day and night will not arrive in their time, **<sup>21</sup>** then also My covenant with My servant David may be broken, so that he would not have a son reigning on his throne, and with the Levites, the priests, My ministers. **<sup>22</sup>** Just as the host of heaven cannot be counted and the sand of the sea cannot be measured, so I will multiply the seed of David My servant and the Levites who minister to Me.

**<sup>23</sup>** And the word of the LORD came to Jeremiah, saying, **<sup>24</sup>** Have you not noticed what these men speak, saying, “The two families that the LORD chose, He has rejected them”? And they treat My people with contempt, as though they are no longer a nation before them. **<sup>25</sup>** Thus says the LORD: If My covenant with day and night, and the fixed patterns of heaven and earth, could be broken, **<sup>26</sup>** then I too would reject the seed of Jacob and My servant David, so that I would not take from his seed rulers over the seed of Abraham, Isaac, and Jacob. For I will restore their fortunes and will have compassion on them. 

## Chapter 34

**<sup>1</sup>** The word that came to Jeremiah from the LORD when Nebuchadnezzar king of Babylon and all his army and all the kingdoms of the earth under the dominion of his hand and all the nations were fighting against Jerusalem and against all its towns, saying, **<sup>2</sup>** Thus says the LORD, the God of Israel: Go and speak to Zedekiah king of Judah and say to him, “Thus says the LORD: I am giving this city into the hand of the king of Babylon, and he will burn it with fire. **<sup>3</sup>** And you will not escape from his hand, for you will surely be captured and given into his hand, and your eyes will see the eyes of the king of Babylon, and his mouth will speak with your mouth, and you will go to Babylon.” **<sup>4</sup>** Yet hear the word of the LORD, O Zedekiah king of Judah: Thus says the LORD concerning you: “You will not die by the sword. **<sup>5</sup>** You will die in peace, and with the burnings for your fathers, the former kings who were before you, so they will burn spices for you and lament for you, saying, ‘Alas, lord,’ for I have spoken the word, says the LORD.” **<sup>6</sup>** Then Jeremiah the prophet spoke all these words to Zedekiah king of Judah in Jerusalem, **<sup>7</sup>** when the army of the king of Babylon was fighting against Jerusalem and against all the remaining towns of Judah, against Lachish and against Azekah, for these alone remained of the fortified cities of Judah.

**<sup>8</sup>** The word that came to Jeremiah from the LORD after King Zedekiah had made a covenant with all the people who were in Jerusalem to proclaim liberty to them, **<sup>9</sup>** that each man should release his male slave and his female slave, the Hebrew man and the Hebrew woman, so that no man would enslave his brother, a Judean. **<sup>10</sup>** And all the officials and all the people who had entered into the covenant obeyed, that each one would release his male slave and his female slave, and they did not force them to serve any longer; they obeyed and released them. **<sup>11</sup>** But afterward they turned and made the male slaves and the female slaves return, whom they had released, and they forced them to be slaves and to serve.

**<sup>12</sup>** And the word of the LORD came to Jeremiah, saying, **<sup>13</sup>** Thus says the LORD, the God of Israel: “I made a covenant with your fathers on the day that I brought them out of the land of Egypt, from the house of slaves, saying, **<sup>14</sup>** ‘At the end of seven years each man must set free his Hebrew brother who has been sold to you and has served you six years; you must set him free.’ But your fathers did not listen to Me or incline their ear. **<sup>15</sup>** But you had recently turned and done what is right in My sight by proclaiming liberty each man to his neighbor, and you had made a covenant before Me in the house that is called by My name. **<sup>16</sup>** But then you turned and profaned My name, and each man made his male slave and his female slave return, whom you had released to be free as they desired, and you forced them to be slaves and to serve.”

**<sup>17</sup>** Therefore thus says the LORD: “You have not listened to Me by proclaiming liberty each man to his brother and each man to his neighbor. Therefore I am now proclaiming to you liberty—to the sword, to pestilence, and to famine—and I will make you an object of horror to all the kingdoms of the earth. **<sup>18</sup>** And the men who transgressed My covenant, who did not uphold the words of the covenant that they made before Me, I will make like the calf which they cut in two and passed between its parts, **<sup>19</sup>** the officials of Judah and the officials of Jerusalem, the eunuchs, the priests, and all the men of the land who passed between the parts of the calf, **<sup>20</sup>** and I will give them into the hand of their enemies and into the hand of those who seek their life, and their corpses will become food for the birds of the sky and for the beasts of the earth. **<sup>21</sup>** And Zedekiah king of Judah and his officials I will give into the hand of their enemies and into the hand of those who seek their life and into the hand of the army of the king of Babylon, which has withdrawn from you. **<sup>22</sup>** I am giving a command, says the LORD, and I will bring them back to this city, and they will fight against it and capture it and burn it with fire, and I will make the towns of Judah a desolation without inhabitant. 

## Chapter 35

**<sup>1</sup>** The word that came to Jeremiah from the LORD in the days of Jehoiakim son of Josiah, king of Judah, saying, **<sup>2</sup>** “Go to the house of the Rechabites, and speak to them, and bring them into the house of the LORD, into one of the chambers, and give them wine to drink.”

**<sup>3</sup>** So I took Jaazaniah son of Jeremiah, son of Habazziniah, and his brothers, and all his sons, and the whole house of the Rechabites, **<sup>4</sup>** and I brought them into the house of the LORD, into the chamber of the sons of Hanan son of Igdaliah, the man of God, which was beside the chamber of the officials, which was above the chamber of Maaseiah son of Shallum, keeper of the threshold. **<sup>5</sup>** Then I set before the men of the house of the Rechabites bowls full of wine and cups, and I said to them, “Drink wine.”

**<sup>6</sup>** But they said, “We will not drink wine, for Jonadab son of Rechab, our father, commanded us, saying, ‘You shall never drink wine, neither you nor your sons forever. **<sup>7</sup>** And you shall not build a house, and you shall not sow seed, and you shall not plant a vineyard, nor shall you have any, but you shall live in tents all your days, so that you may live many days in the land where you sojourn.’ **<sup>8</sup>** And we have obeyed the voice of Jonadab son of Rechab, our father, in all that he commanded us, by not drinking wine all our days, we, our wives, our sons, and our daughters, **<sup>9</sup>** nor building houses to dwell in, nor having vineyard or field or seed. **<sup>10</sup>** But we have lived in tents, and have obeyed and done according to all that Jonadab our father commanded us. **<sup>11</sup>** But when Nebuchadnezzar king of Babylon came up against the land, we said, ‘Come, let us go to Jerusalem before the army of the Chaldeans and before the army of Aram.’ So we have lived in Jerusalem.”

**<sup>12</sup>** Then the word of the LORD came to Jeremiah, saying, **<sup>13</sup>** “Thus says the LORD of hosts, the God of Israel: Go and say to the men of Judah and the inhabitants of Jerusalem, ‘Will you not receive instruction by listening to my words?—declares the LORD. **<sup>14</sup>** The words of Jonadab son of Rechab, which he commanded his sons not to drink wine, have been carried out, and to this day they drink none, for they obey their father’s command. But I have spoken to you persistently, and you have not listened to me. **<sup>15</sup>** I have sent to you all my servants the prophets, sending them persistently, saying, “Turn now every man from his evil way, and amend your deeds, and do not go after other gods to serve them, and you will dwell in the land that I gave to you and to your fathers.” But you did not incline your ear or listen to me. **<sup>16</sup>** The sons of Jonadab son of Rechab have carried out the command of their father that he commanded them, but this people has not listened to me.’

**<sup>17</sup>** Therefore thus says the LORD, the God of hosts, the God of Israel: I am bringing upon Judah and upon all the inhabitants of Jerusalem every disaster that I have spoken against them, because I have spoken to them, but they would not listen; and I have called to them, but they would not answer.”

**<sup>18</sup>** But to the house of the Rechabites Jeremiah said, “Thus says the LORD of hosts, the God of Israel: Because you have obeyed the command of Jonadab your father, and kept all his precepts, and done according to all that he commanded you, **<sup>19</sup>** therefore thus says the LORD of hosts, the God of Israel: Jonadab son of Rechab shall not lack a man to stand before me forever.” 

## Chapter 36

**<sup>1</sup>** And it came to pass in the fourth year of Jehoiakim son of Josiah, king of Judah, that this word came to Jeremiah from the LORD, saying, **<sup>2</sup>** “Take a scroll and write on it all the words that I have spoken to you against Israel, and against Judah, and against all the nations, from the day I spoke to you, from the days of Josiah even to this day. **<sup>3</sup>** Perhaps the house of Judah will hear all the disaster that I intend to bring upon them, so that every man may turn from his evil way, and I may forgive their iniquity and their sin.”

**<sup>4</sup>** Then Jeremiah called Baruch son of Neriah, and Baruch wrote on a scroll from the mouth of Jeremiah all the words of the LORD that he had spoken to him. **<sup>5</sup>** And Jeremiah commanded Baruch, saying, “I am shut in; I cannot go into the house of the LORD. **<sup>6</sup>** So you go, and on a fast day read in the hearing of the people in the house of the LORD the words of the LORD from the scroll that you wrote from my mouth. You shall also read them in the hearing of all Judah who come in from their cities. **<sup>7</sup>** Perhaps their supplication will fall before the LORD, and every man will turn from his evil way, for great is the anger and the wrath that the LORD has pronounced against this people.” **<sup>8</sup>** So Baruch son of Neriah did according to all that Jeremiah the prophet commanded him, reading from the scroll the words of the LORD in the house of the LORD.

**<sup>9</sup>** Now it came to pass in the fifth year of Jehoiakim son of Josiah, king of Judah, in the ninth month, that all the people in Jerusalem and all the people who came from the cities of Judah to Jerusalem proclaimed a fast before the LORD. **<sup>10</sup>** Then Baruch read from the scroll the words of Jeremiah in the house of the LORD, in the chamber of Gemariah son of Shaphan the scribe, in the upper court, at the entrance of the New Gate of the LORD’s house, in the hearing of all the people.

**<sup>11</sup>** When Micaiah son of Gemariah, son of Shaphan, heard all the words of the LORD from the scroll, **<sup>12</sup>** he went down to the king’s house, into the scribe’s chamber, and all the officials were sitting there: Elishama the scribe, Delaiah son of Shemaiah, Elnathan son of Achbor, Gemariah son of Shaphan, Zedekiah son of Hananiah, and all the officials. **<sup>13</sup>** Then Micaiah told them all the words that he had heard, when Baruch read from the scroll in the hearing of the people. **<sup>14</sup>** So all the officials sent Jehudi son of Nethaniah, son of Shelemiah, son of Cushi, to Baruch, saying, “Take in your hand the scroll from which you read in the hearing of the people, and come.” So Baruch son of Neriah took the scroll in his hand and came to them. **<sup>15</sup>** And they said to him, “Sit down now and read it in our hearing.” So Baruch read it in their hearing.

**<sup>16</sup>** Now it came to pass, when they heard all the words, they turned in fear one to another, and they said to Baruch, “We must surely tell the king all these words.” **<sup>17</sup>** And they asked Baruch, saying, “Tell us now, how did you write all these words? Was it from his mouth?” **<sup>18</sup>** Then Baruch said to them, “He recited all these words to me with his mouth, and I wrote them with ink in the scroll.” **<sup>19</sup>** Then the officials said to Baruch, “Go, hide yourself, you and Jeremiah, and let no one know where you are.”

**<sup>20</sup>** So they went in to the king, into the court, but they had deposited the scroll in the chamber of Elishama the scribe, and they reported all the words in the hearing of the king. **<sup>21</sup>** Then the king sent Jehudi to get the scroll, and he took it from the chamber of Elishama the scribe. And Jehudi read it in the hearing of the king and in the hearing of all the officials who stood beside the king. **<sup>22</sup>** Now the king was sitting in the winter house, in the ninth month, with a fire burning in the brazier before him. **<sup>23</sup>** And it came to pass, when Jehudi had read three or four columns, he cut it with a scribe’s knife and threw it into the fire that was in the brazier, until the whole scroll was consumed in the fire that was in the brazier. **<sup>24</sup>** Yet neither the king nor any of his servants who heard all these words were afraid, nor did they tear their garments. **<sup>25</sup>** Even though Elnathan and Delaiah and Gemariah urged the king not to burn the scroll, he would not listen to them. **<sup>26</sup>** Then the king commanded Jerahmeel the king’s son, and Seraiah son of Azriel, and Shelemiah son of Abdeel, to seize Baruch the scribe and Jeremiah the prophet, but the LORD hid them.

**<sup>27</sup>** Then the word of the LORD came to Jeremiah, after the king had burned the scroll and the words that Baruch had written from the mouth of Jeremiah, saying, **<sup>28</sup>** “Take again another scroll and write on it all the former words that were on the first scroll, which Jehoiakim king of Judah burned. **<sup>29</sup>** And concerning Jehoiakim king of Judah you shall say, ‘Thus says the LORD: You have burned this scroll, saying, “Why have you written in it, saying, The king of Babylon will certainly come and destroy this land and will cause man and beast to cease from it?” **<sup>30</sup>** Therefore thus says the LORD concerning Jehoiakim king of Judah: He shall have no one to sit on the throne of David, and his dead body shall be cast out to the heat by day and the frost by night. **<sup>31</sup>** And I will punish him and his offspring and his servants for their iniquity; and I will bring upon them and upon the inhabitants of Jerusalem and upon the men of Judah all the disaster that I have pronounced against them, but they did not listen.’”

**<sup>32</sup>** Then Jeremiah took another scroll and gave it to Baruch son of Neriah the scribe, who wrote on it from the mouth of Jeremiah all the words of the book that Jehoiakim king of Judah had burned in the fire, and many words like them were added to them. 

## Chapter 37

**<sup>1</sup>** Zedekiah, son of Josiah, whom Nebuchadnezzar king of Babylon made king in the land of Judah, reigned instead of Coniah son of Jehoiakim. **<sup>2</sup>** But neither he nor his servants nor the people of the land listened to the words of the LORD that he spoke through Jeremiah the prophet.

**<sup>3</sup>** King Zedekiah sent Jehucal son of Shelemiah and Zephaniah son of Maaseiah the priest to Jeremiah the prophet, saying, “Please pray to the LORD our God for us.” **<sup>4</sup>** Now Jeremiah was still coming and going among the people, for they had not yet put him in prison. **<sup>5</sup>** Pharaoh’s army had set out from Egypt, and when the Chaldeans who were besieging Jerusalem heard the report about them, they withdrew from Jerusalem.

**<sup>6</sup>** Then the word of the LORD came to Jeremiah the prophet, saying, **<sup>7</sup>** “Thus says the LORD, the God of Israel: This is what you shall say to the king of Judah who sent you to me to inquire of me: ‘The army of Pharaoh, which came out to help you, is going to return to its own land, to Egypt. **<sup>8</sup>** And the Chaldeans will come back and fight against this city; they will capture it and burn it with fire.’ **<sup>9</sup>** Thus says the LORD: Do not deceive yourselves, saying, ‘The Chaldeans will surely go away from us,’ for they will not go. **<sup>10</sup>** Even if you had struck down the whole army of the Chaldeans who are fighting against you, and only wounded men remained among them, every man would rise up in his tent and burn this city with fire.”

**<sup>11</sup>** When the army of the Chaldeans had withdrawn from Jerusalem because of Pharaoh’s army, **<sup>12</sup>** Jeremiah set out from Jerusalem to go to the land of Benjamin to receive his portion there among the people. **<sup>13</sup>** But when he was at the Gate of Benjamin, there was a guard there named Irijah son of Shelemiah, son of Hananiah, and he seized Jeremiah the prophet, saying, “You are going over to the Chaldeans!” **<sup>14</sup>** Jeremiah said, “That is a lie! I am not going over to the Chaldeans.” But Irijah would not listen to him, so he detained Jeremiah and brought him to the officials. **<sup>15</sup>** The officials were enraged with Jeremiah, and they beat him and put him in prison in the house of Jonathan the scribe, for they had made it into a prison.

**<sup>16</sup>** When Jeremiah had come into the dungeon and the cells, and had remained there many days, **<sup>17</sup>** King Zedekiah sent and took him out, and the king questioned him secretly in his house, and said, “Is there any word from the LORD?” Jeremiah said, “There is.” And he said, “You will be handed over to the king of Babylon.” **<sup>18</sup>** Then Jeremiah said to King Zedekiah, “What wrong have I done to you or to your servants or to this people, that you have put me in prison? **<sup>19</sup>** Where are your prophets who prophesied to you, saying, ‘The king of Babylon will not come against you or against this land’? **<sup>20</sup>** So now, please listen, my lord the king: let my plea come before you. Do not send me back to the house of Jonathan the scribe, lest I die there.”

**<sup>21</sup>** Then King Zedekiah commanded, and they placed Jeremiah in the court of the guard, and gave him a loaf of bread daily from the Baker’s Street, until all the bread in the city was gone. So Jeremiah remained in the court of the guard. 

## Chapter 38

**<sup>1</sup>** Shephatiah son of Mattan, Gedaliah son of Pashhur, Jucal son of Shelemiah, and Pashhur son of Malchijah heard the words Jeremiah was speaking to all the people, saying, **<sup>2</sup>** “Thus says the LORD: He who stays in this city will die by the sword, by famine, and by plague; but he who goes out to the Chaldeans will live—he will have his life as spoil and will live. **<sup>3</sup>** Thus says the LORD: This city will certainly be handed over to the army of the king of Babylon, and he will capture it.” **<sup>4</sup>** Then the officials said to the king, “Let this man be put to death, because he is discouraging the soldiers who remain in this city and all the people, by speaking such words to them. For this man is not seeking the welfare of this people, but their harm.” **<sup>5</sup>** So King Zedekiah said, “He is in your hands, for the king can do nothing against you.” **<sup>6</sup>** Then they took Jeremiah and threw him into the cistern of Malchijah, the king’s son, which was in the court of the guard, and let Jeremiah down with ropes. Now in the cistern there was no water, only mud, and Jeremiah sank into the mud.

**<sup>7</sup>** But Ebed-melech the Cushite, a eunuch who was in the king’s house, heard that they had put Jeremiah into the cistern, while the king was sitting in the Gate of Benjamin. **<sup>8</sup>** Ebed-melech went out from the king’s house and spoke to the king, saying, **<sup>9</sup>** “My lord the king, these men have done evil in all that they have done to Jeremiah the prophet, whom they have thrown into the cistern; and he will die there of hunger, for there is no more bread in the city.” **<sup>10</sup>** Then the king commanded Ebed-melech the Cushite, saying, “Take thirty men from here with you and lift Jeremiah the prophet out of the cistern before he dies.” **<sup>11</sup>** So Ebed-melech took the men with him and went into the king’s house to a place under the treasury, and took from there worn-out rags and torn clothes, and let them down by ropes to Jeremiah in the cistern. **<sup>12</sup>** Then Ebed-melech the Cushite said to Jeremiah, “Put these worn-out rags and torn clothes under your armpits under the ropes.” And Jeremiah did so. **<sup>13</sup>** So they pulled Jeremiah up with the ropes and lifted him out of the cistern, and Jeremiah remained in the court of the guard.

**<sup>14</sup>** Then King Zedekiah sent and had Jeremiah the prophet brought to him at the third entrance to the house of the LORD, and the king said to Jeremiah, “I am going to ask you something; do not hide anything from me.” **<sup>15</sup>** Jeremiah said to Zedekiah, “If I tell you, will you not surely put me to death? And if I give you advice, you will not listen to me.” **<sup>16</sup>** So King Zedekiah swore secretly to Jeremiah, saying, “As the LORD lives, who made this life for us, I will not put you to death, nor will I hand you over to these men who seek your life.”

**<sup>17</sup>** Then Jeremiah said to Zedekiah, “Thus says the LORD, the God of hosts, the God of Israel: If you will indeed go out to the officials of the king of Babylon, then you will live, this city will not be burned with fire, and you and your household will live. **<sup>18</sup>** But if you do not go out to the officials of the king of Babylon, then this city will be given into the hand of the Chaldeans, and they will burn it with fire, and you yourself will not escape from their hand.” **<sup>19</sup>** Then King Zedekiah said to Jeremiah, “I am afraid of the Judeans who have deserted to the Chaldeans, lest they hand me over to them and they abuse me.” **<sup>20</sup>** But Jeremiah said, “They will not hand you over. Obey now the voice of the LORD in what I am saying to you, that it may go well with you and your life may be spared. **<sup>21</sup>** But if you refuse to go out, this is the word that the LORD has shown me: **<sup>22</sup>** ‘All the women who are left in the house of the king of Judah will be brought out to the officials of the king of Babylon, and they will say, “Your trusted friends have misled you and have prevailed against you; your feet have sunk in the mud, and they turned away.” **<sup>23</sup>** They will bring out all your wives and your sons to the Chaldeans, and you yourself will not escape from their hand, but will be seized by the hand of the king of Babylon, and you will cause this city to be burned with fire.’”

**<sup>24</sup>** Then Zedekiah said to Jeremiah, “Let no man know of these words, and you will not die. **<sup>25</sup>** But if the officials hear that I have spoken with you and come to you and say to you, ‘Tell us now what you said to the king and what the king said to you; do not hide it from us, and we will not put you to death,’ **<sup>26</sup>** then you shall say to them, ‘I was presenting my petition before the king, that he would not send me back to the house of Jonathan to die there.’” **<sup>27</sup>** Then all the officials came to Jeremiah and questioned him, and he told them according to all these words that the king had commanded; so they stopped speaking with him, for the matter had not been overheard. **<sup>28</sup>** And Jeremiah remained in the court of the guard until the day Jerusalem was captured. 

## Chapter 39

**<sup>1</sup>** In the ninth year of Zedekiah king of Judah, in the tenth month, Nebuchadnezzar king of Babylon and all his army came to Jerusalem and besieged it. **<sup>2</sup>** In the eleventh year of Zedekiah, in the fourth month, on the ninth day of the month, the city wall was breached. **<sup>3</sup>** Then all the officials of the king of Babylon came and sat in the Middle Gate: Nergal-sar-ezer, Samgar-nebo, Sarsekim the chief official, Nergal-sar-ezer the Rab-mag, and all the rest of the officials of the king of Babylon. **<sup>4</sup>** When Zedekiah, king of Judah, and all the soldiers saw them, they fled and went out from the city by night by way of the king’s garden through the gate between the two walls; and he went out toward the Arabah. **<sup>5</sup>** But the army of the Chaldeans pursued them, and they overtook Zedekiah in the plains of Jericho. They captured him and brought him up to Nebuchadnezzar, king of Babylon, at Riblah in the land of Hamath, and he passed sentence on him. **<sup>6</sup>** Then the king of Babylon slaughtered the sons of Zedekiah before his eyes at Riblah; the king of Babylon also slaughtered all the nobles of Judah. **<sup>7</sup>** He then put out Zedekiah’s eyes and bound him with bronze chains to bring him to Babylon.

**<sup>8</sup>** The Chaldeans burned the king’s house and the house of the people with fire and broke down the walls of Jerusalem. **<sup>9</sup>** As for the rest of the people who were left in the city, the deserters who had gone over to him, and the rest of the people who remained, Nebuzaradan the captain of the guard carried them into exile to Babylon. **<sup>10</sup>** But some of the poorest of the people, who had nothing, Nebuzaradan the captain of the guard left in the land of Judah, and gave them vineyards and fields on that day.

**<sup>11</sup>** Now Nebuchadnezzar king of Babylon gave orders concerning Jeremiah through Nebuzaradan the captain of the guard, saying, **<sup>12</sup>** “Take him and look after him, and do him no harm; but whatever he says to you, do for him.” **<sup>13</sup>** So Nebuzaradan the captain of the guard, Nebushazban the chief official, Nergal-sar-ezer the Rab-mag, and all the leading officers of the king of Babylon **<sup>14</sup>** sent and took Jeremiah out of the court of the guard and entrusted him to Gedaliah son of Ahikam, son of Shaphan, to take him home. So he remained among the people.

**<sup>15</sup>** Now the word of the LORD came to Jeremiah while he was shut up in the court of the guard, saying, **<sup>16</sup>** “Go and speak to Ebed-melech the Cushite, saying, ‘Thus says the LORD of hosts, the God of Israel: I am about to bring my words upon this city for disaster and not for good, and they will come true before you on that day. **<sup>17</sup>** But I will deliver you on that day,’ declares the LORD, ‘and you will not be given into the hand of the men of whom you are afraid. **<sup>18</sup>** For I will surely rescue you, and you will not fall by the sword, but you will have your life as spoil, because you have trusted in me,’ declares the LORD.” 

## Chapter 40

**<sup>1</sup>** The word that came to Jeremiah from the LORD after Nebuzaradan the captain of the guard had released him from Ramah, when he had taken him bound in chains among all the exiles of Jerusalem and Judah who were being exiled to Babylon. **<sup>2</sup>** The captain of the guard took Jeremiah and said to him, “The LORD your God decreed this disaster upon this place, **<sup>3</sup>** and the LORD has brought it about and done as he said, because you sinned against the LORD and did not listen to his voice. Therefore this thing has happened to you. **<sup>4</sup>** But now, look, I am freeing you today from the chains that are on your hands. If it seems good to you to come with me to Babylon, come, and I will look after you well; but if it seems wrong to you to come with me to Babylon, stay here. See, all the land is before you; go wherever it seems good and right for you to go.” **<sup>5</sup>** While he had not yet turned back, he said, “Return then to Gedaliah son of Ahikam, son of Shaphan, whom the king of Babylon has appointed over the cities of Judah, and stay with him among the people, or go wherever it seems right for you to go.” So the captain of the guard gave him provisions and a gift and let him go. **<sup>6</sup>** Then Jeremiah went to Gedaliah son of Ahikam at Mizpah and stayed with him among the people who were left in the land.

**<sup>7</sup>** When all the commanders of the forces who were in the field, they and their men, heard that the king of Babylon had appointed Gedaliah son of Ahikam over the land, and had put him in charge of men, women, and children, and some of the poorest of the land who had not been exiled to Babylon, **<sup>8</sup>** they came to Gedaliah at Mizpah—namely Ishmael son of Nethaniah, Johanan and Jonathan sons of Kareah, Seraiah son of Tanhumeth, the sons of Ephai the Netophathite, and Jezaniah son of the Maacathite, they and their men. **<sup>9</sup>** Gedaliah son of Ahikam, son of Shaphan, swore to them and to their men, saying, “Do not be afraid to serve the Chaldeans. Stay in the land and serve the king of Babylon, and it will go well with you. **<sup>10</sup>** As for me, I will stay in Mizpah to represent you before the Chaldeans who come to us; but you, gather wine, summer fruit, and oil, and store them in your vessels, and live in your cities that you have taken.”

**<sup>11</sup>** Likewise, when all the Jews who were in Moab and among the sons of Ammon and in Edom and in all the lands heard that the king of Babylon had left a remnant of Judah, and that he had set over them Gedaliah son of Ahikam, son of Shaphan, **<sup>12</sup>** then all the Jews returned from all the places to which they had been scattered, and came to the land of Judah, to Gedaliah at Mizpah, and gathered wine and summer fruit in great abundance.

**<sup>13</sup>** Now Johanan son of Kareah and all the commanders of the forces who were in the field came to Gedaliah at Mizpah **<sup>14</sup>** and said to him, “Do you know that Baalis, king of the sons of Ammon, has sent Ishmael son of Nethaniah to take your life?” But Gedaliah son of Ahikam did not believe them. **<sup>15</sup>** Then Johanan, son of Kareah, spoke secretly to Gedaliah in Mizpah, saying, “Let me go and kill Ishmael son of Nethaniah, and no one will know. Why should he take your life, so that all the Jews who have gathered to you would be scattered and the remnant of Judah perish?” **<sup>16</sup>** But Gedaliah son of Ahikam said to Johanan son of Kareah, “Do not do this thing, for you are speaking falsely about Ishmael.” 

## Chapter 41

**<sup>1</sup>** In the seventh month Ishmael son of Nethaniah, son of Elishama, of the royal family and one of the chief officers of the king, came with ten men to Gedaliah son of Ahikam at Mizpah. While they were eating bread together there at Mizpah, **<sup>2</sup>** Ishmael son of Nethaniah and the ten men who were with him arose and struck down Gedaliah son of Ahikam, son of Shaphan, with the sword, and put to death the one whom the king of Babylon had appointed over the land. **<sup>3</sup>** Ishmael also struck down all the Jews who were with him, that is, with Gedaliah at Mizpah, as well as the Chaldean soldiers who were found there.

**<sup>4</sup>** Now it came about the next day, after Gedaliah had been killed, before anyone knew of it, **<sup>5</sup>** that eighty men came from Shechem, from Shiloh, and from Samaria, with their beards shaved and their clothes torn, and their bodies gashed, bringing grain offerings and incense to present at the house of the LORD. **<sup>6</sup>** Then Ishmael, son of Nethaniah, went out from Mizpah to meet them, weeping as he came. As he met them, he said to them, “Come to Gedaliah son of Ahikam.” **<sup>7</sup>** Yet when they came into the city, Ishmael son of Nethaniah and the men who were with him slaughtered them and threw them into a cistern. **<sup>8</sup>** But ten men were found among them who said to Ishmael, “Do not put us to death, for we have stores of wheat, barley, oil, and honey hidden in the field.” So he refrained and did not kill them among their brothers. **<sup>9</sup>** Now the cistern into which Ishmael had thrown all the dead bodies of the men whom he had struck down because of Gedaliah was the one that King Asa had made on account of Baasha king of Israel; Ishmael son of Nethaniah filled it with the slain. **<sup>10</sup>** Then Ishmael took captive all the rest of the people who were in Mizpah—the king’s daughters and all the people who were left at Mizpah, whom Nebuzaradan the captain of the guard had committed to Gedaliah son of Ahikam—and Ishmael son of Nethaniah took them captive and set out to cross over to the sons of Ammon.

**<sup>11</sup>** But when Johanan son of Kareah and all the commanders of the forces who were with him heard of all the evil that Ishmael son of Nethaniah had done, **<sup>12</sup>** they took all their men and went to fight with Ishmael son of Nethaniah, and they found him by the great pool that is in Gibeon. **<sup>13</sup>** Now when all the people who were with Ishmael saw Johanan, son of Kareah, and all the commanders of the forces who were with him, they were glad. **<sup>14</sup>** So all the people whom Ishmael had taken captive from Mizpah turned around and came back and went to Johanan, son of Kareah. **<sup>15</sup>** But Ishmael, son of Nethaniah, escaped from Johanan with eight men and went to the sons of Ammon.

**<sup>16</sup>** Then Johanan son of Kareah and all the commanders of the forces who were with him took from Mizpah all the rest of the people whom he had recovered from Ishmael son of Nethaniah, after he had struck down Gedaliah son of Ahikam; mighty men of war, women, children, and eunuchs whom he had brought back from Gibeon; **<sup>17</sup>** and they went and stayed at Geruth Chimham, which is near Bethlehem, intending to go to Egypt **<sup>18</sup>** because of the Chaldeans; for they were afraid of them, since Ishmael son of Nethaniah had struck down Gedaliah, son of Ahikam, whom the king of Babylon had appointed over the land. 

## Chapter 42

**<sup>1</sup>** Then all the commanders of the forces, and Johanan son of Kareah, and Jezaniah son of Hoshaiah, and all the people from the least to the greatest approached **<sup>2</sup>** and said to Jeremiah the prophet, “Let our plea for mercy come before you, and pray to the LORD your God for us, for all this remnant, because we are left but a few out of many, as your eyes now see us, **<sup>3</sup>** that the LORD your God may tell us the way we should go and the things that we should do.” **<sup>4</sup>** Jeremiah the prophet said to them, “I have heard you. I will pray to the LORD your God according to your words, and whatever the LORD answers you I will declare to you; I will keep nothing back from you.” **<sup>5</sup>** Then they said to Jeremiah, “May the LORD be a true and faithful witness against us if we do not act according to every word with which the LORD your God sends you to us. **<sup>6</sup>** Whether it is good or evil, we will obey the voice of the LORD our God to whom we are sending you, that it may go well with us when we obey the voice of the LORD our God.”

**<sup>7</sup>** At the end of ten days the word of the LORD came to Jeremiah. **<sup>8</sup>** Then he called Johanan son of Kareah, and all the commanders of the forces who were with him, and all the people from the least to the greatest, **<sup>9</sup>** and said to them, “Thus says the LORD, the God of Israel, to whom you sent me to present your plea before Him: **<sup>10</sup>** ‘If you will remain in this land, then I will build you up and not tear you down; I will plant you and not pluck you up, for I relent of the disaster that I have brought upon you. **<sup>11</sup>** Do not be afraid of the king of Babylon, of whom you are afraid. Do not fear him,’ declares the LORD, ‘for I am with you to save you and to deliver you from his hand. **<sup>12</sup>** And I will grant you mercy, that he may have mercy on you and let you remain in your own land.’

**<sup>13</sup>** But if you say, ‘We will not remain in this land,’ disobeying the voice of the LORD your God, **<sup>14</sup>** saying, ‘No, we will go to the land of Egypt, where we will not see war or hear the sound of the trumpet or be hungry for bread, and there we will dwell,’ **<sup>15</sup>** then hear the word of the LORD, O remnant of Judah. Thus says the LORD of hosts, the God of Israel: ‘If you indeed set your faces to enter Egypt and go to sojourn there, **<sup>16</sup>** then the sword that you fear shall overtake you there in the land of Egypt, and the famine of which you are afraid shall follow close after you to Egypt, and there you shall die. **<sup>17</sup>** All the men who set their faces to go to Egypt to sojourn there shall die by the sword, by famine, and by pestilence; they shall have no remnant or survivor from the disaster that I will bring upon them.’

**<sup>18</sup>** For thus says the LORD of hosts, the God of Israel: ‘As My anger and My wrath were poured out on the inhabitants of Jerusalem, so My wrath shall be poured out on you when you go to Egypt. You shall become a curse, a horror, a reproach, and a disgrace; you shall see this place no more.’ **<sup>19</sup>** The LORD has said concerning you, O remnant of Judah, ‘Do not go to Egypt.’ You should clearly know that I have warned you this day. **<sup>20</sup>** For you have deceived yourselves when you sent me to the LORD your God, saying, ‘Pray for us to the LORD our God, and whatever the LORD our God says, declare to us and we will do it.’ **<sup>21</sup>** And I have declared it to you this day, but you have not obeyed the voice of the LORD your God in anything that He sent me to tell you. **<sup>22</sup>** Now therefore, know for certain that you shall die by the sword, by famine, and by pestilence in the place where you desire to go to sojourn.” 

## Chapter 43

**<sup>1</sup>** When Jeremiah finished speaking to all the people all the words of the LORD their God, with which the LORD their God had sent him to them, all these words, **<sup>2</sup>** Azariah son of Hoshaiah and Johanan son of Kareah and all the proud men said to Jeremiah, “You are speaking a lie! The LORD our God has not sent you to say, ‘You must not go to Egypt to reside there.’ **<sup>3</sup>** But Baruch son of Neriah is inciting you against us, to hand us over to the Chaldeans, so that they may put us to death or take us into exile to Babylon.” **<sup>4</sup>** So Johanan son of Kareah and all the commanders of the forces and all the people did not obey the voice of the LORD, to stay in the land of Judah. **<sup>5</sup>** Instead Johanan son of Kareah and all the commanders of the forces took the entire remnant of Judah who had returned from all the nations to which they had been driven, to reside in the land of Judah; **<sup>6</sup>** the men, the women, the children, the king’s daughters, and every person that Nebuzaradan the captain of the guard had left with Gedaliah son of Ahikam, son of Shaphan, and Jeremiah the prophet and Baruch son of Neriah; **<sup>7</sup>** and they went to the land of Egypt, for they did not obey the voice of the LORD. And they came to Tahpanhes.

**<sup>8</sup>** Then the word of the LORD came to Jeremiah in Tahpanhes, saying, **<sup>9</sup>** “Take in your hands large stones and hide them in the mortar of the brick terrace that is at the entrance of Pharaoh’s house in Tahpanhes, in the sight of the men of Judah, **<sup>10</sup>** and say to them, ‘Thus says the LORD of hosts, the God of Israel: I am sending for Nebuchadnezzar king of Babylon, my servant, and I will set his throne over these stones that I have hidden, and he will spread his canopy over them. **<sup>11</sup>** He will come and strike the land of Egypt: those destined for death, to death; those destined for captivity, to captivity; and those destined for the sword, to the sword. **<sup>12</sup>** And I will kindle a fire in the temples of the gods of Egypt, and he will burn them and carry them away. He will wrap himself with the land of Egypt as a shepherd wraps himself with his garment, and he will depart from there in peace. **<sup>13</sup>** He will also shatter the pillars of Beth-shemesh that are in the land of Egypt, and he will burn the temples of the gods of Egypt with fire.’” 

## Chapter 44

**<sup>1</sup>** The word that came to Jeremiah concerning all the Jews living in the land of Egypt, those living in Migdol, in Tahpanhes, in Noph, and in the land of Pathros, saying, **<sup>2</sup>** “Thus says the LORD of hosts, the God of Israel: You have seen all the disaster that I brought on Jerusalem and on all the cities of Judah, and they are this day a ruin, and no one lives in them, **<sup>3</sup>** because of their evil which they committed to provoke me to anger, by going to burn incense and to serve other gods that they had not known, neither they, nor you, nor your fathers. **<sup>4</sup>** Yet I sent to you all my servants the prophets, rising early and sending them, saying, ‘Do not do this abominable thing that I hate.’ **<sup>5</sup>** But they did not listen or incline their ear to turn from their evil, to stop burning incense to other gods. **<sup>6</sup>** So my wrath and my anger were poured out and burned in the cities of Judah and in the streets of Jerusalem, and they have become a ruin and a desolation, as they are this day.

**<sup>7</sup>** “Now thus says the LORD, the God of hosts, the God of Israel: Why are you committing this great evil against yourselves, cutting off man and woman, child and infant, from the midst of Judah, leaving yourselves no remnant, **<sup>8</sup>** provoking me to anger with the works of your hands, burning incense to other gods in the land of Egypt, where you have come to reside, that you might be cut off and become a curse and a reproach among all the nations of the earth? **<sup>9</sup>** Have you forgotten the wickedness of your fathers, the wickedness of the kings of Judah, the wickedness of their wives, your own wickedness, and the wickedness of your wives, which they committed in the land of Judah and in the streets of Jerusalem? **<sup>10</sup>** To this day they have not humbled themselves, nor have they feared, nor walked in my law or in my statutes that I set before you and before your fathers.

**<sup>11</sup>** “Therefore thus says the LORD of hosts, the God of Israel: I am setting my face against you for disaster and for cutting off all Judah. **<sup>12</sup>** And I will take the remnant of Judah who have set their faces to go into the land of Egypt to reside there, and they will all be consumed. In the land of Egypt they will fall; they will be consumed by the sword and by famine. From the least to the greatest they will die by the sword and by famine, and they will become a curse, a horror, a reproach, and a disgrace. **<sup>13</sup>** For I will punish those who live in the land of Egypt just as I have punished Jerusalem, with the sword, with famine, and with pestilence. **<sup>14</sup>** So none of the remnant of Judah who have gone into the land of Egypt to reside there will escape or survive, to return to the land of Judah to which they long to return to dwell there; for none will return except a few fugitives.”

**<sup>15</sup>** Then all the men who knew that their wives were burning incense to other gods, and all the women who stood by, a large assembly, and all the people who lived in the land of Egypt, in Pathros, answered Jeremiah, saying, **<sup>16</sup>** “As for the word that you have spoken to us in the name of the LORD, we will not listen to you. **<sup>17</sup>** Instead, we will certainly do everything we have vowed: we will burn incense to the queen of heaven and pour out drink offerings to her, just as we, our fathers, our kings, and our officials did in the cities of Judah and in the streets of Jerusalem; for then we had plenty of food, we were well, and saw no disaster. **<sup>18</sup>** But since we stopped burning incense to the queen of heaven and pouring out drink offerings to her, we have lacked everything and have been consumed by the sword and by famine.”

**<sup>19</sup>** And the women said, “When we burned incense to the queen of heaven and poured out drink offerings to her, did we make cakes in her image and pour out drink offerings to her without our husbands’ approval?”

**<sup>20</sup>** Then Jeremiah said to all the people, to the men and to the women, to all the people who had given him that answer, **<sup>21</sup>** “The incense that you burned in the cities of Judah and in the streets of Jerusalem; you and your fathers, your kings, your officials, and the people of the land; did not the LORD remember it, and did it not come into his mind? **<sup>22</sup>** So the LORD could no longer bear it, because of the evil of your deeds and because of the abominations which you committed; therefore your land has become a ruin, a desolation, and a curse, without inhabitant, as it is this day. **<sup>23</sup>** Because you have burned incense and sinned against the LORD and have not obeyed the voice of the LORD or walked in his law, his statutes, or his testimonies, therefore this disaster has happened to you, as it is this day.”

**<sup>24</sup>** Then Jeremiah said to all the people and to all the women, “Hear the word of the LORD, all Judah who are in the land of Egypt. **<sup>25</sup>** Thus says the LORD of hosts, the God of Israel: You and your wives have both spoken with your mouths and fulfilled it with your hands, saying, ‘We will certainly perform our vows that we have vowed, to burn incense to the queen of heaven and to pour out drink offerings to her.’ Go ahead, then, confirm your vows and perform your vows! **<sup>26</sup>** Nevertheless hear the word of the LORD, all Judah who dwell in the land of Egypt: ‘I have sworn by my great name,’ says the LORD, ‘that my name will no more be invoked by the mouth of any man of Judah in all the land of Egypt, saying, “As the Lord GOD lives.” **<sup>27</sup>** Watch, for I am watching over them for disaster and not for good, and all the men of Judah who are in the land of Egypt will be consumed by the sword and by famine until there is an end of them. **<sup>28</sup>** Yet a few who escape the sword will return from the land of Egypt to the land of Judah, few in number; and all the remnant of Judah who have gone into the land of Egypt to reside there will know whose word will stand: mine or theirs.’

**<sup>29</sup>** “And this will be the sign to you,” declares the LORD, “that I am about to punish you in this place, so that you may know that my words will surely stand against you for disaster.” **<sup>30</sup>** Thus says the LORD: “I am going to give Pharaoh Hophra king of Egypt into the hand of his enemies and into the hand of those who seek his life, just as I gave Zedekiah king of Judah into the hand of Nebuchadnezzar king of Babylon, his enemy who sought his life.” 

## Chapter 45

**<sup>1</sup>** The word that Jeremiah the prophet spoke to Baruch son of Neriah, when he wrote these words in a book at Jeremiah’s dictation, in the fourth year of Jehoiakim son of Josiah, king of Judah, saying, **<sup>2</sup>** “Thus says the LORD, the God of Israel, to you, O Baruch: **<sup>3</sup>** You said, ‘Woe is me now! For the LORD has added sorrow to my pain; I am weary with my groaning, and I find no rest.’ **<sup>4</sup>** You shall say to him, ‘Thus says the LORD: What I have built I am about to tear down, and what I have planted I am about to uproot; that is, the whole land. **<sup>5</sup>** And do you seek great things for yourself? Do not seek them; for I am about to bring disaster on all flesh,’ declares the LORD, ‘but I will give you your life as spoil wherever you go.’” 

## Chapter 46

**<sup>1</sup>** The word of the LORD that came to Jeremiah the prophet concerning the nations.

**<sup>2</sup>** Concerning Egypt: about the army of Pharaoh Neco king of Egypt, which was by the river Euphrates at Carchemish, which Nebuchadnezzar king of Babylon defeated in the fourth year of Jehoiakim son of Josiah, king of Judah. **<sup>3</sup>** “Prepare shield and buckler, and advance to battle! **<sup>4</sup>** Harness the horses, mount the steeds, take your positions with helmets on! Polish the spears, put on armor! **<sup>5</sup>** Why have I seen it? They are terrified, they are retreating, and their mighty men are beaten down. They flee in haste and do not look back—terror on every side!—declares the LORD. **<sup>6</sup>** Let not the swift flee away, nor the mighty man escape; in the north by the river Euphrates they have stumbled and fallen.

**<sup>7</sup>** Who is this rising like the Nile, like rivers whose waters surge? **<sup>8</sup>** Egypt rises like the Nile, and like rivers whose waters surge, and he says, ‘I will rise, I will cover the earth, I will destroy cities and their inhabitants.’ **<sup>9</sup>** Advance, horses, and drive wildly, chariots! Let the mighty men come out: Cush and Put, who handle the shield, and the Ludim, who handle and bend the bow.

**<sup>10</sup>** That day belongs to the Lord, the LORD of hosts, a day of vengeance, to avenge himself on his foes. The sword will devour and be sated, and drink its fill of their blood; for the Lord, the LORD of hosts, holds a sacrifice in the land of the north, by the river Euphrates. **<sup>11</sup>** Go up to Gilead and take balm, O virgin daughter of Egypt! In vain you multiply remedies; there is no healing for you. **<sup>12</sup>** The nations have heard of your shame, and the earth is full of your cry; for warrior has stumbled against warrior, they have both fallen together.”

**<sup>13</sup>** The word that the LORD spoke to Jeremiah the prophet concerning the coming of Nebuchadnezzar king of Babylon to strike the land of Egypt: **<sup>14</sup>** “Declare in Egypt, proclaim in Migdol, proclaim in Noph and in Tahpanhes; say, ‘Stand firm and prepare yourself, for the sword has devoured all around you.’ **<sup>15</sup>** Why are your mighty ones cast down? They do not stand, because the LORD has thrust them down. **<sup>16</sup>** He made many stumble, and they fell one against another, and they said, ‘Rise, and let us go back to our own people and to our native land, away from the sword of the oppressor!’ **<sup>17</sup>** They cried there, ‘Pharaoh king of Egypt is but a noise; he has let the appointed time pass by.’

**<sup>18</sup>** “As I live,” declares the King, whose name is the LORD of hosts, “surely one shall come like Tabor among the mountains and like Carmel by the sea. **<sup>19</sup>** Pack your baggage for exile, O inhabitant daughter of Egypt, for Noph shall become a desolation, without inhabitant. **<sup>20</sup>** Egypt is a beautiful heifer, but a gadfly from the north is coming against her. **<sup>21</sup>** Even her mercenaries in her midst are like fattened calves, for they too have turned and fled together; they did not stand, for the day of their calamity has come upon them, the time of their punishment. **<sup>22</sup>** Her sound is like that of a serpent as they go; for they march with an army and come against her with axes like those who cut wood. **<sup>23</sup>** They cut down her forest,” declares the LORD, “though it is impenetrable, for they are more numerous than locusts and cannot be counted. **<sup>24</sup>** The daughter of Egypt is put to shame; she is given into the hand of the people from the north.”

**<sup>25</sup>** The LORD of hosts, the God of Israel, says: “I am about to punish Amon of Thebes, Pharaoh, Egypt, her gods, and her kings—Pharaoh and those who trust in him. **<sup>26</sup>** I will give them into the hand of those who seek their lives, into the hand of Nebuchadnezzar king of Babylon and into the hand of his servants; but afterward Egypt shall be inhabited as in days of old,” declares the LORD.

**<sup>27</sup>** “But you, fear not, O my servant Jacob,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not be dismayed, O Israel.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I will save you from afar<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your offspring from the land of their captivity.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jacob shall return and have quiet and ease,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and none shall make him afraid.

**<sup>28</sup>** Fear not, O Jacob my servant,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“for I am with you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I will make a full end of all the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to which I have driven you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but of you I will not make a full end.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will discipline you with justice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will by no means leave you unpunished.”<br/>


## Chapter 47

**<sup>1</sup>** The word of the LORD that came to Jeremiah the prophet concerning the Philistines, before Pharaoh struck Gaza.

**<sup>2</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Waters are rising out of the north,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will become an overflowing torrent;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will overflow the land and all that fills it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the city and those who dwell in it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then men will cry out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and every inhabitant of the land will wail.

**<sup>3</sup>** At the sound of the stamping hooves of his strong horses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the rumbling of his chariots,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the noise of his wheels,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;fathers will not look back for their children,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because their hands are feeble,<br/>
**<sup>4</sup>** because of the day that is coming<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to destroy all the Philistines,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to cut off from Tyre and Sidon<br/>
&nbsp;&nbsp;&nbsp;&nbsp;every helper that remains.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the LORD is destroying the Philistines,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the remnant from the coastland of Caphtor.

**<sup>5</sup>** Baldness has come upon Gaza,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Ashkelon has been ruined.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O remnant of their valley,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how long will you gash yourself?

**<sup>6</sup>** O sword of the LORD, how long until you are quiet?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Put yourself into your sheath;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;rest and be still.

**<sup>7</sup>** How can it be quiet,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when the LORD has given it a charge<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against Ashkelon and against the seashore?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;There he has appointed it.”<br/>


## Chapter 48

**<sup>1</sup>** Concerning Moab.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus says the LORD of hosts, the God of Israel:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Woe to Nebo, for it is laid waste!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Kiriathaim is put to shame and captured;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the fortress is put to shame and shattered.<br/>
**<sup>2</sup>** There is no more praise for Moab;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in Heshbon they have devised evil against her:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Come, let us cut her off from being a nation.’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You also, O Madmen, will be brought to silence;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the sword will pursue you.

**<sup>3</sup>** A cry of distress from Horonaim:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Desolation and great destruction!’<br/>
**<sup>4</sup>** Moab is destroyed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her little ones have caused a cry to be heard.<br/>
**<sup>5</sup>** For the ascent of Luhith they go up weeping continually;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for on the descent of Horonaim<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the enemies have heard the cry of destruction.

**<sup>6</sup>** Flee, save your lives,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and be like a juniper in the wilderness.<br/>
**<sup>7</sup>** For because you have trusted in your works and your treasures,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you also will be captured;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Chemosh will go into exile,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his priests and his princes together.<br/>
**<sup>8</sup>** And the destroyer will come to every city,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no city will escape;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the valley will perish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the plain will be destroyed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as the LORD has spoken.

**<sup>9</sup>** Give wings to Moab,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for she must fly away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her cities will become a desolation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with no one to dwell in them.

**<sup>10</sup>** Cursed is the one who does the work of the LORD negligently,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cursed is the one who restrains his sword from blood.

**<sup>11</sup>** Moab has been at ease from his youth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he has settled on his lees;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has not been emptied from vessel to vessel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor has he gone into exile;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore his taste has remained in him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his scent has not changed.

**<sup>12</sup>** Therefore, see, the days are coming,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“when I shall send to him those who tip vessels,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will tip him over;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will empty his vessels<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shatter his jars.<br/>
**<sup>13</sup>** Then Moab will be ashamed of Chemosh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as the house of Israel was ashamed of Bethel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their confidence.

**<sup>14</sup>** How can you say, ‘We are mighty warriors<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and men valiant for battle’?<br/>
**<sup>15</sup>** Moab is destroyed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her cities have gone up in smoke,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her choice young men have gone down to the slaughter,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the King, whose name is the LORD of hosts.<br/>
**<sup>16</sup>** The calamity of Moab is near to come,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his disaster hastens swiftly.

**<sup>17</sup>** Grieve for him, all you who are around him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all who know his name;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;say, ‘How the mighty scepter is broken,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the glorious staff!’

**<sup>18</sup>** Come down from your glory,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and sit in thirst,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O inhabitant of Dibon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the destroyer of Moab has come up against you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he has destroyed your strongholds.<br/>
**<sup>19</sup>** Stand by the road and watch,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O inhabitant of Aroer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;ask him who flees and her who escapes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;say, ‘What has happened?’<br/>
**<sup>20</sup>** Moab is put to shame, for it is shattered;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;wail and cry out;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declare by the Arnon<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that Moab is laid waste.

**<sup>21</sup>** “Judgment has come upon the plateau—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;upon Holon and Jahzah and Mephaath,<br/>
**<sup>22</sup>** upon Dibon and Nebo and Beth-diblathaim, **<sup>23</sup>** upon Kiriathaim and Beth-gamul and Beth-meon, **<sup>24</sup>** upon Kerioth and Bozrah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and upon all the cities of the land of Moab,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;far and near.

**<sup>25</sup>** The horn of Moab has been cut off,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his arm broken,” declares the LORD.

**<sup>26</sup>** “Make him drunk,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he magnified himself against the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Moab will wallow in his vomit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he also will become a laughingstock.<br/>
**<sup>27</sup>** Was not Israel a laughingstock to you?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Was he found among thieves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that whenever you spoke of him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you wagged your head?

**<sup>28</sup>** Leave the cities and dwell in the rock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O inhabitants of Moab,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and be like a dove<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that makes her nest in the sides of the mouth of a pit.

**<sup>29</sup>** We have heard of the pride of Moab; he is very proud;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his loftiness, his arrogance, his pride,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the haughtiness of his heart.<br/>
**<sup>30</sup>** I know his wrath,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“but it is nothing;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his boastings accomplish nothing.

**<sup>31</sup>** Therefore I wail for Moab,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I cry out for all Moab;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the men of Kir-heres I mourn.<br/>
**<sup>32</sup>** More than for Jazer I weep for you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O vine of Sibmah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your branches passed over the sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they reached as far as Jazer;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the destroyer has fallen upon your summer fruit<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your vintage.<br/>
**<sup>33</sup>** Gladness and joy are taken away<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the fruitful field<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the land of Moab;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I have made the wine to cease from the winepresses;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no one will tread them with shouting;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the shouting will be no shouting.

**<sup>34</sup>** From the cry of Heshbon to Elealeh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as far as Jahaz they have raised their voice;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from Zoar to Horonaim and Eglath-shelishiyah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for even the waters of Nimrim will become desolate.<br/>
**<sup>35</sup>** And I will bring to an end in Moab,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“the one who offers sacrifice on the high place<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the one who burns incense to his gods.

**<sup>36</sup>** Therefore my heart moans for Moab like flutes;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my heart moans like flutes for the men of Kir-heres,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the wealth that they have gained has perished.

**<sup>37</sup>** For every head is bald and every beard cut off;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on all hands are gashes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and around the waist sackcloth.<br/>
**<sup>38</sup>** On all the housetops of Moab and in its squares<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is wailing everywhere;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have broken Moab like a vessel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for which no one cares,” declares the LORD.<br/>
**<sup>39</sup>** “How it is shattered!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They wail!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How Moab has turned his back in shame!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So Moab has become a laughingstock<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and an object of terror to all around him.”

**<sup>40</sup>** For thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Behold, one will swoop like an eagle<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and spread his wings against Moab.<br/>
**<sup>41</sup>** Kerioth is taken,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the strongholds are seized;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the heart of the warriors of Moab on that day<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be like the heart of a woman in her pangs.

**<sup>42</sup>** Moab will be destroyed from being a people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because he has magnified himself against the LORD.<br/>
**<sup>43</sup>** Terror, pit, and snare<br/>
&nbsp;&nbsp;&nbsp;&nbsp;are upon you, O inhabitant of Moab,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>
**<sup>44</sup>** “He who flees from the terror<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will fall into the pit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he who climbs out of the pit<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be caught in the snare;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will bring upon her, upon Moab,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the year of their punishment,” declares the LORD.

**<sup>45</sup>** “In the shadow of Heshbon<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the fugitives stand without strength;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for a fire has gone out from Heshbon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a flame from the midst of Sihon;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it has devoured the forehead of Moab<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the crown of the sons of tumult.<br/>
**<sup>46</sup>** Woe to you, O Moab!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The people of Chemosh are undone;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for your sons have been taken captive,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your daughters into exile.

**<sup>47</sup>** Yet I will restore the fortunes of Moab<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the latter days,” declares the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus far is the judgment of Moab.<br/>


## Chapter 49

**<sup>1</sup>** Concerning the sons of Ammon.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Has Israel no sons? Has he no heir?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why then has Malcam taken possession of Gad,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his people settled in its cities?<br/>
**<sup>2</sup>** Therefore, behold, the days are coming,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“when I will cause the sound of battle to be heard<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against Rabbah of the Ammonites;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it shall become a desolate mound,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and her villages shall be set on fire.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then Israel shall dispossess those who dispossessed him,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>
**<sup>3</sup>** “Wail, O Heshbon, for Ai is laid waste!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Cry out, O daughters of Rabbah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;gird yourselves with sackcloth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lament, and run to and fro among the walls,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for Malcam shall go into exile,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his priests and his princes together.<br/>
**<sup>4</sup>** Why do you boast of your valleys,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your flowing valley, O faithless daughter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who trusted in her treasures, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Who will come against me?’<br/>
**<sup>5</sup>** See how I will bring terror upon you,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the Lord GOD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“from all around you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and each of you will be driven headlong,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there shall be no one to gather the fugitives.

**<sup>6</sup>** But afterward I will restore the fortunes of the sons of Ammon,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>7</sup>** Concerning Edom.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Is there no longer wisdom in Teman?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Has counsel perished from the prudent?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Has their wisdom vanished?<br/>
**<sup>8</sup>** Flee, turn back, dwell deep,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O inhabitants of Dedan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will bring the calamity of Esau upon him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the time when I punish him.<br/>
**<sup>9</sup>** If grape gatherers came to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;would they not leave gleanings?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If thieves came by night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;would they not destroy only until they had enough?<br/>
**<sup>10</sup>** But I have stripped Esau bare;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have uncovered his hiding places,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he is not able to conceal himself.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His children are destroyed, his brothers and his neighbors;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he is no more.<br/>
**<sup>11</sup>** Leave your orphans, I will keep them alive,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let your widows trust in Me.”

**<sup>12</sup>** For thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Look how those who were not sentenced to drink the cup<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will surely drink it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and are you the one who will go unpunished?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You shall not go unpunished,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but you shall surely drink it.<br/>
**<sup>13</sup>** For I have sworn by Myself,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“that Bozrah shall become a horror,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a reproach, a ruin, and a curse;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all its cities shall become perpetual ruins.”

**<sup>14</sup>** I have heard a message from the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and an envoy has been sent among the nations, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Gather yourselves together and come against her,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and rise up for battle!”<br/>
**<sup>15</sup>** “For you will see that I will make you small among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;despised among men.<br/>
**<sup>16</sup>** As for the terror of you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the pride of your heart has deceived you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O you who dwell in the clefts of the rock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who hold the height of the hill.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Though you make your nest as high as the eagle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will bring you down from there,” declares the LORD.

**<sup>17</sup>** “Edom shall become an object of horror;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;everyone who passes by it will be appalled<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will hiss at all its wounds.<br/>
**<sup>18</sup>** As in the overthrow of Sodom and Gomorrah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their neighboring cities,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“no man shall live there,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor shall any son of man sojourn in it.<br/>
**<sup>19</sup>** One shall come up like a lion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the thickets of the Jordan against a perennial pasture,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for suddenly I will make him run away from it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And I will appoint over it whomever I choose.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For who is like Me, and who will summon Me into court?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Who is the shepherd who can stand before Me?<br/>
**<sup>20</sup>** Therefore hear the counsel of the LORD that He has taken against Edom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His purposes that He has purposed against the inhabitants of Teman:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Surely the little ones of the flock shall be dragged away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;surely He will make their pasture desolate because of them.<br/>
**<sup>21</sup>** The earth has quaked at the sound of their fall;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a cry! Its sound is heard at the Red Sea.<br/>
**<sup>22</sup>** Behold, one shall fly swiftly like an eagle<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and spread his wings against Bozrah;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the hearts of the warriors of Edom in that day<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall be like the heart of a woman in her pangs.”

**<sup>23</sup>** Concerning Damascus.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Hamath and Arpad are put to shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they have heard bad news;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they melt in fear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is trouble on the sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it cannot be quiet.<br/>
**<sup>24</sup>** Damascus has become feeble,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she has turned to flee,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and panic has seized her;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;anguish and sorrows have taken hold of her,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a woman in labor.<br/>
**<sup>25</sup>** How the city of praise has not been forsaken,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the city of My joy!<br/>
**<sup>26</sup>** Therefore her young men shall fall in her streets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the men of war shall be silenced in that day,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD of hosts.<br/>
**<sup>27</sup>** “I will set fire to the wall of Damascus,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall consume the strongholds of Ben-hadad.”

**<sup>28</sup>** Concerning Kedar and the kingdoms of Hazor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which Nebuchadnezzar king of Babylon struck down.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Rise up, go up against Kedar,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and destroy the sons of the east.<br/>
**<sup>29</sup>** They shall take their tents and their flocks,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their curtains and all their goods;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall carry away their camels for themselves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall cry out to them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Terror on every side!’<br/>
**<sup>30</sup>** Flee, wander far away, dwell deep,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O inhabitants of Hazor,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“for Nebuchadnezzar king of Babylon has counseled against you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and has conceived a plan against you.<br/>
**<sup>31</sup>** Rise up, go up against a nation at ease,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that dwells securely,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“that has neither gates nor bars,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that dwells alone.<br/>
**<sup>32</sup>** Their camels shall become plunder,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the multitude of their herds spoil;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will scatter to every wind<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who cut the corners of their hair,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will bring their calamity from every side,” declares the LORD.<br/>
**<sup>33</sup>** “Hazor shall become a haunt of jackals,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a desolation forever;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no man shall dwell there,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor shall any son of man sojourn in it.”

**<sup>34</sup>** The word of the LORD that came to Jeremiah the prophet concerning Elam,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;at the beginning of the reign of Zedekiah king of Judah, saying,<br/>
**<sup>35</sup>** “Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Look! I will break the bow of Elam,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the chief of their might.<br/>
**<sup>36</sup>** And I will bring upon Elam the four winds<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the four quarters of heaven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will scatter them to all those winds;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there shall be no nation<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to which the outcasts of Elam shall not go.<br/>
**<sup>37</sup>** And I will cause Elam to be dismayed before their enemies<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and before those who seek their life;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will bring disaster upon them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My fierce anger,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“and I will send the sword after them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until I have consumed them.<br/>
**<sup>38</sup>** Then I will set My throne in Elam<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and destroy from there king and princes,” declares the LORD.<br/>
**<sup>39</sup>** “But it shall come to pass in the latter days<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I will restore the fortunes of Elam,” declares the LORD.<br/>


## Chapter 50

**<sup>1</sup>** The word that the LORD spoke concerning Babylon, concerning the land of the Chaldeans, by Jeremiah the prophet. **<sup>2</sup>** Proclaim among the nations and make it heard; raise a signal, proclaim and do not hide it. Say, Babylon has been captured, Bel is shamed, Merodach is dismayed; her idols are disgraced, her images are shattered. **<sup>3</sup>** For a nation has come up against her out of the north; it will make her land a desolation, and no one shall dwell in it—neither man nor beast—they have fled and gone.

**<sup>4</sup>** In those days and at that time, declares the LORD, the sons of Israel will come, they and the sons of Judah together; they will go weeping as they go, and will seek the LORD their God. **<sup>5</sup>** They will ask the way to Zion, their faces turned toward it, saying, “Come, let us join ourselves to the LORD in an everlasting covenant that will not be forgotten.” **<sup>6</sup>** My people were lost sheep; their shepherds led them astray, turning them away on the mountains; they went from mountain to hill, they forgot their resting place. **<sup>7</sup>** All who found them devoured them, and their enemies said, “We are not guilty, because they have sinned against the LORD, the habitation of righteousness, the LORD, the hope of their fathers.” **<sup>8</sup>** Flee from the midst of Babylon, and go out of the land of the Chaldeans, and be like the he-goats before the flock. **<sup>9</sup>** For I am stirring up and bringing against Babylon an assembly of great nations from the north country, and they will array themselves against her; from there she shall be taken. Their arrows are like those of a skilled warrior who does not return empty-handed. **<sup>10</sup>** Chaldea shall become plunder; all who plunder her shall be satisfied, declares the LORD.

**<sup>11</sup>** Because you rejoiced, because you exulted, you who plunder My inheritance, because you frisk like a heifer threshing grain and neigh like strong horses, **<sup>12</sup>** your mother shall be utterly shamed, she who bore you shall be disgraced. See, she shall be the least of the nations, a wilderness, a dry land, and a desert. **<sup>13</sup>** Because of the wrath of the LORD she shall not be inhabited, but shall be an utter desolation; everyone who passes by Babylon shall be appalled and hiss because of all her wounds. **<sup>14</sup>** Draw up your battle lines against Babylon all around, all you who bend the bow; shoot at her, spare no arrows, for she has sinned against the LORD. **<sup>15</sup>** Raise a shout against her all around; she has surrendered, her bulwarks have fallen, her walls are thrown down. For this is the vengeance of the LORD; take vengeance on her, as she has done, do to her.

**<sup>16</sup>** Cut off the sower from Babylon and him who handles the sickle at harvest time; because of the oppressing sword every man shall turn to his own people and every man flee to his own land. **<sup>17</sup>** Israel is a hunted sheep driven away by lions; first the king of Assyria devoured him, and last Nebuchadnezzar king of Babylon gnawed his bones. **<sup>18</sup>** Therefore thus says the LORD of hosts, the God of Israel: I will punish the king of Babylon and his land as I punished the king of Assyria. **<sup>19</sup>** I will bring Israel back to his pasture, and he shall feed on Carmel and Bashan, and his soul shall be satisfied on the hills of Ephraim and in Gilead. **<sup>20</sup>** In those days and at that time, declares the LORD, the iniquity of Israel shall be sought, and there shall be none; and the sins of Judah, and they shall not be found, for I will pardon those whom I leave as a remnant.

**<sup>21</sup>** Go up against the land of Merathaim, and against the inhabitants of Pekod; waste and utterly destroy after them, declares the LORD, and do all that I have commanded you. **<sup>22</sup>** The noise of battle is in the land, and great destruction. **<sup>23</sup>** How the hammer of the whole earth is cut down and broken! How Babylon has become a horror among the nations! **<sup>24</sup>** I set a snare for you and you were caught, O Babylon, and you did not know it; you were found and also seized, because you strove against the LORD. **<sup>25</sup>** The LORD has opened His armory and brought out the weapons of His wrath, for the Lord GOD of hosts has work to do in the land of the Chaldeans. **<sup>26</sup>** Come against her from every side; open her storehouses; pile her up like heaps and destroy her utterly; let nothing of her remain. **<sup>27</sup>** Slay all her bulls; let them go down to the slaughter. Woe to them, for their day has come, the time of their punishment. **<sup>28</sup>** The voice of those who flee and escape from the land of Babylon comes to declare in Zion the vengeance of the LORD our God, the vengeance of His temple. **<sup>29</sup>** Summon archers against Babylon, all who bend the bow; encamp around her; let no one escape. Repay her according to her deeds; do to her according to all that she has done, for she has been proud against the LORD, against the Holy One of Israel.

**<sup>30</sup>** Therefore her young men shall fall in her squares, and all her warriors shall perish in that day, declares the LORD. **<sup>31</sup>** I am against you, O proud one, declares the Lord GOD of hosts, for your day has come, the time when I will punish you. **<sup>32</sup>** The proud one shall stumble and fall, with no one to raise him up; and I will kindle a fire in his cities, and it shall devour all that is around him.

**<sup>33</sup>** Thus says the LORD of hosts: the sons of Israel and the sons of Judah are oppressed together, and all who took them captive hold them fast; they refuse to let them go. **<sup>34</sup>** Their Redeemer is strong; the LORD of hosts is His name. He will surely plead their cause, that He may give rest to the earth, but unrest to the inhabitants of Babylon. **<sup>35</sup>** A sword is against the Chaldeans, declares the LORD, and against the inhabitants of Babylon, and against her princes and against her wise men. **<sup>36</sup>** A sword is against the diviners, and they shall become fools; a sword is against her mighty men, and they shall be dismayed. **<sup>37</sup>** A sword is against their horses and against their chariots and against all the mixed people who are in her midst, and they shall become like women; a sword is against her treasures, and they shall be plundered. **<sup>38</sup>** A drought is against her waters, and they shall dry up, for it is a land of idols, and they go mad over their images. **<sup>39</sup>** Therefore wild beasts shall dwell with hyenas, and ostriches shall dwell in her; she shall never again be inhabited or lived in for all generations. **<sup>40</sup>** As when God overthrew Sodom and Gomorrah and their neighboring cities, declares the LORD, so no man shall dwell there, and no son of man shall sojourn in her.

**<sup>41</sup>** A people comes from the north, a great nation and many kings are stirred up from the ends of the earth. **<sup>42</sup>** They hold bow and spear; they are cruel and have no mercy. Their voice roars like the sea, and they ride upon horses, arrayed as a man for battle against you, O daughter of Babylon. **<sup>43</sup>** The king of Babylon heard the report of them, and his hands grew feeble; anguish seized him, pain like that of a woman in labor. **<sup>44</sup>** See, like a lion coming up from the thickets of the Jordan to a secure pasture, I will suddenly make them run from it, and whoever is chosen I will appoint over it. For who is like Me? Who will summon Me to court? Who is the shepherd who can stand before Me? **<sup>45</sup>** Therefore hear the plan of the LORD that He has made against Babylon, and His purposes that He has formed against the land of the Chaldeans: surely the little ones of the flock shall drag them away; surely He shall make their pasture desolate because of them. **<sup>46</sup>** At the sound of Babylon’s capture the earth shall tremble, and her cry shall be heard among the nations. 

## Chapter 51

**<sup>1</sup>** Thus says the LORD: See, I am stirring up against Babylon and against those who dwell in Leb-kamai a destroying wind. **<sup>2</sup>** I will send strangers to Babylon, and they shall winnow her, and they shall empty her land; for in the day of trouble they shall be against her all around. **<sup>3</sup>** Let not the archer bend his bow, and let him not stand up in his armor; do not spare her young men, utterly destroy all her host. **<sup>4</sup>** They shall fall slain in the land of the Chaldeans, and thrust through in her streets.

**<sup>5</sup>** For Israel and Judah have not been forsaken by their God, the LORD of hosts, though their land was full of guilt against the Holy One of Israel. **<sup>6</sup>** Flee from the midst of Babylon, and let each save his life; do not be cut off in her punishment, for this is the time of the LORD’s vengeance; He is repaying her what she has done. **<sup>7</sup>** Babylon was a golden cup in the LORD’s hand, making all the earth drunk; the nations drank of her wine, therefore the nations have gone mad. **<sup>8</sup>** Suddenly Babylon has fallen and been shattered; wail for her! Take balm for her pain; perhaps she may be healed. **<sup>9</sup>** We would have healed Babylon, but she is not healed. Leave her, and let each go to his own land, for her judgment reaches to heaven and is lifted up to the skies. **<sup>10</sup>** The LORD has brought forth our vindication; come, let us declare in Zion the work of the LORD our God.

**<sup>11</sup>** Sharpen the arrows, take up the shields! The LORD has stirred up the spirit of the kings of the Medes, because His purpose concerning Babylon is to destroy it, for that is the vengeance of the LORD, the vengeance for His temple. **<sup>12</sup>** Raise a standard against the walls of Babylon, strengthen the watch, set the guards, prepare the ambushes, for the LORD has both planned and done what He spoke concerning the inhabitants of Babylon. **<sup>13</sup>** O you who dwell by many waters, rich in treasures, your end has come, the measure of your covetousness. **<sup>14</sup>** The LORD of hosts has sworn by Himself: Surely I will fill you with men like locusts, and they shall raise a shout of triumph over you.

**<sup>15</sup>** It is He who made the earth by His power, who established the world by His wisdom, and by His understanding stretched out the heavens. **<sup>16</sup>** When He utters His voice there is a tumult of waters in the heavens, and He causes the vapors to ascend from the ends of the earth; He makes lightning for the rain, and brings forth the wind from His storehouses. **<sup>17</sup>** Every man is stupid, without knowledge; every goldsmith is put to shame by his idols, for his images are a lie, and there is no breath in them. **<sup>18</sup>** They are worthless, a work of delusion; at the time of their punishment they shall perish. **<sup>19</sup>** The portion of Jacob is not like these, for He is the one who formed all things, and Israel is the tribe of His inheritance; the LORD of hosts is His name.

**<sup>20</sup>** You are My hammer and weapon of war; with you I shatter nations, with you I destroy kingdoms; **<sup>21</sup>** with you I shatter horse and rider, with you I shatter chariot and charioteer; **<sup>22</sup>** with you I shatter man and woman, with you I shatter old and young, with you I shatter young man and maiden; **<sup>23</sup>** with you I shatter shepherd and flock, with you I shatter farmer and yoke of oxen, with you I shatter governors and commanders. **<sup>24</sup>** I will repay Babylon and all the inhabitants of Chaldea for all the evil they have done in Zion before your eyes, declares the LORD.

**<sup>25</sup>** I am against you, O destroying mountain, declares the LORD, which destroys all the earth; I will stretch out My hand against you, and roll you down from the crags, and make you a burned-out mountain. **<sup>26</sup>** They shall not take from you a stone for a corner or a stone for a foundation, but you shall be a perpetual waste, declares the LORD. **<sup>27</sup>** Raise a signal in the land, blow the trumpet among the nations; consecrate the nations against her, summon the kingdoms of Ararat, Minni, and Ashkenaz; appoint a marshal against her; bring up horses like bristling locusts. **<sup>28</sup>** Consecrate the nations against her, the kings of Media, their governors and all their deputies, and every land under their dominion. **<sup>29</sup>** The earth trembles and writhes, for the LORD’s purposes against Babylon stand, to make the land of Babylon a desolation without inhabitant.

**<sup>30</sup>** The warriors of Babylon have ceased fighting; they remain in their strongholds; their strength has failed; they have become like women. Her dwellings are set on fire; her bars are broken. **<sup>31</sup>** One runner runs to meet another, and one messenger to meet another, to tell the king of Babylon that his city is taken from end to end, **<sup>32</sup>** the fords have been seized, the marshes have been burned with fire, and the men of war are terrified.

**<sup>33</sup>** For thus says the LORD of hosts, the God of Israel: The daughter of Babylon is like a threshing floor at the time it is trampled; yet a little while and the time of her harvest will come. **<sup>34</sup>** Nebuchadnezzar king of Babylon has devoured me, he has crushed me; he has made me an empty vessel, he has swallowed me like a dragon, he has filled his belly with my delicacies, he has rinsed me out. **<sup>35</sup>** May the violence done to me and to my flesh be upon Babylon, say the inhabitant of Zion; and, “My blood be upon the inhabitants of Chaldea,” says Jerusalem. **<sup>36</sup>** Therefore thus says the LORD: See, I will plead your cause and take vengeance for you; I will dry up her sea and make her fountain dry, **<sup>37</sup>** and Babylon shall become a heap of ruins, a haunt of jackals, an object of horror and of hissing, without inhabitant. **<sup>38</sup>** They shall roar together like lions; they shall growl like lions’ cubs. **<sup>39</sup>** While they are inflamed I will prepare their drink and make them drunk, that they may become merry and sleep a perpetual sleep and not wake, declares the LORD. **<sup>40</sup>** I will bring them down like lambs to the slaughter, like rams and male goats.

**<sup>41</sup>** How Sheshach has been taken, and the praise of the whole earth seized! How Babylon has become a horror among the nations! **<sup>42</sup>** The sea has come up over Babylon; she is covered with its roaring waves. **<sup>43</sup>** Her cities have become a horror, a dry land and a desert, a land in which no man dwells, and through which no son of man passes. **<sup>44</sup>** I will punish Bel in Babylon and make him disgorge what he has swallowed. The nations shall no longer stream to him; the wall of Babylon has fallen.

**<sup>45</sup>** Go out of her midst, My people, and let every man save his life from the fierce anger of the LORD. **<sup>46</sup>** Let not your heart faint, and do not fear the rumor that is heard in the land; for in one year one rumor will come, and afterward another in another year, and violence will be in the land, with ruler against ruler.

**<sup>47</sup>** Therefore, see, the days are coming when I will punish the idols of Babylon; her whole land shall be put to shame, and all her slain shall fall in her midst. **<sup>48</sup>** Then the heavens and the earth and all that is in them shall sing for joy over Babylon, for the destroyers shall come to her from the north, declares the LORD. **<sup>49</sup>** Babylon must fall for the slain of Israel, as for Babylon have fallen the slain of all the earth.

**<sup>50</sup>** You who have escaped from the sword, go, do not stand still! Remember the LORD from afar, and let Jerusalem come into your heart. **<sup>51</sup>** We are ashamed, for we have heard reproach; disgrace has covered our faces, for foreigners have come into the holy places of the LORD’s house. **<sup>52</sup>** Therefore, see, the days are coming, declares the LORD, when I will punish her idols, and throughout her land the wounded shall groan. **<sup>53</sup>** Though Babylon should ascend to heaven, and though she should fortify her strong height, yet destroyers from Me shall come to her, declares the LORD.

**<sup>54</sup>** A sound of cry from Babylon, and great destruction from the land of the Chaldeans! **<sup>55</sup>** For the LORD is laying Babylon waste and stilling her mighty voice; their waves roar like many waters; the noise of their voice is raised. **<sup>56</sup>** For a destroyer has come upon her, upon Babylon; her warriors are taken, their bows are broken, for the LORD is a God of recompense; He will surely repay. **<sup>57</sup>** I will make her princes and her wise men, her governors, her commanders, and her warriors drunk; they shall sleep a perpetual sleep and not wake, declares the King, whose name is the LORD of hosts.

**<sup>58</sup>** Thus says the LORD of hosts: The broad wall of Babylon shall be leveled to the ground, and her high gates shall be burned with fire; the peoples labor for nothing, and the nations weary themselves only for fire.

**<sup>59</sup>** The word which Jeremiah the prophet commanded Seraiah son of Neriah, son of Mahseiah, when he went with Zedekiah king of Judah to Babylon in the fourth year of his reign. Now Seraiah was quartermaster. **<sup>60</sup>** Jeremiah wrote in a book all the disaster that should come upon Babylon, all these words that are written concerning Babylon. **<sup>61</sup>** And Jeremiah said to Seraiah, “When you come to Babylon, see that you read all these words, **<sup>62</sup>** and say, ‘O LORD, You have spoken concerning this place, that You will cut it off, so that none shall dwell in it, neither man nor beast, but it shall be desolate forever.’ **<sup>63</sup>** When you finish reading this book, tie a stone to it and cast it into the middle of the Euphrates, **<sup>64</sup>** and say, ‘Thus shall Babylon sink, to rise no more, because of the disaster that I am bringing upon her, and they shall weary themselves.’”

Thus far are the words of Jeremiah.

## Chapter 52

**<sup>1</sup>** Zedekiah was twenty-one years old when he became king, and he reigned eleven years in Jerusalem. His mother’s name was Hamutal, the daughter of Jeremiah of Libnah. **<sup>2</sup>** He did what was evil in the sight of the LORD, just as Jehoiakim had done. **<sup>3</sup>** For because of the anger of the LORD it came to the point in Jerusalem and Judah that He cast them out from His presence. And Zedekiah rebelled against the king of Babylon.

**<sup>4</sup>** In the ninth year of his reign, in the tenth month, on the tenth day of the month, Nebuchadnezzar king of Babylon came with all his army against Jerusalem, and they encamped against it and built siegeworks all around it. **<sup>5</sup>** So the city was besieged until the eleventh year of King Zedekiah. **<sup>6</sup>** In the fourth month, on the ninth day of the month, the famine became so severe in the city that there was no food for the people of the land. **<sup>7</sup>** Then a breach was made in the city, and all the men of war fled and went out from the city by night by the way of the gate between the two walls, by the king’s garden, though the Chaldeans were all around the city; and they went in the direction of the Arabah. **<sup>8</sup>** But the army of the Chaldeans pursued the king, and they overtook Zedekiah in the plains of Jericho, and all his army was scattered from him. **<sup>9</sup>** Then they captured the king and brought him up to the king of Babylon at Riblah in the land of Hamath, and he passed sentence on him. **<sup>10</sup>** The king of Babylon slaughtered the sons of Zedekiah before his eyes, and he also slaughtered all the princes of Judah at Riblah. **<sup>11</sup>** He put out the eyes of Zedekiah, and bound him in chains, and the king of Babylon took him to Babylon and put him in prison till the day of his death.

**<sup>12</sup>** In the fifth month, on the tenth day of the month, which was the nineteenth year of King Nebuchadnezzar king of Babylon, Nebuzaradan the captain of the guard, who served the king of Babylon, entered Jerusalem. **<sup>13</sup>** He burned the house of the LORD, and the king’s house, and all the houses of Jerusalem; every great house he burned with fire. **<sup>14</sup>** And all the army of the Chaldeans, who were with the captain of the guard, broke down all the walls around Jerusalem. **<sup>15</sup>** And Nebuzaradan the captain of the guard carried away captive some of the poorest of the people, and the rest of the people who were left in the city, and the deserters who had defected to the king of Babylon, and the rest of the craftsmen. **<sup>16</sup>** But Nebuzaradan the captain of the guard left some of the poorest of the land to be vinedressers and plowmen.

**<sup>17</sup>** And the pillars of bronze that were in the house of the LORD, and the stands, and the bronze sea that were in the house of the LORD, the Chaldeans broke in pieces, and carried all the bronze to Babylon. **<sup>18</sup>** They also took away the pots and the shovels and the snuffers and the bowls and the spoons, and all the vessels of bronze used in the temple service. **<sup>19</sup>** The captain of the guard took away the basins and the firepans and the bowls and the pots and the lampstands and the spoons and the cups—whatever was of gold in gold, and whatever was of silver in silver. **<sup>20</sup>** As for the two pillars, the one sea, the twelve bronze oxen that were under the sea, and the stands, which King Solomon had made for the house of the LORD, the bronze of all these things was beyond weighing. **<sup>21</sup>** As for the pillars, the height of one pillar was eighteen cubits, its circumference twelve cubits; it was four fingers thick, and hollow. **<sup>22</sup>** On it was a capital of bronze, and the height of one capital was five cubits; a network and pomegranates, all of bronze, were around the capital; and the second pillar was like these, with pomegranates. **<sup>23</sup>** There were ninety-six pomegranates on the sides; all the pomegranates around the network were a hundred.

**<sup>24</sup>** The captain of the guard took Seraiah the chief priest, and Zephaniah the second priest, and the three keepers of the threshold; **<sup>25</sup>** and from the city he took an officer who was over the men of war, and seven men of those who saw the king’s face, who were found in the city, and the secretary of the commander of the army who mustered the people of the land, and sixty men of the people of the land who were found in the midst of the city. **<sup>26</sup>** And Nebuzaradan the captain of the guard took them and brought them to the king of Babylon at Riblah. **<sup>27</sup>** And the king of Babylon struck them down and put them to death at Riblah in the land of Hamath. So Judah went into exile from its land.

**<sup>28</sup>** This is the number of the people whom Nebuchadnezzar carried away captive: in the seventh year, three thousand twenty-three Jews; **<sup>29</sup>** in the eighteenth year of Nebuchadnezzar, eight hundred thirty-two persons from Jerusalem; **<sup>30</sup>** in the twenty-third year of Nebuchadnezzar, Nebuzaradan the captain of the guard carried away seven hundred forty-five persons of the Jews; all the persons were four thousand six hundred.

**<sup>31</sup>** And in the thirty-seventh year of the exile of Jehoiachin king of Judah, in the twelfth month, on the twenty-fifth day of the month, Evil-merodach king of Babylon, in the year he began to reign, showed favor to Jehoiachin king of Judah and brought him out of prison. **<sup>32</sup>** He spoke kindly to him and gave him a seat above the seats of the kings who were with him in Babylon. **<sup>33</sup>** So Jehoiachin changed his prison garments, and he ate bread before him continually all the days of his life. **<sup>34</sup>** And as for his allowance, a regular allowance was given him by the king of Babylon, day by day, until the day of his death, all the days of his life. 