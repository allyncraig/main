# Zechariah

## Chapter 1

**<sup>1</sup>** In the eighth month, in the second year of Darius, the word of the LORD came to Zechariah the son of Berechiah, son of Iddo the prophet, saying, **<sup>2</sup>** “The LORD was very angry with your fathers. **<sup>3</sup>** Therefore say to them, Thus declares the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Return to Me, declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will return to you, says the LORD of hosts.<br/>
**<sup>4</sup>** Do not be like your fathers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to whom the former prophets cried out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Thus says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Return from your evil ways and from your evil deeds.’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But they did not hear or pay attention to Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>
**<sup>5</sup>** Your fathers—where are they?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And the prophets—do they live forever?<br/>
**<sup>6</sup>** But My words and My statutes, which I commanded My servants the prophets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;did they not overtake your fathers?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So they repented and said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘As the LORD of hosts purposed to deal with us<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for our ways and our deeds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so has He dealt with us.’”

**<sup>7</sup>** On the twenty-fourth day of the eleventh month, which is the month Shebat,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the second year of Darius,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the word of the LORD came to the prophet Zechariah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the son of Berechiah, son of Iddo, saying,<br/>
**<sup>8</sup>** I looked in the night, and saw<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a man riding on a red horse!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He was standing among the myrtle trees in the glen,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and behind him were red, sorrel, and white horses.<br/>
**<sup>9</sup>** Then I said, “What are these, my lord?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The angel who talked with me said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I will show you what they are.”<br/>
**<sup>10</sup>** So the man who was standing among the myrtle trees answered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“These are the ones whom the LORD has sent<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to patrol the earth.”<br/>
**<sup>11</sup>** And they answered the angel of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who was standing among the myrtle trees, and said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“We have patrolled the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the earth remains at rest.”<br/>
**<sup>12</sup>** Then the angel of the LORD said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“O LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;how long will You have no mercy on Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the cities of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against which You have been angry<br/>
&nbsp;&nbsp;&nbsp;&nbsp;these seventy years?”<br/>
**<sup>13</sup>** And the LORD answered the angel who talked with me<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with gracious and comforting words.

**<sup>14</sup>** So the angel who talked with me said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Cry out, Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am exceedingly jealous for Jerusalem and for Zion.<br/>
**<sup>15</sup>** And I am exceedingly angry with the nations that are at ease;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for while I was only a little angry,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they added to the calamity.<br/>
**<sup>16</sup>** Therefore, thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have returned to Jerusalem with mercy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My house shall be built in it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a measuring line shall be stretched out over Jerusalem.<br/>
**<sup>17</sup>** Cry out again, Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My cities shall again overflow with prosperity,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the LORD will again comfort Zion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and again choose Jerusalem.”

**<sup>18</sup>** And I lifted my eyes and saw,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and behold, four horns.<br/>
**<sup>19</sup>** And I said to the angel who talked with me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“What are these?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“These are the horns that have scattered Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel, and Jerusalem.”

**<sup>20</sup>** Then the LORD showed me four craftsmen. **<sup>21</sup>** And I said, “What are these coming to do?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He said, “These are the horns that scattered Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that no one raised his head.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And these have come to terrify them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to cast down the horns of the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that lifted up their horn<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against the land of Judah to scatter it.”<br/>


## Chapter 2

**<sup>1</sup>** And I lifted my eyes and looked<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I saw a man with a measuring line in his hand.<br/>
**<sup>2</sup>** Then I said, “Where are you going?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he said to me, “To measure Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to see what is its width and what is its length.”

**<sup>3</sup>** And the angel who talked with me went out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and another angel went out to meet him,<br/>
**<sup>4</sup>** and said to him, “Run, say to that young man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Jerusalem shall be inhabited as villages without walls,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the multitude of men and livestock in it.<br/>
**<sup>5</sup>** And I will be to her a wall of fire all around,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will be the glory in her midst.’”

**<sup>6</sup>** Up! Up! Flee from the land of the north,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have spread you abroad as the four winds of heaven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>
**<sup>7</sup>** Up! Escape to Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who dwell with the daughter of Babylon.<br/>
**<sup>8</sup>** For thus said the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;after His glory sent Me to the nations who plundered you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he who touches you touches the apple of His eye:<br/>
**<sup>9</sup>** Behold, I will shake My hand over them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall become plunder for those who served them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then you will know that the LORD of hosts has sent Me.

**<sup>10</sup>** Sing and rejoice, O daughter of Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for behold, I come and I will dwell in your midst,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>
**<sup>11</sup>** And many nations shall join themselves to the LORD in that day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall be My people.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And I will dwell in your midst,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you shall know that the LORD of hosts has sent Me to you.<br/>
**<sup>12</sup>** And the LORD will inherit Judah as His portion in the holy land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will again choose Jerusalem.<br/>
**<sup>13</sup>** Be silent, all flesh, before the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He has roused Himself from His holy dwelling.<br/>


## Chapter 3

**<sup>1</sup>** Then he showed me Joshua the high priest standing before the angel of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Satan standing at his right hand to accuse him.<br/>
**<sup>2</sup>** And the LORD said to Satan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“The LORD rebuke you, O Satan!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD who has chosen Jerusalem rebuke you!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is not this a brand plucked from the fire?”

**<sup>3</sup>** Now Joshua was standing before the angel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;clothed with filthy garments.<br/>
**<sup>4</sup>** And the angel said to those who were standing before him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Remove the filthy garments from him.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And to him he said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Behold, I have taken your iniquity away from you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will clothe you with pure vestments.”

**<sup>5</sup>** And I said, “Let them put a clean turban on his head.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So they put a clean turban on his head and clothed him with garments.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And the angel of the LORD was standing by.<br/>
**<sup>6</sup>** And the angel of the LORD solemnly charged Joshua, **<sup>7</sup>** “Thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If you will walk in My ways<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and keep My charge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then you shall rule My house<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have charge of My courts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will give you access among those who are standing here.<br/>
**<sup>8</sup>** Hear now, O Joshua the high priest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you and your companions who sit before you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they are men who are a sign:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Look! I will bring My servant, the Branch.<br/>
**<sup>9</sup>** For on the stone that I have set before Joshua,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on a single stone with seven eyes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will engrave its inscription,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will remove the iniquity of this land<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in a single day.<br/>
**<sup>10</sup>** In that day, declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;every man will invite his neighbor<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to sit under his vine and under his fig tree.”<br/>


## Chapter 4

**<sup>1</sup>** And the angel who talked with me came again and woke me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a man who is awakened out of his sleep.<br/>
**<sup>2</sup>** And he said to me, “What do you see?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I said, “I see a lampstand all of gold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with a bowl on the top of it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and seven lamps on it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with seven lips on each of the lamps<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that are on the top of it.<br/>
**<sup>3</sup>** And there are two olive trees by it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;one on the right of the bowl and the other on its left.”

**<sup>4</sup>** And I said to the angel who talked with me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“What are these, my lord?”<br/>
**<sup>5</sup>** Then the angel who talked with me answered and said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Do you not know what these are?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I said, “No, my lord.”<br/>
**<sup>6</sup>** Then he said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“This is the word of the LORD to Zerubbabel:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Not by might, nor by power,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but by My Spirit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>7</sup>** Who are you, O great mountain?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Before Zerubbabel you shall become a plain.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he shall bring forward the top stone<br/>
&nbsp;&nbsp;&nbsp;&nbsp;amid shouts of ‘Grace, grace to it!’”

**<sup>8</sup>** Then the word of the LORD came to me, saying, **<sup>9</sup>** “The hands of Zerubbabel have laid the foundation of this house;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his hands shall also complete it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then you will know that the LORD of hosts has sent me to you.<br/>
**<sup>10</sup>** For whoever has despised the day of small things shall rejoice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall see the plumb line in the hand of Zerubbabel.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;These seven are the eyes of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which range through the whole earth.”

**<sup>11</sup>** Then I said to him, “What are these two olive trees<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the right and the left of the lampstand?”<br/>
**<sup>12</sup>** And a second time I answered and said to him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“What are these two branches of the olive trees,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which are beside the two golden pipes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from which the golden oil is poured out?”<br/>
**<sup>13</sup>** He said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Do you not know what these are?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I said, “No, my lord.”<br/>
**<sup>14</sup>** Then he said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“These are the two sons of oil<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who stand by the Lord of all the earth.”<br/>


## Chapter 5

**<sup>1</sup>** Again I lifted my eyes and looked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I saw a flying scroll.<br/>
**<sup>2</sup>** And he said to me, “What do you see?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I answered, “I see a flying scroll.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Its length is twenty cubits,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its width, ten cubits.”

**<sup>3</sup>** Then he said to me, “This is the curse<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that goes out over the face of the whole land.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For everyone who steals shall be purged away<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to what is on one side,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and everyone who swears falsely<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall be purged away according to what is on the other side.<br/>
**<sup>4</sup>** I will send it out, declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall enter the house of the thief,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the house of him who swears falsely by My name.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And it shall remain in his house and consume it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;both timber and stones.”

**<sup>5</sup>** Then the angel who talked with me came forward and said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Lift your eyes and see what this is that is going out.”<br/>
**<sup>6</sup>** And I said, “What is it?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He said, “This is the measuring basket that is going out.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he said, “This is their iniquity in all the land.”

**<sup>7</sup>** And I saw that the lead cover was lifted,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and there was a woman sitting in the basket.<br/>
**<sup>8</sup>** And he said, “This is Wickedness.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he thrust her back into the basket,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and thrust down the leaden weight on its opening.

**<sup>9</sup>** Then I lifted my eyes and looked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I saw two women coming forward!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The wind was in their wings.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They had wings like the wings of a stork,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they lifted up the basket between earth and heaven.<br/>
**<sup>10</sup>** Then I said to the angel who talked with me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Where are they taking the basket?”<br/>
**<sup>11</sup>** He said to me, “To the land of Shinar,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to build a house for it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And when this is prepared,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they will set the basket down there on its base.”<br/>


## Chapter 6

**<sup>1</sup>** And again I lifted my eyes and looked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I saw four chariots came out from between two mountains,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the mountains were mountains of bronze.<br/>
**<sup>2</sup>** The first chariot had red horses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the second chariot black horses,<br/>
**<sup>3</sup>** the third chariot white horses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the fourth chariot dappled horses—all of them strong.

**<sup>4</sup>** Then I answered and said to the angel who talked with me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“What are these, my lord?”<br/>
**<sup>5</sup>** And the angel answered and said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“These are the four spirits of heaven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;going out after presenting themselves<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the Lord of all the earth.<br/>
**<sup>6</sup>** The chariot with the black horses goes toward the north country,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the white ones go after them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the dappled ones go toward the south country.”<br/>
**<sup>7</sup>** When the strong horses came out,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they were impatient to go and patrol the earth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he said, “Go, patrol the earth.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So they patrolled the earth.<br/>
**<sup>8</sup>** Then he cried to me, “Behold, those who go toward the north country<br/>
&nbsp;&nbsp;&nbsp;&nbsp;have set My Spirit at rest in the north country.”

**<sup>9</sup>** And the word of the LORD came to me: **<sup>10</sup>** “Take from the exiles Heldai, Tobijah, and Jedaiah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who have arrived from Babylon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and go the same day to the house of Josiah, the son of Zephaniah.<br/>
**<sup>11</sup>** Take from them silver and gold, and make a crown,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and set it on the head of Joshua, the son of Jehozadak, the high priest.<br/>
**<sup>12</sup>** And say to him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Thus says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Behold, the man whose name is the Branch:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he shall branch out from his place,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he shall build the temple of the LORD.<br/>
**<sup>13</sup>** It is he who shall build the temple of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall bear royal honor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and shall sit and rule on his throne.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And he shall be a priest on his throne,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the counsel of peace shall be between them both.”’<br/>
**<sup>14</sup>** And the crown shall be in the temple of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as a memorial to Helem, Tobijah, Jedaiah, and Hen the son of Zephaniah.<br/>
**<sup>15</sup>** And those who are far off shall come<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and help to build the temple of the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And you shall know that the LORD of hosts has sent me to you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And this shall come to pass,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if you will diligently obey the voice of the LORD your God.”<br/>


## Chapter 7

**<sup>1</sup>** And in the fourth year of King Darius, the word of the LORD came to Zechariah on the fourth day of the ninth month, which is Chislev. **<sup>2</sup>** Now the people of Bethel had sent Sharezer and Regem-melech and their men to entreat the favor of the LORD, **<sup>3</sup>** saying to the priests of the house of the LORD of hosts and the prophets, “Should I weep and abstain in the fifth month, as I have done for so many years?”

**<sup>4</sup>** Then the word of the LORD of hosts came to me: **<sup>5</sup>** “Say to all the people of the land and the priests, ‘When you fasted and mourned in the fifth month and in the seventh, for these seventy years, was it for Me that you fasted? **<sup>6</sup>** And when you eat and when you drink, do you not eat for yourselves and drink for yourselves? **<sup>7</sup>** Were not these the words that the LORD proclaimed by the former prophets, when Jerusalem was inhabited and prosperous, with her cities around her, and the South and the lowland were inhabited?’”

**<sup>8</sup>** And the word of the LORD came to Zechariah, saying, **<sup>9</sup>** “Thus says the LORD of hosts, Render true judgments, show kindness and mercy to one another, **<sup>10</sup>** do not oppress the widow, the fatherless, the sojourner, or the poor, and let none of you devise evil against another in your heart. **<sup>11</sup>** But they refused to pay attention and turned a stubborn shoulder and stopped their ears that they might not hear. **<sup>12</sup>** They made their hearts diamond-hard lest they should hear the law and the words that the LORD of hosts had sent by His Spirit through the former prophets. Therefore great wrath came from the LORD of hosts.”

**<sup>13</sup>** “As I called, and they would not hear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so they called, and I would not hear,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts,<br/>
**<sup>14</sup>** “and I scattered them with a whirlwind among all the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they had not known.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thus the land they left was desolate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that no one went to and fro,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the pleasant land was made a desolation.”<br/>


## Chapter 8

**<sup>1</sup>** And the word of the LORD of hosts came, saying, **<sup>2</sup>** “Thus says the LORD of hosts: I am jealous for Zion with great jealousy, and I am jealous for her with great wrath. **<sup>3</sup>** Thus says the LORD: I have returned to Zion and will dwell in the midst of Jerusalem, and Jerusalem shall be called the faithful city, and the mountain of the LORD of hosts, the holy mountain.”

**<sup>4</sup>** Thus says the LORD of hosts: Old men and old women shall again sit in the streets of Jerusalem, each with staff in hand because of great age. **<sup>5</sup>** And the streets of the city shall be full of boys and girls playing in its streets.

**<sup>6</sup>** Thus says the LORD of hosts: If it is marvelous in the sight of the remnant of this people in those days, should it also be marvelous in My sight? declares the LORD of hosts.

**<sup>7</sup>** Thus says the LORD of hosts: Behold, I will save My people from the east country and from the west country, **<sup>8</sup>** and I will bring them to dwell in the midst of Jerusalem. And they shall be My people, and I will be their God, in faithfulness and in righteousness.

**<sup>9</sup>** Thus says the LORD of hosts: Let your hands be strong, you who in these days have been hearing these words from the mouth of the prophets, who were present on the day that the foundation was laid for the house of the LORD of hosts, that the temple might be built. **<sup>10</sup>** For before those days there was no wage for man or any wage for beast, neither was there any safety from the foe for him who went out or came in, for I set every man against his neighbor. **<sup>11</sup>** But now I will not deal with the remnant of this people as in the former days, declares the LORD of hosts. **<sup>12</sup>** For there shall be a sowing of peace. The vine shall give its fruit, and the ground shall give its produce, and the heavens shall give their dew. And I will cause the remnant of this people to inherit all these things. **<sup>13</sup>** And as you have been a byword of cursing among the nations, O house of Judah and house of Israel, so will I save you, and you shall be a blessing. Fear not, but let your hands be strong.

**<sup>14</sup>** For thus says the LORD of hosts: As I purposed to bring disaster to you when your fathers provoked Me to wrath, and I did not relent, says the LORD of hosts, **<sup>15</sup>** so again have I purposed in these days to bring good to Jerusalem and to the house of Judah; fear not. **<sup>16</sup>** These are the things that you shall do: Speak the truth to one another; render in your gates judgments that are true and make for peace; **<sup>17</sup>** do not devise evil in your hearts against one another, and love no false oath, for all these things I hate, declares the LORD.”

**<sup>18</sup>** And the word of the LORD of hosts came to me, saying, **<sup>19</sup>** “Thus says the LORD of hosts: The fast of the fourth month and the fast of the fifth, and the fast of the seventh and the fast of the tenth shall be to the house of Judah seasons of joy and gladness and cheerful feasts. Therefore love truth and peace.

**<sup>20</sup>** Thus says the LORD of hosts: Peoples shall yet come, even the inhabitants of many cities. **<sup>21</sup>** The inhabitants of one city shall go to another, saying, ‘Let us go at once to entreat the favor of the LORD and to seek the LORD of hosts; I myself am going.’ **<sup>22</sup>** Many peoples and strong nations shall come to seek the LORD of hosts in Jerusalem and to entreat the favor of the LORD.

**<sup>23</sup>** Thus says the LORD of hosts: In those days ten men from the nations of every tongue shall take hold of the robe of a Jew, saying, ‘Let us go with you, for we have heard that God is with you.’” 

## Chapter 9

**<sup>1</sup>** The burden of the word of the LORD is against the land of Hadrach, and Damascus is its resting place—for the eye of man and of all the tribes of Israel is toward the LORD— **<sup>2</sup>** and also Hamath, which borders on it, Tyre and Sidon, though they are very wise. **<sup>3</sup>** Tyre has built herself a rampart and heaped up silver like dust, and gold like the mud of the streets. **<sup>4</sup>** But behold, the Lord will dispossess her and cast down her power into the sea, and she shall be devoured by fire.

**<sup>5</sup>** Ashkelon shall see it and be afraid; Gaza too, and shall writhe in anguish; Ekron also, because its hope has withered. The king shall perish from Gaza; Ashkelon shall be uninhabited. **<sup>6</sup>** A mixed people shall dwell in Ashdod, and I will cut off the pride of Philistia. **<sup>7</sup>** I will take away its blood from its mouth and its abominations from between its teeth; it too shall be a remnant for our God; it shall be like a clan in Judah, and Ekron shall be like the Jebusites **<sup>8</sup>** Then I will encamp at My house as a guard, so that none shall march to and fro; no oppressor shall again overrun them, for now I see with My own eyes.

**<sup>9</sup>** Rejoice greatly, O daughter of Zion!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Shout aloud, O daughter of Jerusalem!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Behold, your king is coming to you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He is righteous and having salvation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;humble and mounted on a donkey,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on a colt, the foal of a donkey.<br/>
**<sup>10</sup>** And I will cut off the chariot from Ephraim<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the war horse from Jerusalem;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the battle bow shall be cut off,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he shall speak peace to the nations;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his rule shall be from sea to sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the River to the ends of the earth.

**<sup>11</sup>** As for you also, because of the blood of your covenant,I will set your prisoners free from the waterless pit. **<sup>12</sup>** Return to your stronghold, O prisoners of hope; today I declare that I will restore to you double. **<sup>13</sup>** For I have bent Judah as My bow; I have made Ephraim its arrow. I will stir up. your sons, O Zion, against your sons, O Greece, and wield you like a warrior’s sword. **<sup>14</sup>** Then the LORD will appear over them, and His arrow will go forth like lightning; the Lord GOD will sound the trumpet and will march forth in the whirlwinds of the south. **<sup>15</sup>** The LORD of hosts will protect them, and they shall devour and tread down the sling stones, and they shall drink and roar as if drunk with wine, and be full like a bowl, drenched like the corners of the altar.

**<sup>16</sup>** On that day the LORD their God will save them as the flock of His people; for like the jewels of a crown they shall shine on His land. **<sup>17</sup>** For how great is His goodness, and how great His beauty! Grain shall make the young men flourish, and new wine the young women. 

## Chapter 10

**<sup>1</sup>** Ask rain from the LORD in the season of the spring rain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the LORD who makes the storm clouds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He will give them showers of rain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to everyone the vegetation in the field.<br/>
**<sup>2</sup>** For the household gods utter nonsense,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the diviners see lies;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they tell false dreams and give empty consolation.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Therefore the people wander like sheep;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are afflicted for lack of a shepherd.<br/>
**<sup>3</sup>** My anger is hot against the shepherds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will punish the leaders;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the LORD of hosts cares for His flock, the house of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and will make them like His majestic steed in battle.<br/>
**<sup>4</sup>** From him shall come the cornerstone,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from him the tent peg,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from him the battle bow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from him every ruler—all of them together.<br/>
**<sup>5</sup>** They shall be like mighty men in battle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;trampling the foe in the mud of the streets;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall fight because the LORD is with them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall put to shame the riders on horses.<br/>
**<sup>6</sup>** I will strengthen the house of Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will save the house of Joseph.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will bring them back<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because I have compassion on them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall be as though I had not rejected them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I am the LORD their God and I will answer them.<br/>
**<sup>7</sup>** Then Ephraim shall become like a mighty warrior,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their hearts shall be glad as with wine.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their children shall see it and be glad;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their hearts shall rejoice in the LORD.<br/>
**<sup>8</sup>** I will whistle for them and gather them in,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I have redeemed them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall be as many as they were before.<br/>
**<sup>9</sup>** Though I scattered them among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet in far countries they shall remember Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and with their children they shall live and return.<br/>
**<sup>10</sup>** I will bring them home from the land of Egypt<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gather them from Assyria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will bring them to the land of Gilead and to Lebanon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;till there is no room for them.<br/>
**<sup>11</sup>** He shall pass through the sea of troubles<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and strike down the waves of the sea,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the depths of the Nile shall be dried up.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The pride of Assyria shall be laid low,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the scepter of Egypt shall depart.<br/>
**<sup>12</sup>** I will make them strong in the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall walk in His name,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>


## Chapter 11

**<sup>1</sup>** Open your doors, O Lebanon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that fire may devour your cedars!<br/>
**<sup>2</sup>** Wail, O cypress, for the cedar has fallen,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the glorious trees are ruined!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Wail, oaks of Bashan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the thick forest has been felled!<br/>
**<sup>3</sup>** The sound of the wail of the shepherds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for their glory is ruined!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The sound of the roar of the lions,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the thicket of the Jordan is laid waste!

**<sup>4</sup>** Thus said the LORD my God: “Shepherd the flock doomed to slaughter. **<sup>5</sup>** Those who buy them slaughter them and go unpunished,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and those who sell them say, ‘Blessed be the LORD, I have become rich,’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their own shepherds have no pity on them.<br/>
**<sup>6</sup>** For I will no longer have pity on the inhabitants of this land,” declares the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Behold, I will cause each of them to fall into the hand of his neighbor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and into the hand of his king;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall crush the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will deliver none from their hand.”

**<sup>7</sup>** So I became the shepherd of the flock doomed to be slaughtered by the sheep traders.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And I took two staffs; one I named Favor, the other I named Union.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And I shepherded the flock.<br/>
**<sup>8</sup>** In one month I destroyed the three shepherds.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But I became impatient with them, and they also detested me.<br/>
**<sup>9</sup>** So I said, “I will not shepherd you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What is to die, let it die.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What is to be destroyed, let it be destroyed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let those who are left devour the flesh of one another.”

**<sup>10</sup>** And I took my staff Favor, and I broke it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;annulling the covenant that I had made with all the peoples.<br/>
**<sup>11</sup>** So it was annulled on that day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the sheep traders, who were watching me, knew that it was the word of the LORD.

**<sup>12</sup>** Then I said to them, “If it seems good to you, give me my wages; but if not, keep them.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And they weighed out as my wages thirty pieces of silver.<br/>
**<sup>13</sup>** Then the LORD said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Throw it to the potter”—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the handsome price at which I was priced by them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So I took the thirty pieces of silver<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and threw them into the house of the LORD, to the potter.

**<sup>14</sup>** Then I broke my second staff Union,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;annulling the brotherhood between Judah and Israel.<br/>
**<sup>15</sup>** Then the LORD said to me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Take once more the equipment of a foolish shepherd.<br/>
**<sup>16</sup>** For behold, I am raising up in the land<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a shepherd who does not care for those being destroyed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or seek the young,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or heal the maimed, or nourish the healthy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but devours the flesh of the fat ones,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;tearing off even their hoofs.<br/>
**<sup>17</sup>** Woe to the worthless shepherd<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who deserts the flock!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;May the sword strike his arm<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his right eye!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Let his arm be wholly withered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his right eye utterly blinded!”<br/>


## Chapter 12

**<sup>1</sup>** The burden of the word of the LORD concerning Israel:

Thus declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who stretches out the heavens<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lays the foundation of the earth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and forms the spirit of man within him:**<sup>2</sup>** “Behold, I am about to make Jerusalem a cup of staggering<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to all the surrounding peoples.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The siege of Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will also be against Judah.<br/>
**<sup>3</sup>** On that day I will make Jerusalem a heavy stone for all the peoples.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All who lift it will surely hurt themselves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the nations of the earth will gather against it.<br/>
**<sup>4</sup>** On that day,” declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I will strike every horse with panic,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its rider with madness.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But for the house of Judah I will keep my eyes open,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I strike every horse of the peoples with blindness.<br/>
**<sup>5</sup>** Then the clans of Judah shall say to themselves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘The inhabitants of Jerusalem are our strength<br/>
&nbsp;&nbsp;&nbsp;&nbsp;through the LORD of hosts, their God.’<br/>
**<sup>6</sup>** On that day I will make the clans of Judah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a blazing pot in the midst of wood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a flaming torch among sheaves.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They shall devour to the right and to the left<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the surrounding peoples,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while Jerusalem shall again be inhabited in its place, in Jerusalem.<br/>
**<sup>7</sup>** And the LORD will give salvation to the tents of Judah first,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that the glory of the house of David<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the glory of the inhabitants of Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may not surpass that of Judah.<br/>
**<sup>8</sup>** On that day the LORD will protect the inhabitants of Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that the feeblest among them on that day shall be like David,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the house of David shall be like God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like the angel of the LORD going before them.<br/>
**<sup>9</sup>** And on that day I will seek to destroy<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all the nations that come against Jerusalem.<br/>
**<sup>10</sup>** And I will pour out on the house of David<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the inhabitants of Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a spirit of grace and supplication,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that, when they look on Me, on Him whom they have pierced,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall mourn for Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as one mourns for an only son,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and weep bitterly over Him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as one weeps over a firstborn.<br/>
**<sup>11</sup>** On that day the mourning in Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be as great as the mourning for Hadad-rimmon<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the plain of Megiddo.<br/>
**<sup>12</sup>** The land shall mourn, each family by itself:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the family of the house of David by itself, and their wives by themselves;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the family of the house of Nathan by itself, and their wives by themselves;<br/>
**<sup>13</sup>** the family of the house of Levi by itself, and their wives by themselves;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the family of the Shimeites by itself, and their wives by themselves;<br/>
**<sup>14</sup>** and all the families that are left, each by itself,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their wives by themselves.<br/>


## Chapter 13

**<sup>1</sup>** On that day there shall be a fountain opened<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the house of David and the inhabitants of Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to cleanse from sin and impurity.<br/>
**<sup>2</sup>** And on that day, declares the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will cut off the names of the idols from the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that they shall be remembered no more.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And also I will remove from the land the prophets<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the spirit of uncleanness.<br/>
**<sup>3</sup>** And if anyone still prophesies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his father and mother who bore him shall say to him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘You shall not live,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you speak lies in the name of the LORD.’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And his father and mother who bore him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall pierce him through when he prophesies.<br/>
**<sup>4</sup>** On that day every prophet will be ashamed of his vision<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when he prophesies.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will not put on a hairy cloak in order to deceive,<br/>
**<sup>5</sup>** but he will say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘I am no prophet,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am a tiller of the soil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for a man sold me in my youth.’<br/>
**<sup>6</sup>** And if one asks him, ‘What are these wounds on your back?’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘The wounds I received in the house of my friends.’

**<sup>7</sup>** Awake, O sword, against My shepherd,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against the man who stands next to Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD of hosts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Strike the shepherd, and the sheep shall be scattered;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will turn My hand against the little ones.<br/>
**<sup>8</sup>** In the whole land, declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;two-thirds shall be cut off and perish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and one-third shall be left alive.<br/>
**<sup>9</sup>** And I will put this third into the fire,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and refine them as one refines silver,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and test them as gold is tested.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They will call upon My name, and I will answer them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will say, ‘They are My people’;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will say, ‘The LORD is my God.’<br/>


## Chapter 14

**<sup>1</sup>** Behold, a day is coming for the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when the spoil taken from you will be divided in your midst.<br/>
**<sup>2</sup>** For I will gather all the nations against Jerusalem to battle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the city shall be taken<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the houses plundered<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the women raped.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Half of the city shall go out into exile,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the rest of the people shall not be cut off from the city.<br/>
**<sup>3</sup>** Then the LORD will go out and fight against those nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as when He fights on a day of battle.<br/>
**<sup>4</sup>** On that day His feet shall stand on the Mount of Olives<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that lies before Jerusalem on the east,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the Mount of Olives shall be split in two from east to west<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by a very wide valley,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that one half of the mountain shall move northward,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the other half southward.<br/>
**<sup>5</sup>** And you shall flee to the valley of My mountains,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the valley of the mountains shall reach to Azal.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And you shall flee as you fled from the earthquake<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the days of Uzziah king of Judah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Then the LORD my God will come,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all the holy ones with Him.<br/>
**<sup>6</sup>** On that day there shall be no light,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the luminaries will dwindle.<br/>
**<sup>7</sup>** It shall be a unique day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which is known to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;neither day nor night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but at evening time there shall be light.<br/>
**<sup>8</sup>** On that day living waters shall flow out from Jerusalem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;half of them to the eastern sea<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and half of them to the western sea.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;It shall continue in summer as in winter.<br/>
**<sup>9</sup>** And the LORD will be king over all the earth.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;On that day the LORD will be one<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and His name one.<br/>
**<sup>10</sup>** The whole land shall be turned into a plain<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from Geba to Rimmon south of Jerusalem.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But Jerusalem shall remain aloft on its site<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from the Gate of Benjamin<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the place of the former gate, to the Corner Gate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the Tower of Hananel to the king's winepresses.<br/>
**<sup>11</sup>** And it shall be inhabited,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for there shall never again be a decree of utter destruction.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jerusalem shall dwell in security.<br/>
**<sup>12</sup>** And this shall be the plague<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with which the LORD will strike all the peoples<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that wage war against Jerusalem:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their flesh will rot while they are still standing on their feet,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their eyes will rot in their sockets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their tongues will rot in their mouths.<br/>
**<sup>13</sup>** And on that day a great panic from the LORD shall fall on them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that each will seize the hand of another,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the hand of the one will be raised against the hand of the other.<br/>
**<sup>14</sup>** Even Judah will fight at Jerusalem.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And the wealth of all the surrounding nations shall be collected,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;gold, silver, and garments in great abundance.<br/>
**<sup>15</sup>** And a plague like this plague<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall fall on the horses, the mules, the camels, the donkeys,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and whatever beasts may be in those camps.

**<sup>16</sup>** Then everyone who survives<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of all the nations that came against Jerusalem<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall go up year after year to worship the King, the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to keep the Feast of Booths.<br/>
**<sup>17</sup>** And if any of the families of the earth<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not go up to Jerusalem to worship the King, the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there will be no rain on them.<br/>
**<sup>18</sup>** And if the family of Egypt does not go up and enter in,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then on them shall come the plague<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with which the LORD afflicts the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that do not go up to keep the Feast of Booths.<br/>
**<sup>19</sup>** This shall be the punishment to Egypt<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the punishment to all the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that do not go up to keep the Feast of Booths.<br/>
**<sup>20</sup>** And on that day there shall be inscribed on the bells of the horses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Holy to the LORD.”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And the pots in the house of the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall be as the bowls before the altar.<br/>
**<sup>21</sup>** And every pot in Jerusalem and Judah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall be holy to the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that all who sacrifice may come and take of them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and boil the meat of the sacrifice in them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And there shall no longer be a trader<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the house of the LORD of hosts on that day.<br/>
