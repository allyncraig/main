# Amos

## Chapter 1

**<sup>1</sup>** The words of Amos, who was among the shepherds from Tekoa, which he saw concerning Israel in the days of Uzziah king of Judah, and in the days of Jeroboam son of Joash king of Israel, two years before the earthquake.

**<sup>2</sup>** And he said:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD roars from Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and utters His voice from Jerusalem;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the pastures of the shepherds mourn,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the top of Carmel dries up.

**<sup>3</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Damascus, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they threshed Gilead with threshing sledges of iron.<br/>
**<sup>4</sup>** So I will send fire upon the house of Hazael,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour the strongholds of Ben-hadad.<br/>
**<sup>5</sup>** I will break the gate bar of Damascus,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cut off the inhabitant from the Valley of Aven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the one who holds the scepter from Beth-eden;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the people of Aram shall go into exile to Kir,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.

**<sup>6</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Gaza, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they carried away an entire people into exile<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to deliver them up to Edom.<br/>
**<sup>7</sup>** So I will send fire upon the wall of Gaza,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour her strongholds.<br/>
**<sup>8</sup>** And I will cut off the inhabitant from Ashdod,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the one who holds the scepter from Ashkelon;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will turn my hand against Ekron,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the remnant of the Philistines shall perish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the Lord GOD.

**<sup>9</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Tyre, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they delivered up an entire people into exile from Edom,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and did not remember the covenant of brothers.<br/>
**<sup>10</sup>** So I will send fire upon the wall of Tyre,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour her strongholds.

**<sup>11</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Edom, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because he pursued his brother with the sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cast off all compassion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his anger tore continually,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he kept his wrath forever.<br/>
**<sup>12</sup>** So I will send fire upon Teman,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour the strongholds of Bozrah.

**<sup>13</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of the Ammonites, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they ripped open pregnant women in Gilead<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to enlarge their territory.<br/>
**<sup>14</sup>** So I will kindle a fire in the wall of Rabbah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour her strongholds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with shouting on the day of battle,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with a storm on the day of whirlwind.<br/>
**<sup>15</sup>** And their king shall go into exile,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he and his princes together,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>


## Chapter 2

**<sup>1</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Moab, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because he burned the bones of the king of Edom to lime.<br/>
**<sup>2</sup>** So I will send fire upon Moab,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour the strongholds of Kerioth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Moab shall die amid tumult,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with shouting, with the sound of the trumpet.<br/>
**<sup>3</sup>** And I will cut off the ruler from her midst,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will slay all her princes with him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.

**<sup>4</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Judah, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they rejected the law of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have not kept His statutes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but their lies have led them astray,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;after which their fathers walked.<br/>
**<sup>5</sup>** So I will send fire upon Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall devour the strongholds of Jerusalem.

**<sup>6</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For three transgressions of Israel, even for four,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not turn back the punishment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they sell the righteous for silver,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the needy for a pair of sandals—<br/>
**<sup>7</sup>** those who trample on the head of the poor into the dust of the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and turn aside the way of the afflicted.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;A man and his father go in to the same girl,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that My holy name is profaned.<br/>
**<sup>8</sup>** They lie down beside every altar<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on garments taken in pledge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in the house of their god<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they drink the wine of those who have been punished.<br/>
**<sup>9</sup>** Yet I destroyed the Amorites before them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;whose height was like the height of the cedars,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and who was strong as the oaks;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I destroyed his fruit above<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his roots beneath.<br/>
**<sup>10</sup>** Also I brought you up out of the land of Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and led you forty years in the wilderness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to possess the land of the Amorite.<br/>
**<sup>11</sup>** And I raised up some of your sons as prophets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and some of your young men as Nazirites.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is this not true, O sons of Israel?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>
**<sup>12</sup>** But you made the Nazirites drink wine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and commanded the prophets, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“You shall not prophesy.”<br/>
**<sup>13</sup>** So then, I will press you down in your place,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as a cart full of sheaves presses down.<br/>
**<sup>14</sup>** Flight shall perish from the swift,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the strong shall not strengthen his power,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor shall the mighty save his life.<br/>
**<sup>15</sup>** He who handles the bow shall not stand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the swift of foot shall not escape,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor shall the horseman save his life.<br/>
**<sup>16</sup>** And he who is stout of heart among the mighty<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall flee away naked in that day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>


## Chapter 3

**<sup>1</sup>** Hear this word that the LORD has spoken against you, O sons of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against the whole family that I brought up out of the land of Egypt, saying:<br/>
**<sup>2</sup>** “You only have I known among all the families of the earth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore I will punish you for all your iniquities.”

**<sup>3</sup>** Do two walk together,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;unless they have agreed to meet?<br/>
**<sup>4</sup>** Does a lion roar in the forest,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when he has no prey?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Does a young lion growl from his den,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;unless he has caught something?

**<sup>5</sup>** Does a bird fall in a snare on the ground,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when there is no bait for it?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Does a snare spring up from the ground,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when it has taken nothing at all?<br/>
**<sup>6</sup>** If a trumpet is blown in a city,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not the people tremble?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If disaster comes to a city,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;has not the LORD allowed it?

**<sup>7</sup>** For the Lord GOD does nothing<br/>
&nbsp;&nbsp;&nbsp;&nbsp;without revealing His counsel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to His servants the prophets.<br/>
**<sup>8</sup>** The lion has roared; who will not fear?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The Lord GOD has spoken; who can but prophesy?

**<sup>9</sup>** Proclaim it in the citadels of Ashdod<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in the citadels of the land of Egypt, and say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Assemble yourselves on the mountains of Samaria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and see the great tumults within her,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the oppressions in her midst.”<br/>
**<sup>10</sup>** “They do not know how to do what is right,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“those who store up violence and robbery in their citadels.”<br/>
**<sup>11</sup>** Therefore, thus says the Lord GOD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"An adversary shall surround the land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and bring down your strength from you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your citadels shall be plundered."

**<sup>12</sup>** Thus says the LORD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"Just as the shepherd snatches from the mouth of the lion<br/>
&nbsp;&nbsp;&nbsp;&nbsp;two legs or a piece of an ear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so shall the sons of Israel who dwell in Samaria be snatched—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the corner of a couch and on the damask of a bed."<br/>
**<sup>13</sup>** "Hear and testify against the house of Jacob,"<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the Lord GOD, the God of hosts,<br/>
**<sup>14</sup>** "that on the day I punish Israel for his transgressions,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will also punish the altars of Bethel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the horns of the altar shall be cut off<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and fall to the ground.<br/>
**<sup>15</sup>** I will strike the winter house along with the summer house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the houses of ivory shall perish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the great houses shall come to an end,"<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>


## Chapter 4

**<sup>1</sup>** Hear this word, you cows of Bashan, who are on the mountain of Samaria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who oppress the poor, who crush the needy,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who say to their husbands, “Bring, that we may drink!”<br/>
**<sup>2</sup>** The Lord GOD has sworn by His holiness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Behold, the days are coming upon you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when they shall take you away with hooks,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your descendants with fishhooks.<br/>
**<sup>3</sup>** You shall go out through the breaches, each one straight ahead,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you shall be cast out toward Harmon,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>4</sup>** “Come to Bethel, and transgress;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to Gilgal, and multiply transgression;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;bring your sacrifices every morning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your tithes every three days;<br/>
**<sup>5</sup>** offer a sacrifice of thanksgiving of that which is leavened,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and proclaim freewill offerings, publish them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for so you love to do, O sons of Israel!”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the Lord GOD.

**<sup>6</sup>** “I also gave you cleanness of teeth in all your cities,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and lack of bread in all your places,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet you did not return to Me,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.<br/>
**<sup>7</sup>** “And I also withheld the rain from you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when there were still three months to the harvest;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I caused it to rain on one city,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on another city I did not cause it to rain;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;one portion was rained upon,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the portion where it did not rain withered.<br/>
**<sup>8</sup>** So two or three cities wandered to one city to drink water,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but they were not satisfied;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet you did not return to Me,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>9</sup>** “I struck you with blight and mildew;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your many gardens and your vineyards,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your fig trees and your olive trees the locust devoured;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet you did not return to Me,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>10</sup>** “I sent among you a plague in the manner of Egypt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I slew your young men with the sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;along with your captured horses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I made the stench of your camps go up into your nostrils;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet you did not return to Me,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>11</sup>** “I overthrew some of you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as when God overthrew Sodom and Gomorrah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you were like a brand plucked from the burning;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet you did not return to Me,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD.

**<sup>12</sup>** “Therefore this is what I will do to you, O Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and because I will do this to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;prepare to meet your God, O Israel!”

**<sup>13</sup>** For see here, He who forms the mountains and creates the wind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and declares to man what is His thought,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who makes the dawn into darkness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and treads upon the high places of the earth—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD, the God of hosts, is His name.<br/>


## Chapter 5

**<sup>1</sup>** Hear this word that I take up as a lamentation over you, O house of Israel: **<sup>2</sup>** “Fallen, no more to rise, is the virgin Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;forsaken on her land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with none to raise her up.”

**<sup>3</sup>** For thus says the Lord GOD:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“The city that went out with a thousand<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall have a hundred left,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and that which went out with a hundred<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall have ten left,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the house of Israel.”

**<sup>4</sup>** For thus says the LORD to the house of Israel:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Seek Me and live;<br/>
**<sup>5</sup>** but do not seek Bethel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor enter into Gilgal,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor cross over to Beersheba;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for Gilgal shall surely go into exile,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Bethel shall come to nothing.”

**<sup>6</sup>** Seek the LORD and live,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;lest He break out like fire in the house of Joseph,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it devour, with none to quench it for Bethel,<br/>
**<sup>7</sup>** O you who turn justice to wormwood<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and cast righteousness down to the earth.

**<sup>8</sup>** He who made the Pleiades and Orion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and turns deep darkness into morning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and darkens the day into night,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who calls for the waters of the sea<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and pours them out upon the face of the earth—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the LORD is His name—<br/>
**<sup>9</sup>** who makes destruction flash out against the strong,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that destruction comes upon the fortress.

**<sup>10</sup>** They hate him who reproves in the gate,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they abhor him who speaks with integrity.<br/>
**<sup>11</sup>** Therefore, because you trample on the poor<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and take from him levies of grain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have built houses of hewn stone,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but you shall not dwell in them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have planted pleasant vineyards,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but you shall not drink their wine.

**<sup>12</sup>** For I know how many are your transgressions,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and how great are your sins—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you who afflict the righteous,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;take a bribe,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and turn aside the needy in the gate.

**<sup>13</sup>** Therefore the prudent will keep silent in such a time,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for it is an evil time.

**<sup>14</sup>** Seek good and not evil, that you may live;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and so the LORD, the God of hosts, will be with you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as you have said.<br/>
**<sup>15</sup>** Hate evil and love good,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and establish justice in the gate;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then it may be that the LORD, the God of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will be gracious to the remnant of Joseph.

**<sup>16</sup>** Therefore thus says the LORD, the God of hosts, the Lord:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“In all the squares there shall be wailing,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in all the streets they shall say, ‘Woe! Woe!’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They shall call the farmer to mourning,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to wailing those skilled in lamentation,<br/>
**<sup>17</sup>** and in all vineyards there shall be wailing,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for I will pass through your midst,” says the LORD.

**<sup>18</sup>** Woe to you who desire the day of the LORD!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why would you have the day of the LORD?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;It is darkness, and not light;<br/>
**<sup>19</sup>** as if a man fled from a lion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a bear met him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or went into the house and leaned his hand against the wall,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a serpent bit him.<br/>
**<sup>20</sup>** Is not the day of the LORD darkness, and not light,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gloom with no brightness in it?

**<sup>21</sup>** “I hate, and I despise your feasts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I take no delight in your solemn assemblies.<br/>
**<sup>22</sup>** Even though you offer Me your burnt offerings and grain offerings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not accept them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the peace offerings of your fattened animals,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not look upon them.<br/>
**<sup>23</sup>** Take away from Me the noise of your songs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not listen to the melody of your harps.

**<sup>24</sup>** But let justice roll down like waters,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and righteousness like an ever-flowing stream.

**<sup>25</sup>** Did you bring to Me sacrifices and offerings<br/>
&nbsp;&nbsp;&nbsp;&nbsp;during the forty years in the wilderness, O house of Israel?<br/>
**<sup>26</sup>** You shall take up Sikkuth your king,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Kiyyun your images,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;your star-god that you made for yourselves.<br/>
**<sup>27</sup>** Therefore I will send you into exile beyond Damascus,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD, whose name is the God of hosts.<br/>


## Chapter 6

**<sup>1</sup>** Woe to those who are at ease in Zion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to those who feel secure on the mountain of Samaria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the notable ones of the first of the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to whom the house of Israel comes!<br/>
**<sup>2</sup>** Pass over to Calneh and see,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from there go to Hamath the great;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then go down to Gath of the Philistines.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Are they better than these kingdoms?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Is their territory greater than your territory?<br/>
**<sup>3</sup>** You who put far away the day of disaster<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and bring near the seat of violence,<br/>
**<sup>4</sup>** who lie on beds of ivory<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and stretch themselves out on their couches,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and eat lambs from the flock<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and calves from the midst of the stall,<br/>
**<sup>5</sup>** who sing idle songs to the sound of the harp<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and like David invent for themselves instruments of music,<br/>
**<sup>6</sup>** who drink wine in bowls<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and anoint themselves with the finest oils,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but are not grieved over the ruin of Joseph.<br/>
**<sup>7</sup>** Therefore they shall now go into exile at the head of the exiles,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the revelry of those who stretch themselves out shall pass away.

**<sup>8</sup>** The Lord GOD has sworn by Himself,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;declares the LORD, the God of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“I abhor the pride of Jacob<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and hate his strongholds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will deliver up the city and all that is in it.”<br/>
**<sup>9</sup>** And if ten men remain in one house, they shall die. **<sup>10</sup>** And when one’s relative, the one who burns him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;takes him up to bring out the bones from the house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and says to him who is in the innermost parts of the house,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Is there still anyone with you?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he says, “No,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he shall say, “Silence!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;We must not mention the name of the LORD.”<br/>
**<sup>11</sup>** For behold, the LORD commands,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the great house shall be struck down into fragments,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the little house into bits.

**<sup>12</sup>** Do horses run on rocks?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Does one plow the sea with oxen?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you have turned justice into poison<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the fruit of righteousness into wormwood—<br/>
**<sup>13</sup>** you who rejoice in Lo-debar,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who say, “Have we not by our own strength<br/>
&nbsp;&nbsp;&nbsp;&nbsp;captured Karnaim for ourselves?”<br/>
**<sup>14</sup>** “For look how I am raising up against you a nation,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O house of Israel,” declares the LORD, the God of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“and they shall oppress you from Lebo-hamath<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to the Brook of the Arabah.”<br/>


## Chapter 7

**<sup>1</sup>** This is what the Lord GOD showed me: He was forming locusts at the beginning of the coming up of the latter growth, and it was the latter growth after the king’s mowing. **<sup>2</sup>** And it came to pass, when they had finished eating the grass of the land, that I said, “O Lord GOD, forgive, I beg You! How can Jacob stand? For he is small.” **<sup>3</sup>** The LORD relented concerning this. “It shall not be,” said the LORD.

**<sup>4</sup>** This is what the Lord GOD showed me: the Lord GOD was calling for a judgment by fire, and it devoured the great deep and was eating up the portion of land. **<sup>5</sup>** Then I said, “O Lord GOD, cease, I beg You! How can Jacob stand? For he is small.” **<sup>6</sup>** The LORD relented concerning this. “This also shall not be,” said the Lord GOD.

**<sup>7</sup>** This is what He showed me: the Lord was standing beside a wall built with a plumb line, and in His hand was a plumb line. **<sup>8</sup>** And the LORD said to me, “Amos, what do you see?” And I said, “A plumb line.” Then the Lord said, “Look how I am setting a plumb line in the midst of My people Israel; I will not again pass by them. **<sup>9</sup>** The high places of Isaac shall be made desolate, and the sanctuaries of Israel shall be laid waste, and I will rise against the house of Jeroboam with the sword.”

**<sup>10</sup>** Then Amaziah the priest of Bethel sent to Jeroboam king of Israel, saying, “Amos has conspired against you in the midst of the house of Israel; the land is not able to bear all his words. **<sup>11</sup>** For thus Amos has said, ‘Jeroboam shall die by the sword, and Israel shall surely go into exile away from his land.’” **<sup>12</sup>** And Amaziah said to Amos, “O seer, go, flee away to the land of Judah, and eat bread there, and there you may prophesy. **<sup>13</sup>** But never again prophesy at Bethel, for it is the king’s sanctuary, and it is a royal house.” **<sup>14</sup>** Then Amos answered and said to Amaziah, “I was no prophet, nor was I a prophet’s son, but I was a herdsman and a dresser of sycamore figs. **<sup>15</sup>** But the LORD took me from following the flock, and the LORD said to me, ‘Go, prophesy to My people Israel.’ **<sup>16</sup>** Now therefore hear the word of the LORD: You say, ‘Do not prophesy against Israel, and do not preach against the house of Isaac.’ **<sup>17</sup>** Therefore thus says the LORD: ‘Your wife shall become a prostitute in the city, and your sons and your daughters shall fall by the sword, and your land shall be divided by line; you yourself shall die in an unclean land, and Israel shall surely go into exile away from its land.’” 

## Chapter 8

**<sup>1</sup>** This is what the Lord GOD showed me: a basket of summer fruit. **<sup>2</sup>** And He said, “Amos, what do you see?” And I said, “A basket of summer fruit.” Then the LORD said to me, “The end has come for My people Israel; I will not again pass by them. **<sup>3</sup>** The songs of the temple shall become wailings in that day,” declares the Lord GOD. “The dead bodies shall be many; in every place they shall cast them out in silence.” **<sup>4</sup>** Hear this, you who trample on the needy, to make the poor of the land fail, **<sup>5</sup>** saying, “When will the new moon pass, so that we may sell grain? And the Sabbath, so that we may open the wheat market—making the ephah small and the shekel great, and falsifying dishonest scales, **<sup>6</sup>** to buy the poor for silver and the needy for a pair of sandals, and sell the refuse of the wheat?” **<sup>7</sup>** The LORD has sworn by the pride of Jacob, “Surely I will never forget any of their deeds. **<sup>8</sup>** Shall the land not tremble for this, and everyone who dwells in it mourn? And all of it shall rise up like the Nile; it shall be tossed about and subside like the Nile of Egypt.” **<sup>9</sup>** “And it shall come to pass in that day,” declares the Lord GOD, “that I will cause the sun to go down at noon, and I will darken the earth in broad daylight. **<sup>10</sup>** And I will turn your feasts into mourning and all your songs into lamentation. I will bring sackcloth on every waist and baldness on every head. I will make it like mourning for an only son, and its end like a bitter day.”

**<sup>11</sup>** “Look! The days are coming,” declares the Lord GOD, “when I will send a famine in the land—not a famine of bread nor a thirst for water, but of hearing the words of the LORD. **<sup>12</sup>** They shall wander from sea to sea and from the north even to the east; they shall run to and fro to seek the word of the LORD, but they shall not find it. **<sup>13</sup>** In that day the fair virgins and the young men shall faint from thirst. **<sup>14</sup>** Those who swear by the guilt of Samaria and say, ‘As your god lives, O Dan,’ and, ‘As the way of Beersheba lives’—they shall fall and never rise again.” 

## Chapter 9

**<sup>1</sup>** I saw the Lord standing beside the altar, and He said: “Strike the capitals so that the thresholds shake, and shatter them upon the heads of them all; and the last of them I will slay with the sword. Not one of them shall flee away, and not one of them shall escape. **<sup>2</sup>** Though they dig into the grave, My hand shall take them from there; and though they climb up to heaven, I will bring them down from there. **<sup>3</sup>** Though they hide themselves on the top of Carmel, I will search them out from there and take them; and though they hide from My eyes at the bottom of the sea, I will command the serpent that is there, and it shall bite them. **<sup>4</sup>** And though they go into captivity before their enemies, I will command the sword there, and it shall slay them. And I will set My eyes upon them for evil and not for good.”

**<sup>5</sup>** The Lord, the GOD of Hosts—He who touches the earth so that it melts, and makes all who dwell in it mourn, and makes it rise up like the Nile, and sink again like the Nile of Egypt— **<sup>6</sup>** who builds His upper chambers in the heavens and has founded His vault upon the earth, who calls for the waters of the sea and pours them out upon the surface of the earth—the LORD is His name.

**<sup>7</sup>** “Aren't you like the sons of the Cushites to Me, O sons of Israel?” declares the LORD. “Didn't I bring Israel up out of the land of Egypt, and the Philistines from Caphtor, and the Arameans from Kir? **<sup>8</sup>** See how the eyes of the Lord GOD are upon the sinful kingdom, and I will destroy it entirely from the face of the earth—except that I will not utterly destroy the house of Jacob,” declares the LORD. **<sup>9</sup>** “For, I will command, and I will shake the house of Israel among all the nations, as grain is shaken in a sieve, but not a pebble shall fall to the ground. **<sup>10</sup>** All the sinners of My people shall die by the sword, those who say, ‘Disaster shall not overtake or confront us.’”

**<sup>11</sup>** “In that day I will raise up the fallen stronghold of David, and I will repair its breaches, and raise up its ruins, and rebuild it as in days of old, **<sup>12</sup>** that they may possess the remnant of Edom and all the nations who are called by My name,” declares the LORD who does this.

**<sup>13</sup>** “See, the days are coming,” declares the LORD, “when the plowman shall overtake the reaper and the treader of grapes him who sows seed; and the mountains shall drip sweet wine, and all the hills shall flow with it. **<sup>14</sup>** I will restore the fortunes of My people Israel, and they shall rebuild the ruined cities and inhabit them; they shall plant vineyards and drink their wine, and they shall make gardens and eat their fruit. **<sup>15</sup>** I will plant them upon their land, and they shall never again be uprooted from their land that I have given them,” says the LORD your God. 