# Hosea

## Chapter 1

**<sup>1</sup>** The word of the LORD that came to Hosea son of Beeri, in the days of Uzziah, Jotham, Ahaz, and Hezekiah, kings of Judah, and in the days of Jeroboam son of Joash, king of Israel.

**<sup>2</sup>** When the LORD first spoke through Hosea, the LORD said to Hosea, “Go, take for yourself a wife of prostitution and children of prostitution, for the land commits great prostitution by forsaking the LORD.” **<sup>3</sup>** So he went and took Gomer, daughter of Diblaim, and she conceived and bore him a son.

**<sup>4</sup>** Then the LORD said to him, “Name him Jezreel, for in a little while I will punish the house of Jehu for the blood of Jezreel, and I will put an end to the kingdom of the house of Israel. **<sup>5</sup>** On that day I will break the bow of Israel in the Valley of Jezreel.”

**<sup>6</sup>** Then she conceived again and bore a daughter. And He said to him, “Name her Lo-Ruhamah, for I will no longer show mercy to the house of Israel, that I should ever forgive them. **<sup>7</sup>** But I will show mercy to the house of Judah, and I will save them by the LORD their God. I will not save them by bow or by sword or by war, by horses or horsemen.”

**<sup>8</sup>** After she had weaned Lo-Ruhamah, she conceived and bore a son. **<sup>9</sup>** And He said, “Name him Lo-Ammi, for you are not My people, and I am not your God.” **<sup>10</sup>** Yet the number of the sons of Israel shall be like the sand of the sea, which cannot be measured or counted. And in the place where it was said to them, “You are not My people,” it shall be said to them, “Sons of the living God.” **<sup>11</sup>** And the sons of Judah and the sons of Israel shall be gathered together, and they shall appoint for themselves one head. And they shall go up from the land, for great is the day of Jezreel. 

## Chapter 2

**<sup>1</sup>** Say to your brothers, “Ammi,” and to your sisters, “Ruhamah.” **<sup>2</sup>** Contend with your mother, contend— for she is not my wife, and I am not her husband— so let her remove her prostitution from her face and her adultery from between her breasts, **<sup>3</sup>** lest I strip her naked and expose her as on the day of her birth. I will make her like a wilderness and render her like a parched land, and let her die of thirst.

**<sup>4</sup>** And I will not have compassion on her children, for they are children of prostitution. **<sup>5</sup>** For their mother has played the whore; she who conceived them has acted shamefully. For she said, “I will go after my lovers, who give me my bread and my water, my wool and my flax, my oil and my drink.”

**<sup>6</sup>** Therefore, look how I will hedge up her path with thorns, and I will build a wall against her so that she cannot find her paths. **<sup>7</sup>** She will pursue her lovers but will not overtake them; she will seek them but not find them. Then she will say, “I will go and return to my first husband, for it was better for me then than now.” **<sup>8</sup>** But she did not know that it was I who gave her the grain, the new wine, and the oil, and who lavished on her silver and gold— which they used for Baal.

**<sup>9</sup>** Therefore I will take back my grain in its time, and my new wine in its season, and I will remove my wool and my flax given to cover her nakedness. **<sup>10</sup>** Now I will uncover her lewdness in the sight of her lovers, and no one will rescue her out of my hand. **<sup>11</sup>** And I will put an end to all her joy, her feasts, her new moons, her Sabbaths— all her appointed times. **<sup>12</sup>** And I will lay waste her vines and her fig trees, of which she said, “These are my wages which my lovers have given me.” I will make them a forest, and the beasts of the field shall devour them. **<sup>13</sup>** I will punish her for the days of the Baals, to whom she burned incense. She adorned herself with earrings and jewelry, and went after her lovers, but Me she forgot—declares the LORD.

**<sup>14</sup>** Therefore, see how I will allure her and bring her into the wilderness, and speak tenderly to her. **<sup>15</sup>** And there I will give her vineyards, and the Valley of Achor as a door of hope. And she shall respond there as in the days of her youth, as in the day when she came up from the land of Egypt. **<sup>16</sup>** In that day—declares the LORD—you will call Me “My Husband,” and no longer will you call Me “My Baal.” **<sup>17</sup>** For I will remove the names of the Baals from her mouth, and they shall be remembered by name no more. **<sup>18</sup>** And I will make for them a covenant on that day with the beasts of the field and the birds of the sky and the creeping things of the ground. And I will abolish the bow and the sword and war from the land, and I will make them lie down in safety. **<sup>19</sup>** And I will betroth you to Me forever; I will betroth you to Me in righteousness and in justice, in covenant loyalty and in compassion. **<sup>20</sup>** I will betroth you to Me in faithfulness, and you shall know the LORD.

**<sup>21</sup>** On that day, I will answer—declares the LORD— I will answer the heavens, and they shall answer the earth, **<sup>22</sup>** and the earth shall answer the grain and the new wine and the oil, and they shall answer Jezreel. **<sup>23</sup>** I will sow her for Myself in the land, and I will have compassion on Lo-Ruhamah, and I will say to Lo-Ammi, “You are My people.” And he will say, “You are my God.” 

## Chapter 3

**<sup>1</sup>** Then the LORD said to me, “Go again, love a woman who is loved by another and is an adulteress, just as the LORD loves the sons of Israel, though they turn to other gods and love raisin cakes.” **<sup>2</sup>** So I bought her for myself for fifteen shekels of silver and a homer and a lethech of barley. **<sup>3</sup>** And I said to her, “You must dwell with me for many days. You shall not play the whore, and you shall not belong to another man, and I also will be faithful to you.” **<sup>4</sup>** For the sons of Israel shall dwell many days without king and without prince, without sacrifice and without pillar, and without ephod and teraphim. **<sup>5</sup>** Afterward the sons of Israel will return and seek the LORD their God and David their king, and they will come trembling to the LORD and to His goodness in the latter days. 

## Chapter 4

**<sup>1</sup>** Hear the word of the LORD, O sons of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the LORD has a dispute with the inhabitants of the land:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there is no truth, no covenant loyalty,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no knowledge of God in the land.<br/>
**<sup>2</sup>** There is swearing and lying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;murder and stealing and adultery;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they break all bounds,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and bloodshed follows bloodshed.<br/>
**<sup>3</sup>** Therefore the land mourns,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all who dwell in it languish,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;along with the beasts of the field and the birds of the heavens;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;even the fish of the sea are taken away.

**<sup>4</sup>** Yet let no man contend,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let no man rebuke,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for your people are like those who contend with a priest.<br/>
**<sup>5</sup>** You shall stumble by day,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the prophet also shall stumble with you by night;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will destroy your mother.<br/>
**<sup>6</sup>** My people are destroyed for lack of knowledge;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because you have rejected knowledge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I reject you from being a priest to Me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And since you have forgotten the law of your God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I also will forget your children.<br/>
**<sup>7</sup>** The more they multiplied, the more they sinned against Me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will change their glory into shame.<br/>
**<sup>8</sup>** They feed on the sin of My people;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are greedy for their iniquity.

**<sup>9</sup>** And it shall be like people, like priest:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will punish them for their ways<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and repay them for their deeds.<br/>
**<sup>10</sup>** They shall eat but not be satisfied;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall play the whore but not multiply,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they have forsaken the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to cherish whoredom,<br/>
**<sup>11</sup>** wine, and new wine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;which take away understanding.

**<sup>12</sup>** My people inquire of a piece of wood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their staff gives them oracles.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For a spirit of whoredom has led them astray,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they have played the whore, departing from their God.<br/>
**<sup>13</sup>** They sacrifice on the tops of the mountains<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and burn offerings on the hills,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;under oak, poplar, and terebinth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because their shade is good.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Therefore your daughters play the whore,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your brides commit adultery.<br/>
**<sup>14</sup>** I will not punish your daughters when they play the whore,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor your brides when they commit adultery;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the men themselves go aside with whores<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and sacrifice with cult prostitutes,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a people without understanding shall be thrown down.

**<sup>15</sup>** Though you play the whore, O Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;let not Judah become guilty.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Do not go to Gilgal,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;do not go up to Beth-aven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not swear, “As the LORD lives.”<br/>
**<sup>16</sup>** Like a stubborn heifer,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel is stubborn;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;can the LORD now pasture them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a lamb in a broad pasture?<br/>
**<sup>17</sup>** Ephraim is joined to idols;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;leave him alone.<br/>
**<sup>18</sup>** When their drinking is done,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they give themselves to whoring;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their rulers dearly love shame.<br/>
**<sup>19</sup>** A wind has wrapped them in its wings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall be ashamed because of their sacrifices.<br/>


## Chapter 5

**<sup>1</sup>** Hear this, O priests!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Give heed, O house of Israel!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Listen, O house of the king!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the judgment is for you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because you have been a snare at Mizpah<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a net spread over Tabor.<br/>
**<sup>2</sup>** The revolters have gone deep into slaughter,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but I will discipline them all.<br/>
**<sup>3</sup>** I know Ephraim,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Israel is not hidden from Me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for now, O Ephraim, you have played the whore;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel is defiled.<br/>
**<sup>4</sup>** Their deeds do not allow them to return to their God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for a spirit of whoredom is within them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they do not know the LORD.

**<sup>5</sup>** The pride of Israel testifies against him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel and Ephraim shall stumble in their guilt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Judah also shall stumble with them.<br/>
**<sup>6</sup>** With their flocks and herds they shall go<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to seek the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but they will not find Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has withdrawn from them.<br/>
**<sup>7</sup>** They have dealt treacherously with the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they have borne illegitimate children;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;now the new moon shall devour them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with their fields.

**<sup>8</sup>** Blow the horn in Gibeah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the trumpet in Ramah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Sound the alarm at Beth-aven:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;behind you, Benjamin!<br/>
**<sup>9</sup>** Ephraim shall become a desolation<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the day of punishment;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;among the tribes of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I make known what is sure.

**<sup>10</sup>** The princes of Judah have become<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like those who move the landmark;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;upon them I will pour out<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My wrath like water.<br/>
**<sup>11</sup>** Ephraim is oppressed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;crushed by judgment,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because he was determined<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to walk after filth.<br/>
**<sup>12</sup>** But I am like a moth to Ephraim,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and like rottenness to the house of Judah.<br/>
**<sup>13</sup>** When Ephraim saw his sickness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Judah his wound,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then Ephraim went to Assyria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and sent to the great king,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but he is not able to heal you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or cure your wound.<br/>
**<sup>14</sup>** For I will be like a lion to Ephraim,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and like a young lion to the house of Judah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I, even I, will tear and go away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will carry off, and no one shall rescue.<br/>
**<sup>15</sup>** I will return again to My place,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until they acknowledge their guilt and seek My face,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in their distress earnestly seek Me.<br/>


## Chapter 6

**<sup>1</sup>** Come, let us return to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for He has torn us, but He will heal us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He has struck us down, but He will bind us up.<br/>
**<sup>2</sup>** After two days He will revive us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the third day He will raise us up,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that we may live before Him.<br/>
**<sup>3</sup>** Let us know—yes, let us pursue knowledge of the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;His coming forth is as sure as the dawn.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will come to us like the rain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like the latter rain that waters the earth.

**<sup>4</sup>** What shall I do with you, O Ephraim?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What shall I do with you, O Judah?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your loyalty is like the morning cloud,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like the dew that goes early away.<br/>
**<sup>5</sup>** Therefore I have hewn them by the prophets,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have slain them by the words of My mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and My judgment goes forth like the light.

**<sup>6</sup>** For I desire steadfast love and not sacrifice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the knowledge of God rather than burnt offerings.<br/>
**<sup>7</sup>** But like Adam they transgressed the covenant;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there they dealt faithlessly with Me.

**<sup>8</sup>** Gilead is a city of evildoers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;tracked with blood.<br/>
**<sup>9</sup>** As bands of robbers lie in wait for a man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so the company of priests murder on the way to Shechem;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yes, they commit wickedness.<br/>
**<sup>10</sup>** In the house of Israel I have seen a horrible thing:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there Ephraim plays the whore,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel is defiled.<br/>
**<sup>11</sup>** For you also, O Judah, a harvest is appointed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I restore the fortunes of My people.<br/>


## Chapter 7

**<sup>1</sup>** When I would heal Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then the iniquity of Ephraim is uncovered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the wickedness of Samaria;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they commit falsehood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the thief breaks in,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the band of robbers raids outside.<br/>
**<sup>2</sup>** But they do not consider in their hearts<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that I remember all their evil.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Now their deeds surround them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are before My face.<br/>
**<sup>3</sup>** By their wickedness they make the king glad,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the princes by their lies.<br/>
**<sup>4</sup>** They are all adulterers;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are like an oven heated by the baker,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who ceases stirring from kneading the dough<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until it is leavened.

**<sup>5</sup>** On the day of our king, the princes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;become sick with the heat of wine;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he stretches out his hand with scorners.<br/>
**<sup>6</sup>** For they prepare their hearts like an oven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;while they lie in wait.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their anger smolders all night;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the morning it burns like a flaming fire.<br/>
**<sup>7</sup>** They are all hot as an oven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they devour their judges.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;All their kings have fallen;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;none among them calls to Me.

**<sup>8</sup>** Ephraim mixes himself with the peoples;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Ephraim is a cake not turned.<br/>
**<sup>9</sup>** Strangers devour his strength,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet he does not know it.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Even gray hairs are sprinkled on him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet he does not know.<br/>
**<sup>10</sup>** The pride of Israel testifies against him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they do not return to the LORD their God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;nor seek Him for all this.<br/>
**<sup>11</sup>** Ephraim is like a dove, silly and without sense;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they call to Egypt, they go to Assyria.<br/>
**<sup>12</sup>** As they go, I will spread My net over them;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will bring them down like the birds of the heavens;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will chastise them according to what was heard in their assembly.<br/>
**<sup>13</sup>** Woe to them, for they have strayed from Me!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Destruction to them, for they have rebelled against Me!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Though I would redeem them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they speak lies against Me.<br/>
**<sup>14</sup>** They do not cry to Me from the heart,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but they wail upon their beds.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For grain and wine they gather themselves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they rebel against Me.<br/>
**<sup>15</sup>** Though I trained and strengthened their arms,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;yet they devise evil against Me.<br/>
**<sup>16</sup>** They return, but not upward;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are like a treacherous bow.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Their princes shall fall by the sword<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the rage of their tongue.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;This will be their derision in the land of Egypt.<br/>


## Chapter 8

**<sup>1</sup>** Set the trumpet to your lips!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Like an eagle over the house of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they have transgressed My covenant<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and rebelled against My law.<br/>
**<sup>2</sup>** They cry to Me, “My God, we—Israel—know You!” **<sup>3</sup>** Israel has rejected the good;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the enemy shall pursue him.<br/>
**<sup>4</sup>** They set up kings, but not by Me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they appoint princes, but I did not acknowledge them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;With their silver and gold they make idols for themselves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that they might be cut off.<br/>
**<sup>5</sup>** Your calf, O Samaria, has cast you off.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My anger burns against them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How long will they be incapable of innocence?<br/>
**<sup>6</sup>** For it is from Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a craftsman made it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it is not God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Surely the calf of Samaria shall be broken in pieces.

**<sup>7</sup>** For they sow the wind,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall reap the whirlwind.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The stalk has no head,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it shall yield no grain.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If it were to yield,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;strangers would devour it.<br/>
**<sup>8</sup>** Israel is swallowed up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;now they are among the nations<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a worthless vessel.<br/>
**<sup>9</sup>** For they have gone up to Assyria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a wild donkey wandering alone;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Ephraim has hired lovers.<br/>
**<sup>10</sup>** Even though they hire among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will now gather them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they shall begin to diminish<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the burden of king and princes.

**<sup>11</sup>** Because Ephraim has multiplied altars for sin,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they have become to him altars for sinning.<br/>
**<sup>12</sup>** Though I wrote for him myriads of My laws,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they are regarded as a strange thing.<br/>
**<sup>13</sup>** As for My sacrificial offerings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they sacrifice meat and eat it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but the LORD does not accept them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Now He will remember their iniquity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and punish their sins;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall return to Egypt.<br/>
**<sup>14</sup>** For Israel has forgotten his Maker<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and built palaces,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Judah has multiplied fortified cities.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But I will send fire upon his cities,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and it shall consume her fortresses.<br/>


## Chapter 9

**<sup>1</sup>** Do not rejoice, O Israel, with exultation like the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you have played the whore, forsaking your God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have loved a prostitute's wages on every threshing floor.<br/>
**<sup>2</sup>** Threshing floor and winepress shall not feed them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the new wine shall fail them.<br/>
**<sup>3</sup>** They shall not remain in the land of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but Ephraim shall return to Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in Assyria they shall eat unclean food.<br/>
**<sup>4</sup>** They shall not pour out wine offerings to the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their sacrifices shall not please Him.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They shall be to them like mourners’ bread;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all who eat of it shall be defiled.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For their bread is for their hunger only;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;it shall not come to the house of the LORD.

**<sup>5</sup>** What will you do on the day of the appointed festival,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and on the day of the feast of the LORD?<br/>
**<sup>6</sup>** For behold, they are gone because of destruction;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Egypt shall gather them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Memphis shall bury them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Nettles shall possess their treasures of silver;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;thorns shall be in their tents.<br/>
**<sup>7</sup>** The days of punishment have come;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the days of recompense have arrived.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Let Israel know it!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The prophet is a fool,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the man of the spirit is mad,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of the greatness of your iniquity<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and great hostility.<br/>
**<sup>8</sup>** Ephraim is a watchman with my God—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a prophet!—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a fowler’s snare is on all his paths,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and enmity is in the house of his God.<br/>
**<sup>9</sup>** They have deeply corrupted themselves<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as in the days of Gibeah.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will remember their iniquity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will punish their sins.<br/>
**<sup>10</sup>** Like grapes in the wilderness I found Israel.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Like the first fruit on the fig tree in its first season I saw your fathers.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But they came to Baal-peor,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and consecrated themselves to shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and became detestable like the thing they loved.

**<sup>11</sup>** Ephraim’s glory shall fly away like a bird—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;no birth, no pregnancy, no conception!<br/>
**<sup>12</sup>** Even if they bring up children,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will bereave them till none is left.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Woe to them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when I depart from them!<br/>
**<sup>13</sup>** Ephraim, as I have seen, was like Tyre,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;planted in a meadow;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but Ephraim must lead out his children to slaughter.

**<sup>14</sup>** Give them, O LORD—what will You give?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Give them a miscarrying womb<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and dry breasts.<br/>
**<sup>15</sup>** Every evil of theirs is in Gilgal;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there I began to hate them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Because of the wickedness of their deeds<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will drive them out of My house.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will love them no more;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;all their princes are rebels.<br/>
**<sup>16</sup>** Ephraim is stricken;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their root is dried up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall bear no fruit.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Even though they give birth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will put to death the beloved ones of their womb.<br/>
**<sup>17</sup>** My God will reject them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they have not listened to Him;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall be wanderers among the nations.<br/>


## Chapter 10

**<sup>1</sup>** Israel is a luxuriant vine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he yields fruit for himself.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The more his fruit increased,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the more he increased the altars.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The better his land,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the better they made the sacred pillars.<br/>
**<sup>2</sup>** Their heart is false;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;now they must bear their guilt.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD will break down their altars<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and destroy their sacred pillars.<br/>
**<sup>3</sup>** For now they will say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“We have no king,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for we did not fear the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And a king—what could he do for us?”<br/>
**<sup>4</sup>** They speak empty words,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;swearing falsely, making covenants;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so judgment springs up like hemlock<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in the furrows of the field.

**<sup>5</sup>** The inhabitants of Samaria tremble<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the calf of Beth-aven.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Indeed, its people will mourn over it,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its idolatrous priests—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;those who rejoiced over it—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for its glory has departed from it.<br/>
**<sup>6</sup>** It shall also be carried to Assyria<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as tribute to the great king.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Ephraim shall receive shame,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and Israel shall be ashamed of his own counsel.<br/>
**<sup>7</sup>** Samaria is destroyed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;her king is like a twig<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the face of the waters.<br/>
**<sup>8</sup>** The high places of Aven, the sin of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall be destroyed.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Thorn and thistle shall grow on their altars.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And they shall say to the mountains, “Cover us,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to the hills, “Fall on us.”

**<sup>9</sup>** From the days of Gibeah you have sinned, O Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;there they have continued.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Shall not war overtake them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in Gibeah for the sons of iniquity?<br/>
**<sup>10</sup>** When I please, I will discipline them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and nations shall be gathered against them<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when they are bound for their double guilt.<br/>
**<sup>11</sup>** Ephraim was a trained heifer<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that loved to thresh,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I spared her fair neck.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will make Ephraim to ride;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Judah shall plow,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Jacob shall break his clods.

**<sup>12</sup>** Sow for yourselves righteousness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;reap steadfast love;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;break up your fallow ground,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for it is time to seek the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that He may come and rain righteousness upon you.<br/>
**<sup>13</sup>** You have plowed wickedness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have reaped injustice,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have eaten the fruit of lies.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Because you have trusted in your own way<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in the multitude of your warriors,<br/>
**<sup>14</sup>** therefore the tumult of war shall arise among your people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and all your fortresses shall be destroyed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as Shalman destroyed Beth-arbel on the day of battle;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;mothers were dashed in pieces with their children.<br/>
**<sup>15</sup>** Thus it shall be done to you, O Bethel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because of your great wickedness.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;At dawn the king of Israel<br/>
&nbsp;&nbsp;&nbsp;&nbsp;shall be utterly cut off.<br/>


## Chapter 11

**<sup>1</sup>** When Israel was a child, I loved him,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and out of Egypt I called my son.<br/>
**<sup>2</sup>** The more they were called, the more they went away;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they kept sacrificing to the Baals and burning offerings to idols.<br/>
**<sup>3</sup>** Yet it was I who taught Ephraim to walk;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I took them up by their arms, but they did not know that I healed them.<br/>
**<sup>4</sup>** I led them with cords of kindness, with bands of love,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I became to them as one who lifts the yoke from their jaws;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I bent down to them and fed them.

**<sup>5</sup>** He shall not return to the land of Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but Assyria shall be his king,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because they refused to return.<br/>
**<sup>6</sup>** The sword shall rage against their cities,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and consume the bars of their gates,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and devour them because of their own counsels.<br/>
**<sup>7</sup>** My people are bent on turning away from me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Though they call to the Most High, none at all will exalt him.

**<sup>8</sup>** How can I give you up, O Ephraim?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How can I hand you over, O Israel?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How can I make you like Admah?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;How can I treat you like Zeboiim?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My heart turns within me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;my compassion grows warm and tender.<br/>
**<sup>9</sup>** I will not execute the fierceness of my anger;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will not again destroy Ephraim.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I am God and not a man,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the Holy One in your midst,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will not come in wrath.

**<sup>10</sup>** They shall follow the LORD;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he will roar like a lion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when he roars,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his sons shall come trembling from the west.<br/>
**<sup>11</sup>** They shall come trembling like birds from Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and like doves from the land of Assyria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will return them to their homes, declares the LORD.

**<sup>12</sup>** Ephraim has surrounded me with lies,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the house of Israel with deceit;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but Judah still walks with God and is faithful to the Holy One.<br/>


## Chapter 12

**<sup>1</sup>** Ephraim feeds on wind and pursues the east wind all day long;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he multiplies lies and violence.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They make a covenant with Assyria,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and oil is carried to Egypt.

**<sup>2</sup>** The LORD has a dispute with Judah and will punish Jacob according to his ways;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;according to his deeds he will repay him.<br/>
**<sup>3</sup>** In the womb he took his brother by the heel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in his manhood he strove with God.<br/>
**<sup>4</sup>** He strove with the angel and prevailed;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he wept and sought his favor.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;At Bethel he found him, and there he spoke with us—<br/>
**<sup>5</sup>** the LORD, the God of hosts, the LORD is his memorial name. **<sup>6</sup>** So you, by the help of your God, return,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;keep kindness and justice, and wait continually for your God.

**<sup>7</sup>** A merchant in whose hands are false balances, he loves to oppress. **<sup>8</sup>** Ephraim said, “Surely I have become rich, I have found wealth for myself;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;in all my labors they cannot find in me iniquity or sin.”<br/>
**<sup>9</sup>** But I am the LORD your God from the land of Egypt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will again make you dwell in tents, as in the days of the appointed festival.

**<sup>10</sup>** I spoke to the prophets; it was I who multiplied visions,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and through the prophets gave parables.<br/>
**<sup>11</sup>** If Gilead is wicked, surely they are worthless.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In Gilgal they sacrifice bulls—indeed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their altars are like stone heaps in the furrows of the field.<br/>
**<sup>12</sup>** Jacob fled to the land of Aram;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Israel served for a wife, and for a wife he kept sheep.<br/>
**<sup>13</sup>** By a prophet the LORD brought Israel up from Egypt,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and by a prophet he was guarded.<br/>
**<sup>14</sup>** Ephraim has bitterly provoked his Lord;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore his Lord will leave his bloodguilt upon him and repay him for his reproach.<br/>


## Chapter 13

**<sup>1</sup>** When Ephraim spoke, there was trembling;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he was exalted in Israel, but he incurred guilt through Baal and died.<br/>
**<sup>2</sup>** And now they sin more and more, and make for themselves molten images,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;idols skillfully made from their silver, all of them the work of craftsmen.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;They say of them, “Let the men who sacrifice kiss the calves!”

**<sup>3</sup>** Therefore they shall be like the morning mist, like the dew that goes early away,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like chaff that swirls from the threshing floor, or like smoke from a window.

**<sup>4</sup>** But I am the LORD your God from the land of Egypt;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you know no God but me, and besides me there is no savior.<br/>
**<sup>5</sup>** It was I who knew you in the wilderness, in the land of drought. **<sup>6</sup>** But when they had pasture, they were filled;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they were filled, and their heart was lifted up;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore they forgot me.

**<sup>7</sup>** So I will be to them like a lion;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;like a leopard I will lurk beside the way.<br/>
**<sup>8</sup>** I will fall upon them like a bear robbed of her cubs;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will tear open their breast, and there I will devour them like a lion,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as wild beasts would rip them open.

**<sup>9</sup>** He destroys you, O Israel, for you are against me, against your help. **<sup>10</sup>** Where now is your king, to save you in all your cities?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Where are all your rulers, of whom you said, “Give me a king and princes”?<br/>
**<sup>11</sup>** I gave you a king in my anger, and I took him away in my wrath.

**<sup>12</sup>** The iniquity of Ephraim is bound up; his sin is stored up. **<sup>13</sup>** The pangs of childbirth come for him, but he is an unwise son,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for at the right time he does not present himself at the opening of the womb.

**<sup>14</sup>** Shall I ransom them from the power of the grave?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Shall I redeem them from death? O Death, where are your plagues?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O grave, where is your sting? Compassion is hidden from my eyes.

**<sup>15</sup>** Though he may flourish among his brothers, the east wind shall come,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the wind of the LORD rising from the wilderness, and his fountain shall dry up,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his spring shall be parched. It shall strip his treasury of every precious thing.<br/>
**<sup>16</sup>** Samaria shall bear her guilt, for she has rebelled against her God;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall fall by the sword, their infants shall be dashed in pieces,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and their pregnant women ripped open.<br/>


## Chapter 14

**<sup>1</sup>** Return, O Israel, to the LORD your God,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you have stumbled by your iniquity.<br/>
**<sup>2</sup>** Take with you words and return to the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Say to him, “Take away all iniquity;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;accept what is good, and we will offer the fruit of our lips.<br/>
**<sup>3</sup>** Assyria shall not save us;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;we will not ride on horses, and we will say no more,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;‘Our God,’ to the work of our hands.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For in you the orphan finds mercy.”

**<sup>4</sup>** I will heal their apostasy;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will love them freely,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for my anger has turned away from him.<br/>
**<sup>5</sup>** I will be like the dew to Israel;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he shall blossom like the lily<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and take root like the cedars of Lebanon.<br/>
**<sup>6</sup>** His shoots shall spread out;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;his beauty shall be like the olive tree,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and his fragrance like Lebanon.<br/>
**<sup>7</sup>** They shall return and dwell beneath my shadow;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall flourish like the grain,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;they shall blossom like the vine,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;their renown shall be like the wine of Lebanon.

**<sup>8</sup>** Ephraim shall say, “What have I to do with idols?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;It is I who answer and watch over him.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I am like a green cypress tree;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;from me comes your fruit.

**<sup>9</sup>** Who is wise, that he may understand these things,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;discerning, that he may know them?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For the ways of the LORD are right,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the righteous walk in them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but transgressors stumble in them.<br/>
