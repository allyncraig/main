# The First Book of Moses, called Genesis

## Chapter 1

**<sup>1</sup>** In the beginning, God created the heavens and the earth. **<sup>2</sup>** Now the earth was formless and empty, and darkness was over the surface of the deep, and the Spirit of God was hovering over the waters.

**<sup>3</sup>** Then God said, "Let there be light," and there was light. **<sup>4</sup>** God saw that the light was good, and He separated the light from the darkness. **<sup>5</sup>** God called the light "day," and the darkness He called "night." And there was evening, and there was morning—the first day.

**<sup>6</sup>** Then God said, "Let there be an expanse between the waters, to separate water from water." **<sup>7</sup>** So God made the expanse and separated the water beneath the expanse from the water above it, and it was so. **<sup>8</sup>** God called the expanse "sky." And there was evening, and there was morning—the second day.

**<sup>9</sup>** Then God said, "Let the waters under the sky be gathered into one place, and let dry land appear." And it was so. **<sup>10</sup>** God called the dry land "earth," and the gathered waters He called "seas." And God saw that it was good.

**<sup>11</sup>** Then God said, "Let the earth produce vegetation: seed-bearing plants, and trees bearing fruit with seed in it, according to their kinds." And it was so. **<sup>12</sup>** The earth brought forth vegetation, seed-bearing plants according to their kinds, and trees producing fruit with seed in it according to their kinds. And God saw that it was good. **<sup>13</sup>** And there was evening, and there was morning—the third day.

**<sup>14</sup>** Then God said, "Let there be lights in the expanse of the sky to separate the day from the night, and let them serve as signs to mark seasons, days, and years. **<sup>15</sup>** And let these lights be in the expanse of the sky to shine upon the earth." And it was so. **<sup>16</sup>** God established the two great lights: the greater light to govern the day and the lesser light to govern the night and the stars. **<sup>17</sup>** God set them in the expanse of the sky to shine upon the earth, **<sup>18</sup>** to rule over the day and the night, and to separate light from darkness. And God saw that it was good. **<sup>19</sup>** And there was evening, and there was morning—the fourth day.

**<sup>20</sup>** Then God said, "Let the waters teem with living creatures, and let birds fly above the earth across the expanse of the sky." **<sup>21</sup>** So God created the great sea creatures and every living thing that moves, with which the waters swarm, according to their kinds, and every winged bird according to its kind. And God saw that it was good. **<sup>22</sup>** Then God blessed them, saying, "Be fruitful and multiply, and fill the waters in the seas, and let the birds multiply on the earth." **<sup>23</sup>** And there was evening, and there was morning—the fifth day.

**<sup>24</sup>** Then God said, "Let the earth bring forth living creatures according to their kinds—livestock, moving things, and land animals according to their kinds." And it was so. **<sup>25</sup>** God made the land animals according to their kinds, the livestock according to their kinds, and everything that moves on the ground according to its kind. And God saw that it was good.

**<sup>26</sup>** Then God said, "Let us make man in Our image, after Our likeness, and let him rule over the fish of the sea, the birds of the sky, the livestock, all the earth, and every creeping thing that moves on the earth." **<sup>27</sup>** So God created man in His own image; in the image of God He created him; male and female He created them.

**<sup>28</sup>** And God blessed them and said to them, "Be fruitful and multiply; fill the earth and subdue it. Rule over the fish of the sea, the birds of the sky, and every living thing that moves on the earth." **<sup>29</sup>** Then God said, "See all of these seed-bearing plants on the face of the whole earth and all the trees that produce fruit with seed in it? I have given them to you for food. **<sup>30</sup>** And to every land animal, every bird of the sky, and everything that moves on the earth—everything that has the breath of life in it—I have given them every green plant for food." And it was so.

**<sup>31</sup>** And God observed all that He had made, and saw that it was very good. And there was evening, and there was morning—the sixth day. 

## Chapter 2

**<sup>1</sup>** Thus the heavens and the earth, along with all the creatures, were completed. **<sup>2</sup>** On the seventh day, God finished the work that He had done, and He rested on the seventh day from all the work that He had done. **<sup>3</sup>** Then God blessed the seventh day and made it holy, because on it He rested from all the work of creation that He had done.

**<sup>4</sup>** These are the records of the heavens and the earth when they were created, in the day that the LORD God made the earth and the heavens. **<sup>5</sup>** No shrub of the field had yet appeared on the land, and no plant of the field had yet sprouted, for the LORD God had not sent rain upon the land, and there was no man to cultivate the ground. **<sup>6</sup>** But a mist would rise from the earth and water the entire surface of the ground.

**<sup>7</sup>** Then the LORD God formed the man from the dust of the ground and breathed into his nostrils the breath of life, and the man became a living being.

**<sup>8</sup>** The LORD God planted a garden in Eden, in the east, and there He placed the man He had formed. **<sup>9</sup>** The LORD God caused every tree that is pleasant to the sight and good for food to grow from the ground, including the tree of life in the middle of the garden, as well as the tree of the knowledge of good and evil.

**<sup>10</sup>** A river flowed out of Eden to water the garden, and from there it divided into four headwaters. **<sup>11</sup>** The name of the first is Pishon; it flows around the entire land of Havilah, where there is gold. **<sup>12</sup>** The gold of that land is pure; bdellium and onyx stone are also there. **<sup>13</sup>** The name of the second river is Gihon; it flows around the entire land of Cush. **<sup>14</sup>** The name of the third river is Tigris; it flows east of Assyria. The fourth river is the Euphrates.

**<sup>15</sup>** The Lord God took the man and placed him in the garden of Eden to cultivate and keep it. **<sup>16</sup>** Then the LORD God commanded the man, saying, "You may eat freely from any tree of the garden, **<sup>17</sup>** but you must not eat from the tree of the knowledge of good and evil, for in the day that you eat from it, you will surely die."

**<sup>18</sup>** Then the LORD God said, "It is not good for the man to be alone; I will make a helper suitable for him." **<sup>19</sup>** The LORD God formed every beast of the field and every bird of the sky out of the ground, and He brought them to the man to see what he would call them. Whatever the man called each living creature, that was its name. **<sup>20</sup>** The man gave names to all the livestock, to the birds of the sky, and to every wild animal, but for Adam, no suitable helper was found. **<sup>21</sup>** So the LORD God caused a deep sleep to fall upon the man, and while he slept, He took one of his ribs and closed up the place with flesh. **<sup>22</sup>** Then, with the rib He had taken from the man, the LORD God fashioned a woman and brought her to him. **<sup>23</sup>** The man said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"This one, at last, is bone of my bones<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and flesh of my flesh;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;she shall be called Woman,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for she was taken out of Man."

**<sup>24</sup>** For this reason, a man shall leave his father and mother and be joined to his wife, and they shall become one flesh. **<sup>25</sup>** And the man and his wife were both naked, yet they felt no shame. 

## Chapter 3

**<sup>1</sup>** Now the serpent was more cunning than any beast of the field that the LORD God had made. He said to the woman, "Did God really say, 'You shall not eat from any tree in the garden'?"

**<sup>2</sup>** The woman answered the serpent, "We may eat the fruit of the trees in the garden, **<sup>3</sup>** but concerning the fruit of the tree that is in the middle of the garden, God said, 'You shall not eat from it, nor shall you touch it, lest you die.'"

**<sup>4</sup>** But the serpent said to the woman, "You will certainly not die! **<sup>5</sup>** For God knows that on the day you eat from it, your eyes will be opened, and you will be like God, knowing good and evil."

**<sup>6</sup>** When the woman saw that the tree was good for food, that it was appealing to the eyes, and that it was desirable for gaining wisdom, she took some of its fruit and ate. She also gave some to her husband, who was with her, and he ate. **<sup>7</sup>** Then the eyes of both of them were opened, and they realized they were naked. So they sewed fig leaves together and made coverings for themselves.

**<sup>8</sup>** Then they heard the sound of the LORD God walking in the garden in the cool of the day, and the man and his wife hid themselves among the trees of the garden from the presence of the LORD God. **<sup>9</sup>** But the LORD God called to the man and said to him, "Where are you?"

**<sup>10</sup>** He answered, "I heard Your voice in the garden, and I was afraid because I was naked, so I hid."

**<sup>11</sup>** Then He said, "Who told you that you were naked? Have you eaten from the tree, which I commanded you not to eat?"

**<sup>12</sup>** The man said, "The woman You gave to be with me—she gave me fruit from the tree, and I ate."

**<sup>13</sup>** Then the LORD God said to the woman, "What is this you have done?"

The woman answered, "The serpent deceived me, and I ate."

**<sup>14</sup>** So the LORD God said to the serpent, "Because you have done this,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you are cursed more than all livestock<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and more than any wild animal.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You will crawl on your belly<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and eat dust all the days of your life.<br/>
**<sup>15</sup>** I will put hostility between you and the woman,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and between your offspring and her offspring.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He will strike your head,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you will strike his heel."

**<sup>16</sup>** To the woman He said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"I will greatly increase your pain in childbirth;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with painful labor you will give birth to children.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Your desire will be for your husband,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but he will rule over you."

**<sup>17</sup>** And to Adam He said, "Because you listened to your wife and ate from the tree about which I commanded you, 'You shall not eat from it,'<br/>
&nbsp;&nbsp;&nbsp;&nbsp;cursed is the ground because of you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;through painful toil you will eat from it all the days of your life.<br/>
**<sup>18</sup>** It will produce thorns and thistles for you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you will eat the plants of the field.<br/>
**<sup>19</sup>** By the sweat of your brow you will eat bread<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until you return to the ground,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because from it you were taken.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For you are dust,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and to dust you will return."

**<sup>20</sup>** The man named his wife Eve, because she was the mother of all the living.

**<sup>21</sup>** And the LORD God made garments of animal skins for Adam and his wife and clothed them.

**<sup>22</sup>** Then the LORD God said, "See how the man has become like one of Us, knowing good and evil? Now, lest he reach out his hand and also take from the tree of life and eat, and live forever—" **<sup>23</sup>** the LORD God sent him out of the garden of Eden to work the ground from which he had been taken. **<sup>24</sup>** He drove the man out, and at the east of the garden of Eden He stationed the cherubim and a flaming sword that turned in every direction to guard the way to the tree of life. 

## Chapter 4

**<sup>1</sup>** Now the man knew his wife Eve, and she conceived and bore Cain. She said, "I have acquired a man with the help of the LORD." **<sup>2</sup>** Later, she gave birth to his brother Abel. Abel became a shepherd of flocks, but Cain worked the ground.

**<sup>3</sup>** In the course of time, Cain brought an offering to the LORD from the fruit of the ground, **<sup>4</sup>** while Abel also brought an offering—some of the firstborn of his flock and their fat portions. The LORD looked favorably on Abel and his offering, **<sup>5</sup>** but He did not look with favor on Cain and his offering. So Cain became very angry, and his face fell.

**<sup>6</sup>** Then the LORD said to Cain, "Why are you angry, and why has your face fallen? **<sup>7</sup>** If you do what is right, will you not be accepted? But if you do not do what is right, sin is crouching at the door. Its desire is for you, but you must rule over it."

**<sup>8</sup>** Cain spoke to his brother Abel, and when they were in the field, Cain rose up against his brother Abel and killed him. **<sup>9</sup>** Then the LORD said to Cain, "Where is your brother Abel?" He answered, "I do not know. Am I my brother's keeper?"

**<sup>10</sup>** The Lord said, "What have you done? The voice of your brother's blood is crying out to Me from the ground! **<sup>11</sup>** So now you are cursed from the ground, which has opened its mouth to receive your brother's blood from your hand. **<sup>12</sup>** When you work the ground, it will no longer yield its strength to you. You will be a restless wanderer on the earth."

**<sup>13</sup>** Cain said to the LORD, "My punishment is too great to bear! **<sup>14</sup>** Today, You are driving me from the face of the ground, and I will be hidden from Your presence. I will be a restless wanderer on the earth, and whoever finds me will kill me."

**<sup>15</sup>** But the LORD said to him, "Not so! If anyone kills Cain, vengeance will be taken on him sevenfold." And the LORD put a mark on Cain so that no one who found him would kill him. **<sup>16</sup>** Then Cain went out from the LORD's presence and settled in the land of Nod, east of Eden.

**<sup>17</sup>** Cain knew his wife, and she conceived and bore Enoch. Then Cain built a city and named it after his son Enoch. **<sup>18</sup>** To Enoch was born Irad, and Irad fathered Mehujael, and Mehujael fathered Methushael, and Methushael fathered Lamech.

**<sup>19</sup>** Lamech took two wives for himself. The name of the first was Adah, and the name of the second was Zillah. **<sup>20</sup>** Adah bore Jabal; he was the father of those who dwell in tents and have livestock. **<sup>21</sup>** His brother's name was Jubal; he was the father of all who play the lyre and flute. **<sup>22</sup>** Zillah also bore Tubal-cain, a forger of all kinds of bronze and iron tools. Tubal-cain's sister was Naamah.

**<sup>23</sup>** Then Lamech said to his wives,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"Adah and Zillah, hear my voice!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Wives of Lamech, listen to my speech!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have killed a man for wounding me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;a young man for striking me.<br/>
**<sup>24</sup>** If Cain is avenged sevenfold,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then Lamech seventy-sevenfold."

**<sup>25</sup>** Adam knew his wife again, and she bore a son and named him Seth, saying, "God has given me another son in place of Abel, because Cain killed him." **<sup>26</sup>** A son was also born to Seth, and he named him Enosh. At that time, men began to call on the name of the LORD. 

## Chapter 5

**<sup>1</sup>** This is the book of the generations of Adam. In the day that God created man, He made him in the likeness of God. **<sup>2</sup>** He created them male and female, and He blessed them and called them Man in the day they were created.

**<sup>3</sup>** When Adam had lived 130 years, he fathered a son in his own likeness, after his image, and he named him Seth. **<sup>4</sup>** The days of Adam after he fathered Seth were 800 years, and he had other sons and daughters. **<sup>5</sup>** So all the days that Adam lived were 930 years, and he died.

**<sup>6</sup>** When Seth had lived 105 years, he fathered Enosh. **<sup>7</sup>** After he fathered Enosh, Seth lived 807 years and had other sons and daughters. **<sup>8</sup>** So all the days of Seth were 912 years, and he died.

**<sup>9</sup>** When Enosh had lived 90 years, he fathered Kenan. **<sup>10</sup>** After he fathered Kenan, Enosh lived 815 years and had other sons and daughters. **<sup>11</sup>** So all the days of Enosh were 905 years, and he died.

**<sup>12</sup>** When Kenan had lived 70 years, he fathered Mahalalel. **<sup>13</sup>** After he fathered Mahalalel, Kenan lived 840 years and had other sons and daughters. **<sup>14</sup>** So all the days of Kenan were 910 years, and he died.

**<sup>15</sup>** When Mahalalel had lived 65 years, he fathered Jared. **<sup>16</sup>** After he fathered Jared, Mahalalel lived 830 years and had other sons and daughters. **<sup>17</sup>** So all the days of Mahalalel were 895 years, and he died.

**<sup>18</sup>** When Jared had lived 162 years, he fathered Enoch. **<sup>19</sup>** After he fathered Enoch, Jared lived 800 years and had other sons and daughters. **<sup>20</sup>** So all the days of Jared were 962 years, and he died.

**<sup>21</sup>** When Enoch had lived 65 years, he fathered Methuselah. **<sup>22</sup>** After he fathered Methuselah, Enoch walked with God for 300 years and had other sons and daughters. **<sup>23</sup>** So all the days of Enoch were 365 years. **<sup>24</sup>** Enoch walked with God, and he was no more, for God took him.

**<sup>25</sup>** When Methuselah had lived 187 years, he fathered Lamech. **<sup>26</sup>** After he fathered Lamech, Methuselah lived 782 years and had other sons and daughters. **<sup>27</sup>** So all the days of Methuselah were 969 years, and he died.

**<sup>28</sup>** When Lamech had lived 182 years, he fathered a son. **<sup>29</sup>** He named him Noah, saying, "This one shall comfort us in our work and the toil of our hands, because of the ground that the LORD has cursed." **<sup>30</sup>** After he fathered Noah, Lamech lived 595 years and had other sons and daughters. **<sup>31</sup>** So all the days of Lamech were 777 years, and he died.

**<sup>32</sup>** When Noah was 500 years old, he fathered Shem, Ham, and Japheth. 

## Chapter 6

**<sup>1</sup>** When men began to multiply on the face of the earth and daughters were born to them, **<sup>2</sup>** the sons of God saw that the daughters of men were beautiful, and they took wives for themselves from whomever they chose. **<sup>3</sup>** Then the LORD said, "My Spirit will not contend with man forever, for he is mortal; his days shall be 120 years."

**<sup>4</sup>** The Nephilim were on the earth in those days—and also afterward—when the sons of God came to the daughters of men and had children by them. These were the mighty men of old, men of renown.

**<sup>5</sup>** The LORD saw that the wickedness of man was great upon the earth, and that every inclination of the thoughts of his heart was only evil all the time. **<sup>6</sup>** The LORD regretted that He had made man on the earth, and He was deeply grieved in His heart. **<sup>7</sup>** So the LORD said, "I will wipe out man, whom I have created, from the face of the earth—man, animals, reptiles, and birds of the sky—for I regret that I have made them." **<sup>8</sup>** But Noah found favor in the eyes of the LORD.

**<sup>9</sup>** This is the account of Noah. Noah was a righteous man, blameless among his generation. Noah walked with God. **<sup>10</sup>** And Noah fathered three sons: Shem, Ham, and Japheth.

**<sup>11</sup>** Now the earth was corrupt before God, and it was filled with violence. **<sup>12</sup>** God looked upon the earth, and saw it was corrupt, for all flesh had corrupted its way upon the earth. **<sup>13</sup>** Then God said to Noah, "I have determined to put an end to all flesh, for the earth is filled with violence because of them. Therefore, I will destroy them along with the earth.

**<sup>14</sup>** Make for yourself an ark of gopher wood. Make rooms in the ark and cover it inside and out with pitch. **<sup>15</sup>** This is how you are to build it: The length of the ark shall be 300 cubits, its width 50 cubits, and its height 30 cubits. **<sup>16</sup>** Make a roof for the ark, finishing it to a cubit above, and set the door of the ark on its side. Make it with lower, second, and third decks.

**<sup>17</sup>** I will bring a flood of waters upon the earth to destroy all flesh under heaven in which there is the breath of life; everything on earth shall perish. **<sup>18</sup>** But I will establish My covenant with you, and you shall enter the ark—you, your sons, your wife, and your sons' wives with you. **<sup>19</sup>** And you shall bring into the ark two of every kind of living animal, male and female, to keep them alive with you. **<sup>20</sup>** Of the birds according to their kinds, of the animals according to their kinds, and of every reptile moving on the ground according to its kind, two of each shall come to you to be kept alive. **<sup>21</sup>** And take with you every kind of food that is eaten, and store it up; it shall serve as food for you and for them."

**<sup>22</sup>** Noah did everything exactly as God had commanded him. 

## Chapter 7

**<sup>1</sup>** Then the LORD said to Noah, "Go into the ark, you and all your household, for I have seen that you are righteous before Me in this generation. **<sup>2</sup>** Take with you seven pairs of every clean animal, a male and its female, and one pair of every unclean animal, a male and its female, **<sup>3</sup>** and also seven pairs of the birds of the heavens, male and female, to keep their offspring alive on the face of all the earth. **<sup>4</sup>** For in seven days I will send rain on the earth for forty days and forty nights, and I will wipe out from the face of the earth every living thing that I have made." **<sup>5</sup>** And Noah did all that the LORD commanded him.

**<sup>6</sup>** Noah was six hundred years old when the floodwaters came upon the earth. **<sup>7</sup>** And Noah and his sons and his wife and his sons' wives went into the ark to escape the waters of the flood. **<sup>8</sup>** Of clean animals and of animals that are not clean, and of birds and of reptiles moving on the ground, **<sup>9</sup>** two by two, male and female, they entered the ark with Noah, just as God had commanded Noah. **<sup>10</sup>** And after seven days the waters of the flood came upon the earth.

**<sup>11</sup>** In the six hundredth year of Noah's life, in the second month, on the seventeenth day of the month, on that very day all the fountains of the great deep burst forth, and the windows of the heavens were opened. **<sup>12</sup>** And the rain fell upon the earth for forty days and forty nights. **<sup>13</sup>** On that very day Noah and Shem and Ham and Japheth, the sons of Noah, and Noah's wife and the three wives of his sons entered the ark, **<sup>14</sup>** along with every animal according to its kind, and all the livestock according to their kind, and every reptile that moves on the earth according to its kind, and every bird according to its kind, every winged creature. **<sup>15</sup>** They went into the ark with Noah, two by two of all flesh in which there was the breath of life. **<sup>16</sup>** And those that entered, male and female of all flesh, went in as God had commanded him, and the LORD shut him in.

**<sup>17</sup>** The flood continued for forty days upon the earth, and the waters increased and lifted up the ark, and it rose high above the earth. **<sup>18</sup>** The waters prevailed and rose high above the earth, and the ark floated on the surface of the waters. **<sup>19</sup>** The waters rose so high over the earth that all the high mountains under the whole heaven were covered. **<sup>20</sup>** The waters rose fifteen cubits higher, covering the mountains.

**<sup>21</sup>** And all flesh that moved on the earth perished—birds, livestock, wild animals, every swarming thing that swarms on the earth, and all mankind. **<sup>22</sup>** Everything on dry land, with the breath of life in their nostrils, died. **<sup>23</sup>** God wiped out every living thing that was on the face of the ground: man, animals, reptiles and birds of the heavens. All were blotted out from the earth. Only Noah was left, and those who were with him in the ark. **<sup>24</sup>** And the waters prevailed on the earth for one hundred and fifty days. 

## Chapter 8

**<sup>1</sup>** But God remembered Noah, and all the beasts and livestock that were with him in the ark. Then God made a wind blow over the earth, so that the waters subsided. **<sup>2</sup>** The fountains of the deep and the windows of the heavens were closed, and the rain from the heavens was restrained. **<sup>3</sup>** The waters receded steadily from the earth, and at the end of one hundred and fifty days, the waters had diminished. **<sup>4</sup>** In the seventh month, on the seventeenth day of the month, the ark came to rest on the mountains of Ararat. **<sup>5</sup>** The waters continued to recede until the tenth month. In the tenth month, on the first day of the month, the tops of the mountains became visible.

**<sup>6</sup>** After forty days, Noah opened the window of the ark that he had made **<sup>7</sup>** and sent out a raven, and it went back and forth until the waters had dried up from the earth. **<sup>8</sup>** Then he sent out a dove to see whether the waters had receded from the surface of the ground. **<sup>9</sup>** But the dove found no resting place for the sole of her foot, and she returned to him in the ark, for the waters still covered the surface of the earth. So he reached out his hand, took her, and brought her back into the ark.

**<sup>10</sup>** He waited another seven days and again sent out the dove from the ark. **<sup>11</sup>** The dove returned to him in the evening, and there in her beak was a freshly plucked olive leaf. So Noah knew that the waters had receded from the earth. **<sup>12</sup>** He waited another seven days and sent out the dove again, but she did not return to him.

**<sup>13</sup>** In the six hundred and first year, in the first month, on the first day of the month, the waters had dried up from the earth. Noah removed the covering of the ark and saw that the surface of the ground was drying. **<sup>14</sup>** By the second month, on the twenty-seventh day of the month, the earth was completely dry.

**<sup>15</sup>** Then God spoke to Noah, saying, **<sup>16</sup>** "Come out of the ark, you and your wife, and your sons and their wives with you. **<sup>17</sup>** Bring out with you every living thing that is with you—all flesh, including birds, livestock, and every creeping thing that moves on the earth—so that they may swarm over the earth, be fruitful, and multiply upon the earth."

**<sup>18</sup>** So Noah came out, along with his sons, his wife, and his sons' wives. **<sup>19</sup>** Every beast, every creeping thing, and every bird—everything that moves on the earth—came out of the ark, each according to its kind.

**<sup>20</sup>** Then Noah built an altar to the LORD and took some of every clean animal and every clean bird and offered burnt offerings on the altar. **<sup>21</sup>** The LORD smelled the pleasing aroma and said in His heart, "I will never again curse the ground because of man, even though the inclination of his heart is evil from his youth. Nor will I ever again destroy every living creature as I have done.

**<sup>22</sup>** As long as the earth remains, seedtime and harvest, cold and heat, summer and winter, and day and night shall not cease." 

## Chapter 9

**<sup>1</sup>** Then God blessed Noah and his sons and said to them, "Be fruitful and multiply, and fill the earth. **<sup>2</sup>** The fear and dread of you will be upon every beast of the earth, every bird of the sky, everything that moves on the ground, and all the fish of the sea. They are given into your hands. **<sup>3</sup>** Every moving thing that lives shall be food for you; just as I gave you the green plants, I now give you everything. **<sup>4</sup>** But you shall not eat flesh with its lifeblood still in it. **<sup>5</sup>** I will certainly require a reckoning for your lifeblood; from every beast I will demand it, and from man as well. I will require the life of the man who sheds the blood of his fellow man.

**<sup>6</sup>** Whoever sheds man's blood,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;by man his blood shall be shed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for in the image of God He made man.

**<sup>7</sup>** As for you, be fruitful and multiply; spread out and fill the earth."

**<sup>8</sup>** Then God said to Noah and to his sons with him, **<sup>9</sup>** "From this moment, I am establishing My covenant with you, and with your descendants after you, **<sup>10</sup>** and with every living creature that is with you—the birds, the livestock, and every wild animal that was with you—all that came out of the ark, every living thing of the earth. **<sup>11</sup>** I establish My covenant with you: Never again will all flesh be cut off by the waters of a flood, nor shall there ever again be a flood to destroy the earth."

**<sup>12</sup>** Then God said, "This is the sign of the covenant I am making between Me and you and every living creature with you, for perpetual generations: **<sup>13</sup>** I have set My rainbow in the clouds, and it shall be a sign of the covenant between Me and the earth. **<sup>14</sup>** Whenever I bring clouds over the earth and the rainbow appears in the clouds, **<sup>15</sup>** I will remember My covenant between Me and you and every type of living creature: never again shall the waters become a flood to destroy all life. **<sup>16</sup>** When the rainbow is in the clouds, I will look upon it to remember the everlasting covenant between God and every type of living creature on the earth." **<sup>17</sup>** And God said to Noah, "This is the sign of the covenant I have established between Me and all flesh on the earth."

**<sup>18</sup>** Now the sons of Noah who came out of the ark were Shem, Ham, and Japheth. Ham was the father of Canaan. **<sup>19</sup>** These three were the sons of Noah, and from them the whole earth was populated.

**<sup>20</sup>** Then Noah, a man of the soil, began to plant a vineyard. **<sup>21</sup>** When he drank some of its wine, he became drunk and uncovered himself inside his tent. **<sup>22</sup>** Ham, the father of Canaan, saw his father's nakedness and told his two brothers outside. **<sup>23</sup>** But Shem and Japheth took a garment, laid it on their shoulders, and walked backward to cover their father's nakedness. Their faces were turned away so that they did not see their father's nakedness.

**<sup>24</sup>** When Noah awoke from his wine and learned what his youngest son had done to him, **<sup>25</sup>** he said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"Cursed be Canaan!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;A servant of servants shall he be to his brothers."

**<sup>26</sup>** He also said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"Blessed be the LORD, the God of Shem!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;May Canaan be his servant.<br/>
**<sup>27</sup>** May God enlarge Japheth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may he dwell in the tents of Shem,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may Canaan be his servant."

**<sup>28</sup>** After the flood, Noah lived 350 years. **<sup>29</sup>** All the days of Noah were 950 years, and then he died. 

## Chapter 10

**<sup>1</sup>** These are the generations of the sons of Noah: Shem, Ham, and Japheth. Sons were born to them after the flood.

**<sup>2</sup>** The sons of Japheth: Gomer, Magog, Madai, Javan, Tubal, Meshech, and Tiras. **<sup>3</sup>** The sons of Gomer: Ashkenaz, Riphath, and Togarmah. **<sup>4</sup>** The sons of Javan: Elishah, Tarshish, Kittim, and Dodanim. **<sup>5</sup>** From these the coastlands of the nations spread out, each with its own land, language, clan, and nation.

**<sup>6</sup>** The sons of Ham: Cush, Mizraim, Put, and Canaan. **<sup>7</sup>** The sons of Cush: Seba, Havilah, Sabtah, Raamah, and Sabteca. The sons of Raamah: Sheba and Dedan. **<sup>8</sup>** Cush fathered Nimrod, who was the first to be a mighty man on the earth. **<sup>9</sup>** He was a mighty hunter before the LORD; therefore, it is said, "Like Nimrod, a mighty hunter before the LORD." **<sup>10</sup>** The beginning of his kingdom was Babel, Erech, Accad, and Calneh, in the land of Shinar. **<sup>11</sup>** From that land he went into Assyria and built Nineveh, Rehoboth-Ir, Calah, **<sup>12</sup>** and Resen, which lies between Nineveh and Calah; that is the great city.

**<sup>13</sup>** Mizraim fathered the Ludim, Anamim, Lehabim, Naphtuhim, **<sup>14</sup>** Pathrusim, Casluhim (from whom the Philistines came), and Caphtorim.

**<sup>15</sup>** Canaan fathered Sidon, his firstborn, and Heth, **<sup>16</sup>** as well as the Jebusite, the Amorite, the Girgashite, **<sup>17</sup>** the Hivite, the Arkite, the Sinite, **<sup>18</sup>** the Arvadite, the Zemarite, and the Hamathite. Afterward, the clans of the Canaanites spread out. **<sup>19</sup>** The Canaanite boundary extended from Sidon toward Gerar as far as Gaza, and toward Sodom, Gomorrah, Admah, and Zeboiim, as far as Lasha. **<sup>20</sup>** These were the sons of Ham, according to their clans, languages, lands, and nations.

**<sup>21</sup>** Sons were also born to Shem, the elder brother of Japheth and the father of all the sons of Eber. **<sup>22</sup>** The sons of Shem: Elam, Asshur, Arpachshad, Lud, and Aram. **<sup>23</sup>** The sons of Aram: Uz, Hul, Gether, and Mash. **<sup>24</sup>** Arpachshad fathered Shelah, and Shelah fathered Eber. **<sup>25</sup>** Two sons were born to Eber: the name of the first was Peleg, for in his days the earth was divided, and his brother's name was Joktan. **<sup>26</sup>** Joktan fathered Almodad, Sheleph, Hazarmaveth, Jerah, **<sup>27</sup>** Hadoram, Uzal, Diklah, **<sup>28</sup>** Obal, Abimael, Sheba, **<sup>29</sup>** Ophir, Havilah, and Jobab; all these were the sons of Joktan. **<sup>30</sup>** Their settlements extended from Mesha toward Sephar, in the eastern hill country.

**<sup>31</sup>** These were the sons of Shem, according to their clans, languages, lands, and nations. **<sup>32</sup>** These are the clans of the sons of Noah, according to their genealogies, in their nations. From them the nations spread out over the earth after the flood. 

## Chapter 11

**<sup>1</sup>** Now the whole earth had one language and used the same words. **<sup>2</sup>** As men migrated from the east, they found a plain in the land of Shinar and settled there. **<sup>3</sup>** They said to one another, "Come, let us make bricks and bake them thoroughly." So they used brick for stone, and tar for mortar. **<sup>4</sup>** Then they said, "Come, let us build ourselves a city and a tower with its top in the heavens, and let us make a name for ourselves, lest we be scattered over the face of the whole earth."

**<sup>5</sup>** But the LORD came down to see the city and the tower that the sons of men were building. **<sup>6</sup>** The LORD said, "See how they are one people with one language. This is only the beginning of what they will do. Now nothing they intend to do will be impossible for them. **<sup>7</sup>** Come, let Us go down and confuse their language so that they will not understand one another's speech." **<sup>8</sup>** So the LORD scattered them from there over the face of the whole earth, and they stopped building the city. **<sup>9</sup>** Therefore, its name was called Babel, because there the LORD confused the language of the whole earth, and from there the LORD scattered them over the face of the whole earth.

**<sup>10</sup>** These are the generations of Shem: Shem was 100 years old when he fathered Arpachshad two years after the flood. **<sup>11</sup>** After he fathered Arpachshad, Shem lived 500 years and had other sons and daughters.

**<sup>12</sup>** When Arpachshad was 35 years old, he fathered Shelah. **<sup>13</sup>** After he fathered Shelah, Arpachshad lived 403 years and had other sons and daughters.

**<sup>14</sup>** When Shelah was 30 years old, he fathered Eber. **<sup>15</sup>** After he fathered Eber, Shelah lived 403 years and had other sons and daughters.

**<sup>16</sup>** When Eber was 34 years old, he fathered Peleg. **<sup>17</sup>** After he fathered Peleg, Eber lived 430 years and had other sons and daughters.

**<sup>18</sup>** When Peleg was 30 years old, he fathered Reu. **<sup>19</sup>** After he fathered Reu, Peleg lived 209 years and had other sons and daughters.

**<sup>20</sup>** When Reu was 32 years old, he fathered Serug. **<sup>21</sup>** After he fathered Serug, Reu lived 207 years and had other sons and daughters.

**<sup>22</sup>** When Serug was 30 years old, he fathered Nahor. **<sup>23</sup>** After he fathered Nahor, Serug lived 200 years and had other sons and daughters.

**<sup>24</sup>** When Nahor was 29 years old, he fathered Terah. **<sup>25</sup>** After he fathered Terah, Nahor lived 119 years and had other sons and daughters.

**<sup>26</sup>** When Terah was 70 years old, he fathered Abram, Nahor, and Haran.

**<sup>27</sup>** These are the generations of Terah: Terah fathered Abram, Nahor, and Haran, and Haran fathered Lot. **<sup>28</sup>** Haran died before his father Terah in the land of his birth, in Ur of the Chaldeans. **<sup>29</sup>** Abram and Nahor took wives for themselves. The name of Abram's wife was Sarai, and the name of Nahor's wife was Milcah, the daughter of Haran, the father of Milcah and Iscah. **<sup>30</sup>** But Sarai was barren; she had no child.

**<sup>31</sup>** Terah took his son Abram, his grandson Lot, the son of Haran, and his daughter-in-law Sarai, the wife of his son Abram, and they set out together from Ur of the Chaldeans to go to the land of Canaan. But when they came to Haran, they settled there. **<sup>32</sup>** Terah lived 205 years, and he died in Haran. 

## Chapter 12

**<sup>1</sup>** The LORD said to Abram, "Go from your land, your relatives, and your father's house to the land that I will show you. **<sup>2</sup>** I will make you into a great nation, and I will bless you; I will make your name great, and you will be a blessing. **<sup>3</sup>** I will bless those who bless you, and I will curse those who treat you with contempt, and all the families of the earth will be blessed through you."

**<sup>4</sup>** So Abram went, just as the LORD had told him, and Lot went with him. Abram was seventy-five years old when he left Haran. **<sup>5</sup>** He took his wife Sarai, his nephew Lot, all the possessions they had accumulated, and the servants they had acquired in Haran, and they set out for the land of Canaan. When they arrived in Canaan, **<sup>6</sup>** Abram traveled through the land as far as the site of Shechem, and the oak of Moreh. The Canaanites were in the land at that time.

**<sup>7</sup>** Then the LORD appeared to Abram and said, "To your offspring I will give this land." So he built an altar there to the LORD, who had appeared to him. **<sup>8</sup>** From there he moved on to the hill country east of Bethel and pitched his tent, with Bethel to the west and Ai to the east. He built an altar to the LORD there and called on the name of the LORD. **<sup>9</sup>** Then Abram set out and continued toward the Negev.

**<sup>10</sup>** There was a famine in the land, so Abram went down to Egypt to stay there for a while, because the famine was severe in the land. **<sup>11</sup>** As he was about to enter Egypt, he said to his wife Sarai, "Look, I know that you are a beautiful woman. **<sup>12</sup>** When the Egyptians see you, they will say, 'This is his wife,' and they will kill me but let you live. **<sup>13</sup>** Please say that you are my sister, so that it will go well for me because of you and my life will be spared on your account."

**<sup>14</sup>** When Abram entered Egypt, the Egyptians saw that the woman was very beautiful. **<sup>15</sup>** Pharaoh's officials saw her and praised her to Pharaoh, and the woman was taken into Pharaoh's house. **<sup>16</sup>** He treated Abram well because of her, and Abram acquired flocks and herds, male and female donkeys, male and female servants, and camels.

**<sup>17</sup>** But the LORD struck Pharaoh and his household with severe plagues because of Abram's wife Sarai. **<sup>18</sup>** So Pharaoh summoned Abram and said, "What have you done to me? Why didn't you tell me she was your wife? **<sup>19</sup>** Why did you say, 'She is my sister,' so that I took her as my wife? Now, here is your wife—take her and go!" **<sup>20</sup>** Then Pharaoh gave his men orders concerning him, and they sent him away with his wife and all that he had. 

## Chapter 13

**<sup>1</sup>** So Abram went up from Egypt, he and his wife and all that he had, and Lot with him, into the Negev. **<sup>2</sup>** Now Abram was very rich in livestock, silver, and gold. **<sup>3</sup>** He journeyed by stages from the Negev as far as Bethel, to the place where his tent had been at the beginning, between Bethel and Ai, **<sup>4</sup>** to the place of the altar that he had made there at first. And there Abram called on the name of the LORD.

**<sup>5</sup>** Now Lot, who went with Abram, also had flocks, herds, and tents. **<sup>6</sup>** But the land could not support them while they stayed together, for their possessions were so great that they could not dwell together. **<sup>7</sup>** And there was strife between the herdsmen of Abram's livestock and the herdsmen of Lot's livestock. (At that time, the Canaanites and the Perizzites were dwelling in the land.)

**<sup>8</sup>** Then Abram said to Lot, "Please, let there be no strife between me and you, or between my herdsmen and your herdsmen, for we are brothers. **<sup>9</sup>** Is not the whole land before you? Please, separate from me. If you go to the left, then I will go to the right; or if you go to the right, then I will go to the left."

**<sup>10</sup>** Lot looked around and saw that the whole plain of the Jordan was well watered everywhere (before the LORD destroyed Sodom and Gomorrah), like the garden of the LORD, like the land of Egypt, as far as Zoar. **<sup>11</sup>** So Lot chose for himself the whole plain of the Jordan, and Lot journeyed east. Thus they separated from each other. **<sup>12</sup>** Abram settled in the land of Canaan, but Lot settled in the cities of the plain and pitched his tents near Sodom. **<sup>13</sup>** Now the men of Sodom were exceedingly wicked and sinful against the LORD.

**<sup>14</sup>** The LORD said to Abram after Lot had separated from him, "Lift up your eyes and look from the place where you are—northward, southward, eastward, and westward— **<sup>15</sup>** for all the land that you see, I will give to you and to your descendants forever. **<sup>16</sup>** And I will make your descendants like the dust of the earth, so that if anyone could count the dust of the earth, then your descendants also could be counted. **<sup>17</sup>** Arise, walk through the land, its length and its breadth, for I am giving it to you."

**<sup>18</sup>** So Abram moved his tent and went to dwell by the oaks of Mamre, which are in Hebron, and there he built an altar to the LORD. 

## Chapter 14

**<sup>1</sup>** In the days of Amraphel king of Shinar, Arioch king of Ellasar, Chedorlaomer king of Elam, and Tidal king of Goiim, **<sup>2</sup>** these kings waged war against Bera king of Sodom, Birsha king of Gomorrah, Shinab king of Admah, Shemeber king of Zeboiim, and the king of Bela (that is, Zoar). **<sup>3</sup>** All these gathered together in the Valley of Siddim (which is the Salt Sea). **<sup>4</sup>** For twelve years they had served Chedorlaomer, but in the thirteenth year, they rebelled.

**<sup>5</sup>** In the fourteenth year, Chedorlaomer and the kings with him came and defeated the Rephaim in Ashteroth-karnaim, the Zuzim in Ham, the Emim in Shaveh-kiriathaim, **<sup>6</sup>** and the Horites in their hill country of Seir, as far as El-paran, which is by the wilderness. **<sup>7</sup>** Then they turned back and came to En-mishpat (that is, Kadesh), and they struck down all the territory of the Amalekites and also the Amorites who lived in Hazazon-tamar.

**<sup>8</sup>** Then the king of Sodom, the king of Gomorrah, the king of Admah, the king of Zeboiim, and the king of Bela (that is, Zoar) went out and drew up battle lines in the Valley of Siddim **<sup>9</sup>** against Chedorlaomer king of Elam, Tidal king of Goiim, Amraphel king of Shinar, and Arioch king of Ellasar—four kings against five. **<sup>10</sup>** Now the Valley of Siddim was full of tar pits, and as the kings of Sodom and Gomorrah fled, some fell into them, while the rest fled to the hill country. **<sup>11</sup>** Then the victors seized all the possessions of Sodom and Gomorrah, along with all their food, and departed. **<sup>12</sup>** They also took Lot, the son of Abram's brother, and his possessions, since he was living in Sodom, and they went on their way.

**<sup>13</sup>** Then one who had escaped came and reported this to Abram the Hebrew, who was dwelling by the oaks of Mamre the Amorite, the brother of Eshcol and Aner, who were allies of Abram. **<sup>14</sup>** When Abram heard that his relative had been taken captive, he armed his 318 trained men, born in his household, and pursued them as far as Dan. **<sup>15</sup>** During the night, he divided his men and attacked them, pursuing them as far as Hobah, north of Damascus. **<sup>16</sup>** He recovered all the possessions and also brought back his relative Lot with his possessions, as well as the women and the other men.

**<sup>17</sup>** After Abram returned from defeating Chedorlaomer and the kings who were with him, the king of Sodom went out to meet him in the Valley of Shaveh (that is, the King's Valley). **<sup>18</sup>** And Melchizedek, king of Salem, brought out bread and wine. He was a priest of God Most High. **<sup>19</sup>** He blessed him and said, "Blessed be Abram by God Most High, Creator of heaven and earth! **<sup>20</sup>** And blessed be God Most High, who has delivered your enemies into your hand!" And Abram gave him a tenth of everything.

**<sup>21</sup>** Then the king of Sodom said to Abram, "Give me the men, but take the possessions for yourself." **<sup>22</sup>** But Abram said to the king of Sodom, "I have raised my hand in an oath to the LORD, God Most High, Creator of heaven and earth, **<sup>23</sup>** that I will take nothing belonging to you—not even a thread or a sandal strap—so that you may never say, 'I made Abram rich.' **<sup>24</sup>** I will accept nothing but what the young men have eaten and the share for the men who went with me—Aner, Eshcol, and Mamre. Let them take their portion." 

## Chapter 15

**<sup>1</sup>** After these events, the word of the LORD came to Abram in a vision, saying, "Do not be afraid, Abram. I am your shield; your reward will be very great."

**<sup>2</sup>** But Abram said, "Lord GOD, what can You give me, since I remain childless, and the heir of my house is Eliezer of Damascus?" **<sup>3</sup>** And Abram continued, "Look, You have not given me offspring, so a servant in my household will be my heir."

**<sup>4</sup>** Then, behold, the word of the LORD came to him: "This man will not be your heir; rather, one who comes from your own body will be your heir." **<sup>5</sup>** He took him outside and said, "Look at the sky and count the stars, if you are able to count them." Then He said to him, "So shall your descendants be." **<sup>6</sup>** And Abram believed the LORD, and He credited it to him as righteousness.

**<sup>7</sup>** Then He said to him, "I am the LORD, who brought you out of Ur of the Chaldeans to give you this land to possess." **<sup>8</sup>** But Abram said, "Lord GOD, how can I know that I will possess it?"

**<sup>9</sup>** He said to him, "Bring Me a three-year-old heifer, a three-year-old female goat, a three-year-old ram, a turtledove, and a young pigeon." **<sup>10</sup>** So he brought all these to Him, cut them in two, and laid each half opposite the other, but he did not cut the birds in half. **<sup>11</sup>** Then birds of prey came down on the carcasses, but Abram drove them away.

**<sup>12</sup>** As the sun was setting, a deep sleep fell upon Abram, and terror and great darkness overwhelmed him. **<sup>13</sup>** Then the LORD said to Abram, "Know for certain that your descendants will be strangers in a land that is not their own, and they will serve them and be oppressed for four hundred years. **<sup>14</sup>** But I will judge the nation they serve, and afterward they will come out with great possessions. **<sup>15</sup>** As for you, you will go to your fathers in peace and be buried at a good old age. **<sup>16</sup>** In the fourth generation, they will return here, for the iniquity of the Amorites is not yet complete."

**<sup>17</sup>** When the sun had set and it was dark, a smoking firepot and a flaming torch passed between the divided pieces. **<sup>18</sup>** On that day, the LORD made a covenant with Abram, saying, "To your descendants I have given this land, from the river of Egypt to the great river, the Euphrates— **<sup>19</sup>** the land of the Kenites, Kenizzites, Kadmonites, **<sup>20</sup>** Hittites, Perizzites, Rephaim, **<sup>21</sup>** Amorites, Canaanites, Girgashites, and Jebusites." 

## Chapter 16

**<sup>1</sup>** Now Sarai, Abram's wife, had borne him no children. But she had an Egyptian maidservant named Hagar. **<sup>2</sup>** So Sarai said to Abram, "Look, the LORD has kept me from bearing children. Go to my maidservant; perhaps I will obtain children through her." And Abram listened to Sarai's voice.

**<sup>3</sup>** So after Abram had lived ten years in the land of Canaan, Sarai, his wife, took Hagar the Egyptian, her maidservant, and gave her to Abram her husband as a wife. **<sup>4</sup>** And he went in to Hagar, and she conceived. When she saw that she had conceived, her mistress became insignificant in her eyes.

**<sup>5</sup>** Then Sarai said to Abram, "The wrong done to me is on you! I put my maidservant into your arms, but now that she sees she has conceived, I am despised in her eyes. May the LORD judge between me and you." **<sup>6</sup>** But Abram said to Sarai, "Look, your maidservant is in your hands. Do with her whatever is good in your eyes." Then Sarai afflicted her, and she fled from her presence.

**<sup>7</sup>** Now the angel of the LORD found her by a spring of water in the wilderness, the spring on the way to Shur. **<sup>8</sup>** And he said, "Hagar, maidservant of Sarai, where have you come from, and where are you going?" She said, "I am fleeing from the presence of my mistress Sarai."

**<sup>9</sup>** Then the angel of the LORD said to her, "Return to your mistress and submit yourself under her hand." **<sup>10</sup>** And the angel of the LORD said, "I will greatly multiply your offspring so that they will be too numerous to count." **<sup>11</sup>** And the angel of the LORD said to her, "Behold, you are pregnant and will bear a son. You shall name him Ishmael, for the LORD has heard your affliction. **<sup>12</sup>** He will be a wild man; his hand will be against everyone, and everyone's hand will be against him. And he will dwell in hostility toward all his brothers."

**<sup>13</sup>** Then she called the name of the LORD who spoke to her, "You are the God who sees me," for she said, "Have I also seen Him here, who sees me?" **<sup>14</sup>** Therefore, the well was called Beer-lahai-roi. It is between Kadesh and Bered.

**<sup>15</sup>** And Hagar bore Abram a son, and Abram named his son, whom Hagar bore, Ishmael. **<sup>16</sup>** Abram was eighty-six years old when Hagar bore Ishmael to him. 

## Chapter 17

**<sup>1</sup>** When Abram was ninety-nine years old, the LORD appeared to him and said, "I am God Almighty; walk before me and be blameless. **<sup>2</sup>** I will establish my covenant between me and you, and I will greatly multiply you."

**<sup>3</sup>** Then Abram fell facedown, and God spoke to him, saying, **<sup>4</sup>** "As for me, here is my covenant with you: You will become the father of many nations. **<sup>5</sup>** No longer will your name be Abram; your name will be Abraham, for I have made you the father of many nations. **<sup>6</sup>** I will make you exceedingly fruitful; I will make nations of you, and kings will come from you. **<sup>7</sup>** I will establish my covenant between me and you and your descendants after you throughout their generations as an everlasting covenant, to be God to you and to your descendants after you. **<sup>8</sup>** And I will give to you and to your descendants after you the land where you are living as a foreigner—all the land of Canaan—as an everlasting possession, and I will be their God."

**<sup>9</sup>** Then God said to Abraham, "You must keep my covenant, you and your descendants after you throughout their generations. **<sup>10</sup>** This is my covenant that you are to keep, between me and you and your descendants after you: Every male among you must be circumcised. **<sup>11</sup>** You are to be circumcised in the flesh of your foreskin, and it will be the sign of the covenant between me and you. **<sup>12</sup>** Every male among you, eight days old, must be circumcised, every male throughout your generations, whether born in your household or purchased with money from a foreigner who is not your descendant. **<sup>13</sup>** Whether born in your house or purchased with money, they must be circumcised. My covenant will be in your flesh as an everlasting covenant. **<sup>14</sup>** If any uncircumcised male, who has not been circumcised in the flesh of his foreskin, is found among you, he will be cut off from his people; he has broken my covenant."

**<sup>15</sup>** Then God said to Abraham, "As for your wife Sarai, you must not call her Sarai, for her name will be Sarah. **<sup>16</sup>** I will bless her; indeed, I will give you a son by her. I will bless her, and she will become nations; kings of peoples will come from her."

**<sup>17</sup>** Then Abraham fell facedown and laughed, saying in his heart, "Can a child be born to a man who is a hundred years old? Can Sarah give birth at ninety years old?" **<sup>18</sup>** So Abraham said to God, "If only Ishmael might live under your blessing!"

**<sup>19</sup>** But God said, "No. Your wife Sarah will bear you a son, and you will name him Isaac. I will establish my covenant with him as an everlasting covenant for his descendants after him. **<sup>20</sup>** As for Ishmael, I have heard you. I will bless him, make him fruitful, and greatly multiply him. He will father twelve rulers, and I will make him into a great nation. **<sup>21</sup>** But I will establish my covenant with Isaac, whom Sarah will bear to you at this time next year."

**<sup>22</sup>** When God had finished speaking with Abraham, he departed from him.

**<sup>23</sup>** Then Abraham took his son Ishmael and all the males born in his household or purchased with his money—every male among the men of Abraham's household—and circumcised them that very day, just as God had told him. **<sup>24</sup>** Abraham was ninety-nine years old when he was circumcised, **<sup>25</sup>** and his son Ishmael was thirteen years old when he was circumcised. **<sup>26</sup>** On that very day, Abraham and his son Ishmael were circumcised, **<sup>27</sup>** and all the men of his household—those born in his house and those purchased with money from a foreigner—were circumcised with him. 

## Chapter 18

**<sup>1</sup>** The LORD appeared to him by the oaks of Mamre as he sat at the entrance of his tent in the heat of the day. **<sup>2</sup>** He lifted his eyes and looked, and behold, three men were standing near him. When he saw them, he ran from the entrance of his tent to meet them and bowed himself to the ground. **<sup>3</sup>** He said, "My lord, if I have found favor in your sight, do not pass by your servant. **<sup>4</sup>** Let a little water be brought so that you may wash your feet and rest under the tree. **<sup>5</sup>** I will bring a morsel of bread so that you may refresh yourselves; after that, you may continue on your way, since you have come to your servant." So they said, "Do as you have said."

**<sup>6</sup>** Abraham hurried into the tent to Sarah and said, "Quick! Three measures of fine flour—knead it and make cakes." **<sup>7</sup>** Then Abraham ran to the herd, took a tender and choice calf, and gave it to a servant, who hurried to prepare it. **<sup>8</sup>** He took curds and milk and the calf that he had prepared and set it before them. He stood by them under the tree while they ate.

**<sup>9</sup>** They said to him, "Where is Sarah, your wife?" He replied, "There, in the tent." **<sup>10</sup>** Then one said, "I will surely return to you at this time next year, and behold, Sarah, your wife, will have a son." Sarah was listening at the entrance of the tent behind him. **<sup>11</sup>** Now Abraham and Sarah were old, advanced in years; Sarah had passed the age of childbearing. **<sup>12</sup>** So Sarah laughed to herself, saying, "After I am worn out and my lord is old, shall I have this pleasure?"

**<sup>13</sup>** The LORD said to Abraham, "Why did Sarah laugh and say, 'Shall I indeed bear a child, now that I am old?' **<sup>14</sup>** Is anything too difficult for the LORD? At the appointed time, I will return to you, at this time next year, and Sarah will have a son." **<sup>15</sup>** But Sarah denied it, saying, "I did not laugh," for she was afraid. He said, "No, but you did laugh."

**<sup>16</sup>** Then the men set out from there and looked toward Sodom. Abraham went with them to send them on their way. **<sup>17</sup>** The LORD said, "Shall I hide from Abraham what I am about to do, **<sup>18</sup>** since Abraham will surely become a great and mighty nation, and all the nations of the earth will be blessed through him? **<sup>19</sup>** For I have chosen him, so that he may command his children and his household after him to keep the way of the LORD by doing righteousness and justice, so that the LORD may bring upon Abraham what he has promised him."

**<sup>20</sup>** Then the LORD said, "The outcry against Sodom and Gomorrah is great, and their sin is very grievous. **<sup>21</sup>** I will go down and see whether they have done altogether according to the outcry that has come to me. If not, I will know."

**<sup>22</sup>** The men turned away from there and went toward Sodom, but Abraham remained standing before the LORD. **<sup>23</sup>** Abraham drew near and said, "Will you indeed sweep away the righteous with the wicked? **<sup>24</sup>** Suppose there are fifty righteous within the city. Will you really sweep it away and not spare the place for the sake of the fifty righteous who are in it? **<sup>25</sup>** Far be it from you to do such a thing—to slay the righteous with the wicked, treating the righteous the same as the wicked! Far be it from you! Shall not the Judge of all the earth do what is just?"

**<sup>26</sup>** The LORD said, "If I find in Sodom fifty righteous within the city, then I will spare the whole place for their sake."

**<sup>27</sup>** Abraham answered, "Behold, I have undertaken to speak to my Lord, though I am but dust and ashes. **<sup>28</sup>** Suppose five of the fifty righteous are lacking—will you destroy the whole city for lack of five?" He said, "I will not destroy it if I find forty-five there."

**<sup>29</sup>** Again he spoke to him and said, "Suppose forty are found there." He said, "I will not do it for the sake of forty."

**<sup>30</sup>** Then he said, "Please do not be angry, my Lord, and let me speak. Suppose thirty are found there." He said, "I will not do it if I find thirty there."

**<sup>31</sup>** He said, "Behold, I have undertaken to speak to my Lord. Suppose twenty are found there." He said, "I will not destroy it for the sake of twenty."

**<sup>32</sup>** Then he said, "Please do not let my Lord be angry, and I will speak only this once more. Suppose ten are found there." He said, "I will not destroy it for the sake of ten."

**<sup>33</sup>** When the LORD had finished speaking with Abraham, he departed, and Abraham returned to his place. 

## Chapter 19

**<sup>1</sup>** The two angels arrived at Sodom in the evening, and Lot was sitting at the city gate. When he saw them, he got up to meet them and bowed with his face to the ground. **<sup>2</sup>** He said, "My lords, please turn aside to your servant's house, spend the night, and wash your feet. Then you can rise early and go on your way."

But they said, "No, we will spend the night in the square."

**<sup>3</sup>** However, he strongly urged them, so they turned aside to him, and entered his house. He prepared a feast for them, baking unleavened bread, and they ate.

**<sup>4</sup>** Before they lay down, the men of the city—the men of Sodom, both young and old, all the people from every quarter—surrounded the house. **<sup>5</sup>** They called to Lot and said, "Where are the men who came to you tonight? Bring them out to us so that we may know them."

**<sup>6</sup>** Lot went out to them at the entrance and shut the door behind him. **<sup>7</sup>** He said, "Please, my brothers, do not do this evil thing. **<sup>8</sup>** Look, I have two daughters who have never known a man. Let me bring them out to you, and you may do to them as you see fit. But do not do anything to these men, since they have come under the protection of my roof."

**<sup>9</sup>** But they said, "Stand back!" Then they said, "This fellow came as a foreigner, and now he dares to judge us! We will deal worse with you than with them." They pressed hard against Lot and came near to break the door down.

**<sup>10</sup>** But the men reached out and pulled Lot into the house with them and shut the door. **<sup>11</sup>** Then they struck the men at the entrance, both small and great, with blindness, so that they wore themselves out trying to find the door.

**<sup>12</sup>** Then the men said to Lot, "Do you have anyone else here—a son-in-law, your sons, your daughters, or anyone else in the city who belongs to you? Get them out of this place, **<sup>13</sup>** because we are about to destroy it. The outcry against this city has grown so great before the LORD that He has sent us to destroy it."

**<sup>14</sup>** So Lot went out and spoke to his sons-in-law, who were pledged to marry his daughters. He said, "Get up! Get out of this place, for the LORD is about to destroy the city!" But his sons-in-law thought he was joking.

**<sup>15</sup>** When morning dawned, the angels urged Lot, saying, "Get up! Take your wife and your two daughters who are here, or you will be swept away in the punishment of the city."

**<sup>16</sup>** But he hesitated. So the men took hold of his hand, his wife's hand, and the hands of his two daughters—because of the LORD's mercy to him—and they led him out and set him outside the city.

**<sup>17</sup>** When they had brought them out, one of them said, "Flee for your life! Do not look back or stop anywhere in the plain. Escape to the mountains, or you will be swept away!"

**<sup>18</sup>** But Lot said to them, "No, my lords! **<sup>19</sup>** Your servant has found favor in your sight, and you have shown me great kindness in saving my life. But I cannot flee to the mountains, or disaster will overtake me and I will die. **<sup>20</sup>** Look, this town is near enough to flee to, and it is a small one. Let me go there so that I may live. Is it not a small place?"

**<sup>21</sup>** He said to him, "Very well, I grant you this request also—I will not destroy the town you speak of. **<sup>22</sup>** Hurry, escape there, for I cannot do anything until you arrive there." That is why the town was called Zoar.

**<sup>23</sup>** The sun had risen over the land when Lot arrived in Zoar. **<sup>24</sup>** Then the LORD rained sulfur and fire on Sodom and Gomorrah from the LORD out of the heavens. **<sup>25</sup>** He overthrew those cities, the entire plain, all the inhabitants of the cities, and everything growing on the ground.

**<sup>26</sup>** But Lot's wife, who was behind him, looked back, and she became a pillar of salt.

**<sup>27</sup>** Early in the morning, Abraham went to the place where he had stood before the LORD. **<sup>28</sup>** He looked toward Sodom and Gomorrah and all the land of the plain, and he saw that smoke was rising from the land like the smoke of a furnace.

**<sup>29</sup>** So it was, when God destroyed the cities of the plain, that He remembered Abraham and brought Lot out of the midst of the destruction when He overthrew the cities where Lot had lived.

**<sup>30</sup>** Lot went up from Zoar and settled in the mountains with his two daughters because he was afraid to stay in Zoar. He lived in a cave with his two daughters.

**<sup>31</sup>** The older daughter said to the younger, "Our father is old, and there is no man in the land to come to us as is the custom everywhere. **<sup>32</sup>** Come, let us give our father wine to drink and lie with him, so that we may preserve our father's lineage."

**<sup>33</sup>** That night they gave their father wine to drink, and the older daughter went in and lay with him. He was unaware when she lay down or when she got up.

**<sup>34</sup>** The next day, the older daughter said to the younger, "Look, I lay with my father last night. Let us give him wine to drink again tonight, and you go in and lie with him so that we may preserve our father's lineage."

**<sup>35</sup>** So they gave their father wine to drink that night as well, and the younger daughter went in and lay with him. He was unaware when she lay down or when she got up.

**<sup>36</sup>** So both of Lot's daughters conceived by their father. **<sup>37</sup>** The older daughter bore a son and named him Moab—he became the father of the Moabites of today. **<sup>38</sup>** The younger daughter also bore a son and named him Ben-Ammi—he became the father of the Ammonites of today. 

## Chapter 20

**<sup>1</sup>** Abraham journeyed from there toward the Negev and settled between Kadesh and Shur; then he sojourned in Gerar. **<sup>2</sup>** Abraham said of Sarah his wife, "She is my sister." So Abimelech, king of Gerar, sent for Sarah and took her.

**<sup>3</sup>** But God came to Abimelech in a dream by night and said to him, "Behold, you are as good as dead because of the woman you have taken, for she is a married woman." **<sup>4</sup>** Now Abimelech had not come near her, so he said, "Lord, will You slay even a righteous nation? **<sup>5</sup>** Did he not himself say to me, 'She is my sister'? And she herself also said, 'He is my brother.' In the integrity of my heart and innocence of my hands, I have done this."

**<sup>6</sup>** Then God said to him in the dream, "Yes, I know that you did this in the integrity of your heart, and I also kept you from sinning against Me; therefore, I did not allow you to touch her. **<sup>7</sup>** Now return the man's wife, for he is a prophet, and he will pray for you, and you will live. But if you do not return her, know that you will surely die, you and all who belong to you."

**<sup>8</sup>** So Abimelech rose early in the morning, called all his servants, and spoke all these things in their hearing, and the men were greatly afraid. **<sup>9</sup>** Then Abimelech called Abraham and said to him, "What have you done to us? How have I sinned against you, that you have brought this great sin upon me and my kingdom? You have done to me things that should not be done." **<sup>10</sup>** And Abimelech asked Abraham, "What were you thinking, that you did this thing?"

**<sup>11</sup>** Abraham said, "I did it because I thought, 'Surely there is no fear of God in this place, and they will kill me because of my wife.' **<sup>12</sup>** Besides, she is indeed my sister, the daughter of my father but not the daughter of my mother, and she became my wife. **<sup>13</sup>** And when God caused me to wander from my father's house, I said to her, 'This is the kindness you must show me: wherever we go, say of me, "He is my brother."'"

**<sup>14</sup>** Then Abimelech took sheep, cattle, and male and female servants and gave them to Abraham, and he returned Sarah, his wife, to him. **<sup>15</sup>** And Abimelech said, "Behold, my land is before you; settle wherever you please." **<sup>16</sup>** And to Sarah he said, "Behold, I have given a thousand pieces of silver to your brother. It is a vindication before all who are with you; you are fully vindicated."

**<sup>17</sup>** Then Abraham prayed to God, and God healed Abimelech, his wife, and his female servants, so that they could bear children again. **<sup>18</sup>** For the LORD had completely closed the wombs of all the women in Abimelech's household because of Sarah, Abraham's wife. 

## Chapter 21

**<sup>1</sup>** The LORD visited Sarah as He had said, and the LORD did for Sarah what He had promised. **<sup>2</sup>** So Sarah conceived and bore a son to Abraham in his old age, at the appointed time God had spoken to him. **<sup>3</sup>** Abraham named his son who was born to him, the son Sarah bore him, Isaac. **<sup>4</sup>** And Abraham circumcised his son Isaac when he was eight days old, just as God had commanded him. **<sup>5</sup>** Now Abraham was one hundred years old when his son Isaac was born to him.

**<sup>6</sup>** And Sarah said, "God has made me laugh, and everyone who hears will laugh with me." **<sup>7</sup>** She also said, "Who would have told Abraham that Sarah would nurse children? Yet I have borne a son for him in his old age."

**<sup>8</sup>** The child grew and was weaned, and Abraham held a great feast on the day Isaac was weaned. **<sup>9</sup>** But Sarah saw the son of Hagar the Egyptian, whom she had borne to Abraham, mocking. **<sup>10</sup>** So she said to Abraham, "Drive out this slave woman and her son, for the son of this slave woman shall not share in the inheritance with my son Isaac."

**<sup>11</sup>** This matter was very distressing to Abraham because of his son. **<sup>12</sup>** But God said to Abraham, "Do not be distressed because of the boy and your slave woman. Listen to everything Sarah tells you, for through Isaac your offspring shall be named. **<sup>13</sup>** Yet I will also make a nation of the son of the slave woman, because he is your offspring."

**<sup>14</sup>** So Abraham rose early in the morning, took bread and a skin of water, and gave them to Hagar. He placed them on her shoulder and sent her away with the boy. She departed and wandered in the wilderness of Beersheba. **<sup>15</sup>** When the water in the skin was gone, she placed the boy under one of the bushes. **<sup>16</sup>** Then she went and sat down at a distance, about a bowshot away, for she said, "Let me not see the boy die." As she sat there, she wept aloud.

**<sup>17</sup>** God heard the boy's voice, and the angel of God called to Hagar from heaven and said to her, "What troubles you, Hagar? Do not be afraid, for God has heard the voice of the boy where he is. **<sup>18</sup>** Get up, lift up the boy, and hold him by the hand, for I will make him into a large nation." **<sup>19</sup>** Then God opened her eyes, and she saw a well of water. She went and filled the skin with water and gave the boy a drink.

**<sup>20</sup>** God was with the boy, and he grew. He lived in the wilderness and became an archer. **<sup>21</sup>** He settled in the wilderness of Paran, and his mother took a wife for him from the land of Egypt.

**<sup>22</sup>** At that time, Abimelech and Phicol, the commander of his army, spoke to Abraham, saying, "God is with you in everything you do. **<sup>23</sup>** Now therefore, swear to me by God that you will not deal falsely with me, my offspring, or my descendants. Show to me, and to the land where you have lived as a foreigner, the same kindness I have shown to you."

**<sup>24</sup>** Abraham said, "I swear it." **<sup>25</sup>** Then Abraham reproached Abimelech concerning a well of water that Abimelech's servants had seized. **<sup>26</sup>** But Abimelech replied, "I do not know who did this; you have not spoken of this to me before, nor have I heard of it until today."

**<sup>27</sup>** So Abraham took sheep and cattle and gave them to Abimelech, and the two of them made an agreement. **<sup>28</sup>** Abraham set seven ewe lambs apart from the flock. **<sup>29</sup>** And Abimelech said to Abraham, "What is the meaning of these seven ewe lambs that you have set apart?" **<sup>30</sup>** He replied, "You are to take these seven ewe lambs from me as a witness that I dug this well." **<sup>31</sup>** Therefore, that place was called Beersheba, because the two of them swore an oath there.

**<sup>32</sup>** After they had made an agreement at Beersheba, Abimelech and Phicol, the commander of his army, arose and returned to the land of the Philistines. **<sup>33</sup>** Abraham planted a tamarisk tree in Beersheba and called there on the name of the LORD, the Everlasting God. **<sup>34</sup>** And Abraham stayed in the land of the Philistines for many days. 

## Chapter 22

**<sup>1</sup>** After these things, God tested Abraham and said to him, "Abraham!"

And he said, "Here I am."

**<sup>2</sup>** Then He said, "Take your son, Isaac, your only son, whom you love, and go to the land of Moriah. Offer him there as a burnt offering on one of the mountains that I will show you."

**<sup>3</sup>** So Abraham rose early in the morning, saddled his donkey, and took two of his young men with him, along with his son Isaac. He split the wood for the burnt offering and set out for the place that God had told him about.

**<sup>4</sup>** On the third day, Abraham looked up and saw the place in the distance. **<sup>5</sup>** Then he said to his young men, "Stay here with the donkey. The boy and I will go over there to worship, and then we will return to you."

**<sup>6</sup>** Abraham took the wood for the burnt offering and laid it on his son Isaac. He carried the fire and the knife, and the two of them walked on together. **<sup>7</sup>** Then Isaac spoke to his father Abraham, saying, "My father!"

And he replied, "Here I am, my son."

Isaac said, "Look, the fire and the wood, but where is the lamb for the burnt offering?"

**<sup>8</sup>** Abraham answered, "God Himself will provide the lamb for the burnt offering, my son." And the two of them continued on together.

**<sup>9</sup>** When they arrived at the place God had told him about, Abraham built an altar there and arranged the wood. He bound his son Isaac and laid him on the altar, on top of the wood. **<sup>10</sup>** Then Abraham reached out his hand and took the knife to slaughter his son.

**<sup>11</sup>** But the angel of the LORD called to him from heaven, saying, "Abraham, Abraham!"

And he answered, "Here I am."

**<sup>12</sup>** Then He said, "Do not lay a hand on the boy or do anything to him, for now I know that you fear God, since you have not withheld your son, your only son, from Me."

**<sup>13</sup>** Abraham looked up and saw a ram caught by its horns in a thicket. So he went and took the ram and offered it as a burnt offering in place of his son. **<sup>14</sup>** And Abraham named that place "The LORD Will Provide," as it is said to this day, "It will be provided, on the mountain of the LORD."

**<sup>15</sup>** Then the angel of the LORD called to Abraham a second time from heaven **<sup>16</sup>** and said, "By Myself I have sworn, declares the LORD, because you have done this and have not withheld your son, your only son, **<sup>17</sup>** I will surely bless you and greatly multiply your offspring like the stars of the sky and the sand on the seashore. Your offspring will possess the gate of their enemies, **<sup>18</sup>** and through your offspring all the nations of the earth will be blessed, because you have obeyed My voice."

**<sup>19</sup>** Then Abraham returned to his young men, and they arose and went together to Beersheba, and Abraham lived in Beersheba.

**<sup>20</sup>** After these things, Abraham was told, "Milcah has also borne sons to your brother Nahor: **<sup>21</sup>** Uz, his firstborn, Buz his brother, Kemuel the father of Aram, **<sup>22</sup>** Chesed, Hazo, Pildash, Jidlaph, and Bethuel." **<sup>23</sup>** (Bethuel fathered Rebekah.) Milcah bore these eight to Nahor, Abraham's brother. **<sup>24</sup>** His concubine, whose name was Reumah, also bore Tebah, Gaham, Tahash, and Maacah. 

## Chapter 23

**<sup>1</sup>** Sarah lived to be 127 years old—these were the years of Sarah's life. **<sup>2</sup>** She died in Kiriath-arba (that is, Hebron) in the land of Canaan. Abraham went in to mourn for Sarah and to weep over her. **<sup>3</sup>** Then Abraham rose from beside his dead and spoke to the Hittites: **<sup>4</sup>** "I am a sojourner and a foreigner among you. Grant me a burial site among you so I may bury my dead out of my sight." **<sup>5</sup>** The Hittites answered Abraham, **<sup>6</sup>** "Listen to us, my lord. You are a mighty prince among us. Bury your dead in the best of our tombs. None of us will withhold his tomb from you to bury your dead." **<sup>7</sup>** Then Abraham rose and bowed before the Hittites, the people living in that land. **<sup>8</sup>** He spoke to them, saying, "If you are willing for me to bury my dead out of my sight, hear me and intercede for me with Ephron son of Zohar, **<sup>9</sup>** so that he may give me the cave of Machpelah that belongs to him, at the end of his field. Let him give it to me in your presence for the full price as a burial site." **<sup>10</sup>** Now Ephron was sitting among the Hittites. Ephron the Hittite answered Abraham in the hearing of the Hittites who had gathered at the city gate: **<sup>11</sup>** "No, my lord, listen to me. I give you the field, and I give you the cave that is in it. In the presence of my people, I give it to you. Bury your dead." **<sup>12</sup>** Then Abraham bowed before the people of the land. **<sup>13</sup>** He spoke to Ephron in their hearing: "Please listen to me. I will pay the price for the field. Accept it from me so that I may bury my dead there." **<sup>14</sup>** Ephron answered Abraham, **<sup>15</sup>** "My lord, listen to me. The land is worth four hundred shekels of silver, but what is that between you and me? Bury your dead." **<sup>16</sup>** Abraham agreed to Ephron's terms and weighed out for him the silver he had mentioned in the hearing of the Hittites—four hundred shekels of silver, according to the standard commercial weight.

**<sup>17</sup>** So Ephron's field in Machpelah near Mamre—the field with the cave in it, and all the trees within the field's boundaries—was transferred **<sup>18</sup>** to Abraham's possession in the sight of the Hittites who had gathered at the city gate. **<sup>19</sup>** Afterward, Abraham buried his wife Sarah in the cave of the field of Machpelah near Mamre (that is, Hebron) in the land of Canaan. **<sup>20</sup>** The field and the cave in it were deeded to Abraham by the Hittites as a burial site. 

## Chapter 24

**<sup>1</sup>** Now Abraham was old, well advanced in years, and the LORD had blessed Abraham in all things. **<sup>2</sup>** Abraham said to his servant, the oldest of his household who was in charge of all he owned, "Place your hand under my thigh, **<sup>3</sup>** so that I may make you swear by the LORD, the God of heaven and the God of earth, that you will not take a wife for my son from the daughters of the Canaanites among whom I live, **<sup>4</sup>** but that you will go to my homeland and to my kindred and take a wife for my son Isaac from there." **<sup>5</sup>** The servant said to him, "What if the woman is not willing to follow me back to this land? Should I then take your son back to the land from which you came?" **<sup>6</sup>** Abraham answered him, "Make sure that you do not take my son back there. **<sup>7</sup>** The LORD, the God of heaven, who took me from my father's house and from the land of my kindred, spoke to me and swore to me, saying, 'To your offspring I will give this land.' He will send His angel before you, and you shall take a wife for my son from there. **<sup>8</sup>** But if the woman is not willing to follow you, then you will be released from this oath of mine—only do not take my son back there." **<sup>9</sup>** So the servant placed his hand under the thigh of his master Abraham and swore to him concerning this matter.

**<sup>10</sup>** Then the servant took ten of his master's camels and departed, taking with him all kinds of valuable objects from his master's wealth. He arose and went to Aram-naharaim, to the city of Nahor. **<sup>11</sup>** He made the camels kneel outside the city by the well of water at evening time, the time when women go out to draw water. **<sup>12</sup>** He said, "O LORD, God of my master Abraham, please grant me success today and show your loyal love to my master Abraham. **<sup>13</sup>** I am here, standing beside the spring of water, and the daughters of the men of the city are coming out to draw water. **<sup>14</sup>** Let it be that the girl to whom I say, 'Please lower your jar so that I may drink,' and who replies, 'Drink, and I will also water your camels'—let her be the one You have appointed for Your servant Isaac. By this I will know that You have shown loyal love to my master."

**<sup>15</sup>** Before he had finished speaking, behold, Rebekah came out with her jar on her shoulder. She was the daughter of Bethuel, son of Milcah, the wife of Nahor, Abraham's brother. **<sup>16</sup>** The girl was very beautiful, a virgin; no man had known her. She went down to the spring, filled her jar, and came up. **<sup>17</sup>** Then the servant ran to meet her and said, "Please let me drink a little water from your jar." **<sup>18</sup>** She said, "Drink, my lord," and quickly lowered her jar to her hand and gave him a drink. **<sup>19</sup>** When she had finished giving him a drink, she said, "I will also draw water for your camels until they have finished drinking." **<sup>20</sup>** So she quickly emptied her jar into the trough, ran back to the well to draw more water, and drew for all his camels. **<sup>21</sup>** The man watched her silently to know whether the LORD had made his journey successful or not.

**<sup>22</sup>** When the camels had finished drinking, the man took a gold ring weighing half a shekel and two bracelets for her arms weighing ten shekels of gold, **<sup>23</sup>** and he said, "Whose daughter are you? Please tell me, is there room in your father's house for us to stay overnight?" **<sup>24</sup>** She said to him, "I am the daughter of Bethuel, the son of Milcah, whom she bore to Nahor." **<sup>25</sup>** She also said to him, "We have both straw and fodder in abundance, and a place to stay." **<sup>26</sup>** Then the man bowed his head and worshiped the LORD **<sup>27</sup>** and said, "Blessed be the LORD, the God of my master Abraham, who has not withheld His loyal love and His faithfulness from my master. As for me, the LORD has guided me on the way to the house of my master's relatives."

**<sup>28</sup>** The girl ran and told her mother's household what had happened. **<sup>29</sup>** Now Rebekah had a brother named Laban, and Laban ran out to the man at the spring. **<sup>30</sup>** When he saw the ring and the bracelets on his sister's arms and heard Rebekah recount the words of the man, he went to him, and found him, standing by the camels at the spring. **<sup>31</sup>** Laban said, "Come, blessed of the LORD! Why are you standing outside? I have prepared the house and a place for the camels." **<sup>32</sup>** So the man came to the house, and they unloaded the camels. Straw and fodder were given to the camels, and water to wash his feet and the feet of the men who were with him. **<sup>33</sup>** Then food was set before him, but he said, "I will not eat until I have told my business." So they said, "Speak."

**<sup>34</sup>** And he said, "I am Abraham's servant. **<sup>35</sup>** The LORD has greatly blessed my master, and he has become wealthy. He has given him flocks and herds, silver and gold, male and female servants, camels and donkeys. **<sup>36</sup>** Sarah, my master's wife, bore a son to my master in her old age, and he has given him all he owns. **<sup>37</sup>** My master made me swear, saying, 'You shall not take a wife for my son from the daughters of the Canaanites in whose land I dwell, **<sup>38</sup>** but you shall go to my father's house and to my clan, and take a wife from there for my son.' **<sup>39</sup>** Then I said to my master, 'What if the woman will not follow me?' **<sup>40</sup>** But he said to me, 'The LORD, before whom I have walked, will send His angel with you and make your way successful. You shall take a wife for my son from my clan and from my father's house. **<sup>41</sup>** Then you will be free from my oath, when you come to my clan. And if they will not give her to you, you will be free from my oath.'

**<sup>42</sup>** I came today to the spring and said, 'O LORD, God of my master Abraham, if You are indeed making my journey successful, **<sup>43</sup>** behold, I am standing by the spring of water. Let it be that the young woman who comes out to draw water, to whom I say, "Please give me a little water from your jar to drink," **<sup>44</sup>** that if she says to me, "Drink, and I will also draw for your camels," let her be the woman the LORD has appointed for my master's son.' **<sup>45</sup>** Before I had finished speaking in my heart, Rebekah approached with her jar on her shoulder. She went down to the spring and drew water. I said to her, 'Please let me drink.' **<sup>46</sup>** She quickly lowered her jar from her shoulder and said, 'Drink, and I will also water your camels.' So I drank, and she also watered the camels. **<sup>47</sup>** Then I asked her, 'Whose daughter are you?' She said, 'The daughter of Bethuel, son of Nahor, whom Milcah bore to him.' So I put the ring on her nose and the bracelets on her arms. **<sup>48</sup>** Then I bowed down and worshiped the LORD and blessed the LORD, the God of my master Abraham, who had led me on the right way to take the daughter of my master's relative for his son. **<sup>49</sup>** Now then, if you intend to show loyal love and faithfulness to my master, tell me. But if not, tell me, so that I may turn either to the right or to the left."

**<sup>50</sup>** Then Laban and Bethuel answered, "This matter has come from the LORD; we cannot speak to you either bad or good. **<sup>51</sup>** Behold, Rebekah is before you; take her and go, and let her be the wife of your master's son, just as the LORD has spoken."

**<sup>52</sup>** When Abraham's servant heard their words, he bowed himself to the ground before the LORD. **<sup>53</sup>** And the servant brought out articles of silver and gold and garments and gave them to Rebekah. He also gave costly gifts to her brother and to her mother. **<sup>54</sup>** Then he and the men who were with him ate and drank and spent the night there. When they got up in the morning, he said, "Send me away to my master." **<sup>55</sup>** But her brother and her mother said, "Let the girl stay with us a few days, at least ten; then she may go." **<sup>56</sup>** But he said to them, "Do not delay me, since the LORD has made my journey successful. Send me away so that I may go to my master." **<sup>57</sup>** They said, "Let us call the girl and ask her." **<sup>58</sup>** So they called Rebekah and said to her, "Will you go with this man?" And she said, "I will go."

**<sup>59</sup>** So they sent away their sister Rebekah and her nurse, along with Abraham's servant and his men. **<sup>60</sup>** They blessed Rebekah and said to her, "Our sister, may you become thousands upon thousands, and may your offspring possess the gate of those who hate them."

**<sup>61</sup>** Then Rebekah and her servant girls got up, mounted the camels, and followed the man. So the servant took Rebekah and went on his way.

**<sup>62</sup>** Now Isaac had come from Beer-lahai-roi and was living in the Negev. **<sup>63</sup>** He went out to pray in the field toward evening. When he looked up, he saw camels coming. **<sup>64</sup>** Rebekah also looked up, and when she saw Isaac, she got down from the camel **<sup>65</sup>** and said to the servant, "Who is that man walking in the field to meet us?" The servant said, "It is my master." So she took her veil and covered herself.

**<sup>66</sup>** Then the servant told Isaac everything he had done. **<sup>67</sup>** Isaac brought her into the tent of Sarah his mother and took Rebekah, and she became his wife, and he loved her. So Isaac was comforted after his mother's death. 

## Chapter 25

**<sup>1</sup>** Abraham again took a wife, and her name was Keturah. **<sup>2</sup>** She bore him Zimran, Jokshan, Medan, Midian, Ishbak, and Shuah. **<sup>3</sup>** Jokshan fathered Sheba and Dedan. And the sons of Dedan were the Asshurim, the Letushim, and the Leummim. **<sup>4</sup>** The sons of Midian were Ephah, Epher, Hanoch, Abida, and Eldaah. All these were descendants of Keturah. **<sup>5</sup>** Abraham gave all that he had to Isaac, **<sup>6</sup>** but to the sons of his concubines Abraham gave gifts. While he was still alive, he sent them away from his son Isaac, eastward, to the land of the east.

**<sup>7</sup>** These are the days of the years of Abraham's life: one hundred and seventy-five years. **<sup>8</sup>** Abraham breathed his last and died at a good old age, an old man, full of years, and he was gathered to his people. **<sup>9</sup>** Isaac and Ishmael his sons buried him in the cave of Machpelah, in the field of Ephron the son of Zohar the Hittite, which faces Mamre, **<sup>10</sup>** the field that Abraham had purchased from the sons of Heth. There Abraham was buried, with Sarah his wife. **<sup>11</sup>** After the death of Abraham, God blessed Isaac his son, and Isaac lived at Beer-lahai-roi.

**<sup>12</sup>** These are the generations of Ishmael, Abraham's son, whom Hagar the Egyptian, Sarah's servant, bore to Abraham. **<sup>13</sup>** These are the names of the sons of Ishmael, by their names, according to their generations: the firstborn of Ishmael, Nebaioth; then Kedar, Adbeel, Mibsam, **<sup>14</sup>** Mishma, Dumah, Massa, **<sup>15</sup>** Hadad, Tema, Jetur, Naphish, and Kedemah. **<sup>16</sup>** These are the sons of Ishmael, and these are their names by their settlements and encampments, twelve princes according to their tribes. **<sup>17</sup>** These are the years of the life of Ishmael: one hundred and thirty-seven years. He breathed his last and died, and was gathered to his people. **<sup>18</sup>** They dwelt from Havilah to Shur, which is east of Egypt as one goes toward Assyria. He settled in defiance of all his brothers.

**<sup>19</sup>** These are the generations of Isaac, Abraham's son. Abraham fathered Isaac, **<sup>20</sup>** and Isaac was forty years old when he took Rebekah, the daughter of Bethuel the Aramean of Paddan-aram, the sister of Laban the Aramean, as his wife. **<sup>21</sup>** Isaac prayed to the LORD on behalf of his wife, because she was barren. The LORD granted his plea, and Rebekah his wife conceived. **<sup>22</sup>** But the children struggled within her, and she said, "If it occurs like this, why is this happening to me?" So she went to inquire of the LORD. **<sup>23</sup>** The LORD said to her, "Two nations are in your womb, and two peoples from within you will be separated. One people shall be stronger than the other, and the older shall serve the younger." **<sup>24</sup>** When her days to give birth were completed, behold, there were twins in her womb. **<sup>25</sup>** The first came out red, all over like a hairy garment, so they named him Esau. **<sup>26</sup>** After that his brother came out, with his hand gripping Esau's heel, so he was named Jacob. Isaac was sixty years old when she bore them.

**<sup>27</sup>** The boys grew up. Esau became a skilled hunter, a man of the field, but Jacob was a quiet man, living among the tents. **<sup>28</sup>** Isaac loved Esau because he had a taste for wild game, but Rebekah loved Jacob. **<sup>29</sup>** Once, when Jacob was cooking stew, Esau came in from the field, and he was exhausted. **<sup>30</sup>** Esau said to Jacob, "Let me eat some of that red stew, for I am famished." This is why he was also called Edom. **<sup>31</sup>** Jacob said, "First sell me your birthright." **<sup>32</sup>** Esau said, "Look, I am about to die; what use is a birthright to me?" **<sup>33</sup>** Jacob said, "Swear to me first." So he swore to him, and sold his birthright to Jacob. **<sup>34</sup>** Then Jacob gave Esau bread and lentil stew, and he ate and drank and rose and went his way. Thus Esau despised his birthright. 

## Chapter 26

**<sup>1</sup>** There was a famine in the land, besides the former famine that had occurred in Abraham's days. So Isaac went to Abimelech, king of the Philistines, in Gerar. **<sup>2</sup>** And the LORD appeared to him and said, "Do not go down to Egypt. Stay in the land that I will show you. **<sup>3</sup>** Sojourn in this land, and I will be with you and bless you. For to you and to your offspring I will give all these lands, and I will confirm the oath that I swore to your father Abraham. **<sup>4</sup>** I will multiply your offspring like the stars of heaven and will give to your descendants all these lands. And through your seed all the nations of the earth will be blessed— **<sup>5</sup>** because Abraham obeyed my voice and kept my charge, my commandments, my statutes, and my laws."

**<sup>6</sup>** So Isaac settled in Gerar. **<sup>7</sup>** And when the men of the place asked about his wife, he said, "She is my sister," for he was afraid to say, "my wife," thinking, "the men of this place might kill me because of Rebekah," since she was attractive in appearance. **<sup>8</sup>** After he had been there for some time, Abimelech, king of the Philistines, looked out a window and saw Isaac caressing his wife Rebekah. **<sup>9</sup>** Then Abimelech called Isaac and said, "So, she's your wife! Why did you say, 'She is my sister'?" Isaac said to him, "Because I thought I might die on account of her." **<sup>10</sup>** Abimelech said, "What is this you've done to us? One of the people might easily have lain with your wife, and you would have brought guilt upon us!" **<sup>11</sup>** So Abimelech commanded all the people, saying, "Whoever touches this man or his wife shall surely be put to death."

**<sup>12</sup>** Isaac sowed seed in that land and reaped in the same year a hundredfold, for the LORD blessed him. **<sup>13</sup>** The man became rich and continued to grow richer until he became exceedingly wealthy. **<sup>14</sup>** He had flocks and herds and many servants, and the Philistines envied him. **<sup>15</sup>** So the Philistines stopped up all the wells that his father's servants had dug in Abraham's time, filling them with earth. **<sup>16</sup>** Then Abimelech said to Isaac, "Go away from us, for you are much mightier than we are."

**<sup>17</sup>** So Isaac departed from there and pitched his tent in the Valley of Gerar and settled there. **<sup>18</sup>** Isaac again dug the wells of water that had been dug in the days of his father Abraham, which the Philistines had stopped up after Abraham died. He gave them the same names that his father had given them. **<sup>19</sup>** Isaac's servants dug in the valley and found there a well of flowing water. **<sup>20</sup>** But the herdsmen of Gerar quarreled with Isaac's herdsmen, saying, "The water is ours." So he named the well Esek, because they contended with him. **<sup>21</sup>** Then they dug another well, and they quarreled over that one too. So he named it Sitnah. **<sup>22</sup>** He moved from there and dug another well, and they did not quarrel over it. So he named it Rehoboth, saying, "Now the LORD has made room for us, and we shall be fruitful in the land."

**<sup>23</sup>** From there he went up to Beersheba. **<sup>24</sup>** And the LORD appeared to him that night and said, "I am the God of your father Abraham. Do not be afraid, for I am with you. I will bless you and multiply your offspring for the sake of my servant Abraham." **<sup>25</sup>** So he built an altar there and called on the name of the LORD, and he pitched his tent there. And Isaac's servants dug a well.

**<sup>26</sup>** Then Abimelech came to him from Gerar with Ahuzzath his adviser and Phicol the commander of his army. **<sup>27</sup>** Isaac said to them, "Why have you come to me, seeing that you hate me and have sent me away from you?" **<sup>28</sup>** They said, "We clearly saw that the LORD has been with you, so we said, 'Let there now be an oath between us—between you and us—and let us make a covenant with you **<sup>29</sup>** that you will do us no harm, just as we have not touched you and have done you nothing but good and have sent you away in peace. You are now blessed by the LORD.'" **<sup>30</sup>** So he made them a feast, and they ate and drank. **<sup>31</sup>** In the morning they rose early and swore an oath to each other. Then Isaac sent them off, and they departed from him in peace.

**<sup>32</sup>** That same day Isaac's servants came and told him about the well they had dug, saying to him, "We have found water." **<sup>33</sup>** He named it Shibah; therefore the name of the city is Beersheba to this day.

**<sup>34</sup>** When Esau was forty years old, he took as wives Judith the daughter of Beeri the Hittite and Basemath the daughter of Elon the Hittite. **<sup>35</sup>** They made life bitter for Isaac and Rebekah. 

## Chapter 27

**<sup>1</sup>** When Isaac was old and his eyes were too dim to see, he called his older son Esau and said to him, "My son." Esau replied, "Here I am." **<sup>2</sup>** Isaac said, "See now, I am old, and I do not know the day of my death. **<sup>3</sup>** Now then, take your weapons—your quiver and your bow—and go out to the open country to hunt game for me. **<sup>4</sup>** Prepare for me the kind of tasty food I love, and bring it to me so that I may eat it and bless you before I die."

**<sup>5</sup>** Now Rebekah was listening when Isaac spoke to his son Esau. When Esau went out to the field to hunt game and bring it back, **<sup>6</sup>** Rebekah said to her son Jacob, "Look, I heard your father say to your brother Esau, **<sup>7</sup>** 'Bring me some game and prepare me a tasty meal so that I may eat and bless you before the LORD before I die.' **<sup>8</sup>** Now, my son, obey me and do what I tell you: **<sup>9</sup>** Go now to the flock and bring me two choice young goats so I can prepare from them a dish your father loves. **<sup>10</sup>** Then you shall bring it to your father to eat, so that he may bless you before he dies."

**<sup>11</sup>** But Jacob said to his mother Rebekah, "My brother Esau is a hairy man, and I am a man with smooth skin. **<sup>12</sup>** Suppose my father touches me—then I will be found out as a deceiver and bring a curse on myself rather than a blessing." **<sup>13</sup>** His mother said to him, "Let your curse be on me, my son. Only obey me and go get them for me." **<sup>14</sup>** So he went and got them and brought them to his mother, and she prepared a tasty dish, just the way his father liked it.

**<sup>15</sup>** Rebekah took the best garments of her older son Esau, which were with her in the house, and put them on her younger son Jacob. **<sup>16</sup>** She put the skins of the young goats on his hands and on the smooth part of his neck. **<sup>17</sup>** Then she placed in the hands of her son Jacob the tasty food and the bread she had prepared.

**<sup>18</sup>** He went to his father and said, "My father." Isaac replied, "Here I am. Who are you, my son?" **<sup>19</sup>** Jacob said to his father, "I am Esau your firstborn. I have done as you told me. Please sit up and eat of my game, so that you may bless me." **<sup>20</sup>** But Isaac said to his son, "How did you find it so quickly, my son?" He answered, "Because the LORD your God gave me success." **<sup>21</sup>** Isaac said to Jacob, "Come near so I can touch you, my son, to know whether you are really my son Esau or not." **<sup>22</sup>** So Jacob went near to his father Isaac, who touched him and said, "The voice is the voice of Jacob, but the hands are the hands of Esau." **<sup>23</sup>** He did not recognize him because his hands were hairy like those of his brother Esau, so he blessed him. **<sup>24</sup>** He asked, "Are you really my son Esau?" He answered, "I am." **<sup>25</sup>** Then Isaac said, "Bring it to me so that I may eat of my son's game and bless you." So he brought it to him, and he ate. He also brought him wine, and he drank.

**<sup>26</sup>** Then his father Isaac said to him, "Come near and kiss me, my son." **<sup>27</sup>** So he came near and kissed him, and Isaac smelled the scent of his garments and blessed him. He said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"See, the scent of my son<br/>
&nbsp;&nbsp;&nbsp;&nbsp;is like the scent of a field<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that the LORD has blessed.<br/>
**<sup>28</sup>** May God give you from the dew of the heavens<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and from the richness of the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;an abundance of grain and new wine.<br/>
**<sup>29</sup>** May nations serve you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and peoples bow down to you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Be lord over your brothers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may your mother's sons bow down to you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Cursed be those who curse you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and blessed be those who bless you."

**<sup>30</sup>** Just as Isaac finished blessing Jacob and Jacob had scarcely left his father's presence, Esau his brother came in from hunting. **<sup>31</sup>** He also prepared a tasty dish and brought it to his father and said, "Let my father arise and eat of his son's game, so that you may bless me." **<sup>32</sup>** His father Isaac said to him, "Who are you?" He answered, "I am your son, your firstborn, Esau." **<sup>33</sup>** Then Isaac trembled violently and said, "Who then was it who hunted game and brought it to me? I ate it all before you came, and I blessed him—and he will certainly be blessed."

**<sup>34</sup>** When Esau heard the words of his father, he cried out with a loud and bitter cry and said to his father, "Bless me—me too, my father!" **<sup>35</sup>** But Isaac said, "Your brother came deceitfully and took your blessing." **<sup>36</sup>** Esau said, "Is he not rightly named Jacob? For he has supplanted me these two times: he took my birthright, and now he has taken my blessing." Then he said, "Have you not reserved a blessing for me?" **<sup>37</sup>** Isaac answered Esau, "Look, I have made him lord over you, and I have given all his brothers to him as servants. I have sustained him with grain and wine. What then can I do for you, my son?" **<sup>38</sup>** Esau said to his father, "Do you only have one blessing, my father? Bless me—me too, my father!" And Esau lifted his voice and wept.

**<sup>39</sup>** Then his father Isaac answered him and said,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;"See, your dwelling shall be<br/>
&nbsp;&nbsp;&nbsp;&nbsp;away from the richness of the earth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and away from the dew of the heavens above.<br/>
**<sup>40</sup>** You shall live by your sword,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you shall serve your brother.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But when you become restless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you will break his yoke from your neck."

**<sup>41</sup>** So Esau harbored hatred toward Jacob because of the blessing his father had given him. Esau said in his heart, "The days of mourning for my father are near; then I will kill my brother Jacob." **<sup>42</sup>** When the words of her older son Esau were reported to Rebekah, she sent and called her younger son Jacob and said to him, "See, your brother Esau is consoling himself by planning to kill you. **<sup>43</sup>** Now, my son, listen to me. Get up and flee to my brother Laban in Haran. **<sup>44</sup>** Stay with him for a while until your brother's anger subsides. **<sup>45</sup>** When your brother's fury turns away and he forgets what you did to him, then I will send and bring you back from there. Why should I lose both of you in one day?"

**<sup>46</sup>** Rebekah said to Isaac, "I am sick of my life because of these Hittite women. If Jacob takes a wife from among the daughters of Heth like these, from among the women of this land, what good is my life to me?" 

## Chapter 28

**<sup>1</sup>** Then Isaac summoned Jacob, blessed him, and commanded him, saying, "You must not take a wife from the daughters of Canaan. **<sup>2</sup>** Get up, go to Paddan-aram, to the house of Bethuel, your mother's father, and take for yourself a wife from there, from the daughters of Laban, your mother's brother. **<sup>3</sup>** May God Almighty bless you, make you fruitful, and multiply you, so that you may become a company of peoples. **<sup>4</sup>** May he give to you the blessing of Abraham, to you and to your offspring with you, so that you may take possession of the land of your sojourning, which God gave to Abraham." **<sup>5</sup>** So Isaac sent Jacob off, and he went to Paddan-aram, to Laban son of Bethuel the Aramean, the brother of Rebekah, the mother of Jacob and Esau.

**<sup>6</sup>** When Esau saw that Isaac had blessed Jacob and sent him to Paddan-aram to take a wife from there—and that as he blessed him he commanded him, saying, "You shall not take a wife from the daughters of Canaan"— **<sup>7</sup>** and when Jacob obeyed his father and his mother and had gone to Paddan-aram, **<sup>8</sup>** Esau realized that the daughters of Canaan were displeasing to his father Isaac. **<sup>9</sup>** So Esau went to Ishmael and took Mahalath, the daughter of Ishmael son of Abraham, the sister of Nebaioth, as a wife, in addition to the wives he already had.

**<sup>10</sup>** Jacob left Beersheba and went toward Haran. **<sup>11</sup>** He came to a certain place and spent the night there because the sun had set. He took one of the stones from the place, put it under his head, and lay down in that place to sleep. **<sup>12</sup>** He dreamed, and behold, a stairway was set up on the earth, and the top of it reached to heaven. The angels of God were going up and coming down on it. **<sup>13</sup>** And behold, the LORD was standing beside him and said, "I am the LORD, the God of Abraham your father and the God of Isaac. I will give to you and to your offspring the land on which you lie. **<sup>14</sup>** Your offspring shall be like the dust of the earth, and you shall spread out to the west and to the east, to the north and to the south. Through you and through your offspring all the families of the earth shall be blessed. **<sup>15</sup>** Behold, I am with you, and I will keep you wherever you go, and I will bring you back to this land. For I will not leave you until I have done what I have promised you."

**<sup>16</sup>** Jacob woke from his sleep and said, "Surely the LORD is in this place, and I did not know it." **<sup>17</sup>** And he was afraid and said, "How awesome is this place! This is none other than the house of God, and this is the gate of heaven."

**<sup>18</sup>** So Jacob rose early in the morning, took the stone he had placed under his head, set it up as a pillar, and poured oil on top of it. **<sup>19</sup>** He named that place Bethel, though formerly the name of the city was Luz. **<sup>20</sup>** Then Jacob made a vow, saying, "If God will be with me, and will keep me on this journey that I am taking, and will give me food to eat and clothes to wear, **<sup>21</sup>** so that I return in peace to my father's house, then the LORD shall be my God. **<sup>22</sup>** And this stone, which I have set up as a pillar, shall be God's house. And of all that you give me, I will surely give a tenth to you." 

## Chapter 29

**<sup>1</sup>** Then Jacob continued on his journey and came to the land of the people of the east. **<sup>2</sup>** He looked and saw a well in the open field, with three flocks of sheep lying beside it, because the flocks were watered from that well. A large stone covered the mouth of the well. **<sup>3</sup>** When all the flocks were gathered there, the shepherds would roll the stone from the well's mouth, water the sheep, and then return the stone to its place over the well's opening.

**<sup>4</sup>** Jacob said to them, "My brothers, where are you from?" They answered, "We're from Haran." **<sup>5</sup>** He asked them, "Do you know Laban, Nahor's grandson?" They said, "Yes, we know him." **<sup>6</sup>** He asked them, "Is he well?" They replied, "He's well—and look, here comes his daughter Rachel with the sheep."

**<sup>7</sup>** He said, "Look, it's still broad daylight—it's not time to gather the livestock. Water the sheep, and take them back out to graze." **<sup>8</sup>** But they said, "We can't until all the flocks are gathered and the stone is rolled away from the mouth of the well. Then we water the sheep."

**<sup>9</sup>** While he was still speaking with them, Rachel came with her father's sheep, since she was a shepherdess. **<sup>10</sup>** When Jacob saw Rachel, the daughter of his uncle Laban, and Laban's sheep, he went over and rolled the stone from the mouth of the well and watered his uncle Laban's sheep. **<sup>11</sup>** Then Jacob kissed Rachel and wept aloud. **<sup>12</sup>** Jacob told Rachel that he was her father's relative, the son of Rebekah. She ran and told her father.

**<sup>13</sup>** As soon as Laban heard the news about Jacob, his sister's son, he ran to meet him. He embraced him, kissed him, and brought him to his house. Jacob told Laban all that had happened. **<sup>14</sup>** Then Laban said to him, "Surely you are my own flesh and blood." Jacob stayed with him for a month.

**<sup>15</sup>** Then Laban said to Jacob, "Just because you're my relative, should you work for me for nothing? Tell me what your wages should be." **<sup>16</sup>** Now Laban had two daughters: the older one was named Leah, and the younger one was Rachel. **<sup>17</sup>** Leah had delicate eyes, but Rachel had a beautiful figure and an attractive appearance. **<sup>18</sup>** Jacob loved Rachel, so he said, "I'll serve you seven years for your younger daughter Rachel." **<sup>19</sup>** Laban said, "It's better that I give her to you than to another man. Stay here with me." **<sup>20</sup>** So Jacob served seven years for Rachel, and they seemed like only a few days to him because of his love for her.

**<sup>21</sup>** Then Jacob said to Laban, "Give me my wife, for my time is completed, and I want to be with her." **<sup>22</sup>** So Laban gathered all the men of the place and held a feast. **<sup>23</sup>** But in the evening, he took his daughter Leah and brought her to Jacob, and Jacob slept with her. **<sup>24</sup>** Laban gave his servant girl Zilpah to his daughter Leah as her maid. **<sup>25</sup>** In the morning, Jacob saw that it was Leah, and said to Laban, "What is this you've done to me? Didn't I serve you for Rachel? Why have you deceived me?"

**<sup>26</sup>** Laban replied, "It's not the custom in our place to marry off a younger daughter before the firstborn. **<sup>27</sup>** Finish this bridal week, and then we'll give you the other one also—for another seven years of work." **<sup>28</sup>** Jacob agreed and completed the week with Leah. Then Laban gave him his daughter Rachel to be his wife. **<sup>29</sup>** Laban gave his servant girl Bilhah to his daughter Rachel as her maid. **<sup>30</sup>** Jacob slept with Rachel also, and he loved Rachel more than Leah. He served Laban for another seven years.

**<sup>31</sup>** When the LORD saw that Leah was unloved, he opened her womb, but Rachel was barren. **<sup>32</sup>** Leah conceived and bore a son, and she named him Reuben, for she said, "The LORD has seen my affliction; surely now my husband will love me." **<sup>33</sup>** She conceived again, gave birth to a son, and said, "Because the LORD heard that I am unloved, he gave me this one also." So she named him Simeon. **<sup>34</sup>** She conceived again and bore a son and said, "Now at last my husband will be attached to me, because I've borne him three sons." So he was named Levi. **<sup>35</sup>** She conceived once more and bore a son, and she said, "This time I will praise the LORD." Therefore she named him Judah. Then she stopped having children. 

## Chapter 30

**<sup>1</sup>** When Rachel saw that she bore Jacob no children, she became envious of her sister and said to Jacob, "Give me children, or I shall die!" **<sup>2</sup>** Jacob's anger burned against Rachel, and he said, "Am I in the place of God, who has withheld from you the fruit of the womb?" **<sup>3</sup>** Then she said, "Here is my maid Bilhah; go in to her, so that she may bear children on my behalf, and I too may have a family through her." **<sup>4</sup>** So she gave him Bilhah her servant as a wife, and Jacob went in to her. **<sup>5</sup>** Bilhah conceived and bore Jacob a son. **<sup>6</sup>** Then Rachel said, "God has vindicated me; He has heard my voice and has given me a son." Therefore she named him Dan. **<sup>7</sup>** Rachel's servant Bilhah conceived again and bore Jacob a second son. **<sup>8</sup>** Then Rachel said, "With mighty wrestlings I have wrestled with my sister, and I have prevailed." So she named him Naphtali.

**<sup>9</sup>** When Leah saw that she had ceased bearing children, she took her servant Zilpah and gave her to Jacob as a wife. **<sup>10</sup>** Leah's servant Zilpah bore Jacob a son. **<sup>11</sup>** Then Leah said, "Good fortune has come!" So she named him Gad. **<sup>12</sup>** Leah's servant Zilpah bore Jacob a second son. **<sup>13</sup>** Then Leah said, "How happy I am! For women will call me blessed." So she named him Asher.

**<sup>14</sup>** During the wheat harvest, Reuben went out and found mandrakes in the field and brought them to his mother Leah. Then Rachel said to Leah, "Please give me some of your son's mandrakes." **<sup>15</sup>** But Leah replied, "Is it not enough that you have taken my husband? Now you also want to take my son's mandrakes?" So Rachel said, "Then he may lie with you tonight in exchange for your son's mandrakes." **<sup>16</sup>** When Jacob came in from the field that evening, Leah went out to meet him and said, "You must come in to me, for I have hired you with my son's mandrakes." So he lay with her that night. **<sup>17</sup>** God listened to Leah, and she conceived and bore Jacob a fifth son. **<sup>18</sup>** Then Leah said, "God has given me my wages because I gave my servant to my husband." So she named him Issachar. **<sup>19</sup>** Leah conceived again and bore Jacob a sixth son. **<sup>20</sup>** Then Leah said, "God has endowed me with a good gift; now my husband will honor me, because I have borne him six sons." So she named him Zebulun. **<sup>21</sup>** Afterwards she bore a daughter and named her Dinah.

**<sup>22</sup>** Then God remembered Rachel, and God listened to her and opened her womb. **<sup>23</sup>** She conceived and bore a son and said, "God has taken away my reproach." **<sup>24</sup>** And she named him Joseph, saying, "May the LORD add to me another son."

**<sup>25</sup>** After Rachel had borne Joseph, Jacob said to Laban, "Send me away, that I may go to my own place and my own country. **<sup>26</sup>** Give me my wives and my children for whom I have served you, and let me go, for you know the service that I have rendered you." **<sup>27</sup>** But Laban said to him, "If I have found favor in your eyes, I have learned by divination that the LORD has blessed me because of you." **<sup>28</sup>** He continued, "Name your wages, and I will give it." **<sup>29</sup>** Jacob said to him, "You yourself know how I have served you, and how your livestock has fared with me. **<sup>30</sup>** For you had little before I came, and it has increased abundantly, and the LORD has blessed you wherever I turned. But now, when shall I also provide for my own household?" **<sup>31</sup>** So Laban said, "What shall I give you?" Jacob answered, "You shall give me nothing. If you will do this one thing for me, I will again pasture your flock and keep it: **<sup>32</sup>** Let me pass through all your flock today, removing from it every speckled and spotted sheep, and every black lamb, and the spotted and speckled among the goats, and they shall be my wages. **<sup>33</sup>** So my honesty will answer for me later, when you come to inspect my wages with you. Every one that is not speckled or spotted among the goats, and black among the lambs, if found with me, shall be considered stolen." **<sup>34</sup>** Laban said, "Good! Let it be as you have said." **<sup>35</sup>** But that same day he removed the male goats that were striped and spotted, and all the female goats that were speckled and spotted, every one that had white on it, and every lamb that was black, and he put them in the charge of his sons. **<sup>36</sup>** And he set a distance of three days' journey between himself and Jacob, and Jacob pastured the rest of Laban's flocks.

**<sup>37</sup>** Then Jacob took fresh rods of poplar, almond, and plane trees, and peeled white stripes in them, exposing the white of the rods. **<sup>38</sup>** He set the rods that he had peeled in front of the flocks in the watering troughs, where the flocks came to drink, and they mated when they came to drink. **<sup>39</sup>** So the flocks mated before the rods, and the flocks bore young that were striped, speckled, and spotted. **<sup>40</sup>** Jacob separated the lambs and set the faces of the flocks toward the striped and all the black in the flock of Laban. He put his own droves apart and did not put them with Laban's flock. **<sup>41</sup>** Whenever the stronger of the flock were mating, Jacob would place the rods in the troughs before the eyes of the flock, that they might mate among the rods, **<sup>42</sup>** but for the feebler animals he did not put them there. So the feebler were Laban's and the stronger were Jacob's. **<sup>43</sup>** Thus the man grew exceedingly prosperous, and had large flocks, female and male servants, camels, and donkeys. 

## Chapter 31

**<sup>1</sup>** Now Jacob heard the words of Laban's sons, saying, "Jacob has taken all that belonged to our father, and from what was our father's he has gained all this wealth." **<sup>2</sup>** Jacob also saw that Laban's face was not favorable toward him as before. **<sup>3</sup>** Then the LORD said to Jacob, "Return to the land of your fathers and to your kindred, and I will be with you."

**<sup>4</sup>** So Jacob sent and called Rachel and Leah to the field where his flock was, **<sup>5</sup>** and said to them, "I see that your father's attitude toward me is not as it was before, but the God of my father has been with me. **<sup>6</sup>** You yourselves know that I have served your father with all my strength. **<sup>7</sup>** Yet your father has deceived me and changed my wages ten times, but God did not allow him to harm me. **<sup>8</sup>** If he said, 'The speckled shall be your wages,' then all the flock bore speckled lambs; and if he said, 'The striped shall be your wages,' then all the flock bore striped lambs. **<sup>9</sup>** Thus God has taken away your father's livestock and given them to me.

**<sup>10</sup>** "In the mating season of the flock I lifted up my eyes and saw in a dream that the male goats mating with the flock were striped, speckled, and spotted. **<sup>11</sup>** Then the angel of God said to me in the dream, 'Jacob,' and I said, 'Here I am.' **<sup>12</sup>** And he said, 'Lift up your eyes and see: all the male goats that are mating with the flock are striped, speckled, and spotted, for I have seen all that Laban is doing to you. **<sup>13</sup>** I am the God of Bethel, where you anointed a pillar and made a vow to Me. Now arise, leave this land and return to the land of your kindred.'"

**<sup>14</sup>** Then Rachel and Leah answered and said to him, "Do we still have any portion or inheritance in our father's house? **<sup>15</sup>** Are we not regarded by him as foreigners? For he has sold us and has also entirely consumed our purchase price. **<sup>16</sup>** Surely all the wealth that God has taken from our father belongs to us and our children. Now then, do whatever God has said to you."

**<sup>17</sup>** So Jacob rose up and put his sons and his wives on camels. **<sup>18</sup>** He drove away all his livestock and all the possessions he had acquired, the livestock in his possession that he had gained in Paddan-aram, to go to Isaac, his father, in the land of Canaan.

**<sup>19</sup>** Now Laban had gone to shear his sheep, and Rachel stole the household idols that belonged to her father. **<sup>20</sup>** Jacob deceived Laban the Aramean by not telling him that he was fleeing. **<sup>21</sup>** So he fled with all that he had; he arose, crossed the Euphrates, and set his face toward the hill country of Gilead.

**<sup>22</sup>** On the third day, Laban was told that Jacob had fled. **<sup>23</sup>** So he took his kinsmen with him and pursued him for seven days' journey, and he overtook him in the hill country of Gilead. **<sup>24</sup>** But God came to Laban the Aramean in a dream at night and said to him, "Take care not to say anything to Jacob, either good or bad."

**<sup>25</sup>** Then Laban overtook Jacob. Now Jacob had pitched his tent in the hill country, and Laban with his kinsmen camped in the hill country of Gilead. **<sup>26</sup>** Laban said to Jacob, "What have you done, that you have deceived me and carried away my daughters like captives of the sword? **<sup>27</sup>** Why did you flee secretly and deceive me, and not tell me, so that I might have sent you away with joy and with songs, with tambourine and lyre? **<sup>28</sup>** And you did not allow me to kiss my sons and my daughters farewell. Now you have done foolishly. **<sup>29</sup>** It is in my power to do you harm, but the God of your father spoke to me last night, saying, 'Take care not to say anything to Jacob, either good or bad.' **<sup>30</sup>** Now, you have gone away because you longed for your father's house, but why have you stolen my gods?"

**<sup>31</sup>** Jacob answered and said to Laban, "Because I was afraid, for I thought you would take your daughters from me by force. **<sup>32</sup>** But anyone with whom you find your gods shall not live. In the presence of our kinsmen, point out what I have that is yours and take it." Now Jacob did not know that Rachel had stolen them.

**<sup>33</sup>** So Laban went into Jacob's tent, and into Leah's tent, and into the tent of the two female servants, but he found nothing. Then he went out of Leah's tent and entered Rachel's tent. **<sup>34</sup>** Now Rachel had taken the household idols and put them in the camel's saddle and sat on them. Laban searched all the tent but did not find them. **<sup>35</sup>** She said to her father, "Let not my lord be angry that I cannot rise before you, for the way of women is upon me." So he searched, but did not find the household idols.

**<sup>36</sup>** Then Jacob became angry and argued with Laban. Jacob said to Laban, "What is my offense? What is my sin, that you have hotly pursued me? **<sup>37</sup>** For you have searched through all my possessions, and what have you found of all your household goods? Set it here before my kinsmen and your kinsmen, that they may judge between us two.

**<sup>38</sup>** "These twenty years I have been with you; your ewes and your female goats have not miscarried, and I have not eaten the rams of your flock. **<sup>39</sup>** That which was torn by beasts I did not bring to you; I bore the loss of it myself. From my hand you demanded it, whether stolen by day or stolen by night. **<sup>40</sup>** Thus I was: by day the heat consumed me, and the cold by night, and sleep fled from my eyes.

**<sup>41</sup>** "These twenty years I have been in your house: I served you fourteen years for your two daughters and six years for your flock, and you changed my wages ten times. **<sup>42</sup>** If the God of my father, the God of Abraham and the Fear of Isaac, had not been with me, surely now you would have sent me away empty-handed. God has seen my affliction and the labor of my hands, and rebuked you last night."

**<sup>43</sup>** Then Laban answered and said to Jacob, "The daughters are my daughters, the sons are my sons, the flocks are my flocks, and all that you see is mine. But what can I do this day for these my daughters or for their children whom they have borne? **<sup>44</sup>** So now, come, let us make a covenant, you and I, and let it be a witness between you and me."

**<sup>45</sup>** So Jacob took a stone and set it up as a pillar. **<sup>46</sup>** And Jacob said to his kinsmen, "Gather stones." So they took stones and made a heap, and they ate there by the heap. **<sup>47</sup>** Laban called it Jegar-sahadutha, but Jacob called it Galeed. **<sup>48</sup>** And Laban said, "This heap is a witness between you and me today." Therefore its name was called Galeed, **<sup>49</sup>** and Mizpah, for he said, "The LORD watch between you and me, when we are out of one another's sight. **<sup>50</sup>** If you afflict my daughters, or if you take wives besides my daughters, though no man is with us, see—God is witness between you and me."

**<sup>51</sup>** Then Laban said to Jacob, "See this heap and the pillar which I have set between you and me. **<sup>52</sup>** This heap is a witness, and the pillar is a witness, that I will not pass beyond this heap to you, and you will not pass beyond this heap and this pillar to me, to harm. **<sup>53</sup>** The God of Abraham and the god of Nahor, the god of their father, judge between us." So Jacob swore by the Fear of his father Isaac. **<sup>54</sup>** Then Jacob offered a sacrifice on the mountain and called his kinsmen to eat bread. They ate bread and spent the night on the mountain.

**<sup>55</sup>** Early in the morning, Laban rose and kissed his sons and his daughters and blessed them. Then Laban departed and returned to his place. 

## Chapter 32

**<sup>1</sup>** As Jacob went on his way, the angels of God met him. **<sup>2</sup>** When he saw them, Jacob said, "This is God's camp!" So he called that place Mahanaim.

**<sup>3</sup>** Then Jacob sent messengers ahead of him to Esau, his brother, in the land of Seir, the territory of Edom. **<sup>4</sup>** He instructed them, saying, "This is what you shall say to my lord Esau: 'Your servant Jacob says this: I have sojourned with Laban and stayed until now. **<sup>5</sup>** I have oxen, donkeys, flocks, male servants, and female servants. I have sent word to tell my lord, so that I may find favor in your sight.'"

**<sup>6</sup>** The messengers returned to Jacob, saying, "We came to your brother Esau, and he is also coming to meet you, and four hundred men are with him." **<sup>7</sup>** Then Jacob was very afraid and distressed. He divided the people who were with him, along with the flocks, the herds, and the camels, into two camps. **<sup>8</sup>** For he thought, "If Esau comes to the one camp and strikes it, then the other camp will escape."

**<sup>9</sup>** Then Jacob said, "O God of my father Abraham and God of my father Isaac, O LORD, who said to me, 'Return to your country and to your kindred, and I will bless you,' **<sup>10</sup>** I am not worthy of all the kindness and faithfulness that You have shown to Your servant. For with only my staff I crossed this Jordan, and now I have become two camps. **<sup>11</sup>** Deliver me, I pray, from the hand of my brother, from the hand of Esau, for I fear him, that he may come and strike me down, the mothers with the children. **<sup>12</sup>** Yet You Yourself said, 'I will surely bless you, and make your offspring like the sand of the sea, which cannot be numbered for multitude.'"

**<sup>13</sup>** He spent the night there, and from what he had with him he took a gift for his brother Esau: **<sup>14</sup>** two hundred female goats and twenty male goats, two hundred ewes and twenty rams, **<sup>15</sup>** thirty milking camels and their calves, forty cows and ten bulls, twenty female donkeys and ten male donkeys. **<sup>16</sup>** He put them in the care of his servants, each drove by itself, and said to his servants, "Go on ahead of me, and put some distance between each drove."

**<sup>17</sup>** He commanded the first, saying, "When Esau my brother meets you and asks, 'To whom do you belong? Where are you going? And whose animals are these ahead of you?' **<sup>18</sup>** then you shall say, 'They belong to your servant Jacob. It is a gift sent to my lord Esau, and he himself is behind us.'" **<sup>19</sup>** He also commanded the second and the third, and all who followed the droves, saying, "You shall speak the same words to Esau when you find him. **<sup>20</sup>** And you shall say, 'Your servant Jacob is behind us.'" For he said, "I will appease him with the gift that goes ahead of me, and afterward I will see his face; perhaps he will accept me." **<sup>21</sup>** So the gift passed ahead of him, and he himself spent the night in the camp.

**<sup>22</sup>** That night he rose, took his two wives, his two female servants, and his eleven children, and crossed the ford of the Jabbok. **<sup>23</sup>** He took them and sent them across the stream, along with everything else that he had. **<sup>24</sup>** And Jacob was left alone. And a man wrestled with him until the break of day. **<sup>25</sup>** When he saw that he could not prevail against him, he touched the socket of Jacob's hip, and the socket of Jacob's hip was dislocated as he wrestled with him.

**<sup>26</sup>** Then he said, "Let me go, for the day has broken." But Jacob said, "I will not let you go unless you bless me." **<sup>27</sup>** So he said to him, "What is your name?" And he said, "Jacob." **<sup>28</sup>** Then he said, "Your name shall no longer be called Jacob, but Israel, for you have striven with God and with men, and have prevailed."

**<sup>29</sup>** Then Jacob asked him, "Please tell me your name." But he said, "Why do you ask my name?" And there he blessed him. **<sup>30</sup>** So Jacob called the name of the place Peniel, saying, "For I have seen God face to face, and yet my life has been preserved."

**<sup>31</sup>** The sun rose upon him as he passed Peniel, limping because of his hip. **<sup>32</sup>** Therefore to this day the sons of Israel do not eat the sinew of the thigh that is on the socket of the hip, because he touched the socket of Jacob's hip at the sinew of the thigh. 

## Chapter 33

**<sup>1</sup>** Jacob looked up and saw Esau coming, and with him were four hundred men. So he divided the children among Leah, Rachel, and the two maidservants. **<sup>2</sup>** He placed the maidservants and their children in front, Leah and her children after them, and Rachel and Joseph last. **<sup>3</sup>** He himself went on ahead of them and bowed to the ground seven times, until he came near to his brother.

**<sup>4</sup>** But Esau ran to meet him, embraced him, threw his arms around his neck, and kissed him, and they wept. **<sup>5</sup>** When Esau looked up and saw the women and children, he asked, "Who are these with you?" Jacob answered, "The children whom God has graciously given your servant." **<sup>6</sup>** Then the maidservants came forward, they and their children, and bowed down. **<sup>7</sup>** Leah also came forward with her children, and they bowed down. Afterward Joseph and Rachel came forward, and they bowed down.

**<sup>8</sup>** Esau said, "What do you mean by all this company that I met?" He replied, "To find favor in the eyes of my lord." **<sup>9</sup>** But Esau said, "I have enough, my brother; keep what you have for yourself." **<sup>10</sup>** Jacob said, "No, please. If I have found favor in your eyes, accept this gift from my hand. For to see your face is like seeing the face of God, since you have received me favorably. **<sup>11</sup>** Please take my blessing that has been brought to you, because God has dealt graciously with me, and because I have everything I need." So he urged him, and he took it.

**<sup>12</sup>** Then Esau said, "Let us journey on our way, and I will go ahead of you." **<sup>13</sup>** But Jacob said to him, "My lord knows that the children are frail, and the flocks and herds that are nursing are a concern to me. If they are driven hard for a single day, all the livestock will die. **<sup>14</sup>** Let my lord go ahead of his servant, and I will lead on slowly at the pace of the livestock that goes before me and the children, until I come to my lord in Seir."

**<sup>15</sup>** Esau said, "Let me leave with you some of the men who are with me." But he replied, "Why do that? Let me find favor in the eyes of my lord." **<sup>16</sup>** So Esau returned that day on his way to Seir. **<sup>17</sup>** But Jacob journeyed to Succoth, and he built himself a house and made booths for his livestock. Therefore the name of the place is called Succoth.

**<sup>18</sup>** And Jacob came safely to the city of Shechem, which is in the land of Canaan, when he came from Paddan-Aram; and he camped before the city. **<sup>19</sup>** He bought the parcel of land where he had pitched his tent from the sons of Hamor, Shechem's father, for one hundred pieces of money. **<sup>20</sup>** There he set up an altar and called it El-Elohe-Israel. 

## Chapter 34

**<sup>1</sup>** Now Dinah, the daughter whom Leah had borne to Jacob, went out to see the daughters of the land. **<sup>2</sup>** Shechem, the son of Hamor the Hivite, the prince of the land, saw her, took her, lay with her, and violated her. **<sup>3</sup>** His soul was drawn to Dinah, the daughter of Jacob, and he loved the young woman and spoke tenderly to her. **<sup>4</sup>** So Shechem said to his father Hamor, "Get me this girl as a wife."

**<sup>5</sup>** Now Jacob heard that he had defiled Dinah, his daughter, but his sons were with his livestock in the field, so Jacob kept silent until they came in. **<sup>6</sup>** Then Hamor, the father of Shechem, went out to Jacob to speak with him. **<sup>7</sup>** When Jacob's sons heard about it, they came in from the field. The men were grieved and very angry, because he had committed a disgraceful act in Israel by lying with Jacob's daughter—for such a thing ought not to be done. **<sup>8</sup>** But Hamor spoke with them, saying, "My son Shechem's soul longs for your daughter. Please give her to him as a wife. **<sup>9</sup>** Make marriages with us. Give your daughters to us and take our daughters for yourselves. **<sup>10</sup>** You shall dwell with us, and the land shall be before you; settle and trade in it, and acquire property in it." **<sup>11</sup>** Shechem also said to her father and to her brothers, "Let me find favor in your eyes, and whatever you say to me I will give. **<sup>12</sup>** Name the bride-price and dowry as high as you like, and I will give whatever you ask of me; only give me the young woman as a wife."

**<sup>13</sup>** Jacob's sons answered Shechem and his father Hamor with deceit, because he had defiled their sister Dinah. **<sup>14</sup>** They said to them, "We cannot do this thing, to give our sister to one who is uncircumcised, for that would be a disgrace to us. **<sup>15</sup>** Only on this condition will we agree with you—that you become like us by every male among you being circumcised. **<sup>16</sup>** Then we will give our daughters to you, and we will take your daughters for ourselves; we will dwell with you and become one people. **<sup>17</sup>** But if you will not listen to us and be circumcised, then we will take our daughter and go."

**<sup>18</sup>** Their words pleased Hamor and Hamor's son Shechem. **<sup>19</sup>** The young man did not delay to do what they asked, because he was delighted with Jacob's daughter, and he was honored above all the house of his father. **<sup>20</sup>** So Hamor and his son Shechem came to the gate of their city and spoke to the men of their city, saying, **<sup>21</sup>** "These men are at peace with us. Let them dwell in the land and trade in it, for behold, the land is broad enough for them. Let us take their daughters as wives, and let us give them our daughters. **<sup>22</sup>** Only on this condition will the men agree to dwell with us and become one people—that every male among us be circumcised as they are circumcised. **<sup>23</sup>** Will not their livestock, their property, and all their animals be ours? Let us agree with them, and they will dwell with us." **<sup>24</sup>** And all who went out of the gate of his city listened to Hamor and his son Shechem, and every male was circumcised, all who went out of the gate of his city.

**<sup>25</sup>** Now on the third day, when they were in pain, two of Jacob's sons, Simeon and Levi, Dinah's brothers, each took his sword, came upon the city unopposed, and killed every male. **<sup>26</sup>** They killed Hamor and his son Shechem with the sword, took Dinah out of Shechem's house, and went out. **<sup>27</sup>** The sons of Jacob came upon the slain and plundered the city, because their sister had been defiled. **<sup>28</sup>** They took their flocks and their herds and their donkeys, and whatever was in the city and in the field. **<sup>29</sup>** All their wealth, all their little ones and their wives, all that was in the houses, they captured and looted.

**<sup>30</sup>** Then Jacob said to Simeon and Levi, "You have brought trouble on me by making me stink to the inhabitants of the land, the Canaanites and the Perizzites. My men are few in number, and if they gather against me and attack me, I shall be destroyed, both I and my household." **<sup>31</sup>** But they said, "Should he treat our sister like a prostitute?" 

## Chapter 35

**<sup>1</sup>** Then God said to Jacob, "Arise, go up to Bethel and dwell there, and build an altar there to the God who appeared to you when you fled from your brother Esau."

**<sup>2</sup>** So Jacob said to his household and to all who were with him, "Remove the foreign gods that are among you, purify yourselves, and change your garments. **<sup>3</sup>** Let us arise and go up to Bethel, and I will build an altar there to God, who answered me in the day of my distress and was with me on the way that I went." **<sup>4</sup>** So they gave to Jacob all the foreign gods they had and the rings that were in their ears, and Jacob hid them under the oak that was near Shechem.

**<sup>5</sup>** Then they set out, and the terror of God was upon the cities around them, so that they did not pursue the sons of Jacob. **<sup>6</sup>** And Jacob came to Luz (that is, Bethel), which is in the land of Canaan, he and all the people who were with him. **<sup>7</sup>** And there he built an altar and called the place El-Bethel, because there God had revealed himself to him when he fled from his brother.

**<sup>8</sup>** And Deborah, Rebekah's nurse, died, and she was buried below Bethel under the oak; and he called its name Allon-bacuth.

**<sup>9</sup>** Then God appeared to Jacob again when he came from Paddan-aram, and he blessed him. **<sup>10</sup>** And God said to him, "Your name is Jacob; your name shall no longer be called Jacob, but Israel shall be your name." So he called his name Israel.

**<sup>11</sup>** And God said to him, "I am God Almighty. Be fruitful and multiply. A nation and an assembly of nations shall come from you, and kings shall come from your own body. **<sup>12</sup>** And the land that I gave to Abraham and to Isaac, I will give to you, and I will give the land to your descendants after you." **<sup>13</sup>** Then God went up from him at the place where he had spoken with him.

**<sup>14</sup>** So Jacob set up a pillar in the place where he had spoken with him, a pillar of stone, and he poured a drink offering on it and poured oil on it. **<sup>15</sup>** And Jacob called the name of the place where God had spoken with him, Bethel.

**<sup>16</sup>** Then they journeyed from Bethel. And when there was still some distance to go to Ephrath, Rachel went into labor, and she had hard labor. **<sup>17</sup>** And when her labor was at its hardest, the midwife said to her, "Do not be afraid, for you have another son." **<sup>18</sup>** And as her breath was departing (for she died), she called his name Ben-oni, but his father called him Benjamin.

**<sup>19</sup>** So Rachel died, and she was buried on the way to Ephrath (that is, Bethlehem). **<sup>20</sup>** And Jacob set up a pillar over her grave; it is the pillar of Rachel's grave to this day.

**<sup>21</sup>** Then Israel journeyed on and pitched his tent beyond the tower of Eder. **<sup>22</sup>** And it came to pass, while Israel dwelt in that land, that Reuben went and lay with Bilhah, his father's concubine, and Israel heard of it.

Now the sons of Jacob were twelve:**<sup>23</sup>** The sons of Leah: Reuben, Jacob's firstborn, and Simeon and Levi and Judah and Issachar and Zebulun. **<sup>24</sup>** The sons of Rachel: Joseph and Benjamin. **<sup>25</sup>** The sons of Bilhah, Rachel's servant: Dan and Naphtali. **<sup>26</sup>** The sons of Zilpah, Leah's servant: Gad and Asher. These are the sons of Jacob who were born to him in Paddan-aram.

**<sup>27</sup>** And Jacob came to Isaac, his father, at Mamre, at Kiriath-arba (that is, Hebron), where Abraham and Isaac had sojourned. **<sup>28</sup>** Now the days of Isaac were one hundred and eighty years. **<sup>29</sup>** And Isaac breathed his last, and died, and was gathered to his people, old and full of days. And his sons Esau and Jacob buried him. 

## Chapter 36

**<sup>1</sup>** These are the generations of Esau (that is, Edom). **<sup>2</sup>** Esau took his wives from the daughters of Canaan: Adah the daughter of Elon the Hittite, and Oholibamah the daughter of Anah, the daughter of Zibeon the Hivite, **<sup>3</sup>** and Basemath, Ishmael's daughter, the sister of Nebaioth. **<sup>4</sup>** Adah bore Eliphaz to Esau, and Basemath bore Reuel, **<sup>5</sup>** and Oholibamah bore Jeush, Jalam, and Korah. These are the sons of Esau who were born to him in the land of Canaan.

**<sup>6</sup>** Then Esau took his wives, his sons, his daughters, and all the members of his household, along with his livestock, all his animals, and all his possessions that he had gathered in the land of Canaan, and went to a land away from his brother Jacob. **<sup>7</sup>** For their possessions were too great for them to dwell together, and the land of their sojournings could not support them because of their livestock. **<sup>8</sup>** So Esau settled in the hill country of Seir. Esau is Edom.

**<sup>9</sup>** These are the generations of Esau, the father of the Edomites in the hill country of Seir. **<sup>10</sup>** These are the names of Esau's sons: Eliphaz the son of Adah the wife of Esau, Reuel the son of Basemath the wife of Esau. **<sup>11</sup>** The sons of Eliphaz were Teman, Omar, Zepho, Gatam, and Kenaz. **<sup>12</sup>** Timna was a concubine to Eliphaz, Esau's son; she bore Amalek to Eliphaz. These are the sons of Adah, Esau's wife. **<sup>13</sup>** These are the sons of Reuel: Nahath, Zerah, Shammah, and Mizzah. These were the sons of Basemath, Esau's wife. **<sup>14</sup>** These were the sons of Oholibamah the daughter of Anah, the daughter of Zibeon, Esau's wife: she bore to Esau Jeush, Jalam, and Korah.

**<sup>15</sup>** These are the chiefs of the sons of Esau. The sons of Eliphaz, the firstborn of Esau: the chiefs Teman, Omar, Zepho, Kenaz, **<sup>16</sup>** Korah, Gatam, and Amalek. These are the chiefs of Eliphaz in the land of Edom; they are the sons of Adah. **<sup>17</sup>** These are the sons of Reuel, Esau's son: the chiefs Nahath, Zerah, Shammah, and Mizzah. These are the chiefs of Reuel in the land of Edom; they are the sons of Basemath, Esau's wife. **<sup>18</sup>** These are the sons of Oholibamah, Esau's wife: the chiefs Jeush, Jalam, and Korah. These are the chiefs born of Oholibamah the daughter of Anah, Esau's wife. **<sup>19</sup>** These are the sons of Esau (that is, Edom), and these are their chiefs.

**<sup>20</sup>** These are the sons of Seir the Horite, the inhabitants of the land: Lotan, Shobal, Zibeon, Anah, **<sup>21</sup>** Dishon, Ezer, and Dishan. These are the chiefs of the Horites, the sons of Seir in the land of Edom. **<sup>22</sup>** The sons of Lotan were Hori and Hemam, and Lotan's sister was Timna. **<sup>23</sup>** These are the sons of Shobal: Alvan, Manahath, Ebal, Shepho, and Onam. **<sup>24</sup>** These are the sons of Zibeon: Aiah and Anah. This is the Anah who found the hot springs in the wilderness as he pastured the donkeys of Zibeon his father. **<sup>25</sup>** These are the children of Anah: Dishon and Oholibamah the daughter of Anah. **<sup>26</sup>** These are the sons of Dishon: Hemdan, Eshban, Ithran, and Cheran. **<sup>27</sup>** These are the sons of Ezer: Bilhan, Zaavan, and Akan. **<sup>28</sup>** These are the sons of Dishan: Uz and Aran.

**<sup>29</sup>** These are the chiefs of the Horites: the chiefs Lotan, Shobal, Zibeon, Anah, **<sup>30</sup>** Dishon, Ezer, and Dishan. These are the chiefs of the Horites, according to their chiefs in the land of Seir.

**<sup>31</sup>** These are the kings who reigned in the land of Edom before any king reigned over the sons of Israel: **<sup>32</sup>** Bela the son of Beor reigned in Edom, and the name of his city was Dinhabah. **<sup>33</sup>** When Bela died, Jobab the son of Zerah of Bozrah reigned in his place. **<sup>34</sup>** When Jobab died, Husham of the land of the Temanites reigned in his place. **<sup>35</sup>** When Husham died, Hadad the son of Bedad, who struck down Midian in the field of Moab, reigned in his place. The name of his city was Avith. **<sup>36</sup>** When Hadad died, Samlah of Masrekah reigned in his place. **<sup>37</sup>** When Samlah died, Shaul of Rehoboth on the Euphrates reigned in his place. **<sup>38</sup>** When Shaul died, Baal-hanan the son of Achbor reigned in his place. **<sup>39</sup>** When Baal-hanan the son of Achbor died, Hadar reigned in his place. The name of his city was Pau, and his wife's name was Mehetabel, the daughter of Matred, the daughter of Mezahab.

**<sup>40</sup>** These are the names of the chiefs of Esau, according to their clans and places, by their names: the chiefs Timna, Alvah, Jetheth, **<sup>41</sup>** Oholibamah, Elah, Pinon, **<sup>42</sup>** Kenaz, Teman, Mibzar, **<sup>43</sup>** Magdiel, and Iram. These are the chiefs of Edom, according to their dwellings in the land of their possession. This is Esau, the father of Edom. 

## Chapter 37

**<sup>1</sup>** Jacob settled in the land of his father's sojournings, in the land of Canaan.

**<sup>2</sup>** This is the account of Jacob. Joseph, being seventeen years old, was shepherding the flock with his brothers. He was a youth with the sons of Bilhah and Zilpah, his father's wives. And Joseph brought a bad report of them to their father.

**<sup>3</sup>** Now Israel loved Joseph more than all his sons, because he was the son of his old age, and he made him a long-sleeved tunic. **<sup>4</sup>** But when his brothers saw that their father loved him more than all his brothers, they hated him and could not speak peaceably to him.

**<sup>5</sup>** Then Joseph had a dream, and when he told it to his brothers, they hated him even more. **<sup>6</sup>** He said to them, "Please listen to this dream I had: **<sup>7</sup>** So, we were binding sheaves in the field, and it happened that my sheaf rose up and stood upright, and then your sheaves gathered around it and bowed down to my sheaf." **<sup>8</sup>** His brothers said to him, "Will you really reign over us? Or will you truly have authority over us?" So they hated him even more for his dreams and for his words.

**<sup>9</sup>** Then he dreamed again, and told it to his brothers, saying, "Hey, I had another dream: this time, the sun and the moon and eleven stars were bowing down to me." **<sup>10</sup>** But when he told it to his father and to his brothers, his father rebuked him and said to him, "What is this that you have dreamed? Shall I and your mother and your brothers indeed come to bow down to the ground before you?" **<sup>11</sup>** And his brothers were jealous of him, but his father kept the matter in mind.

**<sup>12</sup>** Now his brothers went to pasture their father's flock near Shechem. **<sup>13</sup>** And Israel said to Joseph, "Aren't your brothers pasturing the flock at Shechem? Come, and I will send you to them." And he said to him, "Here I am." **<sup>14</sup>** Then he said to him, "Go now, see if it is well with your brothers and with the flock, and bring me word." So he sent him from the Valley of Hebron, and he came to Shechem.

**<sup>15</sup>** A man found him wandering in the field, and the man asked him, "What are you seeking?" **<sup>16</sup>** And he said, "I am looking for my brothers; please tell me where they are pasturing the flock." **<sup>17</sup>** The man said, "They have moved on from here, for I heard them say, 'Let's go to Dothan.'" So Joseph went after his brothers and found them at Dothan.

**<sup>18</sup>** They saw him from a distance, and before he came near to them, they conspired against him to kill him. **<sup>19</sup>** They said to one another, "Look out, here comes the dreamer. **<sup>20</sup>** Come now, let us kill him and throw him into one of the pits. Then we will say a wild beast has devoured him, and then we will see what will become of his dreams."

**<sup>21</sup>** But Reuben heard it and rescued him out of their hands. He said, "Let's not kill him." **<sup>22</sup>** And Reuben said to them, "Shed no blood; instead, throw him into this pit in the wilderness, but do not lay a hand on him." He intended to rescue him out of their hand, and restore him to his father.

**<sup>23</sup>** So when Joseph came to his brothers, they stripped him of his robe, the long-sleeved tunic that he wore. **<sup>24</sup>** And they took him and threw him into the pit. The pit was empty; there was no water in it.

**<sup>25</sup>** Then they sat down to eat. And looking up, they saw a caravan of Ishmaelites coming from Gilead, with their camels bearing gum, balm, and myrrh, on their way to carry it down to Egypt. **<sup>26</sup>** Then Judah said to his brothers, "What profit is it if we kill our brother and conceal his blood? **<sup>27</sup>** Instead, let us sell him to the Ishmaelites, and let it not be our hand that is upon him, for he is our brother, our own flesh." And his brothers agreed.

**<sup>28</sup>** Then Midianite traders passed by, and they drew Joseph up and lifted him out of the pit, and sold him to the Ishmaelites for twenty shekels of silver. And they took Joseph to Egypt.

**<sup>29</sup>** When Reuben returned to the pit and saw that Joseph was not in the pit, he tore his garments. **<sup>30</sup>** He returned to his brothers and said, "The boy is gone, and I—where shall I go?"

**<sup>31</sup>** Then they took Joseph's robe and slaughtered a goat and dipped the tunic in the blood. **<sup>32</sup>** And they sent the long-sleeved tunic and brought it to their father and said, "We found this; please identify whether it is your son's tunic or not." **<sup>33</sup>** And he recognized it and said, "It is my son's tunic. A wild beast has devoured him. Joseph is without doubt torn to pieces."

**<sup>34</sup>** Then Jacob tore his garments and put on sackcloth, and mourned for his son for many days. **<sup>35</sup>** All his sons and all his daughters came to comfort him, but he refused to be comforted and said, "No, I shall go down to the grave, mourning for my son." Thus his father wept for him.

**<sup>36</sup>** Meanwhile, the Midianites had sold him in Egypt to Potiphar, an officer of Pharaoh, the captain of the guard. 

## Chapter 38

**<sup>1</sup>** At that time Judah departed from his brothers and settled near a man of Adullam named Hirah. **<sup>2</sup>** Judah saw there the daughter of a certain Canaanite man named Shua. He took her and went in to her, **<sup>3</sup>** and she conceived and bore a son, and he called his name Er. **<sup>4</sup>** She conceived again and bore a son, and she named him Onan. **<sup>5</sup>** Then she bore yet another son, and she named him Shelah. He was in Kezib when she bore him.

**<sup>6</sup>** Judah took a wife for Er, his firstborn, and her name was Tamar. **<sup>7</sup>** But Er, Judah's firstborn, was evil in the sight of the LORD, and the LORD put him to death. **<sup>8</sup>** Then Judah said to Onan, "Go in to your brother's wife and perform your duty as a brother-in-law to her, and raise up offspring for your brother." **<sup>9</sup>** But Onan knew that the offspring would not be his, so whenever he went in to his brother's wife, he would spill his seed on the ground, in order not to give offspring to his brother. **<sup>10</sup>** What he did was wicked in the sight of the LORD, and he put him to death also. **<sup>11</sup>** Then Judah said to Tamar his daughter-in-law, "Remain a widow in your father's house until my son Shelah grows up." For he thought, "He too might die, like his brothers." So Tamar went and lived in her father's house.

**<sup>12</sup>** After a considerable time Judah's wife, the daughter of Shua, died. When Judah had finished mourning, he went up to the sheep shearers at Timnah, he and his friend Hirah the Adullamite. **<sup>13</sup>** And Tamar was told, "Your father-in-law is going up to Timnah to shear his sheep." **<sup>14</sup>** So she took off her widow's garments, covered herself with a veil, and wrapped herself, and sat at the entrance to Enaim, which is on the road to Timnah. For she saw that Shelah had grown up, yet she had not been given to him as a wife. **<sup>15</sup>** When Judah saw her, he thought she was a prostitute, for she had covered her face. **<sup>16</sup>** He turned aside to her by the road and said, "Come now, let me come in to you," for he did not know that she was his daughter-in-law. And she said, "What will you give me, that you may come in to me?" **<sup>17</sup>** He said, "I will send you a young goat from the flock." She said, "Only if you give me a pledge until you send it." **<sup>18</sup>** He said, "What pledge shall I give you?" She replied, "Your seal and your cord and the staff that is in your hand." So he gave them to her and went in to her, and she conceived by him. **<sup>19</sup>** Then she arose and went away. She took off her veil and put on her widow's garments again.

**<sup>20</sup>** Judah sent the young goat by his friend the Adullamite, to retrieve the pledge from the woman's hand, but he did not find her. **<sup>21</sup>** He asked the men of that place, "Where is the cult prostitute who was at Enaim by the road?" They said, "No cult prostitute has been here." **<sup>22</sup>** So he returned to Judah and said, "I did not find her. Moreover, the men of the place said, 'No cult prostitute has been here.'" **<sup>23</sup>** Then Judah said, "Let her keep the things for herself, or we will become a laughingstock. After all, I sent this young goat, but you did not find her."

**<sup>24</sup>** About three months later, Judah was told, "Tamar your daughter-in-law has played the harlot, and she is even pregnant by her harlotry." Then Judah said, "Bring her out and let her be burned." **<sup>25</sup>** As she was being brought out, she sent word to her father-in-law: "The man to whom these belong made me pregnant." And she said, "Please examine and see whose these are—the seal, and the cord, and the staff." **<sup>26</sup>** Then Judah recognized them and said, "She is more righteous than I, since I did not give her to my son Shelah." And he did not lie with her again.

**<sup>27</sup>** When the time came for her to give birth, behold, there were twins in her womb. **<sup>28</sup>** As she gave birth, one put out his hand, and the midwife took a scarlet thread and tied it on his hand, saying, "This one came out first." **<sup>29</sup>** But as he drew back his hand, his brother came out, and she said, "What a breach you have made for yourself!" So he was named Perez. **<sup>30</sup>** Afterward his brother came out, the one who had the scarlet thread on his hand, and he was named Zerah. 

## Chapter 39

**<sup>1</sup>** Now Joseph had been brought down to Egypt, and Potiphar, an officer of Pharaoh, the captain of the guard, an Egyptian, bought him from the Ishmaelites who had brought him down there. **<sup>2</sup>** The LORD was with Joseph, and he became a successful man. He was in the house of his Egyptian master. **<sup>3</sup>** His master saw that the LORD was with him and that the LORD made all that he did prosper in his hand. **<sup>4</sup>** So Joseph found favor in his eyes and served him, and he made him overseer of his house and put everything he owned into his hand. **<sup>5</sup>** From the time that he made him overseer in his house and over all that he had, the LORD blessed the Egyptian's house for Joseph's sake. The blessing of the LORD was upon all that he had, in the house and in the field. **<sup>6</sup>** So he left all that he had in Joseph's hand, and with him there he did not concern himself with anything except the food he ate. Now Joseph was handsome in form and appearance.

**<sup>7</sup>** And after these things, his master's wife cast her eyes on Joseph and said, "Lie with me." **<sup>8</sup>** But he refused and said to his master's wife, "Look, my master does not concern himself with anything in the house because of me, and he has put everything that he owns into my hand. **<sup>9</sup>** There is no one greater in this house than I, and he has not withheld anything from me except you, because you are his wife. How then could I do this great evil and sin against God?"

**<sup>10</sup>** Though she spoke to Joseph day after day, he would not listen to her, to lie with her or to be with her. **<sup>11</sup>** One day he went into the house to do his work, and none of the men of the house were there inside. **<sup>12</sup>** She grabbed him by his garment and said, "Lie with me!" But he left his garment in her hand and fled and ran outside.

**<sup>13</sup>** When she saw that he had left his garment in her hand and had fled outside, **<sup>14</sup>** she called the men of her house and said to them, "Look, he brought us a Hebrew to mock us. He came in to me to lie with me, and I screamed. **<sup>15</sup>** And when he heard that I lifted up my voice and screamed, he left his garment beside me and fled and went outside."

**<sup>16</sup>** She kept his garment beside her until his master came home. **<sup>17</sup>** Then she spoke to him with these words: "The Hebrew slave you brought to us came in to me to mock me. **<sup>18</sup>** But as I lifted up my voice and screamed, he left his garment beside me and fled outside."

**<sup>19</sup>** When his master heard the words his wife spoke to him, saying, "This is what your servant did to me," his anger burned. **<sup>20</sup>** So Joseph's master took him and put him into the prison, the place where the king's prisoners were confined. And he was there in the prison.

**<sup>21</sup>** But the LORD was with Joseph and showed him steadfast love and gave him favor in the eyes of the warden of the prison. **<sup>22</sup>** And the warden put all the prisoners who were in the prison under Joseph's care. Whatever was done there, he was the one doing it. **<sup>23</sup>** The warden did not pay attention to anything that was in Joseph's hand, because the LORD was with him, and whatever he did, the LORD made it succeed. 

## Chapter 40

**<sup>1</sup>** After these events, the cupbearer of the king of Egypt and his baker offended their master, the king of Egypt. **<sup>2</sup>** Pharaoh became angry with his two officials, the chief cupbearer and the chief baker, **<sup>3</sup>** and he placed them in custody in the house of the captain of the guard, in the same prison where Joseph was confined. **<sup>4</sup>** The captain of the guard appointed Joseph to be with them, and he attended to them; they were in custody for some time.

**<sup>5</sup>** Now both of them, the cupbearer and the baker of the king of Egypt, who were confined in the prison, had a dream the same night—each his own dream with its own interpretation. **<sup>6</sup>** When Joseph came to them in the morning, he saw that they were troubled. **<sup>7</sup>** So he asked Pharaoh's officials who were with him in custody in his master's house, "Why are your faces downcast today?" **<sup>8</sup>** They said to him, "We have had a dream, and there is no one to interpret it." Then Joseph said to them, "Do not interpretations belong to God? Please tell them to me."

**<sup>9</sup>** So the chief cupbearer told his dream to Joseph, and said to him, "In my dream, there was a vine in front of me, **<sup>10</sup>** and on the vine were three branches. As it was budding, its blossoms came out, and its clusters ripened into grapes. **<sup>11</sup>** Pharaoh's cup was in my hand, and I took the grapes and pressed them into Pharaoh's cup, and I placed the cup in Pharaoh's hand." **<sup>12</sup>** Then Joseph said to him, "This is its interpretation: the three branches are three days. **<sup>13</sup>** Within three days Pharaoh will lift up your head and restore you to your office, and you will place Pharaoh's cup in his hand, just as you used to do when you were his cupbearer. **<sup>14</sup>** But remember me when it goes well with you, and please show kindness to me by mentioning me to Pharaoh, and get me out of this house. **<sup>15</sup>** For I was certainly stolen from the land of the Hebrews, and even here I have done nothing that they should put me into the pit."

**<sup>16</sup>** When the chief baker saw that the interpretation was favorable, he said to Joseph, "I also saw in my dream that there were three baskets of white bread on my head. **<sup>17</sup>** In the top basket were all sorts of baked goods for Pharaoh, and birds were eating them out of the basket on my head." **<sup>18</sup>** Then Joseph answered and said, "This is its interpretation: the three baskets are three days. **<sup>19</sup>** Within three days Pharaoh will lift up your head—from off you—and will hang you on a tree, and the birds will eat your flesh from you."

**<sup>20</sup>** Now on the third day, which was Pharaoh's birthday, he made a feast for all his servants, and he lifted up the head of the chief cupbearer and the head of the chief baker among his servants. **<sup>21</sup>** He restored the chief cupbearer to his position, and he placed the cup in Pharaoh's hand, **<sup>22</sup>** but he hanged the chief baker, just as Joseph had interpreted to them. **<sup>23</sup>** Yet the chief cupbearer did not remember Joseph; he forgot him. 

## Chapter 41

**<sup>1</sup>** Two full years later, Pharaoh had a dream: he was standing by the Nile, **<sup>2</sup>** and there came up out of the Nile seven cows, attractive and plump, and they grazed among the reeds. **<sup>3</sup>** Then seven other cows came up after them from the Nile, ugly and thin, and stood beside the other cows on the bank of the Nile. **<sup>4</sup>** The ugly and thin cows ate up the seven attractive and plump cows. Then Pharaoh awoke.

**<sup>5</sup>** He fell asleep again and dreamed a second time. Seven ears of grain, plump and good, were growing on one stalk. **<sup>6</sup>** Then, behold, seven ears, thin and scorched by the east wind, sprouted after them. **<sup>7</sup>** The thin ears swallowed up the seven plump and full ears. Then Pharaoh awoke, and it was a dream.

**<sup>8</sup>** In the morning his spirit was troubled. He sent and called for all the magicians of Egypt and all its wise men. Pharaoh told them his dreams, but there was no one who could interpret them for Pharaoh.

**<sup>9</sup>** Then the chief cupbearer spoke to Pharaoh, saying, "I remember my offenses today. **<sup>10</sup>** When Pharaoh was angry with his servants, he put me and the chief baker in custody in the house of the captain of the guard. **<sup>11</sup>** We both had dreams on the same night, each dream with its own interpretation. **<sup>12</sup>** A young Hebrew was there with us, a servant of the captain of the guard. When we told him, he interpreted our dreams for us, giving each man an interpretation according to his dream. **<sup>13</sup>** And just as he interpreted for us, so it came to pass. I was restored to my office, and the other was hanged."

**<sup>14</sup>** Then Pharaoh sent and called Joseph, and they quickly brought him out of the jail. When he had shaved himself and changed his clothes, he came before Pharaoh. **<sup>15</sup>** Pharaoh said to Joseph, "I have had a dream, and there is no one who can interpret it. But I have heard it said of you that when you hear a dream, you can interpret it." **<sup>16</sup>** Joseph answered Pharaoh, "It is not in me; but it is God who will give Pharaoh a favorable answer."

**<sup>17</sup>** Then Pharaoh said to Joseph, "In my dream I was standing on the bank of the Nile. **<sup>18</sup>** Seven cows, plump and attractive, came up out of the Nile and grazed among the reeds. **<sup>19</sup>** Then seven other cows came up after them, poor and very ugly and thin—such ugliness as I had never seen in all the land of Egypt. **<sup>20</sup>** And the thin and ugly cows ate up the first seven plump cows. **<sup>21</sup>** But when they had eaten them, no one would have known they had eaten them, for they were still as ugly as at the beginning. Then I awoke.

**<sup>22</sup>** "I also saw in my dream seven ears of grain growing on one stalk, full and good. **<sup>23</sup>** Then seven ears, withered, thin, and scorched by the east wind, sprouted after them. **<sup>24</sup>** And the thin ears swallowed up the seven good ears. I told this to the magicians, but there was no one who could explain it to me."

**<sup>25</sup>** Then Joseph said to Pharaoh, "The dreams of Pharaoh are one; God has revealed to Pharaoh what he is about to do. **<sup>26</sup>** The seven good cows are seven years, and the seven good ears are seven years; the dreams are one. **<sup>27</sup>** The seven thin and ugly cows that came up after them are seven years, and the seven empty ears scorched by the east wind are also seven years of famine. **<sup>28</sup>** It is as I told Pharaoh: God has shown to Pharaoh what he is about to do.

**<sup>29</sup>** "Behold, seven years of great abundance are coming throughout all the land of Egypt. **<sup>30</sup>** But after them will come seven years of famine, and all the abundance will be forgotten in the land of Egypt. The famine will consume the land, **<sup>31</sup>** and the abundance in the land will not be remembered because of the famine that follows, for it will be very severe. **<sup>32</sup>** The doubling of Pharaoh's dream means that the thing is fixed by God, and God will shortly bring it to pass.

**<sup>33</sup>** "Now therefore let Pharaoh select a discerning and wise man and set him over the land of Egypt. **<sup>34</sup>** Let Pharaoh act, and appoint overseers over the land, and take one-fifth of the produce of the land of Egypt during the seven plentiful years. **<sup>35</sup>** And let them gather all the food of these good years that are coming and store up grain under Pharaoh's authority for food in the cities, and let them keep it. **<sup>36</sup>** That food shall be a reserve for the land against the seven years of famine that are to occur in the land of Egypt, so that the land may not perish through the famine."

**<sup>37</sup>** This proposal seemed good to Pharaoh and to all his servants. **<sup>38</sup>** And Pharaoh said to his servants, "Can we find a man like this, in whom is the spirit of God?" **<sup>39</sup>** Then Pharaoh said to Joseph, "Since God has shown you all this, there is none so discerning and wise as you are. **<sup>40</sup>** You shall be over my house, and all my people shall submit themselves according to your command. Only as it pertains to the throne will I be greater than you."

**<sup>41</sup>** And Pharaoh said to Joseph, "Now, I am setting you over all the land of Egypt." **<sup>42</sup>** Then Pharaoh took his signet ring from his hand and put it on Joseph's hand, and clothed him in garments of fine linen and put a gold chain around his neck. **<sup>43</sup>** And he made him ride in his second chariot. And they called out before him, "Bow the knee!" Thus he set him over all the land of Egypt.

**<sup>44</sup>** Moreover, Pharaoh said to Joseph, "I am Pharaoh, and without your permission no man shall lift hand or foot in all the land of Egypt." **<sup>45</sup>** And Pharaoh called Joseph's name Zaphenath-paneah. And he gave him Asenath, the daughter of Potiphera priest of On, as a wife. So Joseph went out over the land of Egypt.

**<sup>46</sup>** Joseph was thirty years old when he entered the service of Pharaoh king of Egypt. And Joseph went out from Pharaoh's presence and passed through all the land of Egypt. **<sup>47</sup>** During the seven plentiful years the earth produced abundantly. **<sup>48</sup>** And he gathered up all the food of the seven years which occurred in the land of Egypt and stored the food in the cities. He stored up in every city the food from the fields surrounding it. **<sup>49</sup>** And Joseph stored up grain in great abundance, like the sand of the sea, until he stopped measuring it, for it could not be measured.

**<sup>50</sup>** Before the year of famine came, two sons were born to Joseph. Asenath, the daughter of Potiphera priest of On, bore them to him. **<sup>51</sup>** Joseph called the name of the firstborn Manasseh, for he said, "God has made me forget all my hardship and all my father's house." **<sup>52</sup>** The name of the second he called Ephraim, for he said, "God has made me fruitful in the land of my affliction."

**<sup>53</sup>** The seven years of plenty that occurred in the land of Egypt came to an end, **<sup>54</sup>** and the seven years of famine began to come, just as Joseph had said. There was famine in all lands, but in all the land of Egypt there was bread. **<sup>55</sup>** When all the land of Egypt was famished, the people cried to Pharaoh for bread. Pharaoh said to all the Egyptians, "Go to Joseph. Do what he tells you."

**<sup>56</sup>** So when the famine had spread over all the land, Joseph opened all the storehouses and sold to the Egyptians, for the famine was severe in the land of Egypt. **<sup>57</sup>** Moreover, all the earth came to Egypt to Joseph to buy grain, because the famine was severe over all the earth. 

## Chapter 42

**<sup>1</sup>** When Jacob learned that there was grain in Egypt, he said to his sons, "Why are you just standing around looking at each other?" **<sup>2</sup>** He said, "Look, I've heard that there is grain in Egypt. Go down there and buy some for us from that place, so that we may live and not die."

**<sup>3</sup>** Then ten of Joseph's brothers went down to buy grain from Egypt. **<sup>4</sup>** But Jacob did not send Benjamin, Joseph's brother, with his brothers, "Lest harm come to him," he said. **<sup>5</sup>** So the sons of Israel came to buy grain among others who were going, for the famine was in the land of Canaan also.

**<sup>6</sup>** Now Joseph was the governor over the land; he was the one selling grain to all the people of the land. So when Joseph's brothers came and bowed down before him with their faces to the ground, **<sup>7</sup>** and Joseph saw his brothers, he recognized them. But he acted like a stranger toward them and spoke harshly with them. He said to them, "Where do you come from?" And they said, "From the land of Canaan to buy food." **<sup>8</sup>** Though Joseph recognized his brothers, they did not recognize him. **<sup>9</sup>** Then Joseph remembered the dreams that he had dreamed about them, and he said to them, "You are spies! You've come to see where the land is vulnerable."

**<sup>10</sup>** But they said to him, "No, my lord! Your servants have come to buy food. **<sup>11</sup>** We are all sons of one man. We are honest men; your servants are not spies."

**<sup>12</sup>** But he said to them, "No! You have come to see where the land is vulnerable." **<sup>13</sup>** And they said, "Your servants are twelve brothers, the sons of one man in the land of Canaan. The youngest is now with our father, and one is no more."

**<sup>14</sup>** But Joseph said to them, "It is just as I said to you: you are spies. **<sup>15</sup>** Here is how you will be tested: by the life of Pharaoh, you shall not leave this place unless your youngest brother comes here. **<sup>16</sup>** Send one of you to bring your brother, and the rest of you will be kept under guard, so that your words may be tested, whether there is truth in you. Otherwise, by the life of Pharaoh, surely you are spies." **<sup>17</sup>** Then he put them all together in custody for three days.

**<sup>18</sup>** On the third day Joseph said to them, "Do this and live, for I fear God. **<sup>19</sup>** If you are honest men, let one of your brothers remain confined in prison, and the rest of you go, bring grain to your households for the famine. **<sup>20</sup>** But bring your youngest brother to me. In this way your words will be verified, and you shall not die." And they did so.

**<sup>21</sup>** Then they said to one another, "Surely we are guilty concerning our brother, because we saw the distress of his soul when he pleaded with us, and we would not listen. That is why this trouble has come upon us." **<sup>22</sup>** Reuben answered them, saying, "Did I not tell you, 'Do not sin against the boy'? But you would not listen, and now his blood is required of us." **<sup>23</sup>** They did not know that Joseph understood them, for there was an interpreter between them. **<sup>24</sup>** Then he turned away from them and wept. When he returned to them, he spoke to them and took Simeon from them and bound him before their eyes.

**<sup>25</sup>** Then Joseph gave orders to fill their bags with grain and to return each man's silver to his sack and to give them provisions for the journey. And it was done for them. **<sup>26</sup>** So they loaded their grain on their donkeys and departed from there.

**<sup>27</sup>** When one of them opened his sack at the lodging place to give feed to his donkey, he saw his silver—there, in the mouth of his sack. **<sup>28</sup>** He said to his brothers, "My silver has been returned, here in my sack!" Then their hearts failed them, and trembling, they said to one another, "What has God done to us?"

**<sup>29</sup>** When they came to Jacob their father in the land of Canaan, they told him all that had happened to them, saying, **<sup>30</sup>** "The man, the lord of the land, spoke harshly with us and took us for spies of the land. **<sup>31</sup>** But we said to him, 'We are honest men; we are not spies. **<sup>32</sup>** We are twelve brothers, sons of our father; one is no more, and the youngest is with our father this day in the land of Canaan.' **<sup>33</sup>** Then the man, the lord of the land, said to us, 'By this I shall know that you are honest: leave one of your brothers with me, and take grain to your families for the famine. And go! **<sup>34</sup>** But bring your youngest brother to me. Then I shall know that you are not spies but honest men. I will give your brother back to you, and you may trade in the land.'"

**<sup>35</sup>** And it came about as they were emptying their sacks, that there in each man's sack was his pouch of silver. When they and their father saw the pouches of silver, they were afraid. **<sup>36</sup>** And Jacob their father said to them, "You have bereaved me of my children: Joseph is no more, Simeon is no more, and now you would take Benjamin. All this has come upon me!" **<sup>37</sup>** Then Reuben said to his father, "You may put my two sons to death if I do not bring him back to you. Put him in my hand, and I will bring him back to you." **<sup>38</sup>** But he said, "My son shall not go down with you, for his brother is dead, and he alone is left. If harm should befall him on the journey that you are taking, then you will bring my gray head in sorrow to the grave." 

## Chapter 43

**<sup>1</sup>** Now the famine was severe in the land. **<sup>2</sup>** When they had finished eating the grain they had brought from Egypt, their father said to them, "Go back and buy us a little food." **<sup>3</sup>** But Judah said to him, "The man solemnly warned us, saying, 'You shall not see my face unless your brother is with you.' **<sup>4</sup>** If you will send our brother with us, we will go down and buy you food. **<sup>5</sup>** But if you will not send him, we will not go down, for the man said to us, 'You shall not see my face unless your brother is with you.'" **<sup>6</sup>** Then Israel said, "Why did you treat me so badly as to tell the man that you had another brother?" **<sup>7</sup>** They replied, "The man asked us carefully about ourselves and our family, saying, 'Is your father still alive? Do you have another brother?' So we answered him according to these words. How could we know that he would say, 'Bring your brother down'?" **<sup>8</sup>** Then Judah said to his father Israel, "Send the boy with me, and we will arise and go, so that we may live and not die—both we and you and also our little ones. **<sup>9</sup>** I will be a pledge for his safety; from my hand you shall require him. If I do not bring him back to you and set him before you, then I shall bear the blame forever. **<sup>10</sup>** For if we had not delayed, we would by now have returned twice."

**<sup>11</sup>** Then their father Israel said to them, "If it must be so, then do this: take some of the choice products of the land in your bags and carry them down to the man as a gift—a little balm and a little honey, gum resin and myrrh, pistachio nuts and almonds. **<sup>12</sup>** Take double the silver with you, and carry back the silver that was returned in the mouth of your sacks—perhaps it was a mistake. **<sup>13</sup>** Take your brother also, and arise, go back to the man. **<sup>14</sup>** May God Almighty grant you mercy before the man, that he may release your other brother and Benjamin. As for me, if I am bereaved, I am bereaved."

**<sup>15</sup>** So the men took this gift, and double the silver with them, and Benjamin. They arose, went down to Egypt, and stood before Joseph. **<sup>16</sup>** When Joseph saw Benjamin with them, he said to the steward of his house, "Bring the men into the house, and slaughter an animal, and make ready, for the men shall dine with me at noon." **<sup>17</sup>** The man did as Joseph said, and brought the men to Joseph's house. **<sup>18</sup>** And the men were afraid when they were brought into Joseph's house. They said, "It is because of the silver that was returned in our sacks the first time, that we are being brought in, so that he may assault us and fall upon us and make us servants and seize our donkeys." **<sup>19</sup>** So they approached the steward of Joseph's house and spoke to him at the entrance of the house, **<sup>20</sup>** and said, "Please, my lord, we came down the first time to buy food. **<sup>21</sup>** But when we came to the lodging place and opened our sacks, behold, each man's silver was in the mouth of his sack—our silver in full weight. So we have brought it back with us. **<sup>22</sup>** And we have brought other silver with us to buy food. We do not know who put our silver in our sacks." **<sup>23</sup>** He replied, "Peace to you, do not be afraid. Your God and the God of your father has given you treasure in your sacks. I received your silver." Then he brought Simeon out to them.

**<sup>24</sup>** Then the man brought the men into Joseph's house and gave them water, and they washed their feet, and he gave their donkeys fodder. **<sup>25</sup>** They prepared the gift for Joseph's arrival at noon, for they had heard that they would eat there. **<sup>26</sup>** When Joseph came into the house, they brought him the gift that they had with them and bowed down before him to the ground. **<sup>27</sup>** He asked them about their welfare and said, "Is your aged father well, the one of whom you spoke? Is he still alive?" **<sup>28</sup>** They said, "Your servant our father is well; he is still alive." And they bowed their heads and prostrated themselves. **<sup>29</sup>** Then he lifted up his eyes and saw his brother Benjamin, his mother's son, and said, "Is this your youngest brother of whom you spoke to me?" Then he said, "May God be gracious to you, my son." **<sup>30</sup>** Then Joseph hurried out, for his compassion grew warm for his brother, and he sought a place to weep. He went into a chamber and wept there.

**<sup>31</sup>** Then he washed his face and came out. Controlling himself, he said, "Serve the meal." **<sup>32</sup>** They served him by himself, and them by themselves, and the Egyptians who ate with him by themselves, for the Egyptians could not eat with the Hebrews, for that is an abomination to the Egyptians. **<sup>33</sup>** And they sat before him, the firstborn according to his birthright and the youngest according to his youth, and the men looked at one another in astonishment. **<sup>34</sup>** He took portions to them from before him, but Benjamin's portion was five times as much as any of theirs. And they drank and were merry with him. 

## Chapter 44

**<sup>1</sup>** Then he commanded the steward of his house, saying, "Fill the men's sacks with as much food as they can carry, and put each man's silver in the mouth of his sack. **<sup>2</sup>** And put my cup, the silver one, in the mouth of the sack of the youngest, along with the silver for his grain." And he did as Joseph had spoken.

**<sup>3</sup>** At morning light the men were sent off, they and their donkeys. **<sup>4</sup>** They had gone only a short distance from the city when Joseph said to his steward, "Get up, pursue the men; and when you overtake them, say to them, 'Why have you repaid good with evil? **<sup>5</sup>** Is not this the cup from which my master drinks and by which he indeed practices divination? You have done evil in what you have done.'"

**<sup>6</sup>** When he overtook them, he spoke these words to them. **<sup>7</sup>** But they said to him, "Why does my lord speak such words as these? Far be it from your servants to do such a thing. **<sup>8</sup>** Look, the silver that we found in the mouths of our sacks we brought back to you from the land of Canaan. How then could we steal silver or gold from your master's house? **<sup>9</sup>** Whichever of your servants is found with it shall die, and we also will become slaves to my lord."

**<sup>10</sup>** And he said, "Now also let it be according to your words: he who is found with it shall be my slave, and the rest of you shall be innocent." **<sup>11</sup>** Then they quickly lowered each man his sack to the ground, and each man opened his sack. **<sup>12</sup>** And he searched, beginning with the eldest and ending with the youngest; and the cup was found in Benjamin's sack. **<sup>13</sup>** Then they tore their clothes, and each man loaded his donkey and returned to the city.

**<sup>14</sup>** When Judah and his brothers came to Joseph's house, he was still there, and they fell before him to the ground. **<sup>15</sup>** And Joseph said to them, "What is this deed you have done? Did you not know that a man like me can indeed practice divination?"

**<sup>16</sup>** Then Judah said, "What shall we say to my lord? What shall we speak? Or how shall we justify ourselves? God has found out the guilt of your servants. Look, we are my lord's slaves, both we and he also in whose hand the cup was found."

**<sup>17</sup>** But he said, "Far be it from me to do this. The man in whose hand the cup was found, he shall be my slave. But you—go up in peace to your father."

**<sup>18</sup>** Then Judah approached him and said, "Please, my lord, let your servant speak a word in the ears of my lord, and do not be angry with your servant, for you are as Pharaoh. **<sup>19</sup>** My lord asked his servants, saying, 'Do you have a father or a brother?' **<sup>20</sup>** And we said to my lord, 'We have an aged father and a young boy born to him in his old age. His brother is dead, and he alone is left of his mother, and his father loves him.'

**<sup>21</sup>** Then you said to your servants, 'Bring him down to me so that I may set my eyes on him.' **<sup>22</sup>** But we said to my lord, 'The boy cannot leave his father, for if he leaves his father, he will die.' **<sup>23</sup>** But you said to your servants, 'Unless your youngest brother comes down with you, you shall not see my face again.'

**<sup>24</sup>** And it happened when we went up to your servant my father, we told him the words of my lord. **<sup>25</sup>** Then our father said, 'Go again, buy us a little food.' **<sup>26</sup>** But we said, 'We cannot go down. If our youngest brother is with us, then we will go down. For we cannot see the man's face unless our youngest brother is with us.'

**<sup>27</sup>** Then your servant my father said to us, 'You know that my wife bore me two sons. **<sup>28</sup>** And the one went out from me, and I said, "Surely he has been torn to pieces," and I have not seen him since. **<sup>29</sup>** If you take this one also from me, and harm befalls him, you will bring down my gray hairs in sorrow to the grave.'

**<sup>30</sup>** Now therefore, when I come to your servant my father and the boy is not with us, since his life is bound up in the boy's life, **<sup>31</sup>** it shall happen, when he sees that the boy is not there, that he will die. Then your servants will bring down the gray hairs of your servant our father in sorrow to the grave. **<sup>32</sup>** For your servant became surety for the boy to my father, saying, 'If I do not bring him back to you, then I shall bear the blame before my father all my days.'

**<sup>33</sup>** Now therefore, please let your servant remain as a slave to my lord in place of the boy, and let the boy go up with his brothers. **<sup>34</sup>** For how shall I go up to my father if the boy is not with me—lest I see the evil that would come upon my father?" 

## Chapter 45

**<sup>1</sup>** Then Joseph could no longer restrain himself before all those who stood by him, and he cried, "Have everyone go out from me!" So no man stood with him when Joseph made himself known to his brothers. **<sup>2</sup>** And he wept aloud, so that the Egyptians heard it, and the household of Pharaoh heard of it.

**<sup>3</sup>** Then Joseph said to his brothers, "I am Joseph. Is my father still alive?" But his brothers could not answer him, for they were dismayed at his presence. **<sup>4</sup>** And Joseph said to his brothers, "Come near to me, please." And they came near. And he said, "I am Joseph your brother, whom you sold into Egypt. **<sup>5</sup>** But now do not be distressed or angry with yourselves because you sold me here, for God sent me before you to preserve life. **<sup>6</sup>** For the famine has been in the land these two years, and there are yet five years in which there will be neither plowing nor harvest. **<sup>7</sup>** And God sent me before you to preserve for you a remnant on the earth and to keep many survivors alive. **<sup>8</sup>** So then, it was not you who sent me here, but God. And He has made me a father to Pharaoh, and lord of all his house, and ruler over all the land of Egypt. **<sup>9</sup>** Hurry and go up to my father and say to him, 'Thus says your son Joseph, "God has made me lord of all Egypt; come down to me, do not delay. **<sup>10</sup>** You shall dwell in the land of Goshen, and you shall be near me—you, and your sons, and your sons' sons, and your flocks, and your herds, and all that you have. **<sup>11</sup>** There I will provide for you, for there are yet five years of famine to come, so that you and your household and all that you have do not come to poverty."' **<sup>12</sup>** And now, your eyes see, and the eyes of my brother Benjamin see, that it is my mouth that speaks to you. **<sup>13</sup>** You shall tell my father of all my honor in Egypt and of all that you have seen, and you shall hurry and bring my father down here."

**<sup>14</sup>** Then he fell upon the neck of his brother Benjamin and wept, and Benjamin wept on his neck. **<sup>15</sup>** And he kissed all his brothers and wept upon them. After that, his brothers talked with him.

**<sup>16</sup>** And the report was heard in Pharaoh's house, saying, "Joseph's brothers have come." And it was good in the eyes of Pharaoh and in the eyes of his servants. **<sup>17</sup>** Then Pharaoh said to Joseph, "Say to your brothers, 'Do this: load your beasts and go to the land of Canaan, **<sup>18</sup>** and take your father and your households and come to me, and I will give you the best of the land of Egypt, and you shall eat the fat of the land.' **<sup>19</sup>** And you, Joseph, are commanded to say, 'Do this: take wagons from the land of Egypt for your little ones and for your wives, and bring your father and come. **<sup>20</sup>** Do not concern yourselves with your goods, for the best of all the land of Egypt is yours.'"

**<sup>21</sup>** And the sons of Israel did so. And Joseph gave them wagons according to the command of Pharaoh, and gave them provisions for the journey. **<sup>22</sup>** To all of them he gave each man changes of garments, but to Benjamin he gave three hundred pieces of silver and five changes of garments. **<sup>23</sup>** And he sent to his father the following: ten donkeys loaded with the best things of Egypt, and ten female donkeys loaded with grain and bread and provisions for his father on the journey. **<sup>24</sup>** Then he sent his brothers away, and they departed. And he said to them, "Do not quarrel on the way."

**<sup>25</sup>** So they went up out of Egypt and came to the land of Canaan to Jacob, their father. **<sup>26</sup>** And they told him, saying, "Joseph is still alive, and he is ruler over all the land of Egypt." And his heart grew numb, for he did not believe them. **<sup>27</sup>** But when they told him all the words of Joseph that he had spoken to them, and when he saw the wagons that Joseph had sent to carry him, the spirit of Jacob their father revived. **<sup>28</sup>** And Israel said, "It is enough. My son Joseph is still alive. I will go and see him before I die." 

## Chapter 46

**<sup>1</sup>** So Israel set out with all that he had and came to Beersheba, and he offered sacrifices to the God of his father Isaac. **<sup>2</sup>** And God spoke to Israel in visions of the night and said, "Jacob, Jacob." And he said, "Here I am." **<sup>3</sup>** Then He said, "I am God, the God of your father. Do not be afraid to go down to Egypt, for I will make you a great nation there. **<sup>4</sup>** I Myself will go down with you to Egypt, and I Myself will surely bring you up again; and Joseph shall close your eyes."

**<sup>5</sup>** Then Jacob arose from Beersheba, and the sons of Israel carried their father Jacob, and their little ones and their wives, in the wagons that Pharaoh had sent to carry him. **<sup>6</sup>** They took their livestock and their property, which they had acquired in the land of Canaan, and came to Egypt, Jacob and all his offspring with him. **<sup>7</sup>** His sons and his grandsons with him, his daughters and his granddaughters—all his offspring—he brought with him to Egypt.

**<sup>8</sup>** Now these are the names of the sons of Israel, Jacob and his sons, who came to Egypt: Reuben, Jacob's firstborn. **<sup>9</sup>** And the sons of Reuben: Hanoch, Pallu, Hezron, and Carmi.

**<sup>10</sup>** And the sons of Simeon: Jemuel, Jamin, Ohad, Jachin, Zohar, and Shaul the son of a Canaanite woman.

**<sup>11</sup>** And the sons of Levi: Gershon, Kohath, and Merari.

**<sup>12</sup>** And the sons of Judah: Er, Onan, Shelah, Perez, and Zerah (but Er and Onan died in the land of Canaan). And the sons of Perez were Hezron and Hamul.

**<sup>13</sup>** And the sons of Issachar: Tola, Puvah, Iob, and Shimron.

**<sup>14</sup>** And the sons of Zebulun: Sered, Elon, and Jahleel.

**<sup>15</sup>** These are the sons of Leah, whom she bore to Jacob in Paddan-aram, along with his daughter Dinah. All the sons and daughters of his were thirty-three persons.

**<sup>16</sup>** And the sons of Gad: Ziphion, Haggi, Shuni, Ezbon, Eri, Arodi, and Areli.

**<sup>17</sup>** And the sons of Asher: Imnah, Ishvah, Ishvi, Beriah, and their sister Serah. And the sons of Beriah: Heber and Malchiel.

**<sup>18</sup>** These are the sons of Zilpah, whom Laban gave to his daughter Leah, and she bore these to Jacob—sixteen persons.

**<sup>19</sup>** The sons of Jacob's wife Rachel: Joseph and Benjamin.

**<sup>20</sup>** And to Joseph in the land of Egypt were born Manasseh and Ephraim, whom Asenath daughter of Potiphera, priest of On, bore to him.

**<sup>21</sup>** And the sons of Benjamin: Bela, Becher, Ashbel, Gera, Naaman, Ehi, Rosh, Muppim, Huppim, and Ard.

**<sup>22</sup>** These are the sons of Rachel, who were born to Jacob—fourteen persons in all.

**<sup>23</sup>** And the sons of Dan: Hushim.

**<sup>24</sup>** And the sons of Naphtali: Jahzeel, Guni, Jezer, and Shillem.

**<sup>25</sup>** These are the sons of Bilhah, whom Laban gave to his daughter Rachel, and she bore these to Jacob—seven persons in all.

**<sup>26</sup>** All the persons belonging to Jacob who came to Egypt, who were his direct descendants, not counting the wives of Jacob's sons, were sixty-six persons in all.

**<sup>27</sup>** And the sons of Joseph, who were born to him in Egypt, were two. All the persons of the house of Jacob who came to Egypt were seventy.

**<sup>28</sup>** Now he sent Judah ahead of him to Joseph, to direct him to Goshen. And they came into the land of Goshen. **<sup>29</sup>** Then Joseph made ready his chariot and went up to meet Israel, his father, in Goshen. And when he appeared to him, he fell on his neck and wept on his neck a long time. **<sup>30</sup>** And Israel said to Joseph, "Now let me die, since I have seen your face and you are still alive."

**<sup>31</sup>** Then Joseph said to his brothers and to his father's household, "I will go up and tell Pharaoh, and will say to him, 'My brothers and my father's household who were in the land of Canaan have come to me. **<sup>32</sup>** And the men are shepherds, for they have been keepers of livestock; and they have brought their flocks and their herds and all that they have.' **<sup>33</sup>** And it shall be, when Pharaoh calls you and says, 'What is your occupation?' **<sup>34</sup>** that you shall say, 'Your servants have been keepers of livestock from our youth even until now, both we and our fathers,' so that you may dwell in the land of Goshen, for every shepherd is detestable to the Egyptians." 

## Chapter 47

**<sup>1</sup>** Joseph went in and informed Pharaoh, saying, "My father and my brothers have come from the land of Canaan, with their flocks and herds and all that they possess, and they are now in the land of Goshen." **<sup>2</sup>** He took five men from among his brothers and presented them before Pharaoh. **<sup>3</sup>** Pharaoh said to his brothers, "What is your occupation?" They said to Pharaoh, "Your servants, both we and our fathers, are shepherds." **<sup>4</sup>** They said further to Pharaoh, "We have come to reside temporarily in the land, for there is no pasture for your servants' flocks, for the famine is severe in the land of Canaan. Now please let your servants settle in the land of Goshen." **<sup>5</sup>** Then Pharaoh said to Joseph, "Your father and your brothers have come to you. **<sup>6</sup>** The land of Egypt is before you. Settle your father and your brothers in the best of the land. Let them live in the land of Goshen, and if you know of capable men among them, appoint them as overseers of my livestock."

**<sup>7</sup>** Then Joseph brought in Jacob his father and presented him before Pharaoh, and Jacob blessed Pharaoh. **<sup>8</sup>** Pharaoh said to Jacob, "How many are the years of your life?" **<sup>9</sup>** Jacob said to Pharaoh, "The years of my pilgrimage are one hundred thirty. Few and difficult have been the years of my life, and they have not reached the length of the years of my fathers during their time of sojourning." **<sup>10</sup>** And Jacob blessed Pharaoh and went out from his presence.

**<sup>11</sup>** So Joseph settled his father and his brothers and gave them a possession in the land of Egypt, in the best part of the land, in the land of Rameses, as Pharaoh had commanded. **<sup>12</sup>** Joseph provided food for his father and his brothers and for all his father's household, according to the number of their dependents.

**<sup>13</sup>** Now there was no food in all the land, for the famine was very severe, so that the land of Egypt and the land of Canaan languished because of the famine. **<sup>14</sup>** Joseph collected all the money that was found in the land of Egypt and in the land of Canaan in exchange for the grain that they bought, and Joseph brought the money into Pharaoh's house. **<sup>15</sup>** When the money was gone from the land of Egypt and from the land of Canaan, all the Egyptians came to Joseph and said, "Give us food! Why should we die in your presence? For our money is gone." **<sup>16</sup>** Then Joseph said, "Bring your livestock, and I will give you food in exchange for your livestock, if your money is gone." **<sup>17</sup>** So they brought their livestock to Joseph, and Joseph gave them food in exchange for the horses and the flocks and the herds and the donkeys; and he fed them with food that year in exchange for all their livestock.

**<sup>18</sup>** When that year ended, they came to him the next year and said to him, "We cannot hide from my lord that our money is gone, and the livestock is now my lord's. There is nothing left in the sight of my lord but our bodies and our land. **<sup>19</sup>** Why should we die before your eyes, both we and our land? Buy us and our land for food, and we and our land will become servants to Pharaoh. Provide seed that we may live and not die, and that the land not become desolate."

**<sup>20</sup>** So Joseph bought all the land of Egypt for Pharaoh, for every Egyptian sold his field, because the famine was severe upon them. Thus the land became Pharaoh's. **<sup>21</sup>** As for the people, he relocated them to the cities from one end of Egypt's border to the other. **<sup>22</sup>** Only the land of the priests he did not buy, for the priests had an allotment from Pharaoh, and they lived off that allotment which Pharaoh gave them. Therefore, they did not sell their land.

**<sup>23</sup>** Then Joseph said to the people, "Behold, today I have bought you and your land for Pharaoh. Here is seed for you, and you shall sow the land. **<sup>24</sup>** At harvest you shall give a fifth to Pharaoh, and four parts shall be yours for seed for the field and for your food and for those of your households and for your little ones." **<sup>25</sup>** And they said, "You have saved our lives. May we find favor in the sight of my lord, and we will be servants to Pharaoh." **<sup>26</sup>** So Joseph made it a statute concerning the land of Egypt to this day, that Pharaoh should have the fifth. Only the land of the priests did not become Pharaoh's.

**<sup>27</sup>** Thus Israel lived in the land of Egypt, in the land of Goshen, and they acquired property in it and were fruitful and multiplied greatly. **<sup>28</sup>** Jacob lived in the land of Egypt seventeen years, so the days of Jacob, the years of his life, were one hundred forty-seven. **<sup>29</sup>** When the time of Israel's death drew near, he called his son Joseph and said to him, "If I have found favor in your eyes, place your hand under my thigh and deal with me in kindness and faithfulness. Do not bury me in Egypt, **<sup>30</sup>** but let me lie with my fathers. Carry me out of Egypt and bury me in their burial place." And he said, "I will do as you have said." **<sup>31</sup>** Then he said, "Swear to me." So he swore to him. And Israel bowed himself at the head of the bed. 

## Chapter 48

**<sup>1</sup>** After these things, Joseph was told, "Behold, your father is ill." So he took his two sons, Manasseh and Ephraim, with him. **<sup>2</sup>** And it was told to Jacob, "Behold, your son Joseph has come to you." Then Israel summoned his strength and sat up in bed.

**<sup>3</sup>** And Jacob said to Joseph, "God Almighty appeared to me at Luz in the land of Canaan and blessed me, **<sup>4</sup>** and said to me, 'Behold, I will make you fruitful and multiply you, and I will make you a company of nations, and I will give this land to your descendants after you as an everlasting possession.' **<sup>5</sup>** And now your two sons, who were born to you in the land of Egypt before I came to you in Egypt, are mine; Ephraim and Manasseh shall be mine, as Reuben and Simeon are. **<sup>6</sup>** But your offspring, whom you beget after them, shall be yours. They shall be called by the name of their brothers in their inheritance.

**<sup>7</sup>** Now as for me, when I came from Paddan, Rachel died to my sorrow in the land of Canaan on the way, when there was still some distance to go to Ephrath. And I buried her there on the way to Ephrath—that is, Bethlehem."

**<sup>8</sup>** When Israel saw Joseph's sons, he said, "Who are these?" **<sup>9</sup>** And Joseph said to his father, "They are my sons, whom God has given me here." And he said, "Bring them to me, please, so that I may bless them."

**<sup>10</sup>** Now the eyes of Israel were dim with age so that he could not see well. So Joseph brought them near to him, and he kissed them and embraced them. **<sup>11</sup>** And Israel said to Joseph, "I did not expect to see your face, and yet, God has let me see your children also." **<sup>12</sup>** Then Joseph brought them out from his knees, and he bowed himself with his face to the ground.

**<sup>13</sup>** And Joseph took them both, Ephraim in his right hand toward Israel's left hand, and Manasseh in his left hand toward Israel's right hand, and brought them near to him. **<sup>14</sup>** But Israel stretched out his right hand and laid it on the head of Ephraim, who was the younger, and his left hand on the head of Manasseh—he crossed his hands, for Manasseh was the firstborn. **<sup>15</sup>** And he blessed Joseph and said,

"The God before whom my fathers Abraham and Isaac walked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the God who has been my shepherd all my life to this day,**<sup>16</sup>** the angel who has redeemed me from all evil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;may he bless the boys;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may my name be named in them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the name of my fathers Abraham and Isaac,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and may they grow into a multitude in the midst of the earth."

**<sup>17</sup>** When Joseph saw that his father laid his right hand on the head of Ephraim, it displeased him, and he took hold of his father's hand to move it from Ephraim's head to Manasseh's head. **<sup>18</sup>** And Joseph said to his father, "Not so, my father, for this one is the firstborn; put your right hand on his head." **<sup>19</sup>** But his father refused and said, "I know, my son, I know. He too shall become a people, and he too shall be great. Nevertheless, his younger brother shall be greater than he, and his descendants shall become a multitude of nations." **<sup>20</sup>** So he blessed them that day, saying,

"By you Israel will pronounce blessing, saying,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;'May God make you like Ephraim and like Manasseh.'"

In this way, he set Ephraim before Manasseh.

**<sup>21</sup>** Then Israel said to Joseph, "Behold, I am about to die, but God will be with you and will bring you back to the land of your fathers. **<sup>22</sup>** And I give to you one portion more than your brothers, which I took from the hand of the Amorite with my sword and with my bow." 

## Chapter 49

**<sup>1</sup>** Then Jacob called his sons and said, "Gather yourselves together, that I may tell you what shall happen to you in days to come.

**<sup>2</sup>** Assemble and listen, O sons of Jacob, listen to Israel your father.

**<sup>3</sup>** Reuben, you are my firstborn, my might and the first of my strength, preeminent in dignity and preeminent in power. **<sup>4</sup>** Unstable as water, you shall not excel, because you went up to your father's bed; then you defiled it by going up to my couch.

**<sup>5</sup>** Simeon and Levi are brothers; instruments of violence are their swords. **<sup>6</sup>** Let my soul not enter their council; let not my glory be joined with their assembly. For in their anger they slew a man, and in their willfulness they hamstrung an ox. **<sup>7</sup>** Cursed be their anger, for it is fierce, and their wrath, for it is cruel. I will divide them in Jacob and scatter them in Israel.

**<sup>8</sup>** Judah, your brothers shall praise you; your hand shall be on the neck of your enemies; your father's sons shall bow down before you. **<sup>9</sup>** Judah is a lion's cub; from the prey, my son, you have gone up. He stooped down, he crouched like a lion and like a lioness—who dares rouse him? **<sup>10</sup>** The scepter shall not depart from Judah, nor the ruler's staff from between his feet, until he comes to whom it belongs, and to him shall be the obedience of the peoples. **<sup>11</sup>** Binding his foal to the vine and his donkey's colt to the choice vine, he washes his garments in wine and his robe in the blood of grapes. **<sup>12</sup>** His eyes are darker than wine, and his teeth whiter than milk.

**<sup>13</sup>** Zebulun shall dwell at the seashore, and he shall be a haven for ships, and his flank shall be toward Sidon.

**<sup>14</sup>** Issachar is a strong-boned donkey, lying down between the sheepfolds. **<sup>15</sup>** He saw that a resting place was good, and that the land was pleasant, so he bowed his shoulder to bear a load and became a servant at forced labor.

**<sup>16</sup>** Dan shall judge his people as one of the tribes of Israel. **<sup>17</sup>** Dan shall be a serpent by the road, a viper on the path, that bites the horse's heels so that its rider falls backward. **<sup>18</sup>** I wait for your salvation, O LORD.

**<sup>19</sup>** Gad, raiders shall raid him, but he shall raid at their heels.

**<sup>20</sup>** Asher's food shall be rich, and he shall yield royal delicacies.

**<sup>21</sup>** Naphtali is a doe let loose, who gives beautiful words.

**<sup>22</sup>** Joseph is a fruitful bough, a fruitful bough by a spring; his branches run over the wall. **<sup>23</sup>** The archers bitterly attacked him, shot at him, and harassed him severely, **<sup>24</sup>** yet his bow remained steady, and his arms were agile by the hands of the Mighty One of Jacob—from there is the Shepherd, the Stone of Israel— **<sup>25</sup>** by the God of your father who will help you, and by the Almighty who will bless you with blessings of heaven above, blessings of the deep that lies beneath, blessings of the breasts and of the womb. **<sup>26</sup>** The blessings of your father are greater than the blessings of the ancient mountains, than the bounty of the everlasting hills. May they be on the head of Joseph, and on the crown of the head of him who was set apart from his brothers.

**<sup>27</sup>** Benjamin is a ravenous wolf; in the morning he devours the prey, and in the evening he divides the spoil.

**<sup>28</sup>** All these are the twelve tribes of Israel, and this is what their father said to them as he blessed them. He blessed each one according to his own blessing.

**<sup>29</sup>** Then he commanded them and said to them, "I am about to be gathered to my people. Bury me with my fathers in the cave that is in the field of Ephron the Hittite, **<sup>30</sup>** in the cave that is in the field of Machpelah, which is before Mamre, in the land of Canaan, the field that Abraham bought from Ephron the Hittite as a burial site. **<sup>31</sup>** There they buried Abraham and Sarah his wife; there they buried Isaac and Rebekah his wife; and there I buried Leah— **<sup>32</sup>** the field and the cave that is in it were purchased from the sons of Heth."

**<sup>33</sup>** When Jacob finished commanding his sons, he drew his feet up into the bed, breathed his last, and was gathered to his people. 

## Chapter 50

**<sup>1</sup>** Then Joseph fell upon his father's face and wept over him and kissed him. **<sup>2</sup>** Joseph commanded his servants, the physicians, to embalm his father. So the physicians embalmed Israel. **<sup>3</sup>** Forty days were required for him, for that is the time required for embalming. And the Egyptians mourned for him seventy days.

**<sup>4</sup>** When the days of mourning for him had passed, Joseph spoke to Pharaoh's household, saying, "If I have found favor in your eyes, please speak in the ears of Pharaoh, saying, **<sup>5</sup>** 'My father made me swear, saying, "Behold, I am about to die. In my grave which I dug for myself in the land of Canaan, there shall you bury me." Now therefore, let me go up and bury my father; then I will return.'" **<sup>6</sup>** Pharaoh said, "Go up and bury your father, as he made you swear."

**<sup>7</sup>** So Joseph went up to bury his father. All of Pharaoh's servants of Pharaoh, the elders of his house, and all the elders of the land of Egypt went with him, **<sup>8</sup>** as did as all the house of Joseph, his brothers, and his father's household. Only their little ones, their flocks, and their herds were left in the land of Goshen. **<sup>9</sup>** Both chariots and horsemen went up with him in a very great company.

**<sup>10</sup>** When they came to the threshing floor of Atad, which is beyond the Jordan, they lamented there with a great and very bitter mourning. He held a mourning ceremony for his father lasting seven days. **<sup>11</sup>** When the inhabitants of the land, the Canaanites, saw the mourning at the threshing floor of Atad, they said, "This is a grievous mourning for the Egyptians." Therefore its name was called Abel-mizraim; it is beyond the Jordan river. **<sup>12</sup>** Thus his sons did for him as he had commanded them, **<sup>13</sup>** for his sons carried him to the land of Canaan and buried him in the cave of the field of Machpelah, which Abraham bought with the field for a possession as a burial site from Ephron the Hittite, before Mamre.

**<sup>14</sup>** After he had buried his father, Joseph returned to Egypt, he and his brothers and all who had gone up with him to bury his father.

**<sup>15</sup>** When Joseph's brothers saw that their father was dead, they said, "What if Joseph bears a grudge against us and repays us in full for all the evil that we did to him?" **<sup>16</sup>** So they sent word to Joseph, saying, "Your father gave this command before he died: **<sup>17</sup>** 'Say to Joseph, Please forgive the transgression of your brothers and their sin, for they did evil to you.' Now please forgive the transgression of the servants of the God of your father." Joseph wept when they spoke to him. **<sup>18</sup>** Then his brothers also came and fell down before him and said, "Behold, we are your servants." **<sup>19</sup>** But Joseph said to them, "Do not fear, for am I in the place of God? **<sup>20</sup>** As for you, you intended evil against me, but God intended it for good, to bring about what is now being done—the preservation of many lives. **<sup>21</sup>** Now therefore, do not fear. I will provide for you and your little ones." So he comforted them and spoke kindly to them.

**<sup>22</sup>** Joseph remained in Egypt—he and his father's household—and Joseph lived one hundred and ten years. **<sup>23</sup>** Joseph saw the third generation of Ephraim's sons; the sons of Machir, the son of Manasseh, were also born on Joseph's knees.

**<sup>24</sup>** Joseph said to his brothers, "I am about to die. But God will surely visit you and bring you up out of this land to the land that He swore to Abraham, to Isaac, and to Jacob." **<sup>25</sup>** Then Joseph made the sons of Israel swear, saying, "God will surely visit you, and you shall carry up my bones from here." **<sup>26</sup>** So Joseph died at the age of one hundred and ten years, and they embalmed him and placed him in a coffin in Egypt. 