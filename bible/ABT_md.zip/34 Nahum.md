# Nahum

## Chapter 1

**<sup>1</sup>** The oracle concerning Nineveh. The book of the vision of Nahum of Elkosh.

**<sup>2</sup>** The LORD is a jealous and avenging God; the LORD takes vengeance and is full of wrath. The LORD takes vengeance on his adversaries and reserves wrath for his enemies. **<sup>3</sup>** The LORD is slow to anger and great in power, but he will by no means leave the guilty unpunished. His way is in whirlwind and storm, and the clouds are the dust of his feet.

**<sup>4</sup>** He rebukes the sea and makes it dry, and he dries up all the rivers; Bashan and Carmel wither, and the bloom of Lebanon fades. **<sup>5</sup>** The mountains quake before him, and the hills melt; the earth heaves before him, the world and all who dwell in it. **<sup>6</sup>** Who can stand before his indignation? Who can endure the heat of his anger? His wrath is poured out like fire, and the rocks are broken apart by him.

**<sup>7</sup>** The LORD is good, a stronghold in the day of distress; he knows those who take refuge in him. **<sup>8</sup>** But with an overflowing flood he will make a complete end of its place, and will pursue his enemies into darkness.

**<sup>9</sup>** What do you plot against the LORD? He will make a complete end of it; trouble will not rise up a second time. **<sup>10</sup>** For they are entangled like thorns and drunk like drunkards; they are consumed like stubble fully dry. **<sup>11</sup>** From you came one who plotted evil against the LORD, a worthless counselor.

**<sup>12</sup>** Thus says the LORD, “Though they are at full strength and many in number, they will be cut down and pass away. Though I have afflicted you, I will afflict you no more. **<sup>13</sup>** And now I will break his yoke from off you, and will tear away your bonds.”

**<sup>14</sup>** The LORD has commanded concerning you: “No more of your name shall be sown; from the house of your gods I will cut off the carved image and the metal image. I will make your grave, for you are vile.”

**<sup>15</sup>** Look on the mountains<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the feet of him who brings good news,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who announces peace.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Keep your feasts, O Judah,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;fulfill your vows,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for the wicked man will never again pass through you;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he is entirely cut off.<br/>


## Chapter 2

**<sup>1</sup>** A scatterer has come up against you. Guard the rampart; watch the road; brace your loins; strengthen your power mightily. **<sup>2</sup>** For the LORD is restoring the majesty of Jacob as the majesty of Israel, though ravagers have ravaged them and ruined their vine branches.

**<sup>3</sup>** The shields of his mighty men are red; his warriors are clothed in scarlet. The chariots flash like fire on the day of his preparation, and the spears are brandished. **<sup>4</sup>** The chariots race madly through the streets; they rush to and fro through the squares; their appearance is like torches, they dart like lightning.

**<sup>5</sup>** He calls his officers; they stumble as they march. They hasten to the wall, and the siege tower is set up. **<sup>6</sup>** The gates of the rivers are opened, and the palace melts away. **<sup>7</sup>** She is stripped, she is carried off—her servant girls moan like the sound of doves, beating their breasts. **<sup>8</sup>** Nineveh is like a pool whose waters run away. “Halt! Halt!” they cry, but none turns back.

**<sup>9</sup>** Plunder the silver! Plunder the gold! There is no end to the treasure, wealth beyond all measure. **<sup>10</sup>** Desolation, emptiness, and waste! Hearts melt and knees give way; anguish is in all loins; all faces grow pale.

**<sup>11</sup>** Where is the den of lions, the feeding place of the young lions, where the lion and lioness went, where his cubs were, with none to make them afraid? **<sup>12</sup>** The lion tore enough for his cubs and strangled prey for his lionesses; he filled his caves with prey and his dens with torn flesh.

**<sup>13</sup>** “I am against you,” declares the LORD of hosts, “and I will burn your chariots in smoke, and the sword shall devour your young lions. I will cut off your prey from the earth, and the voice of your messengers shall no longer be heard.” 

## Chapter 3

**<sup>1</sup>** Woe to the city of blood! She is all full of lies and plunder; the prey never departs. **<sup>2</sup>** The crack of the whip, and the rumble of the wheel, galloping horse and bounding chariot! **<sup>3</sup>** Horsemen charging, flashing sword and glittering spear, hosts of slain, heaps of corpses, dead bodies without end—they stumble over the dead.

**<sup>4</sup>** Because of the many harlotries of the harlot, the charming and graceful mistress of sorceries, who sells nations through her harlotries, and clans through her sorceries, **<sup>5</sup>** “I am against you,” declares the LORD of hosts. “I will lift up your skirts over your face; I will show the nations your nakedness and the kingdoms your shame. **<sup>6</sup>** I will throw filth on you and treat you with contempt, and make you a spectacle. **<sup>7</sup>** And all who see you will shrink from you and say, ‘Nineveh is devastated! Who will grieve for her?’ Where shall I seek comforters for you?”

**<sup>8</sup>** Are you better than Thebes, that sat by the Nile, with water around her, whose rampart was the sea, water her wall? **<sup>9</sup>** Cush was her strength, Egypt too, without limit; Put and the Libyans were her helpers. **<sup>10</sup>** Yet she went into exile; she went into captivity. Her infants were dashed in pieces at the head of every street; they cast lots for her honored men, and all her great men were bound in chains.

**<sup>11</sup>** You also will become drunk; you will go into hiding; you will seek refuge from the enemy. **<sup>12</sup>** All your fortresses are like fig trees with first-ripe figs—if shaken, they fall into the mouth of the eater. **<sup>13</sup>** Behold, your people are women in your midst; the gates of your land are wide open to your enemies; fire has devoured your bars.

**<sup>14</sup>** Draw water for the siege; strengthen your fortresses; go into the clay; tread the mortar; take hold of the brick mold! **<sup>15</sup>** There fire will consume you; the sword will cut you off. It will devour you like the locust. Multiply yourselves like the locust; multiply like the grasshopper! **<sup>16</sup>** You increased your merchants more than the stars of the heavens. The locust strips and flies away. **<sup>17</sup>** Your guards are like locusts, your scribes like swarms of locusts settling on the fences in a day of cold—when the sun rises, they fly away, and no one knows where they are.

**<sup>18</sup>** Your shepherds are asleep, O king of Assyria; your nobles slumber. Your people are scattered on the mountains, and there is no one to gather them. **<sup>19</sup>** There is no healing for your wound; your injury is fatal. All who hear the news about you clap their hands over you. For upon whom has your evil not passed continually? 