# The Holy Bible

[Projects Page](../../index.md) | [ABT Project Page](../index.md)

## ABT Version (Allyn's Bible Translation)

### The Old Testament

| | | | |
|:---|:---|:---|:---|
|1. [Genesis](01%20Genesis.md)|11. [1 Kings](11%201%20Kings.md)|21. [Ecclesiastes](21%20Ecclesiastes.md)|31. [Obadiah](31%20Obadiah.md)|
|2. [Exodus](02%20Exodus.md)|12. [2 Kings](12%202%20Kings.md)|22. [Song of Solomon](22%20Song%20of%20Solomon.md)|32. [Jonah](32%20Jonah.md)|
|3. [Leviticus](03%20Leviticus.md)|13. [1 Chronicles](13%201%20Chronicles.md)|23. [Isaiah](23%20Isaiah.md)|33. [Micah](33%20Micah.md)|
|4. [Numbers](04%20Numbers.md)|14. [2 Chronicles](14%202%20Chronicles.md)|24. [Jeremiah](24%20Jeremiah.md)|34. [Nahum](34%20Nahum.md)|
|5. [Deuteronomy](05%20Deuteronomy.md)|15. [Ezra](15%20Ezra.md)|25. [Lamentations](25%20Lamentations.md)|35. [Habakkuk](35%20Habakkuk.md)|
|6. [Joshua](06%20Joshua.md)|16. [Nehemiah](16%20Nehemiah.md)|26. [Ezekiel](26%20Ezekiel.md)|36. [Zephaniah](36%20Zephaniah.md)|
|7. [Judges](07%20Judges.md)|17. [Esther](17%20Esther.md)|27. [Daniel](27%20Daniel.md)|37. [Haggai](37%20Haggai.md)|
|8. [Ruth](08%20Ruth.md)|18. [Job](18%20Job.md)|28. [Hosea](28%20Hosea.md)|38. [Zechariah](38%20Zechariah.md)|
|9. [1 Samuel](09%201%20Samuel.md)|19. [Psalms](19%20Psalms.md)|29. [Joel](29%20Joel.md)|39. [Malachi](39%20Malachi.md)|
|10. [2 Samuel](10%202%20Samuel.md)|20. [Proverbs](20%20Proverbs.md)|30. [Amos](30%20Amos.md)| |

### The New Testament

| | | | |
|:---|:---|:---|:---|
|40. [Matthew](40%20Matthew.md)|47. [2 Corinthians](47%202%20Corinthians.md)|54. [1 Timothy](54%201%20Timothy.md)|61. [2 Peter](61%202%20Peter.md)|
|41. [Mark](41%20Mark.md)|48. [Galatians](48%20Galatians.md)|55. [2 Timothy](55%202%20Timothy.md)|62. [1 John](62%201%20John.md)|
|42. [Luke](42%20Luke.md)|49. [Ephesians](49%20Ephesians.md)|56. [Titus](56%20Titus.md)|63. [2 John](63%202%20John.md)|
|43. [John](43%20John.md)|50. [Philippians](50%20Philippians.md)|57. [Philemon](57%20Philemon.md)|64. [3 John](64%203%20John.md)|
|44. [Acts of the Apostles](44%20Acts.md)|51. [Colossians](51%20Colossians.md)|58. [Hebrews](58%20Hebrews.md)|65. [Jude](65%20Jude.md)|
|45. [Romans](45%20Romans.md)|52. [1 Thessalonians](52%201%20Thessalonians.md)|59. [James](59%20James.md)|66. [Revelation](66%20Revelation.md)|
|46. [1 Corinthians](46%201%20Corinthians.md)|53. [2 Thessalonians](53%202%20Thessalonians.md)|60. [1 Peter](60%201%20Peter.md)| |
