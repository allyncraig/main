# Malachi

## Chapter 1

**<sup>1</sup>** The oracle of the word of the LORD to Israel by the hand of Malachi. **<sup>2</sup>** “I have loved you,” says the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “How have You loved us?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Was not Esau Jacob’s brother?” declares the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Yet I loved Jacob,<br/>
**<sup>3</sup>** but Esau I hated.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I made his mountains a desolation<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and gave his inheritance to the jackals of the wilderness.”<br/>
**<sup>4</sup>** If Edom says, “We are shattered,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but we will rebuild the ruins,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;thus says the LORD of hosts:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“They may build, but I will tear down,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will be called ‘The Wicked Territory,’<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and ‘The people with whom the LORD is angry forever.’”<br/>
**<sup>5</sup>** Your eyes shall see this, and you shall say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“Great is the LORD beyond the border of Israel!”

**<sup>6</sup>** A son honors his father,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a servant, his master.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;If then I am a father, where is My honor?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And if I am a master, where is My fear?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;O priests who despise My name.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “How have we despised Your name?”<br/>
**<sup>7</sup>** You offer defiled food on My altar.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “How have we defiled You?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;By saying that the table of the LORD is to be despised.<br/>
**<sup>8</sup>** When you present the blind for sacrifice, is it not evil?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And when you present the lame and the sick, is it not evil?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Bring it now to your governor—will he be pleased with you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or show you favor? says the LORD of hosts.

**<sup>9</sup>** And now, entreat the favor of God, that He may be gracious to us.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;With such a gift from your hand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;will He show favor to any of you? says the LORD of hosts.

**<sup>10</sup>** Oh that there were one among you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;who would shut the doors,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that you might not kindle fire on My altar in vain!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I have no pleasure in you, says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will not accept an offering from your hand.

**<sup>11</sup>** For from the rising of the sun to its setting,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;My name will be great among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and in every place incense is offered to My name,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a pure offering.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For My name will be great among the nations,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.

**<sup>12</sup>** But you profane it when you say,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“The table of the LORD is defiled,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and its fruit—that is, its food—is to be despised.”

**<sup>13</sup>** But you say, “Look, what a weariness this is,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you sniff at it, says the LORD of hosts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You bring what has been taken by violence,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or is lame or sick—<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and this you bring as an offering!<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Shall I accept this from your hand? says the LORD.<br/>
**<sup>14</sup>** Cursed be the deceiver who has a male in his flock,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and vows it, yet sacrifices to the LORD what is blemished.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For I am a great King, says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and My name will be feared among the nations.<br/>


## Chapter 2

**<sup>1</sup>** And now, O priests, this command is for you. **<sup>2</sup>** If you will not listen,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if you will not put it in your heart to honor My name,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;then I will send a curse upon you.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will even curse your blessings;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;indeed, I have already cursed them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because you do not lay it to heart.<br/>
**<sup>3</sup>** See, I will rebuke your offspring,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and spread dung on your faces,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the dung of your festival offerings,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and you shall be taken away with it.

**<sup>4</sup>** So you shall know that I have sent this command to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that My covenant with Levi may stand,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>5</sup>** My covenant with him was one of life and peace,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I gave them to him for fear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he feared Me;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;he stood in awe of My name.<br/>
**<sup>6</sup>** True instruction was in his mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and no injustice was found on his lips.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;He walked with Me in peace and uprightness,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he turned many from iniquity.<br/>
**<sup>7</sup>** For the lips of a priest should guard knowledge,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and men should seek instruction from his mouth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for he is the messenger of the LORD of hosts.

**<sup>8</sup>** But you have turned aside from the way;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;you have caused many to stumble by your instruction.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You have corrupted the covenant of Levi,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>9</sup>** So I make you despised and low<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before all the people,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;inasmuch as you do not keep My ways<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but show partiality in your instruction.<br/>
**<sup>10</sup>** Have we not all one father?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Has not one God created us?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Why then are we faithless to one another,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;profaning the covenant of our fathers?<br/>
**<sup>11</sup>** Judah has been faithless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and abomination has been committed in Israel and in Jerusalem.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For Judah has profaned the sanctuary of the LORD, which He loves,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and has married the daughter of a foreign god.<br/>
**<sup>12</sup>** May the LORD cut off from the tents of Jacob<br/>
&nbsp;&nbsp;&nbsp;&nbsp;any man who does this,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and brings an offering to the LORD of hosts.

**<sup>13</sup>** And this second thing you do:<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You cover the altar of the LORD with tears,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with weeping and groaning<br/>
&nbsp;&nbsp;&nbsp;&nbsp;because He no longer regards the offering<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or accepts it with favor from your hand.<br/>
**<sup>14</sup>** But you say, “Why doesn't He?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Because the LORD was witness between you and the wife of your youth,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;to whom you have been faithless,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;though she is your companion and your wife by covenant.<br/>
**<sup>15</sup>** Did He not make them one,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;with a portion of the Spirit in their union?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And what was the one God seeking?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Godly offspring.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So guard yourselves in your spirit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and let none of you be faithless to the wife of your youth.<br/>
**<sup>16</sup>** “For I hate divorce,” says the LORD, the God of Israel,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“and him who covers his garment with violence,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;So guard yourselves in your spirit,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and do not be faithless.

**<sup>17</sup>** You have wearied the LORD with your words.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “How have we wearied Him?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;By saying, “Everyone who does evil is good in the sight of the LORD,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He delights in them,”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or by asking, “Where is the God of justice?”<br/>


## Chapter 3

**<sup>1</sup>** Behold, I am sending My messenger,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and he will prepare the way before Me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And the Lord whom you seek will suddenly come to His temple;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the messenger of the covenant in whom you delight,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;behold, He is coming,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>2</sup>** But who can endure the day of His coming,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and who can stand when He appears?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;For He is like a refiner’s fire<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and like fullers’ soap.<br/>
**<sup>3</sup>** He will sit as a refiner and purifier of silver,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and He will purify the sons of Levi<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and refine them like gold and silver,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and they will bring offerings in righteousness to the LORD.<br/>
**<sup>4</sup>** Then the offering of Judah and Jerusalem will be pleasing to the LORD<br/>
&nbsp;&nbsp;&nbsp;&nbsp;as in the days of old and as in former years.<br/>
**<sup>5</sup>** Then I will draw near to you for judgment.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;I will be a swift witness against the sorcerers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against the adulterers,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against those who swear falsely,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against those who oppress the hired worker in his wages,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the widow and the orphan,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;against those who turn aside the foreigner and do not fear Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>6</sup>** For I, the LORD, do not change;<br/>
&nbsp;&nbsp;&nbsp;&nbsp;therefore you, O sons of Jacob, are not consumed.

**<sup>7</sup>** From the days of your fathers you have turned aside from My statutes<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and have not kept them.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Return to Me, and I will return to you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “How shall we return?”<br/>
**<sup>8</sup>** Will a man rob God?<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Yet you are robbing Me.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “How have we robbed You?”<br/>
&nbsp;&nbsp;&nbsp;&nbsp;In tithes and offerings.<br/>
**<sup>9</sup>** You are cursed with a curse,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you are robbing Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the whole nation of you.<br/>
**<sup>10</sup>** Bring the full tithe into the storehouse,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;that there may be food in My house.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;And test Me now in this,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;if I will not open the windows of heaven for you<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and pour down for you a blessing<br/>
&nbsp;&nbsp;&nbsp;&nbsp;until there is no more need.<br/>
**<sup>11</sup>** I will rebuke the devourer for you,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that it will not destroy the fruits of your soil,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and your vine in the field shall not fail to bear,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.<br/>
**<sup>12</sup>** Then all the nations will call you blessed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for you will be a land of delight,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.

**<sup>13</sup>** Your words have been harsh against Me,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;But you say, “What have we spoken against You?”<br/>
**<sup>14</sup>** You have said, “It is vain to serve God.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;What is the profit of our keeping His charge<br/>
&nbsp;&nbsp;&nbsp;&nbsp;or of walking as mourners before the LORD of hosts?<br/>
**<sup>15</sup>** And now we call the arrogant blessed.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Evildoers not only prosper<br/>
&nbsp;&nbsp;&nbsp;&nbsp;but they put God to the test and they escape.”<br/>
**<sup>16</sup>** Then those who feared the LORD spoke with one another.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The LORD paid attention and heard them,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and a book of remembrance was written before Him<br/>
&nbsp;&nbsp;&nbsp;&nbsp;of those who feared the LORD and esteemed His name.<br/>
**<sup>17</sup>** “They shall be Mine,” says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;“in the day when I make up My treasured possession,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and I will spare them as a man spares his son who serves him.<br/>
**<sup>18</sup>** Then once more you shall see the distinction<br/>
&nbsp;&nbsp;&nbsp;&nbsp;between the righteous and the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;between one who serves God<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and one who does not serve Him.”<br/>


## Chapter 4

**<sup>1</sup>** For behold, the day is coming, burning like an oven,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;when all the arrogant and all evildoers will be stubble.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;The day that is coming shall set them ablaze,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;so that it will leave them neither root nor branch.<br/>
**<sup>2</sup>** But for you who fear My name,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the sun of righteousness shall rise with healing in its wings.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;You shall go out leaping like calves from the stall.<br/>
**<sup>3</sup>** And you shall tread down the wicked,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for they shall be ashes under the soles of your feet<br/>
&nbsp;&nbsp;&nbsp;&nbsp;on the day when I act,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;says the LORD of hosts.

**<sup>4</sup>** Remember the law of My servant Moses,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;the statutes and judgments that I commanded him at Horeb<br/>
&nbsp;&nbsp;&nbsp;&nbsp;for all Israel.<br/>
**<sup>5</sup>** Behold, I am sending you Elijah the prophet<br/>
&nbsp;&nbsp;&nbsp;&nbsp;before the great and awesome day of the LORD comes.<br/>
**<sup>6</sup>** And he will turn the hearts of the fathers to the sons,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;and the hearts of the sons to their fathers.<br/>
&nbsp;&nbsp;&nbsp;&nbsp;Otherwise I will come and strike the land with a curse.<br/>
